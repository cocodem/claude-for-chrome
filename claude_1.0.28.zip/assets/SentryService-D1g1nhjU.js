import './request.js'
const e = {
        production: {
            STATSIG_CLIENT_API_KEY:
                "client-CyitfCoKlr6QZ2BXVfDZ3aDIE2fvWh4DTd4CIegPYQ8",
            SEGMENT_WRITE_KEY: "H7hVDRIBUrlBySLqJ15oAivgqhomdAKT",
        },
        development: {
            STATSIG_CLIENT_API_KEY:
                "client-FFBic9L5QkZYsnRDrIAvTimKS998hznw31H6KPBciH8",
            SEGMENT_WRITE_KEY: "hNex10EGp3coubOXQI1BIElYaZcA1o0u",
        },
    },
    t = "fcoeoabgfenejglbffodgkkbkcdhcgfn",
    n = {
        AUTHORIZE_URL: "https://claude.ai/oauth/authorize",
        TOKEN_URL: "https://console.anthropic.com/v1/oauth/token",
        SCOPES_STR: "user:profile user:inference",
        CLIENT_ID: "54511e87-7abf-4923-9d84-d6f24532e871",
        REDIRECT_URI: `chrome-extension://${"dihbgbndebgnbjfmelmegjepbnkhlgni"}/oauth_callback.html`,
    },
    r = {
        development: n,
        production: {
            ...n,
            CLIENT_ID: "dae2cad8-15c5-43d2-9046-fcaecc135fa4",
            REDIRECT_URI: `chrome-extension://${t}/oauth_callback.html`,
        },
    },
    s = () => {
        const t = "production",
            n = e[t],
            s = r[t];
        return {
            environment: t,
            apiBaseUrl: "https://api.anthropic.com",
            statsigClientApiKey: n.STATSIG_CLIENT_API_KEY,
            segmentWriteKey: n.SEGMENT_WRITE_KEY,
            oauth: s,
        };
    };
var o,
    i,
    a = {},
    c = {},
    u = {},
    l = {};
function d() {
    return (
        o ||
            ((o = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Log = e.LogLevel = void 0);
                e.LogLevel = { None: 0, Error: 1, Warn: 2, Info: 3, Debug: 4 };
                class t {
                    static info(...n) {
                        t.level, e.LogLevel.Info;
                    }
                    static debug(...n) {
                        t.level, e.LogLevel.Debug;
                    }
                    static warn(...n) {
                        t.level, e.LogLevel.Warn;
                    }
                    static error(...n) {
                        t.level, e.LogLevel.Error;
                    }
                }
                (e.Log = t), (t.level = e.LogLevel.Warn);
            })(l)),
        l
    );
}
function f() {
    return (
        i ||
            ((i = 1),
            (function (e) {
                var t, n, r;
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._getInstance =
                        e._getStatsigGlobalFlag =
                        e._getStatsigGlobal =
                            void 0);
                const s = d();
                e._getStatsigGlobal = () => {
                    try {
                        return "undefined" != typeof __STATSIG__
                            ? __STATSIG__
                            : u;
                    } catch (e) {
                        return u;
                    }
                };
                e._getStatsigGlobalFlag = (t) => (0, e._getStatsigGlobal)()[t];
                e._getInstance = (t) => {
                    const n = (0, e._getStatsigGlobal)();
                    return t
                        ? n.instances && n.instances[t]
                        : (n.instances &&
                              Object.keys(n.instances).length > 1 &&
                              s.Log.warn(
                                  "Call made to Statsig global instance without an SDK key but there is more than one client instance. If you are using mulitple clients, please specify the SDK key."
                              ),
                          n.firstInstance);
                };
                const o = "__STATSIG__",
                    i = "undefined" != typeof window ? window : {},
                    a = "undefined" != typeof globalThis ? globalThis : {},
                    c = "undefined" != typeof globalThis ? globalThis : {},
                    u =
                        null !==
                            (r =
                                null !==
                                    (n =
                                        null !== (t = i[o]) && void 0 !== t
                                            ? t
                                            : a[o]) && void 0 !== n
                                    ? n
                                    : c[o]) && void 0 !== r
                            ? r
                            : { instance: e._getInstance };
                (i[o] = u), (a[o] = u), (c[o] = u);
            })(u)),
        u
    );
}
var h,
    p = {};
function _() {
    return (
        h ||
            ((h = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Diagnostics = void 0);
                const t = new Map(),
                    n = "start",
                    r = "end",
                    s = "statsig::diagnostics";
                function o(e, t, n, r) {
                    return Object.assign(
                        { key: n, action: t, step: r, timestamp: Date.now() },
                        e
                    );
                }
                function i(e, n) {
                    var r;
                    const s = null !== (r = t.get(e)) && void 0 !== r ? r : [];
                    s.push(n), t.set(e, s);
                }
                function a(e, t) {
                    if (t in e) return e[t];
                }
                e.Diagnostics = {
                    _getMarkers: (e) => t.get(e),
                    _markInitOverallStart: (e) => {
                        i(e, o({}, n, "overall"));
                    },
                    _markInitOverallEnd: (e, t, n) => {
                        i(
                            e,
                            o(
                                {
                                    success: t,
                                    error: t
                                        ? void 0
                                        : {
                                              name: "InitializeError",
                                              message: "Failed to initialize",
                                          },
                                    evaluationDetails: n,
                                },
                                r,
                                "overall"
                            )
                        );
                    },
                    _markInitNetworkReqStart: (e, t) => {
                        i(e, o(t, n, "initialize", "network_request"));
                    },
                    _markInitNetworkReqEnd: (e, t) => {
                        i(e, o(t, r, "initialize", "network_request"));
                    },
                    _markInitProcessStart: (e) => {
                        i(e, o({}, n, "initialize", "process"));
                    },
                    _markInitProcessEnd: (e, t) => {
                        i(e, o(t, r, "initialize", "process"));
                    },
                    _clearMarkers: (e) => {
                        t.delete(e);
                    },
                    _formatError(e) {
                        if (e && "object" == typeof e)
                            return {
                                code: a(e, "code"),
                                name: a(e, "name"),
                                message: a(e, "message"),
                            };
                    },
                    _getDiagnosticsData(t, n, r, s) {
                        var o;
                        return {
                            success: !0 === (null == t ? void 0 : t.ok),
                            statusCode: null == t ? void 0 : t.status,
                            sdkRegion:
                                null === (o = null == t ? void 0 : t.headers) ||
                                void 0 === o
                                    ? void 0
                                    : o.get("x-statsig-region"),
                            isDelta:
                                !0 === r.includes('"is_delta":true') || void 0,
                            attempt: n,
                            error: e.Diagnostics._formatError(s),
                        };
                    },
                    _enqueueDiagnosticsEvent(t, n, r, o) {
                        const i = e.Diagnostics._getMarkers(r);
                        if (null == i || i.length <= 0) return -1;
                        const a = i[i.length - 1].timestamp - i[0].timestamp;
                        e.Diagnostics._clearMarkers(r);
                        const c = (function (e, t) {
                            const n = {
                                eventName: s,
                                user: e,
                                value: null,
                                metadata: t,
                                time: Date.now(),
                            };
                            return n;
                        })(t, {
                            context: "initialize",
                            markers: i.slice(),
                            statsigOptions: o,
                        });
                        return n.enqueue(c), a;
                    },
                };
            })(p)),
        p
    );
}
var g,
    m,
    v,
    y = {},
    b = {},
    E = {},
    S = {};
function k() {
    if (g) return S;
    return (
        (g = 1),
        Object.defineProperty(S, "__esModule", { value: !0 }),
        (S._isTypeMatch = S._typeOf = void 0),
        (S._typeOf = function (e) {
            return Array.isArray(e) ? "array" : typeof e;
        }),
        (S._isTypeMatch = function (e, t) {
            const n = (e) =>
                Array.isArray(e) ? "array" : null === e ? "null" : typeof e;
            return n(e) === n(t);
        }),
        S
    );
}
function w() {
    return (
        m ||
            ((m = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._getSortedObject = e._DJB2Object = e._DJB2 = void 0);
                const t = k();
                e._DJB2 = (e) => {
                    let t = 0;
                    for (let n = 0; n < e.length; n++) {
                        (t = (t << 5) - t + e.charCodeAt(n)), (t &= t);
                    }
                    return String(t >>> 0);
                };
                e._DJB2Object = (t, n) =>
                    (0, e._DJB2)(JSON.stringify((0, e._getSortedObject)(t, n)));
                e._getSortedObject = (n, r) => {
                    if (null == n) return null;
                    const s = Object.keys(n).sort(),
                        o = {};
                    return (
                        s.forEach((s) => {
                            const i = n[s];
                            0 !== r && "object" === (0, t._typeOf)(i)
                                ? (o[s] = (0, e._getSortedObject)(
                                      i,
                                      null != r ? r - 1 : r
                                  ))
                                : (o[s] = i);
                        }),
                        o
                    );
                };
            })(E)),
        E
    );
}
function x() {
    if (v) return b;
    (v = 1),
        Object.defineProperty(b, "__esModule", { value: !0 }),
        (b._getStorageKey = b._getUserStorageKey = void 0);
    const e = w();
    function t(t, n, r) {
        var s;
        if (r) return r(t, n);
        const o = n && n.customIDs ? n.customIDs : {},
            i = [
                `uid:${
                    null !== (s = null == n ? void 0 : n.userID) && void 0 !== s
                        ? s
                        : ""
                }`,
                `cids:${Object.keys(o)
                    .sort((e, t) => e.localeCompare(t))
                    .map((e) => `${e}-${o[e]}`)
                    .join(",")}`,
                `k:${t}`,
            ];
        return (0, e._DJB2)(i.join("|"));
    }
    return (
        (b._getUserStorageKey = t),
        (b._getStorageKey = function (n, r, s) {
            return r ? t(n, r, s) : (0, e._DJB2)(`k:${n}`);
        }),
        b
    );
}
var O,
    I = {};
function D() {
    return (
        O ||
            ((O = 1),
            (e = I),
            Object.defineProperty(e, "__esModule", { value: !0 }),
            (e.NetworkParam = e.NetworkDefault = e.Endpoint = void 0),
            (e.Endpoint = {
                _initialize: "initialize",
                _rgstr: "rgstr",
                _download_config_specs: "download_config_specs",
            }),
            (e.NetworkDefault = {
                [e.Endpoint._rgstr]: "https://prodregistryv2.org/v1",
                [e.Endpoint._initialize]: "https://featureassets.org/v1",
                [e.Endpoint._download_config_specs]:
                    "https://api.statsigcdn.com/v1",
            }),
            (e.NetworkParam = {
                EventCount: "ec",
                SdkKey: "k",
                SdkType: "st",
                SdkVersion: "sv",
                Time: "t",
                SessionID: "sid",
                StatsigEncoded: "se",
                IsGzipped: "gz",
            })),
        I
    );
    var e;
}
var C,
    T = {};
function P() {
    return (
        C ||
            ((C = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._getUnloadEvent =
                        e._getCurrentPageUrlSafe =
                        e._addDocumentEventListenerSafe =
                        e._addWindowEventListenerSafe =
                        e._isServerEnv =
                        e._getDocumentSafe =
                        e._getWindowSafe =
                            void 0);
                e._getWindowSafe = () =>
                    "undefined" != typeof window ? window : null;
                e._getDocumentSafe = () => {
                    var t;
                    const n = (0, e._getWindowSafe)();
                    return null !== (t = null == n ? void 0 : n.document) &&
                        void 0 !== t
                        ? t
                        : null;
                };
                e._isServerEnv = () => {
                    if (null !== (0, e._getDocumentSafe)()) return !1;
                    const t =
                        "undefined" != typeof process &&
                        null != process.versions &&
                        null != process.versions.node;
                    return "string" == typeof EdgeRuntime || t;
                };
                e._addWindowEventListenerSafe = (t, n) => {
                    const r = (0, e._getWindowSafe)();
                    "function" ==
                        typeof (null == r ? void 0 : r.addEventListener) &&
                        r.addEventListener(t, n);
                };
                e._addDocumentEventListenerSafe = (t, n) => {
                    const r = (0, e._getDocumentSafe)();
                    "function" ==
                        typeof (null == r ? void 0 : r.addEventListener) &&
                        r.addEventListener(t, n);
                };
                e._getCurrentPageUrlSafe = () => {
                    var t;
                    try {
                        return null === (t = (0, e._getWindowSafe)()) ||
                            void 0 === t
                            ? void 0
                            : t.location.href.split(/[?#]/)[0];
                    } catch (n) {
                        return;
                    }
                };
                e._getUnloadEvent = () => {
                    const t = (0, e._getWindowSafe)();
                    if (!t) return "beforeunload";
                    return "onpagehide" in t ? "pagehide" : "beforeunload";
                };
            })(T)),
        T
    );
}
var A,
    R = {};
function j() {
    if (A) return R;
    (A = 1),
        Object.defineProperty(R, "__esModule", { value: !0 }),
        (R._createLayerParameterExposure =
            R._createConfigExposure =
            R._mapExposures =
            R._createGateExposure =
            R._isExposureEvent =
                void 0);
    const e = "statsig::config_exposure",
        t = "statsig::gate_exposure",
        n = "statsig::layer_exposure",
        r = (e, t, n, r, s) => (
            n.bootstrapMetadata && (r.bootstrapMetadata = n.bootstrapMetadata),
            {
                eventName: e,
                user: t,
                value: null,
                metadata: o(n, r),
                secondaryExposures: s,
                time: Date.now(),
            }
        );
    R._isExposureEvent = ({ eventName: r }) => r === t || r === e || r === n;
    function s(e, t) {
        return e
            .map((e) => ("string" == typeof e ? (null != t ? t : {})[e] : e))
            .filter((e) => null != e);
    }
    (R._createGateExposure = (e, n, o) => {
        var i, a, c;
        const u = {
            gate: n.name,
            gateValue: String(n.value),
            ruleID: n.ruleID,
        };
        return (
            null !=
                (null === (i = n.__evaluation) || void 0 === i
                    ? void 0
                    : i.version) && (u.configVersion = n.__evaluation.version),
            r(
                t,
                e,
                n.details,
                u,
                s(
                    null !==
                        (c =
                            null === (a = n.__evaluation) || void 0 === a
                                ? void 0
                                : a.secondary_exposures) && void 0 !== c
                        ? c
                        : [],
                    o
                )
            )
        );
    }),
        (R._mapExposures = s);
    R._createConfigExposure = (t, n, o) => {
        var i, a, c, u;
        const l = { config: n.name, ruleID: n.ruleID };
        return (
            null !=
                (null === (i = n.__evaluation) || void 0 === i
                    ? void 0
                    : i.version) && (l.configVersion = n.__evaluation.version),
            null !=
                (null === (a = n.__evaluation) || void 0 === a
                    ? void 0
                    : a.passed) &&
                (l.rulePassed = String(n.__evaluation.passed)),
            r(
                e,
                t,
                n.details,
                l,
                s(
                    null !==
                        (u =
                            null === (c = n.__evaluation) || void 0 === c
                                ? void 0
                                : c.secondary_exposures) && void 0 !== u
                        ? u
                        : [],
                    o
                )
            )
        );
    };
    R._createLayerParameterExposure = (e, t, o, i) => {
        var a, c, u, l, d, f, h;
        const p = t.__evaluation,
            _ =
                !0 ===
                (null === (a = null == p ? void 0 : p.explicit_parameters) ||
                void 0 === a
                    ? void 0
                    : a.includes(o));
        let g = "",
            m =
                null !==
                    (c =
                        null == p
                            ? void 0
                            : p.undelegated_secondary_exposures) && void 0 !== c
                    ? c
                    : [];
        _ &&
            ((g =
                null !== (u = p.allocated_experiment_name) && void 0 !== u
                    ? u
                    : ""),
            (m =
                null !== (l = p.secondary_exposures) && void 0 !== l ? l : []));
        const v =
                null === (d = t.__evaluation) || void 0 === d
                    ? void 0
                    : d.parameter_rule_ids,
            y = {
                config: t.name,
                parameterName: o,
                ruleID:
                    null !== (f = null == v ? void 0 : v[o]) && void 0 !== f
                        ? f
                        : t.ruleID,
                allocatedExperiment: g,
                isExplicitParameter: String(_),
            };
        return (
            null !=
                (null === (h = t.__evaluation) || void 0 === h
                    ? void 0
                    : h.version) && (y.configVersion = t.__evaluation.version),
            r(n, e, t.details, y, s(m, i))
        );
    };
    const o = (e, t) => (
        (t.reason = e.reason),
        e.lcut && (t.lcut = String(e.lcut)),
        e.receivedAt && (t.receivedAt = String(e.receivedAt)),
        t
    );
    return R;
}
var L,
    U = {};
function M() {
    return (
        L ||
            ((L = 1),
            Object.defineProperty(U, "__esModule", { value: !0 }),
            (U.LoggingEnabledOption = U.LogEventCompressionMode = void 0),
            (U.LogEventCompressionMode = {
                Disabled: "d",
                Enabled: "e",
                Forced: "f",
            }),
            (U.LoggingEnabledOption = {
                disabled: "disabled",
                browserOnly: "browser-only",
                always: "always",
            })),
        U
    );
}
var N,
    $ = {};
function K() {
    return (
        N ||
            ((N = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._setObjectInStorage =
                        e._getObjectFromStorage =
                        e.Storage =
                            void 0);
                const t = d(),
                    n = P(),
                    r = {},
                    s = {
                        isReady: () => !0,
                        isReadyResolver: () => null,
                        getProviderName: () => "InMemory",
                        getItem: (e) => (r[e] ? r[e] : null),
                        setItem: (e, t) => {
                            r[e] = t;
                        },
                        removeItem: (e) => {
                            delete r[e];
                        },
                        getAllKeys: () => Object.keys(r),
                    };
                let o = null;
                try {
                    const e = (0, n._getWindowSafe)();
                    e &&
                        e.localStorage &&
                        "function" == typeof e.localStorage.getItem &&
                        (o = {
                            isReady: () => !0,
                            isReadyResolver: () => null,
                            getProviderName: () => "LocalStorage",
                            getItem: (t) => e.localStorage.getItem(t),
                            setItem: (t, n) => e.localStorage.setItem(t, n),
                            removeItem: (t) => e.localStorage.removeItem(t),
                            getAllKeys: () => Object.keys(e.localStorage),
                        });
                } catch (u) {
                    t.Log.warn("Failed to setup localStorageProvider.");
                }
                let i = null != o ? o : s,
                    a = i;
                function c(t) {
                    try {
                        return t();
                    } catch (u) {
                        if (u instanceof Error && "SecurityError" === u.name)
                            return e.Storage._setProvider(s), null;
                        if (
                            u instanceof Error &&
                            "QuotaExceededError" === u.name
                        ) {
                            const n = e.Storage.getAllKeys().filter((e) =>
                                e.startsWith("statsig.")
                            );
                            u.message = `${u.message}. Statsig Keys: ${n.length}`;
                        }
                        throw u;
                    }
                }
                (e.Storage = {
                    isReady: () => a.isReady(),
                    isReadyResolver: () => a.isReadyResolver(),
                    getProviderName: () => a.getProviderName(),
                    getItem: (e) => c(() => a.getItem(e)),
                    setItem: (e, t) => c(() => a.setItem(e, t)),
                    removeItem: (e) => a.removeItem(e),
                    getAllKeys: () => a.getAllKeys(),
                    _setProvider: (e) => {
                        (i = e), (a = e);
                    },
                    _setDisabled: (e) => {
                        a = e ? s : i;
                    },
                }),
                    (e._getObjectFromStorage = function (t) {
                        const n = e.Storage.getItem(t);
                        return JSON.parse(null != n ? n : "null");
                    }),
                    (e._setObjectInStorage = function (t, n) {
                        e.Storage.setItem(t, JSON.stringify(n));
                    });
            })($)),
        $
    );
}
var F,
    B = {};
function z() {
    if (F) return B;
    (F = 1),
        Object.defineProperty(B, "__esModule", { value: !0 }),
        (B.UrlConfiguration = void 0);
    const e = w(),
        t = D(),
        n = {
            [t.Endpoint._initialize]: "i",
            [t.Endpoint._rgstr]: "e",
            [t.Endpoint._download_config_specs]: "d",
        };
    return (
        (B.UrlConfiguration = class {
            constructor(e, r, s, o) {
                (this.customUrl = null),
                    (this.fallbackUrls = null),
                    (this.endpoint = e),
                    (this.endpointDnsKey = n[e]),
                    r && (this.customUrl = r),
                    !r &&
                        s &&
                        (this.customUrl = s.endsWith("/")
                            ? `${s}${e}`
                            : `${s}/${e}`),
                    o && (this.fallbackUrls = o);
                const i = t.NetworkDefault[e];
                this.defaultUrl = `${i}/${e}`;
            }
            getUrl() {
                var e;
                return null !== (e = this.customUrl) && void 0 !== e
                    ? e
                    : this.defaultUrl;
            }
            getChecksum() {
                var t;
                const n = (
                    null !== (t = this.fallbackUrls) && void 0 !== t ? t : []
                )
                    .sort()
                    .join(",");
                return (0, e._DJB2)(this.customUrl + n);
            }
        }),
        B
    );
}
var q,
    V,
    G = {};
function W() {
    return (
        q ||
            ((q = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._notifyVisibilityChanged =
                        e._subscribeToVisiblityChanged =
                        e._isUnloading =
                        e._isCurrentlyVisible =
                            void 0);
                const t = P(),
                    n = "foreground",
                    r = "background",
                    s = [];
                let o = n,
                    i = !1;
                e._isCurrentlyVisible = () => o === n;
                e._isUnloading = () => i;
                e._subscribeToVisiblityChanged = (e) => {
                    s.unshift(e);
                };
                (e._notifyVisibilityChanged = (e) => {
                    e !== o && ((o = e), s.forEach((t) => t(e)));
                }),
                    (0, t._addWindowEventListenerSafe)("focus", () => {
                        (i = !1), (0, e._notifyVisibilityChanged)(n);
                    }),
                    (0, t._addWindowEventListenerSafe)("blur", () =>
                        (0, e._notifyVisibilityChanged)(r)
                    ),
                    (0, t._addDocumentEventListenerSafe)(
                        "visibilitychange",
                        () => {
                            (0, e._notifyVisibilityChanged)(
                                "visible" === document.visibilityState ? n : r
                            );
                        }
                    ),
                    (0, t._addWindowEventListenerSafe)(
                        (0, t._getUnloadEvent)(),
                        () => {
                            (i = !0), (0, e._notifyVisibilityChanged)(r);
                        }
                    );
            })(G)),
        G
    );
}
function H() {
    if (V) return y;
    V = 1;
    var e =
        (y && y.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(y, "__esModule", { value: !0 }),
        (y.EventLogger = void 0);
    const t = x(),
        n = w(),
        r = d(),
        s = D(),
        o = P(),
        i = j(),
        a = M(),
        c = K(),
        u = z(),
        l = W(),
        f = {},
        h = "startup",
        p = "gained_focus";
    return (
        (y.EventLogger = class d {
            static _safeFlushAndForget(e) {
                var t;
                null === (t = f[e]) ||
                    void 0 === t ||
                    t.flush().catch(() => {});
            }
            static _safeRetryFailedLogs(e) {
                var t;
                null === (t = f[e]) || void 0 === t || t._retryFailedLogs(p);
            }
            constructor(e, t, n, o) {
                var i, c;
                (this._sdkKey = e),
                    (this._emitter = t),
                    (this._network = n),
                    (this._options = o),
                    (this._queue = []),
                    (this._lastExposureTimeMap = {}),
                    (this._nonExposedChecks = {}),
                    (this._hasRunQuickFlush = !1),
                    (this._creationTime = Date.now()),
                    (this._loggingEnabled =
                        null !== (i = null == o ? void 0 : o.loggingEnabled) &&
                        void 0 !== i
                            ? i
                            : !0 === (null == o ? void 0 : o.disableLogging)
                            ? a.LoggingEnabledOption.disabled
                            : a.LoggingEnabledOption.browserOnly),
                    (null == o ? void 0 : o.loggingEnabled) &&
                        void 0 !== o.disableLogging &&
                        r.Log.warn(
                            "Detected both loggingEnabled and disableLogging options. loggingEnabled takes precedence - please remove disableLogging."
                        ),
                    (this._maxQueueSize =
                        null !==
                            (c = null == o ? void 0 : o.loggingBufferMaxSize) &&
                        void 0 !== c
                            ? c
                            : 100);
                const l = null == o ? void 0 : o.networkConfig;
                this._logEventUrlConfig = new u.UrlConfiguration(
                    s.Endpoint._rgstr,
                    null == l ? void 0 : l.logEventUrl,
                    null == l ? void 0 : l.api,
                    null == l ? void 0 : l.logEventFallbackUrls
                );
            }
            setLogEventCompressionMode(e) {
                this._network.setLogEventCompressionMode(e);
            }
            setLoggingEnabled(e) {
                this._loggingEnabled = e;
            }
            enqueue(e) {
                this._shouldLogEvent(e) &&
                    (this._normalizeAndAppendEvent(e),
                    this._quickFlushIfNeeded(),
                    this._queue.length > this._maxQueueSize &&
                        d._safeFlushAndForget(this._sdkKey));
            }
            incrementNonExposureCount(e) {
                var t;
                const n =
                    null !== (t = this._nonExposedChecks[e]) && void 0 !== t
                        ? t
                        : 0;
                this._nonExposedChecks[e] = n + 1;
            }
            reset() {
                this.flush().catch(() => {}), (this._lastExposureTimeMap = {});
            }
            start() {
                var e;
                const t = (0, o._isServerEnv)();
                (t &&
                    "always" !==
                        (null === (e = this._options) || void 0 === e
                            ? void 0
                            : e.loggingEnabled)) ||
                    ((f[this._sdkKey] = this),
                    t ||
                        (0, l._subscribeToVisiblityChanged)((e) => {
                            "background" === e
                                ? d._safeFlushAndForget(this._sdkKey)
                                : "foreground" === e &&
                                  d._safeRetryFailedLogs(this._sdkKey);
                        }),
                    this._retryFailedLogs(h),
                    this._startBackgroundFlushInterval());
            }
            stop() {
                return e(this, void 0, void 0, function* () {
                    this._flushIntervalId &&
                        (clearInterval(this._flushIntervalId),
                        (this._flushIntervalId = null)),
                        delete f[this._sdkKey],
                        yield this.flush();
                });
            }
            flush() {
                return e(this, void 0, void 0, function* () {
                    if (
                        (this._appendAndResetNonExposedChecks(),
                        0 === this._queue.length)
                    )
                        return;
                    const e = this._queue;
                    (this._queue = []), yield this._sendEvents(e);
                });
            }
            _quickFlushIfNeeded() {
                this._hasRunQuickFlush ||
                    ((this._hasRunQuickFlush = !0),
                    Date.now() - this._creationTime > 200 ||
                        setTimeout(
                            () => d._safeFlushAndForget(this._sdkKey),
                            200
                        ));
            }
            _shouldLogEvent(e) {
                var n;
                if (
                    "always" !==
                        (null === (n = this._options) || void 0 === n
                            ? void 0
                            : n.loggingEnabled) &&
                    (0, o._isServerEnv)()
                )
                    return !1;
                if (!(0, i._isExposureEvent)(e)) return !0;
                const r = e.user ? e.user : { statsigEnvironment: void 0 },
                    s = (0, t._getUserStorageKey)(this._sdkKey, r),
                    a = e.metadata ? e.metadata : {},
                    c = [
                        e.eventName,
                        s,
                        a.gate,
                        a.config,
                        a.ruleID,
                        a.allocatedExperiment,
                        a.parameterName,
                        String(a.isExplicitParameter),
                        a.reason,
                    ].join("|"),
                    u = this._lastExposureTimeMap[c],
                    l = Date.now();
                return (
                    !(u && l - u < 6e5) &&
                    (Object.keys(this._lastExposureTimeMap).length > 1e3 &&
                        (this._lastExposureTimeMap = {}),
                    (this._lastExposureTimeMap[c] = l),
                    !0)
                );
            }
            _sendEvents(t) {
                return e(this, void 0, void 0, function* () {
                    var e, n;
                    if ("disabled" === this._loggingEnabled)
                        return this._saveFailedLogsToStorage(t), !1;
                    try {
                        const s =
                            (0, l._isUnloading)() &&
                            this._network.isBeaconSupported() &&
                            null ==
                                (null ===
                                    (n =
                                        null === (e = this._options) ||
                                        void 0 === e
                                            ? void 0
                                            : e.networkConfig) || void 0 === n
                                    ? void 0
                                    : n.networkOverrideFunc);
                        this._emitter({ name: "pre_logs_flushed", events: t });
                        return (s
                            ? this._sendEventsViaBeacon(t)
                            : yield this._sendEventsViaPost(t)
                        ).success
                            ? (this._emitter({
                                  name: "logs_flushed",
                                  events: t,
                              }),
                              !0)
                            : (r.Log.warn("Failed to flush events."),
                              this._saveFailedLogsToStorage(t),
                              !1);
                    } catch (s) {
                        return r.Log.warn("Failed to flush events."), !1;
                    }
                });
            }
            _sendEventsViaPost(t) {
                return e(this, void 0, void 0, function* () {
                    var e;
                    const n = yield this._network.post(this._getRequestData(t)),
                        r =
                            null !== (e = null == n ? void 0 : n.code) &&
                            void 0 !== e
                                ? e
                                : -1;
                    return { success: r >= 200 && r < 300 };
                });
            }
            _sendEventsViaBeacon(e) {
                return {
                    success: this._network.beacon(this._getRequestData(e)),
                };
            }
            _getRequestData(e) {
                return {
                    sdkKey: this._sdkKey,
                    data: { events: e },
                    urlConfig: this._logEventUrlConfig,
                    retries: 3,
                    isCompressable: !0,
                    params: { [s.NetworkParam.EventCount]: String(e.length) },
                    credentials: "same-origin",
                };
            }
            _saveFailedLogsToStorage(e) {
                for (; e.length > 500; ) e.shift();
                const t = this._getStorageKey();
                try {
                    (0, c._setObjectInStorage)(t, e);
                } catch (n) {
                    r.Log.warn("Unable to save failed logs to storage");
                }
            }
            _retryFailedLogs(t) {
                const n = this._getStorageKey();
                (() =>
                    e(this, void 0, void 0, function* () {
                        c.Storage.isReady() ||
                            (yield c.Storage.isReadyResolver());
                        const e = (0, c._getObjectFromStorage)(n);
                        if (!e) return;
                        t === h && c.Storage.removeItem(n);
                        (yield this._sendEvents(e)) &&
                            t === p &&
                            c.Storage.removeItem(n);
                    }))().catch(() => {
                    r.Log.warn("Failed to flush stored logs");
                });
            }
            _getStorageKey() {
                return `statsig.failed_logs.${(0, n._DJB2)(this._sdkKey)}`;
            }
            _normalizeAndAppendEvent(e) {
                e.user &&
                    ((e.user = Object.assign({}, e.user)),
                    delete e.user.privateAttributes);
                const t = {},
                    n = this._getCurrentPageUrl();
                n && (t.statsigMetadata = { currentPage: n });
                const s = Object.assign(Object.assign({}, e), t);
                r.Log.debug("Enqueued Event:", s), this._queue.push(s);
            }
            _appendAndResetNonExposedChecks() {
                0 !== Object.keys(this._nonExposedChecks).length &&
                    (this._normalizeAndAppendEvent({
                        eventName: "statsig::non_exposed_checks",
                        user: null,
                        time: Date.now(),
                        metadata: {
                            checks: Object.assign({}, this._nonExposedChecks),
                        },
                    }),
                    (this._nonExposedChecks = {}));
            }
            _getCurrentPageUrl() {
                var e;
                if (
                    !1 !==
                    (null === (e = this._options) || void 0 === e
                        ? void 0
                        : e.includeCurrentPageUrlWithEvents)
                )
                    return (0, o._getCurrentPageUrlSafe)();
            }
            _startBackgroundFlushInterval() {
                var e, t;
                const n =
                        null !==
                            (t =
                                null === (e = this._options) || void 0 === e
                                    ? void 0
                                    : e.loggingIntervalMs) && void 0 !== t
                            ? t
                            : 1e4,
                    r = setInterval(() => {
                        const e = f[this._sdkKey];
                        e && e._flushIntervalId === r
                            ? d._safeFlushAndForget(this._sdkKey)
                            : clearInterval(r);
                    }, n);
                this._flushIntervalId = r;
            }
        }),
        y
    );
}
var J,
    Y = {};
function X() {
    return (
        J ||
            ((J = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.StatsigMetadataProvider = e.SDK_VERSION = void 0),
                    (e.SDK_VERSION = "3.24.4");
                let t = { sdkVersion: e.SDK_VERSION, sdkType: "js-mono" };
                e.StatsigMetadataProvider = {
                    get: () => t,
                    add: (e) => {
                        t = Object.assign(Object.assign({}, t), e);
                    },
                };
            })(Y)),
        Y
    );
}
var Q,
    Z = {};
var ee,
    te,
    ne = {},
    re = {},
    se = {};
function oe() {
    if (ee) return se;
    return (
        (ee = 1),
        Object.defineProperty(se, "__esModule", { value: !0 }),
        (se.getUUID = void 0),
        (se.getUUID = function () {
            if (
                "undefined" != typeof crypto &&
                "function" == typeof crypto.randomUUID
            )
                return crypto.randomUUID();
            let e = new Date().getTime(),
                t =
                    ("undefined" != typeof performance &&
                        performance.now &&
                        1e3 * performance.now()) ||
                    0;
            return `xxxxxxxx-xxxx-4xxx-${
                "89ab"[Math.floor(4 * Math.random())]
            }xxx-xxxxxxxxxxxx`.replace(/[xy]/g, (n) => {
                let r = 16 * Math.random();
                return (
                    e > 0
                        ? ((r = (e + r) % 16 | 0), (e = Math.floor(e / 16)))
                        : ((r = (t + r) % 16 | 0), (t = Math.floor(t / 16))),
                    ("x" === n ? r : (7 & r) | 8).toString(16)
                );
            });
        }),
        se
    );
}
function ie() {
    if (te) return re;
    (te = 1),
        Object.defineProperty(re, "__esModule", { value: !0 }),
        (re.getCookieName = re.StableID = void 0);
    const e = x(),
        t = d(),
        n = P(),
        r = K(),
        s = oe(),
        o = {},
        i = {},
        a = {};
    function c(t) {
        return `statsig.stable_id.${(0, e._getStorageKey)(t)}`;
    }
    function u(e, n) {
        const s = c(n);
        try {
            (0, r._setObjectInStorage)(s, e);
        } catch (o) {
            t.Log.warn("Failed to save StableID to storage");
        }
    }
    function l(e, t) {
        if (!i[t] || null == (0, n._getDocumentSafe)()) return;
        const r = new Date();
        r.setFullYear(r.getFullYear() + 1),
            (document.cookie = `${f(t)}=${encodeURIComponent(
                e
            )}; expires=${r.toUTCString()}; path=/`);
    }
    function f(t) {
        return `statsig.stable_id.${(0, e._getStorageKey)(t)}`;
    }
    return (
        (re.StableID = {
            cookiesEnabled: !1,
            randomID: Math.random().toString(36),
            get: (e) => {
                if (a[e]) return null;
                if (null != o[e]) return o[e];
                let t = null;
                return (
                    (t = (function (e) {
                        if (!i[e] || null == (0, n._getDocumentSafe)())
                            return null;
                        const t = document.cookie.split(";");
                        for (const n of t) {
                            const [t, r] = n.trim().split("=");
                            if (t === f(e)) return decodeURIComponent(r);
                        }
                        return null;
                    })(e)),
                    null != t
                        ? ((o[e] = t), u(t, e), t)
                        : ((t = (function (e) {
                              const t = c(e);
                              return (0, r._getObjectFromStorage)(t);
                          })(e)),
                          null == t && (t = (0, s.getUUID)()),
                          u(t, e),
                          l(t, e),
                          (o[e] = t),
                          t)
                );
            },
            setOverride: (e, t) => {
                (o[t] = e), u(e, t), l(e, t);
            },
            _setCookiesEnabled: (e, t) => {
                i[e] = t;
            },
            _setDisabled: (e, t) => {
                a[e] = t;
            },
        }),
        (re.getCookieName = f),
        re
    );
}
var ae,
    ce = {};
function ue() {
    if (ae) return ce;
    (ae = 1),
        Object.defineProperty(ce, "__esModule", { value: !0 }),
        (ce._getFullUserHash = ce._normalizeUser = void 0);
    const e = w(),
        t = d();
    return (
        (ce._normalizeUser = function (e, n, r) {
            try {
                const t = JSON.parse(JSON.stringify(e));
                return (
                    null != n && null != n.environment
                        ? (t.statsigEnvironment = n.environment)
                        : null != r && (t.statsigEnvironment = { tier: r }),
                    t
                );
            } catch (s) {
                return (
                    t.Log.error("Failed to JSON.stringify user"),
                    { statsigEnvironment: void 0 }
                );
            }
        }),
        (ce._getFullUserHash = function (t) {
            return t ? (0, e._DJB2Object)(t) : null;
        }),
        ce
    );
}
var le,
    de,
    fe = {};
function he() {
    if (le) return fe;
    (le = 1),
        Object.defineProperty(fe, "__esModule", { value: !0 }),
        (fe._typedJsonParse = void 0);
    const e = d();
    return (
        (fe._typedJsonParse = function (t, n, r) {
            try {
                const e = JSON.parse(t);
                if (e && "object" == typeof e && n in e) return e;
            } catch (s) {}
            return e.Log.error(`Failed to parse ${r}`), null;
        }),
        fe
    );
}
function pe() {
    if (de) return ne;
    de = 1;
    var e =
        (ne && ne.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(ne, "__esModule", { value: !0 }),
        (ne._makeDataAdapterResult = ne.DataAdapterCore = void 0);
    const t = d(),
        n = ie(),
        r = ue(),
        s = K(),
        o = he();
    function i(e, t, n, s) {
        return {
            source: e,
            data: t,
            receivedAt: Date.now(),
            stableID: n,
            fullUserHash: (0, r._getFullUserHash)(s),
        };
    }
    (ne.DataAdapterCore = class {
        constructor(e, t) {
            (this._adapterName = e),
                (this._cacheSuffix = t),
                (this._options = null),
                (this._sdkKey = null),
                (this._lastModifiedStoreKey = `statsig.last_modified_time.${t}`),
                (this._inMemoryCache = new a());
        }
        attach(e, t, n) {
            (this._sdkKey = e), (this._options = t);
        }
        getDataSync(e) {
            const t = e && (0, r._normalizeUser)(e, this._options),
                n = this._getCacheKey(t),
                s = this._inMemoryCache.get(n, t);
            if (s && this._getIsCacheValueValid(s)) return s;
            const o = this._loadFromCache(n);
            return o && this._getIsCacheValueValid(o)
                ? (this._inMemoryCache.add(n, o), this._inMemoryCache.get(n, t))
                : null;
        }
        setData(e, t) {
            const n = t && (0, r._normalizeUser)(t, this._options),
                s = this._getCacheKey(n);
            this._inMemoryCache.add(s, i("Bootstrap", e, null, n));
        }
        _getIsCacheValueValid(e) {
            return (
                null == e.stableID ||
                e.stableID === n.StableID.get(this._getSdkKey())
            );
        }
        _getDataAsyncImpl(n, r, o) {
            return e(this, void 0, void 0, function* () {
                s.Storage.isReady() || (yield s.Storage.isReadyResolver());
                const e = null != n ? n : this.getDataSync(r),
                    i = [this._fetchAndPrepFromNetwork(e, r, o)];
                return (
                    (null == o ? void 0 : o.timeoutMs) &&
                        i.push(
                            new Promise((e) => setTimeout(e, o.timeoutMs)).then(
                                () => (
                                    t.Log.debug(
                                        "Fetching latest value timed out"
                                    ),
                                    null
                                )
                            )
                        ),
                    yield Promise.race(i)
                );
            });
        }
        _prefetchDataImpl(t, n) {
            return e(this, void 0, void 0, function* () {
                const e = t && (0, r._normalizeUser)(t, this._options),
                    s = this._getCacheKey(e),
                    o = yield this._getDataAsyncImpl(null, e, n);
                o &&
                    this._inMemoryCache.add(
                        s,
                        Object.assign(Object.assign({}, o), {
                            source: "Prefetch",
                        })
                    );
            });
        }
        _fetchAndPrepFromNetwork(r, s, a) {
            return e(this, void 0, void 0, function* () {
                var e;
                const c =
                        null !== (e = null == r ? void 0 : r.data) &&
                        void 0 !== e
                            ? e
                            : null,
                    u = null != r && this._isCachedResultValidFor204(r, s),
                    l = yield this._fetchFromNetwork(c, s, a, u);
                if (!l)
                    return (
                        t.Log.debug("No response returned for latest value"),
                        null
                    );
                const d = (0, o._typedJsonParse)(l, "has_updates", "Response"),
                    f = this._getSdkKey(),
                    h = n.StableID.get(f);
                let p = null;
                if (!0 === (null == d ? void 0 : d.has_updates))
                    p = i("Network", l, h, s);
                else {
                    if (!c || !1 !== (null == d ? void 0 : d.has_updates))
                        return null;
                    p = i("NetworkNotModified", c, h, s);
                }
                const _ = this._getCacheKey(s);
                return (
                    this._inMemoryCache.add(_, p), this._writeToCache(_, p), p
                );
            });
        }
        _getSdkKey() {
            return null != this._sdkKey
                ? this._sdkKey
                : (t.Log.error(
                      `${this._adapterName} is not attached to a Client`
                  ),
                  "");
        }
        _loadFromCache(e) {
            var t;
            const n =
                null === (t = s.Storage.getItem) || void 0 === t
                    ? void 0
                    : t.call(s.Storage, e);
            if (null == n) return null;
            const r = (0, o._typedJsonParse)(n, "source", "Cached Result");
            return r
                ? Object.assign(Object.assign({}, r), { source: "Cache" })
                : null;
        }
        _writeToCache(e, t) {
            s.Storage.setItem(e, JSON.stringify(t)),
                this._runLocalStorageCacheEviction(e);
        }
        _runLocalStorageCacheEviction(e) {
            var t;
            const n =
                null !==
                    (t = (0, s._getObjectFromStorage)(
                        this._lastModifiedStoreKey
                    )) && void 0 !== t
                    ? t
                    : {};
            n[e] = Date.now();
            const r = c(n, 10);
            r && (delete n[r], s.Storage.removeItem(r)),
                (0, s._setObjectInStorage)(this._lastModifiedStoreKey, n);
        }
    }),
        (ne._makeDataAdapterResult = i);
    class a {
        constructor() {
            this._data = {};
        }
        get(e, n) {
            var r;
            const s = this._data[e],
                o = null == s ? void 0 : s.stableID,
                i =
                    null === (r = null == n ? void 0 : n.customIDs) ||
                    void 0 === r
                        ? void 0
                        : r.stableID;
            return i && o && i !== o
                ? (t.Log.warn("'StatsigUser.customIDs.stableID' mismatch"),
                  null)
                : s;
        }
        add(e, t) {
            const n = c(this._data, 9);
            n && delete this._data[n], (this._data[e] = t);
        }
        merge(e) {
            this._data = Object.assign(Object.assign({}, this._data), e);
        }
    }
    function c(e, t) {
        const n = Object.keys(e);
        return n.length <= t
            ? null
            : n.reduce((t, n) => {
                  const r = e[t],
                      s = e[n];
                  return "object" == typeof r && "object" == typeof s
                      ? s.receivedAt < r.receivedAt
                          ? n
                          : t
                      : s < r
                      ? n
                      : t;
              });
    }
    return ne;
}
var _e,
    ge = {};
var me,
    ve,
    ye = {},
    be = {};
function Ee() {
    if (me) return be;
    (me = 1),
        Object.defineProperty(be, "__esModule", { value: !0 }),
        (be.SDKType = void 0);
    const e = {};
    let t;
    return (
        (be.SDKType = {
            _get: (n) => {
                var r;
                return (
                    (null !== (r = e[n]) && void 0 !== r ? r : "js-mono") +
                    (null != t ? t : "")
                );
            },
            _setClientType(t, n) {
                e[t] = n;
            },
            _setBindingType(e) {
                (t && "-react" !== t) || (t = "-" + e);
            },
        }),
        be
    );
}
function Se() {
    return (
        ve ||
            ((ve = 1),
            (function (e) {
                var t =
                    (ye && ye.__awaiter) ||
                    function (e, t, n, r) {
                        return new (n || (n = Promise))(function (s, o) {
                            function i(e) {
                                try {
                                    c(r.next(e));
                                } catch (t) {
                                    o(t);
                                }
                            }
                            function a(e) {
                                try {
                                    c(r.throw(e));
                                } catch (t) {
                                    o(t);
                                }
                            }
                            function c(e) {
                                var t;
                                e.done
                                    ? s(e.value)
                                    : ((t = e.value),
                                      t instanceof n
                                          ? t
                                          : new n(function (e) {
                                                e(t);
                                            })).then(i, a);
                            }
                            c((r = r.apply(e, t || [])).next());
                        });
                    };
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.ErrorBoundary = e.EXCEPTION_ENDPOINT = void 0);
                const n = d(),
                    r = Ee(),
                    s = X();
                e.EXCEPTION_ENDPOINT =
                    "https://statsigapi.net/v1/sdk_exception";
                const o = "[Statsig] UnknownError";
                function i(e) {
                    return e instanceof Error
                        ? e
                        : "string" == typeof e
                        ? new Error(e)
                        : new Error("An unknown error occurred.");
                }
                function a(e) {
                    if (!e) return {};
                    const t = {};
                    return (
                        Object.entries(e).forEach(([e, n]) => {
                            switch (typeof n) {
                                case "number":
                                case "bigint":
                                case "boolean":
                                    t[String(e)] = n;
                                    break;
                                case "string":
                                    n.length < 50
                                        ? (t[String(e)] = n)
                                        : (t[String(e)] = "set");
                                    break;
                                case "object":
                                    "environment" === e
                                        ? (t.environment = n)
                                        : "networkConfig" === e
                                        ? (t.networkConfig = n)
                                        : (t[String(e)] =
                                              null != n ? "set" : "unset");
                            }
                        }),
                        t
                    );
                }
                e.ErrorBoundary = class {
                    constructor(e, t, n, r) {
                        (this._sdkKey = e),
                            (this._options = t),
                            (this._emitter = n),
                            (this._lastSeenError = r),
                            (this._seen = new Set());
                    }
                    wrap(e, t) {
                        try {
                            const n = e;
                            (function (e) {
                                const t = new Set();
                                let n = Object.getPrototypeOf(e);
                                for (; n && n !== Object.prototype; )
                                    Object.getOwnPropertyNames(n)
                                        .filter(
                                            (e) =>
                                                "function" ==
                                                typeof (null == n
                                                    ? void 0
                                                    : n[e])
                                        )
                                        .forEach((e) => t.add(e)),
                                        (n = Object.getPrototypeOf(n));
                                return Array.from(t);
                            })(n).forEach((r) => {
                                const s = n[r];
                                "$EB" in s ||
                                    ((n[r] = (...n) =>
                                        this._capture(t ? `${t}:${r}` : r, () =>
                                            s.apply(e, n)
                                        )),
                                    (n[r].$EB = !0));
                            });
                        } catch (n) {
                            this._onError("eb:wrap", n);
                        }
                    }
                    logError(e, t) {
                        this._onError(e, t);
                    }
                    getLastSeenErrorAndReset() {
                        const e = this._lastSeenError;
                        return (
                            (this._lastSeenError = void 0), null != e ? e : null
                        );
                    }
                    attachErrorIfNoneExists(e) {
                        this._lastSeenError || (this._lastSeenError = i(e));
                    }
                    _capture(e, t) {
                        try {
                            const n = t();
                            return n && n instanceof Promise
                                ? n.catch((t) => this._onError(e, t))
                                : n;
                        } catch (n) {
                            return this._onError(e, n), null;
                        }
                    }
                    _onError(c, u) {
                        try {
                            n.Log.warn(`Caught error in ${c}`, { error: u });
                            (() =>
                                t(this, void 0, void 0, function* () {
                                    var t, n, l, d, f, h, p;
                                    const _ = u || Error(o),
                                        g = _ instanceof Error,
                                        m = g ? _.name : "No Name",
                                        v = i(_);
                                    if (
                                        ((this._lastSeenError = v),
                                        this._seen.has(m))
                                    )
                                        return;
                                    if (
                                        (this._seen.add(m),
                                        null ===
                                            (n =
                                                null === (t = this._options) ||
                                                void 0 === t
                                                    ? void 0
                                                    : t.networkConfig) ||
                                        void 0 === n
                                            ? void 0
                                            : n.preventAllNetworkTraffic)
                                    )
                                        return void (
                                            null === (l = this._emitter) ||
                                            void 0 === l ||
                                            l.call(this, {
                                                name: "error",
                                                error: u,
                                                tag: c,
                                            })
                                        );
                                    const y = r.SDKType._get(this._sdkKey),
                                        b = s.StatsigMetadataProvider.get(),
                                        E = g
                                            ? _.stack
                                            : (function (e) {
                                                  try {
                                                      return JSON.stringify(e);
                                                  } catch (t) {
                                                      return o;
                                                  }
                                              })(_),
                                        S = Object.assign(
                                            {
                                                tag: c,
                                                exception: m,
                                                info: E,
                                                statsigOptions: a(
                                                    this._options
                                                ),
                                            },
                                            Object.assign(
                                                Object.assign({}, b),
                                                { sdkType: y }
                                            )
                                        ),
                                        k =
                                            null !==
                                                (h =
                                                    null ===
                                                        (f =
                                                            null ===
                                                                (d =
                                                                    this
                                                                        ._options) ||
                                                            void 0 === d
                                                                ? void 0
                                                                : d.networkConfig) ||
                                                    void 0 === f
                                                        ? void 0
                                                        : f.networkOverrideFunc) &&
                                            void 0 !== h
                                                ? h
                                                : fetch;
                                    yield k(e.EXCEPTION_ENDPOINT, {
                                        method: "POST",
                                        headers: {
                                            "STATSIG-API-KEY": this._sdkKey,
                                            "STATSIG-SDK-TYPE": String(y),
                                            "STATSIG-SDK-VERSION": String(
                                                b.sdkVersion
                                            ),
                                            "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify(S),
                                    }),
                                        null === (p = this._emitter) ||
                                            void 0 === p ||
                                            p.call(this, {
                                                name: "error",
                                                error: u,
                                                tag: c,
                                            });
                                }))()
                                .then(() => {})
                                .catch(() => {});
                        } catch (l) {}
                    }
                };
            })(ye)),
        ye
    );
}
var ke,
    we = {};
var xe,
    Oe = {};
var Ie,
    De = {};
var Ce,
    Te = {};
function Pe() {
    if (Ce) return Te;
    (Ce = 1),
        Object.defineProperty(Te, "__esModule", { value: !0 }),
        (Te.createMemoKey = Te.MemoPrefix = void 0),
        (Te.MemoPrefix = {
            _gate: "g",
            _dynamicConfig: "c",
            _experiment: "e",
            _configList: "cl",
            _layer: "l",
            _paramStore: "p",
        });
    const e = new Set([]),
        t = new Set(["userPersistedValues"]);
    return (
        (Te.createMemoKey = function (n, r, s) {
            let o = `${n}|${r}`;
            if (!s) return o;
            for (const i of Object.keys(s)) {
                if (t.has(i)) return;
                e.has(i) ? (o += `|${i}=true`) : (o += `|${i}=${s[i]}`);
            }
            return o;
        }),
        Te
    );
}
var Ae,
    Re,
    je = {},
    Le = {},
    Ue = {};
function Me() {
    if (Ae) return Ue;
    Ae = 1;
    var e =
        (Ue && Ue.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Ue, "__esModule", { value: !0 }),
        (Ue._fetchTxtRecords = void 0);
    const t = new Uint8Array([
            0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 13, 102, 101, 97, 116, 117, 114,
            101, 97, 115, 115, 101, 116, 115, 3, 111, 114, 103, 0, 0, 16, 0, 1,
        ]),
        n = ["i", "e", "d"];
    return (
        (Ue._fetchTxtRecords = function (r) {
            return e(this, void 0, void 0, function* () {
                const e = yield r("https://cloudflare-dns.com/dns-query", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/dns-message",
                        Accept: "application/dns-message",
                    },
                    body: t,
                });
                if (!e.ok) {
                    const e = new Error("Failed to fetch TXT records from DNS");
                    throw ((e.name = "DnsTxtFetchError"), e);
                }
                const s = yield e.arrayBuffer();
                return (function (e) {
                    const t = e.findIndex(
                        (t, r) =>
                            r < 200 &&
                            "=" === String.fromCharCode(t) &&
                            n.includes(String.fromCharCode(e[r - 1]))
                    );
                    if (-1 === t) {
                        const e = new Error(
                            "Failed to parse TXT records from DNS"
                        );
                        throw ((e.name = "DnsTxtParseError"), e);
                    }
                    let r = "";
                    for (let n = t - 1; n < e.length; n++)
                        r += String.fromCharCode(e[n]);
                    return r.split(",");
                })(new Uint8Array(s));
            });
        }),
        Ue
    );
}
function Ne() {
    if (Re) return Le;
    Re = 1;
    var e =
        (Le && Le.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Le, "__esModule", { value: !0 }),
        (Le._isDomainFailure = Le.NetworkFallbackResolver = void 0);
    const t = Me(),
        n = w(),
        r = d(),
        s = K(),
        o = 6048e5;
    function i(e, t) {
        var n;
        const r =
            null !== (n = null == e ? void 0 : e.toLowerCase()) && void 0 !== n
                ? n
                : "";
        return (
            t ||
            r.includes("uncaught exception") ||
            r.includes("failed to fetch") ||
            r.includes("networkerror when attempting to fetch resource")
        );
    }
    function a(e) {
        return `statsig.network_fallback.${(0, n._DJB2)(e)}`;
    }
    function c(e, t) {
        const n = a(e);
        t && 0 !== Object.keys(t).length
            ? s.Storage.setItem(n, JSON.stringify(t))
            : s.Storage.removeItem(n);
    }
    return (
        (Le.NetworkFallbackResolver = class {
            constructor(e) {
                var t;
                (this._fallbackInfo = null),
                    (this._errorBoundary = null),
                    (this._dnsQueryCooldowns = {}),
                    (this._networkOverrideFunc =
                        null === (t = e.networkConfig) || void 0 === t
                            ? void 0
                            : t.networkOverrideFunc);
            }
            setErrorBoundary(e) {
                this._errorBoundary = e;
            }
            tryBumpExpiryTime(e, t) {
                var n;
                const r =
                    null === (n = this._fallbackInfo) || void 0 === n
                        ? void 0
                        : n[t.endpoint];
                r &&
                    ((r.expiryTime = Date.now() + o),
                    c(
                        e,
                        Object.assign(Object.assign({}, this._fallbackInfo), {
                            [t.endpoint]: r,
                        })
                    ));
            }
            getActiveFallbackUrl(e, t) {
                var n, o;
                if (null != t.customUrl && null != t.fallbackUrls) return null;
                let i = this._fallbackInfo;
                null == i &&
                    ((i =
                        null !==
                            (n = (function (e) {
                                const t = a(e),
                                    o = s.Storage.getItem(t);
                                if (!o) return null;
                                try {
                                    return JSON.parse(o);
                                } catch (n) {
                                    return (
                                        r.Log.error(
                                            "Failed to parse FallbackInfo"
                                        ),
                                        null
                                    );
                                }
                            })(e)) && void 0 !== n
                            ? n
                            : {}),
                    (this._fallbackInfo = i));
                const u = i[t.endpoint];
                return !u ||
                    Date.now() >
                        (null !== (o = u.expiryTime) && void 0 !== o ? o : 0) ||
                    t.getChecksum() !== u.urlConfigChecksum
                    ? (delete i[t.endpoint],
                      (this._fallbackInfo = i),
                      c(e, this._fallbackInfo),
                      null)
                    : u.url
                    ? u.url
                    : null;
            }
            tryFetchUpdatedFallbackInfo(t, n, r, s) {
                return e(this, void 0, void 0, function* () {
                    var e, o;
                    try {
                        if (!i(r, s)) return !1;
                        const o =
                                null == n.customUrl && null == n.fallbackUrls
                                    ? yield this._tryFetchFallbackUrlsFromNetwork(
                                          n
                                      )
                                    : n.fallbackUrls,
                            a = this._pickNewFallbackUrl(
                                null === (e = this._fallbackInfo) ||
                                    void 0 === e
                                    ? void 0
                                    : e[n.endpoint],
                                o
                            );
                        return (
                            !!a &&
                            (this._updateFallbackInfoWithNewUrl(t, n, a), !0)
                        );
                    } catch (a) {
                        return (
                            null === (o = this._errorBoundary) ||
                                void 0 === o ||
                                o.logError("tryFetchUpdatedFallbackInfo", a),
                            !1
                        );
                    }
                });
            }
            _updateFallbackInfoWithNewUrl(e, t, n) {
                var r, s, i;
                const a = {
                        urlConfigChecksum: t.getChecksum(),
                        url: n,
                        expiryTime: Date.now() + o,
                        previous: [],
                    },
                    u = t.endpoint,
                    l =
                        null === (r = this._fallbackInfo) || void 0 === r
                            ? void 0
                            : r[u];
                l && a.previous.push(...l.previous),
                    a.previous.length > 10 && (a.previous = []);
                const d =
                    null ===
                        (i =
                            null === (s = this._fallbackInfo) || void 0 === s
                                ? void 0
                                : s[u]) || void 0 === i
                        ? void 0
                        : i.url;
                null != d && a.previous.push(d),
                    (this._fallbackInfo = Object.assign(
                        Object.assign({}, this._fallbackInfo),
                        { [u]: a }
                    )),
                    c(e, this._fallbackInfo);
            }
            _tryFetchFallbackUrlsFromNetwork(n) {
                return e(this, void 0, void 0, function* () {
                    var e;
                    const r = this._dnsQueryCooldowns[n.endpoint];
                    if (r && Date.now() < r) return null;
                    this._dnsQueryCooldowns[n.endpoint] = Date.now() + 144e5;
                    const s = [],
                        o = yield (0, t._fetchTxtRecords)(
                            null !== (e = this._networkOverrideFunc) &&
                                void 0 !== e
                                ? e
                                : fetch
                        ),
                        i = (function (e) {
                            try {
                                return new URL(e).pathname;
                            } catch (t) {
                                return null;
                            }
                        })(n.defaultUrl);
                    for (const t of o) {
                        if (!t.startsWith(n.endpointDnsKey + "=")) continue;
                        const e = t.split("=");
                        if (e.length > 1) {
                            let t = e[1];
                            t.endsWith("/") && (t = t.slice(0, -1)),
                                s.push(`https://${t}${i}`);
                        }
                    }
                    return s;
                });
            }
            _pickNewFallbackUrl(e, t) {
                var n;
                if (null == t) return null;
                const r = new Set(
                        null !== (n = null == e ? void 0 : e.previous) &&
                        void 0 !== n
                            ? n
                            : []
                    ),
                    s = null == e ? void 0 : e.url;
                let o = null;
                for (const i of t) {
                    const e = i.endsWith("/") ? i.slice(0, -1) : i;
                    if (!r.has(i) && e !== s) {
                        o = e;
                        break;
                    }
                }
                return o;
            }
        }),
        (Le._isDomainFailure = i),
        Le
    );
}
var $e,
    Ke = {};
function Fe() {
    if ($e) return Ke;
    ($e = 1),
        Object.defineProperty(Ke, "__esModule", { value: !0 }),
        (Ke.SDKFlags = void 0);
    const e = {};
    return (
        (Ke.SDKFlags = {
            setFlags: (t, n) => {
                e[t] = n;
            },
            get: (t, n) => {
                var r, s;
                return (
                    null !==
                        (s =
                            null === (r = e[t]) || void 0 === r
                                ? void 0
                                : r[n]) &&
                    void 0 !== s &&
                    s
                );
            },
        }),
        Ke
    );
}
var Be,
    ze = {};
function qe() {
    return (
        Be ||
            ((Be = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.StatsigSession = e.SessionID = void 0);
                const t = f(),
                    n = x(),
                    r = d(),
                    s = K(),
                    o = oe(),
                    i = 18e5,
                    a = 144e5,
                    c = {};
                function u(e, n) {
                    return setTimeout(() => {
                        var n;
                        const r =
                            null === (n = (0, t._getStatsigGlobal)()) ||
                            void 0 === n
                                ? void 0
                                : n.instance(e);
                        r && r.$emt({ name: "session_expired" });
                    }, n);
                }
                function l(e) {
                    return `statsig.session_id.${(0, n._getStorageKey)(e)}`;
                }
                (e.SessionID = {
                    get: (t) => e.StatsigSession.get(t).data.sessionID,
                }),
                    (e.StatsigSession = {
                        get: (e) => {
                            null == c[e] &&
                                (c[e] = (function (e) {
                                    let t = (function (e) {
                                        const t = l(e);
                                        return (0, s._getObjectFromStorage)(t);
                                    })(e);
                                    const n = Date.now();
                                    t ||
                                        (t = {
                                            sessionID: (0, o.getUUID)(),
                                            startTime: n,
                                            lastUpdate: n,
                                        });
                                    return { data: t, sdkKey: e };
                                })(e));
                            return (function (e) {
                                const t = Date.now(),
                                    n = e.data,
                                    c = e.sdkKey;
                                if (
                                    (function ({ lastUpdate: e }) {
                                        return Date.now() - e > i;
                                    })(n) ||
                                    (function ({ startTime: e }) {
                                        return Date.now() - e > a;
                                    })(n)
                                ) {
                                    (n.sessionID = (0, o.getUUID)()),
                                        (n.startTime = t);
                                    const e =
                                        null === __STATSIG__ ||
                                        void 0 === __STATSIG__
                                            ? void 0
                                            : __STATSIG__.instance(c);
                                    e && e.$emt({ name: "session_expired" });
                                }
                                (n.lastUpdate = t),
                                    (function (e, t) {
                                        const n = l(t);
                                        try {
                                            (0, s._setObjectInStorage)(n, e);
                                        } catch (o) {
                                            r.Log.warn(
                                                "Failed to save SessionID"
                                            );
                                        }
                                    })(n, e.sdkKey),
                                    clearTimeout(e.idleTimeoutID),
                                    clearTimeout(e.ageTimeoutID);
                                const d = t - n.startTime;
                                return (
                                    (e.idleTimeoutID = u(c, i)),
                                    (e.ageTimeoutID = u(c, a - d)),
                                    e
                                );
                            })(c[e]);
                        },
                        overrideInitialSessionID: (e, t) => {
                            c[t] = (function (e, t) {
                                const n = Date.now();
                                return {
                                    data: {
                                        sessionID: e,
                                        startTime: n,
                                        lastUpdate: n,
                                    },
                                    sdkKey: t,
                                };
                            })(e, t);
                        },
                    });
            })(ze)),
        ze
    );
}
var Ve,
    Ge,
    We = {};
function He() {
    return (
        Ve ||
            ((Ve = 1),
            Object.defineProperty(We, "__esModule", { value: !0 }),
            (We.ErrorTag = void 0),
            (We.ErrorTag = { NetworkError: "NetworkError" })),
        We
    );
}
function Je() {
    if (Ge) return je;
    Ge = 1;
    var e =
        (je && je.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(je, "__esModule", { value: !0 }),
        (je.NetworkCore = void 0),
        f();
    const t = f(),
        n = _(),
        r = d(),
        s = D(),
        o = Ne(),
        i = Fe(),
        a = Ee(),
        c = P(),
        u = qe(),
        l = ie(),
        h = He(),
        p = X(),
        g = M(),
        m = W(),
        v = new Set([408, 500, 502, 503, 504, 522, 524, 599]);
    je.NetworkCore = class {
        constructor(e, t) {
            (this._emitter = t),
                (this._errorBoundary = null),
                (this._timeout = 1e4),
                (this._netConfig = {}),
                (this._options = {}),
                (this._leakyBucket = {}),
                (this._lastUsedInitUrl = null),
                e && (this._options = e),
                this._options.networkConfig &&
                    (this._netConfig = this._options.networkConfig),
                this._netConfig.networkTimeoutMs &&
                    (this._timeout = this._netConfig.networkTimeoutMs),
                (this._fallbackResolver = new o.NetworkFallbackResolver(
                    this._options
                )),
                this.setLogEventCompressionMode(
                    this._getLogEventCompressionMode(e)
                );
        }
        setLogEventCompressionMode(e) {
            this._options.logEventCompressionMode = e;
        }
        setErrorBoundary(e) {
            (this._errorBoundary = e),
                this._errorBoundary.wrap(this),
                this._errorBoundary.wrap(this._fallbackResolver),
                this._fallbackResolver.setErrorBoundary(e);
        }
        isBeaconSupported() {
            return (
                "undefined" != typeof navigator &&
                "function" == typeof navigator.sendBeacon
            );
        }
        getLastUsedInitUrlAndReset() {
            const e = this._lastUsedInitUrl;
            return (this._lastUsedInitUrl = null), e;
        }
        beacon(e) {
            if (!y(e)) return !1;
            const t = this._getInternalRequestArgs("POST", e),
                n = this._getPopulatedURL(t),
                r = navigator;
            return r.sendBeacon.bind(r)(n, t.body);
        }
        post(t) {
            return e(this, void 0, void 0, function* () {
                const e = this._getInternalRequestArgs("POST", t);
                return (
                    this._tryEncodeBody(e),
                    yield this._tryToCompressBody(e),
                    this._sendRequest(e)
                );
            });
        }
        get(e) {
            const t = this._getInternalRequestArgs("GET", e);
            return this._sendRequest(t);
        }
        _sendRequest(t) {
            return e(this, void 0, void 0, function* () {
                var o, i, a, c;
                if (!y(t)) return null;
                if (this._netConfig.preventAllNetworkTraffic) return null;
                const { method: u, body: l, retries: d, attempt: f } = t,
                    p = t.urlConfig.endpoint;
                if (this._isRateLimited(p))
                    return (
                        r.Log.warn(
                            `Request to ${p} was blocked because you are making requests too frequently.`
                        ),
                        null
                    );
                const _ = null != f ? f : 1,
                    g =
                        "undefined" != typeof AbortController
                            ? new AbortController()
                            : null,
                    b = setTimeout(() => {
                        null == g ||
                            g.abort(`Timeout of ${this._timeout}ms expired.`);
                    }, this._timeout),
                    S = this._getPopulatedURL(t);
                let k = null;
                const w = (0, m._isUnloading)();
                try {
                    const e = {
                        method: u,
                        body: l,
                        headers: Object.assign({}, t.headers),
                        signal: null == g ? void 0 : g.signal,
                        priority: t.priority,
                        keepalive: w,
                    };
                    !(function (e, t) {
                        if (e.urlConfig.endpoint !== s.Endpoint._initialize)
                            return;
                        n.Diagnostics._markInitNetworkReqStart(e.sdkKey, {
                            attempt: t,
                        });
                    })(t, _);
                    const r = this._leakyBucket[p];
                    r &&
                        ((r.lastRequestTime = Date.now()),
                        (this._leakyBucket[p] = r));
                    const i =
                        null !== (o = this._netConfig.networkOverrideFunc) &&
                        void 0 !== o
                            ? o
                            : fetch;
                    if (((k = yield i(S, e)), clearTimeout(b), !k.ok)) {
                        const e = yield k.text().catch(() => "No Text"),
                            t = new Error(`NetworkError: ${S} ${e}`);
                        throw ((t.name = "NetworkError"), t);
                    }
                    const a = yield k.text();
                    return (
                        E(t, k, _, a),
                        this._fallbackResolver.tryBumpExpiryTime(
                            t.sdkKey,
                            t.urlConfig
                        ),
                        { body: a, code: k.status }
                    );
                } catch (O) {
                    const n = (function (e, t) {
                            if (
                                (null == e ? void 0 : e.signal.aborted) &&
                                "string" == typeof e.signal.reason
                            )
                                return e.signal.reason;
                            if ("string" == typeof t) return t;
                            if (t instanceof Error)
                                return `${t.name}: ${t.message}`;
                            return "Unknown Error";
                        })(g, O),
                        s =
                            ((null == (x = g) ? void 0 : x.signal.aborted) &&
                                "string" == typeof x.signal.reason &&
                                x.signal.reason.includes("Timeout")) ||
                            !1;
                    E(t, k, _, "", O);
                    if (
                        ((yield this._fallbackResolver.tryFetchUpdatedFallbackInfo(
                            t.sdkKey,
                            t.urlConfig,
                            n,
                            s
                        )) &&
                            (t.fallbackUrl =
                                this._fallbackResolver.getActiveFallbackUrl(
                                    t.sdkKey,
                                    t.urlConfig
                                )),
                        !d ||
                            _ > d ||
                            !v.has(
                                null !== (i = null == k ? void 0 : k.status) &&
                                    void 0 !== i
                                    ? i
                                    : 500
                            ))
                    ) {
                        null === (a = this._emitter) ||
                            void 0 === a ||
                            a.call(this, {
                                name: "error",
                                error: O,
                                tag: h.ErrorTag.NetworkError,
                                requestArgs: t,
                            });
                        const e = `A networking error occurred during ${u} request to ${S}.`;
                        return (
                            r.Log.error(e, n, O),
                            null === (c = this._errorBoundary) ||
                                void 0 === c ||
                                c.attachErrorIfNoneExists(e),
                            null
                        );
                    }
                    return (
                        yield (function (t) {
                            return e(this, void 0, void 0, function* () {
                                yield new Promise((e) =>
                                    setTimeout(e, Math.min(t * t * 500, 3e4))
                                );
                            });
                        })(_),
                        this._sendRequest(
                            Object.assign(Object.assign({}, t), {
                                retries: d,
                                attempt: _ + 1,
                            })
                        )
                    );
                }
                var x;
            });
        }
        _getLogEventCompressionMode(e) {
            let t = null == e ? void 0 : e.logEventCompressionMode;
            return (
                t ||
                    !0 !== (null == e ? void 0 : e.disableCompression) ||
                    (t = g.LogEventCompressionMode.Disabled),
                t || (t = g.LogEventCompressionMode.Enabled),
                t
            );
        }
        _isRateLimited(e) {
            var t;
            const n = Date.now(),
                r =
                    null !== (t = this._leakyBucket[e]) && void 0 !== t
                        ? t
                        : { count: 0, lastRequestTime: n },
                s = n - r.lastRequestTime,
                o = Math.floor(0.05 * s);
            return (
                (r.count = Math.max(0, r.count - o)),
                r.count >= 50 ||
                    ((r.count += 1),
                    (r.lastRequestTime = n),
                    (this._leakyBucket[e] = r),
                    !1)
            );
        }
        _getPopulatedURL(e) {
            var t;
            const n =
                null !== (t = e.fallbackUrl) && void 0 !== t
                    ? t
                    : e.urlConfig.getUrl();
            (e.urlConfig.endpoint !== s.Endpoint._initialize &&
                e.urlConfig.endpoint !== s.Endpoint._download_config_specs) ||
                (this._lastUsedInitUrl = n);
            const r = Object.assign(
                    {
                        [s.NetworkParam.SdkKey]: e.sdkKey,
                        [s.NetworkParam.SdkType]: a.SDKType._get(e.sdkKey),
                        [s.NetworkParam.SdkVersion]: p.SDK_VERSION,
                        [s.NetworkParam.Time]: String(Date.now()),
                        [s.NetworkParam.SessionID]: u.SessionID.get(e.sdkKey),
                    },
                    e.params
                ),
                o = Object.keys(r)
                    .map(
                        (e) =>
                            `${encodeURIComponent(e)}=${encodeURIComponent(
                                r[e]
                            )}`
                    )
                    .join("&");
            return `${n}${o ? `?${o}` : ""}`;
        }
        _tryEncodeBody(e) {
            var n;
            const o = (0, c._getWindowSafe)(),
                i = e.body;
            if (
                e.isStatsigEncodable &&
                !this._options.disableStatsigEncoding &&
                "string" == typeof i &&
                null == (0, t._getStatsigGlobalFlag)("no-encode") &&
                (null == o ? void 0 : o.btoa)
            )
                try {
                    (e.body = o.btoa(i).split("").reverse().join("")),
                        (e.params = Object.assign(
                            Object.assign(
                                {},
                                null !== (n = e.params) && void 0 !== n ? n : {}
                            ),
                            { [s.NetworkParam.StatsigEncoded]: "1" }
                        ));
                } catch (a) {
                    r.Log.warn(
                        `Request encoding failed for ${e.urlConfig.getUrl()}`,
                        a
                    );
                }
        }
        _tryToCompressBody(n) {
            return e(this, void 0, void 0, function* () {
                var e;
                const o = n.body;
                if (
                    "string" == typeof o &&
                    (function (e, n) {
                        if (!e.isCompressable) return !1;
                        if (
                            null !=
                                (0, t._getStatsigGlobalFlag)("no-compress") ||
                            "undefined" == typeof CompressionStream ||
                            "undefined" == typeof TextEncoder
                        )
                            return !1;
                        const r =
                                null != e.urlConfig.customUrl ||
                                null != e.urlConfig.fallbackUrls,
                            s =
                                !0 ===
                                i.SDKFlags.get(
                                    e.sdkKey,
                                    "enable_log_event_compression"
                                );
                        switch (n.logEventCompressionMode) {
                            case g.LogEventCompressionMode.Disabled:
                                return !1;
                            case g.LogEventCompressionMode.Enabled:
                                return !(r && !s);
                            case g.LogEventCompressionMode.Forced:
                                return !0;
                            default:
                                return !1;
                        }
                    })(n, this._options)
                )
                    try {
                        const t = new TextEncoder().encode(o),
                            i = new CompressionStream("gzip"),
                            a = i.writable.getWriter();
                        a.write(t).catch(r.Log.error),
                            a.close().catch(r.Log.error);
                        const c = i.readable.getReader(),
                            u = [];
                        let l;
                        for (; !(l = yield c.read()).done; ) u.push(l.value);
                        const d = u.reduce((e, t) => e + t.length, 0),
                            f = new Uint8Array(d);
                        let h = 0;
                        for (const e of u) f.set(e, h), (h += e.length);
                        (n.body = f),
                            (n.params = Object.assign(
                                Object.assign(
                                    {},
                                    null !== (e = n.params) && void 0 !== e
                                        ? e
                                        : {}
                                ),
                                { [s.NetworkParam.IsGzipped]: "1" }
                            ));
                    } catch (a) {
                        r.Log.warn(
                            `Request compression failed for ${n.urlConfig.getUrl()}`,
                            a
                        );
                    }
            });
        }
        _getInternalRequestArgs(e, t) {
            const n = this._fallbackResolver.getActiveFallbackUrl(
                    t.sdkKey,
                    t.urlConfig
                ),
                r = Object.assign(Object.assign({}, t), {
                    method: e,
                    fallbackUrl: n,
                });
            return "data" in t && b(r, t.data), r;
        }
    };
    const y = (e) =>
            !!e.sdkKey ||
            (r.Log.warn("Unable to make request without an SDK key"), !1),
        b = (e, t) => {
            const { sdkKey: n, fallbackUrl: r } = e,
                s = l.StableID.get(n),
                o = u.SessionID.get(n),
                i = a.SDKType._get(n);
            e.body = JSON.stringify(
                Object.assign(Object.assign({}, t), {
                    statsigMetadata: Object.assign(
                        Object.assign({}, p.StatsigMetadataProvider.get()),
                        {
                            stableID: s,
                            sessionID: o,
                            sdkType: i,
                            fallbackUrl: r,
                        }
                    ),
                })
            );
        };
    function E(e, t, r, o, i) {
        e.urlConfig.endpoint === s.Endpoint._initialize &&
            n.Diagnostics._markInitNetworkReqEnd(
                e.sdkKey,
                n.Diagnostics._getDiagnosticsData(t, r, o, i)
            );
    }
    return je;
}
var Ye,
    Xe = {};
var Qe,
    Ze = {};
var et,
    tt = {};
var nt,
    rt = {};
function st() {
    if (nt) return rt;
    nt = 1;
    var e =
        (rt && rt.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(rt, "__esModule", { value: !0 }),
        (rt.StatsigClientBase = void 0),
        f();
    const t = f(),
        n = Se(),
        r = H(),
        s = d(),
        o = Pe(),
        i = P(),
        a = qe(),
        c = ie(),
        u = M(),
        l = K();
    return (
        (rt.StatsigClientBase = class {
            constructor(e, o, u, d) {
                var f, h, p, _;
                (this.loadingStatus = "Uninitialized"),
                    (this._initializePromise = null),
                    (this._listeners = {});
                const g = this.$emt.bind(this);
                null != (null == d ? void 0 : d.logLevel) &&
                    (s.Log.level = d.logLevel),
                    (null == d ? void 0 : d.disableStorage) &&
                        l.Storage._setDisabled(!0),
                    (null == d ? void 0 : d.initialSessionID) &&
                        a.StatsigSession.overrideInitialSessionID(
                            d.initialSessionID,
                            e
                        ),
                    (null == d ? void 0 : d.storageProvider) &&
                        l.Storage._setProvider(d.storageProvider),
                    (null == d ? void 0 : d.enableCookies) &&
                        c.StableID._setCookiesEnabled(e, d.enableCookies),
                    (null == d ? void 0 : d.disableStableID) &&
                        c.StableID._setDisabled(e, !0),
                    (this._sdkKey = e),
                    (this._options = null != d ? d : {}),
                    (this._memoCache = {}),
                    (this.overrideAdapter =
                        null !== (f = null == d ? void 0 : d.overrideAdapter) &&
                        void 0 !== f
                            ? f
                            : null),
                    (this._logger = new r.EventLogger(e, g, u, d)),
                    (this._errorBoundary = new n.ErrorBoundary(e, d, g)),
                    this._errorBoundary.wrap(this),
                    this._errorBoundary.wrap(o),
                    this._errorBoundary.wrap(this._logger),
                    u.setErrorBoundary(this._errorBoundary),
                    (this.dataAdapter = o),
                    this.dataAdapter.attach(e, d, u),
                    (this.storageProvider = l.Storage),
                    null ===
                        (_ =
                            null ===
                                (p =
                                    null === (h = this.overrideAdapter) ||
                                    void 0 === h
                                        ? void 0
                                        : h.loadFromStorage) || void 0 === p
                                ? void 0
                                : p.call(h)) ||
                        void 0 === _ ||
                        _.catch((e) =>
                            this._errorBoundary.logError(
                                "OA::loadFromStorage",
                                e
                            )
                        ),
                    this._primeReadyRipcord(),
                    (function (e, n) {
                        var r;
                        if ((0, i._isServerEnv)()) return;
                        const o = (0, t._getStatsigGlobal)(),
                            a =
                                null !== (r = o.instances) && void 0 !== r
                                    ? r
                                    : {},
                            c = n;
                        null != a[e] &&
                            s.Log.warn(
                                "Creating multiple Statsig clients with the same SDK key can lead to unexpected behavior. Multi-instance support requires different SDK keys."
                            );
                        (a[e] = c), o.firstInstance || (o.firstInstance = c);
                        (o.instances = a), (__STATSIG__ = o);
                    })(e, this);
            }
            updateRuntimeOptions(e) {
                e.loggingEnabled
                    ? ((this._options.loggingEnabled = e.loggingEnabled),
                      this._logger.setLoggingEnabled(e.loggingEnabled))
                    : null != e.disableLogging &&
                      ((this._options.disableLogging = e.disableLogging),
                      this._logger.setLoggingEnabled(
                          e.disableLogging ? "disabled" : "browser-only"
                      )),
                    null != e.disableStorage &&
                        ((this._options.disableStorage = e.disableStorage),
                        l.Storage._setDisabled(e.disableStorage)),
                    null != e.enableCookies &&
                        ((this._options.enableCookies = e.enableCookies),
                        c.StableID._setCookiesEnabled(
                            this._sdkKey,
                            e.enableCookies
                        )),
                    e.logEventCompressionMode
                        ? this._logger.setLogEventCompressionMode(
                              e.logEventCompressionMode
                          )
                        : e.disableCompression &&
                          this._logger.setLogEventCompressionMode(
                              u.LogEventCompressionMode.Disabled
                          );
            }
            flush() {
                return this._logger.flush();
            }
            shutdown() {
                return e(this, void 0, void 0, function* () {
                    this.$emt({ name: "pre_shutdown" }),
                        this._setStatus("Uninitialized", null),
                        (this._initializePromise = null),
                        yield this._logger.stop();
                });
            }
            on(e, t) {
                this._listeners[e] || (this._listeners[e] = []),
                    this._listeners[e].push(t);
            }
            off(e, t) {
                if (this._listeners[e]) {
                    const n = this._listeners[e].indexOf(t);
                    -1 !== n && this._listeners[e].splice(n, 1);
                }
            }
            $on(e, t) {
                (t.__isInternal = !0), this.on(e, t);
            }
            $emt(e) {
                var t;
                const n = (t) => {
                    try {
                        t(e);
                    } catch (n) {
                        if (!0 === t.__isInternal)
                            return void this._errorBoundary.logError(
                                `__emit:${e.name}`,
                                n
                            );
                        s.Log.error(
                            "An error occurred in a StatsigClientEvent listener. This is not an issue with Statsig.",
                            e
                        );
                    }
                };
                this._listeners[e.name] &&
                    this._listeners[e.name].forEach((e) => n(e)),
                    null === (t = this._listeners["*"]) ||
                        void 0 === t ||
                        t.forEach(n);
            }
            _setStatus(e, t) {
                (this.loadingStatus = e),
                    (this._memoCache = {}),
                    this.$emt({ name: "values_updated", status: e, values: t });
            }
            _enqueueExposure(e, t, n) {
                !0 !== (null == n ? void 0 : n.disableExposureLog)
                    ? this._logger.enqueue(t)
                    : this._logger.incrementNonExposureCount(e);
            }
            _memoize(e, t) {
                return (n, r) => {
                    if (this._options.disableEvaluationMemoization)
                        return t(n, r);
                    const s = (0, o.createMemoKey)(e, n, r);
                    return s
                        ? (s in this._memoCache ||
                              (Object.keys(this._memoCache).length >= 3e3 &&
                                  (this._memoCache = {}),
                              (this._memoCache[s] = t(n, r))),
                          this._memoCache[s])
                        : t(n, r);
                };
            }
        }),
        rt
    );
}
var ot,
    it = {};
var at,
    ct = {};
var ut,
    lt = {};
var dt,
    ft = {};
var ht,
    pt,
    _t = {};
function gt() {
    return (
        pt ||
            ((pt = 1),
            (function (e) {
                var t =
                        (c && c.__createBinding) ||
                        (Object.create
                            ? function (e, t, n, r) {
                                  void 0 === r && (r = n);
                                  var s = Object.getOwnPropertyDescriptor(t, n);
                                  (s &&
                                      !("get" in s
                                          ? !t.__esModule
                                          : s.writable || s.configurable)) ||
                                      (s = {
                                          enumerable: !0,
                                          get: function () {
                                              return t[n];
                                          },
                                      }),
                                      Object.defineProperty(e, r, s);
                              }
                            : function (e, t, n, r) {
                                  void 0 === r && (r = n), (e[r] = t[n]);
                              }),
                    n =
                        (c && c.__exportStar) ||
                        function (e, n) {
                            for (var r in e)
                                "default" === r ||
                                    Object.prototype.hasOwnProperty.call(
                                        n,
                                        r
                                    ) ||
                                    t(n, e, r);
                        };
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Storage =
                        e.Log =
                        e.EventLogger =
                        e.Diagnostics =
                            void 0),
                    f();
                const r = f(),
                    s = _();
                Object.defineProperty(e, "Diagnostics", {
                    enumerable: !0,
                    get: function () {
                        return s.Diagnostics;
                    },
                });
                const o = H();
                Object.defineProperty(e, "EventLogger", {
                    enumerable: !0,
                    get: function () {
                        return o.EventLogger;
                    },
                });
                const i = d();
                Object.defineProperty(e, "Log", {
                    enumerable: !0,
                    get: function () {
                        return i.Log;
                    },
                });
                const a = X(),
                    u = K();
                Object.defineProperty(e, "Storage", {
                    enumerable: !0,
                    get: function () {
                        return u.Storage;
                    },
                }),
                    n(f(), e),
                    n(x(), e),
                    n(
                        (Q ||
                            ((Q = 1),
                            Object.defineProperty(Z, "__esModule", {
                                value: !0,
                            })),
                        Z),
                        e
                    ),
                    n(pe(), e),
                    n(_(), e),
                    n(
                        (_e ||
                            ((_e = 1),
                            Object.defineProperty(ge, "__esModule", {
                                value: !0,
                            })),
                        ge),
                        e
                    ),
                    n(Se(), e),
                    n(
                        (ke ||
                            ((ke = 1),
                            Object.defineProperty(we, "__esModule", {
                                value: !0,
                            })),
                        we),
                        e
                    ),
                    n(
                        (xe ||
                            ((xe = 1),
                            Object.defineProperty(Oe, "__esModule", {
                                value: !0,
                            })),
                        Oe),
                        e
                    ),
                    n(w(), e),
                    n(
                        (Ie ||
                            ((Ie = 1),
                            Object.defineProperty(De, "__esModule", {
                                value: !0,
                            })),
                        De),
                        e
                    ),
                    n(d(), e),
                    n(Pe(), e),
                    n(D(), e),
                    n(Je(), e),
                    n(
                        (Ye ||
                            ((Ye = 1),
                            Object.defineProperty(Xe, "__esModule", {
                                value: !0,
                            })),
                        Xe),
                        e
                    ),
                    n(
                        (Qe ||
                            ((Qe = 1),
                            Object.defineProperty(Ze, "__esModule", {
                                value: !0,
                            })),
                        Ze),
                        e
                    ),
                    n(P(), e),
                    n(Ee(), e),
                    n(qe(), e),
                    n(
                        (et ||
                            ((et = 1),
                            (function (e) {
                                Object.defineProperty(e, "__esModule", {
                                    value: !0,
                                }),
                                    (e._fastApproxSizeOf = void 0),
                                    (e._fastApproxSizeOf = (t, n) => {
                                        let r = 0;
                                        const s = Object.keys(t);
                                        for (let o = 0; o < s.length; o++) {
                                            const i = s[o],
                                                a = t[i];
                                            if (
                                                ((r += i.length),
                                                (r +=
                                                    "object" == typeof a &&
                                                    null !== a
                                                        ? (0,
                                                          e._fastApproxSizeOf)(
                                                              a,
                                                              n
                                                          ) + 2
                                                        : String(a).length + 1),
                                                r >= n)
                                            )
                                                return r;
                                        }
                                        return r;
                                    });
                            })(tt)),
                        tt),
                        e
                    ),
                    n(ie(), e),
                    n(st(), e),
                    n(He(), e),
                    n(
                        (ot ||
                            ((ot = 1),
                            Object.defineProperty(it, "__esModule", {
                                value: !0,
                            }),
                            (it.DataAdapterCachePrefix = void 0),
                            (it.DataAdapterCachePrefix = "statsig.cached")),
                        it),
                        e
                    ),
                    n(j(), e),
                    n(X(), e),
                    n(M(), e),
                    n(
                        (at ||
                            ((at = 1),
                            Object.defineProperty(ct, "__esModule", {
                                value: !0,
                            })),
                        ct),
                        e
                    ),
                    n(
                        (function () {
                            if (ut) return lt;
                            (ut = 1),
                                Object.defineProperty(lt, "__esModule", {
                                    value: !0,
                                }),
                                (lt._makeTypedGet =
                                    lt._mergeOverride =
                                    lt._makeLayer =
                                    lt._makeExperiment =
                                    lt._makeDynamicConfig =
                                    lt._makeFeatureGate =
                                        void 0);
                            const e = d(),
                                t = k();
                            function n(e, t, n, r) {
                                var s;
                                return {
                                    name: e,
                                    details: t,
                                    ruleID:
                                        null !==
                                            (s =
                                                null == n
                                                    ? void 0
                                                    : n.rule_id) && void 0 !== s
                                            ? s
                                            : "",
                                    __evaluation: n,
                                    value: r,
                                };
                            }
                            function r(e, t, r) {
                                var o;
                                const i =
                                    null !==
                                        (o = null == r ? void 0 : r.value) &&
                                    void 0 !== o
                                        ? o
                                        : {};
                                return Object.assign(
                                    Object.assign({}, n(e, t, r, i)),
                                    { get: s(e, null == r ? void 0 : r.value) }
                                );
                            }
                            function s(n, r, s) {
                                return (o, i) => {
                                    var a;
                                    const c =
                                        null !==
                                            (a = null == r ? void 0 : r[o]) &&
                                        void 0 !== a
                                            ? a
                                            : null;
                                    return null == c
                                        ? null != i
                                            ? i
                                            : null
                                        : null == i || (0, t._isTypeMatch)(c, i)
                                        ? (null == s || s(o), c)
                                        : (e.Log.warn(
                                              `Parameter type mismatch. '${n}.${o}' was found to be type '${typeof c}' but fallback/return type is '${typeof i}'. See https://docs.statsig.com/client/javascript-sdk/#typed-getters`
                                          ),
                                          null != i ? i : null);
                                };
                            }
                            return (
                                (lt._makeFeatureGate = function (e, t, r) {
                                    var s;
                                    return Object.assign(
                                        Object.assign(
                                            {},
                                            n(
                                                e,
                                                t,
                                                r,
                                                !0 ===
                                                    (null == r
                                                        ? void 0
                                                        : r.value)
                                            )
                                        ),
                                        {
                                            idType:
                                                null !==
                                                    (s =
                                                        null == r
                                                            ? void 0
                                                            : r.id_type) &&
                                                void 0 !== s
                                                    ? s
                                                    : null,
                                        }
                                    );
                                }),
                                (lt._makeDynamicConfig = r),
                                (lt._makeExperiment = function (e, t, n) {
                                    var s;
                                    const o = r(e, t, n);
                                    return Object.assign(Object.assign({}, o), {
                                        groupName:
                                            null !==
                                                (s =
                                                    null == n
                                                        ? void 0
                                                        : n.group_name) &&
                                            void 0 !== s
                                                ? s
                                                : null,
                                    });
                                }),
                                (lt._makeLayer = function (e, t, r, o) {
                                    var i, a;
                                    return Object.assign(
                                        Object.assign({}, n(e, t, r, void 0)),
                                        {
                                            get: s(
                                                e,
                                                null == r ? void 0 : r.value,
                                                o
                                            ),
                                            groupName:
                                                null !==
                                                    (i =
                                                        null == r
                                                            ? void 0
                                                            : r.group_name) &&
                                                void 0 !== i
                                                    ? i
                                                    : null,
                                            __value:
                                                null !==
                                                    (a =
                                                        null == r
                                                            ? void 0
                                                            : r.value) &&
                                                void 0 !== a
                                                    ? a
                                                    : {},
                                        }
                                    );
                                }),
                                (lt._mergeOverride = function (e, t, n, r) {
                                    return Object.assign(
                                        Object.assign(Object.assign({}, e), t),
                                        { get: s(e.name, n, r) }
                                    );
                                }),
                                (lt._makeTypedGet = s),
                                lt
                            );
                        })(),
                        e
                    ),
                    n(
                        (dt ||
                            ((dt = 1),
                            Object.defineProperty(ft, "__esModule", {
                                value: !0,
                            })),
                        ft),
                        e
                    ),
                    n(ue(), e),
                    n(K(), e),
                    n(he(), e),
                    n(k(), e),
                    n(z(), e),
                    n(oe(), e),
                    n(W(), e),
                    n(
                        (ht ||
                            ((ht = 1),
                            Object.defineProperty(_t, "__esModule", {
                                value: !0,
                            }),
                            (_t.UPDATE_DETAIL_ERROR_MESSAGES =
                                _t.createUpdateDetails =
                                    void 0),
                            (_t.createUpdateDetails = (e, t, n, r, s, o) => ({
                                duration: n,
                                source: t,
                                success: e,
                                error: r,
                                sourceUrl: s,
                                warnings: o,
                            })),
                            (_t.UPDATE_DETAIL_ERROR_MESSAGES = {
                                NO_NETWORK_DATA:
                                    "No data was returned from the network. This may be due to a network timeout if a timeout value was specified in the options or ad blocker error.",
                            })),
                        _t),
                        e
                    ),
                    n(Fe(), e),
                    Object.assign((0, r._getStatsigGlobal)(), {
                        Log: i.Log,
                        SDK_VERSION: a.SDK_VERSION,
                    });
            })(c)),
        c
    );
}
var mt,
    vt = {},
    yt = {};
var bt,
    Et,
    St = {},
    kt = {};
function wt() {
    if (bt) return kt;
    (bt = 1),
        Object.defineProperty(kt, "__esModule", { value: !0 }),
        (kt._resolveDeltasResponse = void 0);
    const e = gt();
    function t(e, t) {
        null == e ||
            e.forEach((e) => {
                delete t[e];
            });
    }
    return (
        (kt._resolveDeltasResponse = function (n, r) {
            const s = (0, e._typedJsonParse)(
                r,
                "checksum",
                "DeltasEvaluationResponse"
            );
            if (!s) return { hadBadDeltaChecksum: !0 };
            const o = (function (e) {
                    const n = e;
                    return (
                        t(e.deleted_gates, n.feature_gates),
                        delete n.deleted_gates,
                        t(e.deleted_configs, n.dynamic_configs),
                        delete n.deleted_configs,
                        t(e.deleted_layers, n.layer_configs),
                        delete n.deleted_layers,
                        n
                    );
                })(
                    (function (e, t) {
                        return Object.assign(
                            Object.assign(Object.assign({}, e), t),
                            {
                                feature_gates: Object.assign(
                                    Object.assign({}, e.feature_gates),
                                    t.feature_gates
                                ),
                                layer_configs: Object.assign(
                                    Object.assign({}, e.layer_configs),
                                    t.layer_configs
                                ),
                                dynamic_configs: Object.assign(
                                    Object.assign({}, e.dynamic_configs),
                                    t.dynamic_configs
                                ),
                            }
                        );
                    })(n, s)
                ),
                i = (0, e._DJB2Object)(
                    {
                        feature_gates: o.feature_gates,
                        dynamic_configs: o.dynamic_configs,
                        layer_configs: o.layer_configs,
                    },
                    2
                );
            return i === s.checksumV2
                ? JSON.stringify(o)
                : {
                      hadBadDeltaChecksum: !0,
                      badChecksum: i,
                      badMergedConfigs: o,
                      badFullResponse: s.deltas_full_response,
                  };
        }),
        kt
    );
}
function xt() {
    if (Et) return St;
    Et = 1;
    var e =
        (St && St.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(St, "__esModule", { value: !0 });
    const t = gt(),
        n = wt();
    class r extends t.NetworkCore {
        constructor(e, n) {
            super(e, n);
            const r = null == e ? void 0 : e.networkConfig;
            (this._option = e),
                (this._initializeUrlConfig = new t.UrlConfiguration(
                    t.Endpoint._initialize,
                    null == r ? void 0 : r.initializeUrl,
                    null == r ? void 0 : r.api,
                    null == r ? void 0 : r.initializeFallbackUrls
                ));
        }
        fetchEvaluations(n, r, s, o, i) {
            return e(this, void 0, void 0, function* () {
                var e, a, c, u, l, d;
                const f = r
                    ? (0, t._typedJsonParse)(
                          r,
                          "has_updates",
                          "InitializeResponse"
                      )
                    : null;
                let h = {
                    user: o,
                    hash:
                        null !==
                            (c =
                                null ===
                                    (a =
                                        null === (e = this._option) ||
                                        void 0 === e
                                            ? void 0
                                            : e.networkConfig) || void 0 === a
                                    ? void 0
                                    : a.initializeHashAlgorithm) && void 0 !== c
                            ? c
                            : "djb2",
                    deltasResponseRequested: !1,
                    full_checksum: null,
                };
                if (null == f ? void 0 : f.has_updates) {
                    const e =
                        (null == f ? void 0 : f.hash_used) !==
                        (null !==
                            (d =
                                null ===
                                    (l =
                                        null === (u = this._option) ||
                                        void 0 === u
                                            ? void 0
                                            : u.networkConfig) || void 0 === l
                                    ? void 0
                                    : l.initializeHashAlgorithm) && void 0 !== d
                            ? d
                            : "djb2");
                    h = Object.assign(Object.assign({}, h), {
                        sinceTime: i && !e ? f.time : 0,
                        previousDerivedFields:
                            "derived_fields" in f && i ? f.derived_fields : {},
                        deltasResponseRequested: !0,
                        full_checksum: f.full_checksum,
                        partialUserMatchSinceTime: e ? 0 : f.time,
                    });
                }
                return this._fetchEvaluations(n, f, h, s);
            });
        }
        _fetchEvaluations(t, r, s, o) {
            return e(this, void 0, void 0, function* () {
                var e, i;
                const a = yield this.post({
                    sdkKey: t,
                    urlConfig: this._initializeUrlConfig,
                    data: s,
                    retries: 2,
                    isStatsigEncodable: !0,
                    priority: o,
                });
                if (204 === (null == a ? void 0 : a.code))
                    return '{"has_updates": false}';
                if (200 !== (null == a ? void 0 : a.code))
                    return null !== (e = null == a ? void 0 : a.body) &&
                        void 0 !== e
                        ? e
                        : null;
                if (
                    !0 !== (null == r ? void 0 : r.has_updates) ||
                    !0 !==
                        (null === (i = a.body) || void 0 === i
                            ? void 0
                            : i.includes('"is_delta":true')) ||
                    !0 !== s.deltasResponseRequested
                )
                    return a.body;
                const c = (0, n._resolveDeltasResponse)(r, a.body);
                return "string" == typeof c
                    ? c
                    : this._fetchEvaluations(
                          t,
                          r,
                          Object.assign(
                              Object.assign(Object.assign({}, s), c),
                              { deltasResponseRequested: !1 }
                          ),
                          o
                      );
            });
        }
    }
    return (St.default = r), St;
}
var Ot,
    It = {};
function Dt() {
    if (Ot) return It;
    (Ot = 1),
        Object.defineProperty(It, "__esModule", { value: !0 }),
        (It._makeParamStoreGetter = void 0);
    const e = gt(),
        t = { disableExposureLog: !0 };
    function n(e) {
        return null == e || !1 === e.disableExposureLog;
    }
    function r(t, n) {
        return null != n && !(0, e._isTypeMatch)(t, n);
    }
    return (
        (It._makeParamStoreGetter = function (s, o, i) {
            return (a, c) => {
                if (null == o) return c;
                const u = o[a];
                if (
                    null == u ||
                    (null != c && (0, e._typeOf)(c) !== u.param_type)
                )
                    return c;
                switch (u.ref_type) {
                    case "static":
                        return (function (e) {
                            return e.value;
                        })(u);
                    case "gate":
                        return (function (e, r, s) {
                            return e.getFeatureGate(
                                r.gate_name,
                                n(s) ? void 0 : t
                            ).value
                                ? r.pass_value
                                : r.fail_value;
                        })(s, u, i);
                    case "dynamic_config":
                        return (function (e, s, o, i) {
                            const a = e
                                .getDynamicConfig(
                                    s.config_name,
                                    n(i) ? void 0 : t
                                )
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    case "experiment":
                        return (function (e, s, o, i) {
                            const a = e
                                .getExperiment(
                                    s.experiment_name,
                                    n(i) ? void 0 : t
                                )
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    case "layer":
                        return (function (e, s, o, i) {
                            const a = e
                                .getLayer(s.layer_name, n(i) ? void 0 : t)
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    default:
                        return c;
                }
            };
        }),
        It
    );
}
var Ct,
    Tt,
    Pt,
    At = {};
function Rt() {
    if (Ct) return At;
    Ct = 1;
    var e =
        (At && At.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(At, "__esModule", { value: !0 }),
        (At.StatsigEvaluationsDataAdapter = void 0);
    const t = gt(),
        n = xt();
    let r = class extends t.DataAdapterCore {
        constructor() {
            super("EvaluationsDataAdapter", "evaluations"),
                (this._network = null),
                (this._options = null);
        }
        attach(e, t, r) {
            super.attach(e, t, r),
                null !== r && r instanceof n.default
                    ? (this._network = r)
                    : (this._network = new n.default(null != t ? t : {}));
        }
        getDataAsync(e, n, r) {
            return this._getDataAsyncImpl(
                e,
                (0, t._normalizeUser)(n, this._options),
                r
            );
        }
        prefetchData(e, t) {
            return this._prefetchDataImpl(e, t);
        }
        setData(e) {
            const n = (0, t._typedJsonParse)(e, "has_updates", "data");
            n && "user" in n
                ? super.setData(e, n.user)
                : t.Log.error(
                      "StatsigUser not found. You may be using an older server SDK version. Please upgrade your SDK or use setDataLegacy."
                  );
        }
        setDataLegacy(e, t) {
            super.setData(e, t);
        }
        _fetchFromNetwork(t, n, r, s) {
            return e(this, void 0, void 0, function* () {
                var e;
                const o = yield null === (e = this._network) || void 0 === e
                    ? void 0
                    : e.fetchEvaluations(
                          this._getSdkKey(),
                          t,
                          null == r ? void 0 : r.priority,
                          n,
                          s
                      );
                return null != o ? o : null;
            });
        }
        _getCacheKey(e) {
            var n;
            const r = (0, t._getStorageKey)(
                this._getSdkKey(),
                e,
                null === (n = this._options) || void 0 === n
                    ? void 0
                    : n.customUserCacheKeyFunc
            );
            return `${t.DataAdapterCachePrefix}.${this._cacheSuffix}.${r}`;
        }
        _isCachedResultValidFor204(e, n) {
            return (
                null != e.fullUserHash &&
                e.fullUserHash === (0, t._getFullUserHash)(n)
            );
        }
    };
    return (At.StatsigEvaluationsDataAdapter = r), At;
}
function jt() {
    if (Tt) return vt;
    Tt = 1;
    var e =
        (vt && vt.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(vt, "__esModule", { value: !0 });
    const t = gt(),
        n = (function () {
            if (mt) return yt;
            (mt = 1), Object.defineProperty(yt, "__esModule", { value: !0 });
            const e = gt();
            return (
                (yt.default = class {
                    constructor(e) {
                        (this._sdkKey = e),
                            (this._rawValues = null),
                            (this._values = null),
                            (this._source = "Uninitialized"),
                            (this._lcut = 0),
                            (this._receivedAt = 0),
                            (this._bootstrapMetadata = null),
                            (this._warnings = new Set());
                    }
                    reset() {
                        (this._values = null),
                            (this._rawValues = null),
                            (this._source = "Loading"),
                            (this._lcut = 0),
                            (this._receivedAt = 0),
                            (this._bootstrapMetadata = null),
                            this._warnings.clear();
                    }
                    finalize() {
                        this._values || (this._source = "NoValues");
                    }
                    getValues() {
                        return this._rawValues
                            ? (0, e._typedJsonParse)(
                                  this._rawValues,
                                  "has_updates",
                                  "EvaluationStoreValues"
                              )
                            : null;
                    }
                    setValues(t, n) {
                        var r;
                        if (!t) return !1;
                        const s = (0, e._typedJsonParse)(
                            t.data,
                            "has_updates",
                            "EvaluationResponse"
                        );
                        return (
                            null != s &&
                            ((this._source = t.source),
                            !0 !== (null == s ? void 0 : s.has_updates) ||
                                ((this._rawValues = t.data),
                                (this._lcut = s.time),
                                (this._receivedAt = t.receivedAt),
                                (this._values = s),
                                (this._bootstrapMetadata =
                                    this._extractBootstrapMetadata(
                                        t.source,
                                        s
                                    )),
                                t.source &&
                                    s.user &&
                                    this._setWarningState(n, s),
                                e.SDKFlags.setFlags(
                                    this._sdkKey,
                                    null !== (r = s.sdk_flags) && void 0 !== r
                                        ? r
                                        : {}
                                )),
                            !0)
                        );
                    }
                    getWarnings() {
                        if (0 !== this._warnings.size)
                            return Array.from(this._warnings);
                    }
                    getGate(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.feature_gates,
                            e
                        );
                    }
                    getConfig(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.dynamic_configs,
                            e
                        );
                    }
                    getConfigList() {
                        var e;
                        return (
                            null === (e = this._values) || void 0 === e
                                ? void 0
                                : e.dynamic_configs
                        )
                            ? Object.values(this._values.dynamic_configs).map(
                                  (e) => e.name
                              )
                            : [];
                    }
                    getLayer(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.layer_configs,
                            e
                        );
                    }
                    getParamStore(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.param_stores,
                            e
                        );
                    }
                    getSource() {
                        return this._source;
                    }
                    getExposureMapping() {
                        var e;
                        return null === (e = this._values) || void 0 === e
                            ? void 0
                            : e.exposures;
                    }
                    _extractBootstrapMetadata(e, t) {
                        if ("Bootstrap" !== e) return null;
                        const n = {};
                        return (
                            t.user && (n.user = t.user),
                            t.sdkInfo && (n.generatorSDKInfo = t.sdkInfo),
                            (n.lcut = t.time),
                            n
                        );
                    }
                    _getDetailedStoreResult(t, n) {
                        let r = null;
                        return (
                            t && (r = t[n] ? t[n] : t[(0, e._DJB2)(n)]),
                            { result: r, details: this._getDetails(null == r) }
                        );
                    }
                    _setWarningState(t, n) {
                        var r, s;
                        const o = e.StableID.get(this._sdkKey);
                        if (
                            (null === (r = t.customIDs) || void 0 === r
                                ? void 0
                                : r.stableID) === o ||
                            (!(null === (s = t.customIDs) || void 0 === s
                                ? void 0
                                : s.stableID) &&
                                !o)
                        ) {
                            if ("user" in n) {
                                const r = n.user,
                                    s = Object.assign(Object.assign({}, t), {
                                        analyticsOnlyMetadata: void 0,
                                        privateAttributes: void 0,
                                    });
                                (0, e._getFullUserHash)(s) !==
                                    (0, e._getFullUserHash)(r) &&
                                    this._warnings.add("PartialUserMatch");
                            }
                        } else this._warnings.add("StableIDMismatch");
                    }
                    getCurrentSourceDetails() {
                        if (
                            "Uninitialized" === this._source ||
                            "NoValues" === this._source
                        )
                            return { reason: this._source };
                        const e = {
                            reason: this._source,
                            lcut: this._lcut,
                            receivedAt: this._receivedAt,
                        };
                        return (
                            this._warnings.size > 0 &&
                                (e.warnings = Array.from(this._warnings)),
                            e
                        );
                    }
                    _getDetails(e) {
                        var t, n;
                        const r = this.getCurrentSourceDetails();
                        let s = r.reason;
                        const o =
                            null !== (t = r.warnings) && void 0 !== t ? t : [];
                        "Bootstrap" === this._source &&
                            o.length > 0 &&
                            (s += o[0]),
                            "Uninitialized" !== s &&
                                "NoValues" !== s &&
                                (s = `${s}:${
                                    e ? "Unrecognized" : "Recognized"
                                }`);
                        const i =
                            "Bootstrap" === this._source &&
                            null !== (n = this._bootstrapMetadata) &&
                            void 0 !== n
                                ? n
                                : void 0;
                        return (
                            i && (r.bootstrapMetadata = i),
                            Object.assign(Object.assign({}, r), { reason: s })
                        );
                    }
                }),
                yt
            );
        })(),
        r = xt(),
        s = Dt(),
        o = Rt();
    let i = class i extends t.StatsigClientBase {
        static instance(e) {
            const n = (0, t._getStatsigGlobal)().instance(e);
            return n instanceof i
                ? n
                : (t.Log.warn(
                      (0, t._isServerEnv)()
                          ? "StatsigClient.instance is not supported in server environments"
                          : "Unable to find StatsigClient instance"
                  ),
                  new i(null != e ? e : "", {}));
        }
        constructor(e, s, i = null) {
            var a, c;
            t.SDKType._setClientType(e, "javascript-client");
            const u = new r.default(i, (e) => {
                this.$emt(e);
            });
            super(
                e,
                null !== (a = null == i ? void 0 : i.dataAdapter) &&
                    void 0 !== a
                    ? a
                    : new o.StatsigEvaluationsDataAdapter(),
                u,
                i
            ),
                (this._possibleFirstTouchMetadata = {}),
                (this.getFeatureGate = this._memoize(
                    t.MemoPrefix._gate,
                    this._getFeatureGateImpl.bind(this)
                )),
                (this.getDynamicConfig = this._memoize(
                    t.MemoPrefix._dynamicConfig,
                    this._getDynamicConfigImpl.bind(this)
                )),
                (this.getExperiment = this._memoize(
                    t.MemoPrefix._experiment,
                    this._getExperimentImpl.bind(this)
                )),
                (this.getConfigList = this._memoize(
                    t.MemoPrefix._configList,
                    this._getConfigListImpl.bind(this)
                )),
                (this.getLayer = this._memoize(
                    t.MemoPrefix._layer,
                    this._getLayerImpl.bind(this)
                )),
                (this.getParameterStore = this._memoize(
                    t.MemoPrefix._paramStore,
                    this._getParameterStoreImpl.bind(this)
                )),
                (this._store = new n.default(e)),
                (this._network = u),
                (this._user = this._configureUser(s, i)),
                (this._sdkInstanceID = (0, t.getUUID)());
            const l =
                null !== (c = null == i ? void 0 : i.plugins) && void 0 !== c
                    ? c
                    : [];
            for (const t of l) t.bind(this);
        }
        initializeSync(e) {
            var n;
            return "Uninitialized" !== this.loadingStatus
                ? (0, t.createUpdateDetails)(
                      !0,
                      this._store.getSource(),
                      -1,
                      null,
                      null,
                      [
                          "MultipleInitializations",
                          ...(null !== (n = this._store.getWarnings()) &&
                          void 0 !== n
                              ? n
                              : []),
                      ]
                  )
                : (this._logger.start(), this.updateUserSync(this._user, e));
        }
        initializeAsync(t) {
            return e(this, void 0, void 0, function* () {
                return (
                    this._initializePromise ||
                        (this._initializePromise =
                            this._initializeAsyncImpl(t)),
                    this._initializePromise
                );
            });
        }
        updateUserSync(e, t) {
            const n = performance.now();
            try {
                return this._updateUserSyncImpl(e, t, n);
            } catch (r) {
                const e = r instanceof Error ? r : new Error(String(r));
                return this._createErrorUpdateDetails(e, n);
            }
        }
        _updateUserSyncImpl(e, n, r) {
            var s;
            const o = [
                ...(null !== (s = this._store.getWarnings()) && void 0 !== s
                    ? s
                    : []),
            ];
            this._resetForUser(e);
            const i = this.dataAdapter.getDataSync(this._user);
            null == i && o.push("NoCachedValues"),
                this._store.setValues(i, this._user),
                this._finalizeUpdate(i);
            const a = null == n ? void 0 : n.disableBackgroundCacheRefresh;
            return (
                !0 === a ||
                    (null == a &&
                        "Bootstrap" === (null == i ? void 0 : i.source)) ||
                    this._runPostUpdate(null != i ? i : null, this._user),
                (0, t.createUpdateDetails)(
                    !0,
                    this._store.getSource(),
                    performance.now() - r,
                    this._errorBoundary.getLastSeenErrorAndReset(),
                    this._network.getLastUsedInitUrlAndReset(),
                    o
                )
            );
        }
        updateUserAsync(t, n) {
            return e(this, void 0, void 0, function* () {
                const e = performance.now();
                try {
                    return yield this._updateUserAsyncImpl(t, n);
                } catch (r) {
                    const t = r instanceof Error ? r : new Error(String(r));
                    return this._createErrorUpdateDetails(t, e);
                }
            });
        }
        _updateUserAsyncImpl(n, r) {
            return e(this, void 0, void 0, function* () {
                this._resetForUser(n);
                const e = this._user;
                t.Diagnostics._markInitOverallStart(this._sdkKey);
                let s = this.dataAdapter.getDataSync(e);
                if (
                    (this._store.setValues(s, this._user),
                    this._setStatus("Loading", s),
                    (s = yield this.dataAdapter.getDataAsync(s, e, r)),
                    e !== this._user)
                )
                    return (0, t.createUpdateDetails)(
                        !1,
                        this._store.getSource(),
                        -1,
                        new Error("User changed during update"),
                        this._network.getLastUsedInitUrlAndReset()
                    );
                let o = !1;
                null != s &&
                    (t.Diagnostics._markInitProcessStart(this._sdkKey),
                    (o = this._store.setValues(s, this._user)),
                    t.Diagnostics._markInitProcessEnd(this._sdkKey, {
                        success: o,
                    })),
                    this._finalizeUpdate(s),
                    o ||
                        (this._errorBoundary.attachErrorIfNoneExists(
                            t.UPDATE_DETAIL_ERROR_MESSAGES.NO_NETWORK_DATA
                        ),
                        this.$emt({ name: "initialization_failure" })),
                    t.Diagnostics._markInitOverallEnd(
                        this._sdkKey,
                        o,
                        this._store.getCurrentSourceDetails()
                    );
                const i = t.Diagnostics._enqueueDiagnosticsEvent(
                    this._user,
                    this._logger,
                    this._sdkKey,
                    this._options
                );
                return (0,
                t.createUpdateDetails)(o, this._store.getSource(), i, this._errorBoundary.getLastSeenErrorAndReset(), this._network.getLastUsedInitUrlAndReset(), this._store.getWarnings());
            });
        }
        getContext() {
            return {
                sdkKey: this._sdkKey,
                options: this._options,
                values: this._store.getValues(),
                user: JSON.parse(JSON.stringify(this._user)),
                errorBoundary: this._errorBoundary,
                session: t.StatsigSession.get(this._sdkKey),
                stableID: t.StableID.get(this._sdkKey),
                sdkInstanceID: this._sdkInstanceID,
            };
        }
        checkGate(e, t) {
            return this.getFeatureGate(e, t).value;
        }
        logEvent(e, t, n) {
            const r =
                "string" == typeof e
                    ? { eventName: e, value: t, metadata: n }
                    : e;
            this.$emt({ name: "log_event_called", event: r }),
                this._logger.enqueue(
                    Object.assign(Object.assign({}, r), {
                        user: this._user,
                        time: Date.now(),
                    })
                );
        }
        updateUserWithAnalyticsOnlyMetadata(e) {
            this._user = this._configureUser(
                Object.assign(Object.assign({}, this._user), {
                    analyticsOnlyMetadata: e,
                }),
                this._options
            );
        }
        _primeReadyRipcord() {
            this.$on("error", () => {
                "Loading" === this.loadingStatus && this._finalizeUpdate(null);
            });
        }
        _initializeAsyncImpl(n) {
            return e(this, void 0, void 0, function* () {
                return (
                    t.Storage.isReady() || (yield t.Storage.isReadyResolver()),
                    this._logger.start(),
                    this.updateUserAsync(this._user, n)
                );
            });
        }
        _createErrorUpdateDetails(e, n) {
            var r;
            return (0, t.createUpdateDetails)(
                !1,
                this._store.getSource(),
                performance.now() - n,
                e,
                null,
                [
                    ...(null !== (r = this._store.getWarnings()) && void 0 !== r
                        ? r
                        : []),
                ]
            );
        }
        _finalizeUpdate(e) {
            this._store.finalize(), this._setStatus("Ready", e);
        }
        _runPostUpdate(e, n) {
            this.dataAdapter
                .getDataAsync(e, n, { priority: "low" })
                .catch((e) => {
                    t.Log.error("An error occurred after update.", e);
                });
        }
        _resetForUser(e) {
            this._logger.reset(),
                this._store.reset(),
                (this._user = this._configureUser(e, this._options));
        }
        _configureUser(e, n) {
            var r;
            const s = (0, t._normalizeUser)(e, n),
                o =
                    null === (r = s.customIDs) || void 0 === r
                        ? void 0
                        : r.stableID;
            return (
                o && t.StableID.setOverride(o, this._sdkKey),
                Object.keys(this._possibleFirstTouchMetadata).length > 0 &&
                    (s.analyticsOnlyMetadata = Object.assign(
                        Object.assign({}, s.analyticsOnlyMetadata),
                        this._possibleFirstTouchMetadata
                    )),
                s
            );
        }
        _getFeatureGateImpl(e, n) {
            var r, s;
            const { result: o, details: i } = this._store.getGate(e),
                a = (0, t._makeFeatureGate)(e, i, o),
                c =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getGateOverride) || void 0 === s
                        ? void 0
                        : s.call(r, a, this._user, n),
                u = null != c ? c : a;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createGateExposure)(
                        this._user,
                        u,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({ name: "gate_evaluation", gate: u }),
                u
            );
        }
        _getDynamicConfigImpl(e, n) {
            var r, s;
            const { result: o, details: i } = this._store.getConfig(e),
                a = (0, t._makeDynamicConfig)(e, i, o),
                c =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getDynamicConfigOverride) || void 0 === s
                        ? void 0
                        : s.call(r, a, this._user, n),
                u = null != c ? c : a;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createConfigExposure)(
                        this._user,
                        u,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({
                    name: "dynamic_config_evaluation",
                    dynamicConfig: u,
                }),
                u
            );
        }
        _getExperimentImpl(e, n) {
            var r, s, o, i;
            const { result: a, details: c } = this._store.getConfig(e),
                u = (0, t._makeExperiment)(e, c, a);
            null != u.__evaluation &&
                (u.__evaluation.secondary_exposures = (0, t._mapExposures)(
                    null !==
                        (s =
                            null === (r = u.__evaluation) || void 0 === r
                                ? void 0
                                : r.secondary_exposures) && void 0 !== s
                        ? s
                        : [],
                    this._store.getExposureMapping()
                ));
            const l =
                    null ===
                        (i =
                            null === (o = this.overrideAdapter) || void 0 === o
                                ? void 0
                                : o.getExperimentOverride) || void 0 === i
                        ? void 0
                        : i.call(o, u, this._user, n),
                d = null != l ? l : u;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createConfigExposure)(
                        this._user,
                        d,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({ name: "experiment_evaluation", experiment: d }),
                d
            );
        }
        _getConfigListImpl() {
            return this._store.getConfigList();
        }
        _getLayerImpl(e, n) {
            var r, s, o;
            const { result: i, details: a } = this._store.getLayer(e),
                c = (0, t._makeLayer)(e, a, i),
                u =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getLayerOverride) || void 0 === s
                        ? void 0
                        : s.call(r, c, this._user, n);
            (null == n ? void 0 : n.disableExposureLog) &&
                this._logger.incrementNonExposureCount(e);
            const l = (0, t._mergeOverride)(
                c,
                u,
                null !== (o = null == u ? void 0 : u.__value) && void 0 !== o
                    ? o
                    : c.__value,
                (r) => {
                    (null == n ? void 0 : n.disableExposureLog) ||
                        this._enqueueExposure(
                            e,
                            (0, t._createLayerParameterExposure)(
                                this._user,
                                l,
                                r,
                                this._store.getExposureMapping()
                            ),
                            n
                        );
                }
            );
            return this.$emt({ name: "layer_evaluation", layer: l }), l;
        }
        _getParameterStoreImpl(e, t) {
            var n, r;
            const { result: o, details: i } = this._store.getParamStore(e);
            this._logger.incrementNonExposureCount(e);
            const a = {
                    name: e,
                    details: i,
                    __configuration: o,
                    get: (0, s._makeParamStoreGetter)(this, o, t),
                },
                c =
                    null ===
                        (r =
                            null === (n = this.overrideAdapter) || void 0 === n
                                ? void 0
                                : n.getParamStoreOverride) || void 0 === r
                        ? void 0
                        : r.call(n, a, t);
            return (
                null != c &&
                    ((a.__configuration = c.config),
                    (a.details = c.details),
                    (a.get = (0, s._makeParamStoreGetter)(this, c.config, t))),
                a
            );
        }
    };
    return (vt.default = i), vt;
}
var Lt =
        (Pt ||
            ((Pt = 1),
            (function (e) {
                var t =
                        (a && a.__createBinding) ||
                        (Object.create
                            ? function (e, t, n, r) {
                                  void 0 === r && (r = n);
                                  var s = Object.getOwnPropertyDescriptor(t, n);
                                  (s &&
                                      !("get" in s
                                          ? !t.__esModule
                                          : s.writable || s.configurable)) ||
                                      (s = {
                                          enumerable: !0,
                                          get: function () {
                                              return t[n];
                                          },
                                      }),
                                      Object.defineProperty(e, r, s);
                              }
                            : function (e, t, n, r) {
                                  void 0 === r && (r = n), (e[r] = t[n]);
                              }),
                    n =
                        (a && a.__exportStar) ||
                        function (e, n) {
                            for (var r in e)
                                "default" === r ||
                                    Object.prototype.hasOwnProperty.call(
                                        n,
                                        r
                                    ) ||
                                    t(n, e, r);
                        };
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.StatsigClient = void 0);
                const r = gt(),
                    s = jt();
                (e.StatsigClient = s.default), n(gt(), e);
                const o = Object.assign((0, r._getStatsigGlobal)(), {
                    StatsigClient: s.default,
                });
                e.default = o;
            })(a)),
        a),
    Ut = ((e) => (
        (e.ACCESS_TOKEN = "accessToken"),
        (e.REFRESH_TOKEN = "refreshToken"),
        (e.TOKEN_EXPIRY = "tokenExpiry"),
        (e.OAUTH_STATE = "oauthState"),
        (e.CODE_VERIFIER = "codeVerifier"),
        (e.ANTHROPIC_API_KEY = "anthropicApiKey"),
        (e.SELECTED_MODEL = "selectedModel"),
        (e.SYSTEM_PROMPT = "systemPrompt"),
        (e.DEBUG_MODE = "debugMode"),
        (e.SHOW_TRACE_IDS = "showTraceIds"),
        (e.BROWSER_CONTROL_PERMISSION_ACCEPTED =
            "browserControlPermissionAccepted"),
        (e.PERMISSION_STORAGE = "permissionStorage"),
        (e.LAST_SKIP_PERMISSIONS_PREFERENCE = "lastSkipPermissionsPreference"),
        (e.ANONYMOUS_ID = "anonymousId"),
        (e.TEST_DATA_MESSAGES = "test_data_messages"),
        (e.SCHEDULED_TASKS = "scheduledTasks"),
        (e.SCHEDULED_TASKS_ENABLED = "scheduledTasksEnabled"),
        (e.SCHEDULED_TASKS_PRELOADED = "scheduledTasksPreloaded"),
        (e.TEST_SCHEDULED_TASK = "testScheduledTask"),
        (e.TASK_RUN_LOGS = "taskRunLogs"),
        (e.TASK_RUN_STATS = "taskRunStats"),
        (e.SCHEDULED_TASK_LOGS = "scheduledTaskLogs"),
        (e.SCHEDULED_TASK_STATS = "scheduledTaskStats"),
        (e.TARGET_TAB_ID = "targetTabId"),
        (e.UPDATE_AVAILABLE = "updateAvailable"),
        (e.TIP_DISPLAY_COUNTS = "tipDisplayCounts"),
        (e.SAVED_PROMPTS = "savedPrompts"),
        (e.SAVED_PROMPT_CATEGORIES = "savedPromptCategories"),
        e
    ))(Ut || {});
async function Mt(e) {
    return (await chrome.storage.local.get(e))[e];
}
async function Nt(e, t) {
    await chrome.storage.local.set({ [e]: t });
}
async function $t(e) {
    const t = Array.isArray(e) ? e : [e];
    await chrome.storage.local.remove(t);
}
async function Kt(e) {
    return await chrome.storage.local.get(e);
}
async function Ft(e) {
    await chrome.storage.local.set(e);
}
const Bt = new Set(["anonymousId", "updateAvailable"]);
async function zt() {
    const e = Object.values(Ut).filter((e) => !Bt.has(e));
    await $t(e);
}
let qt = null;
const Vt = async () => {
        try {
            const e = await Qt();
            if (!e) return null;
            const t = `${s().apiBaseUrl}/api/oauth/profile`,
                n = await fetch(t, {
                    headers: {
                        Authorization: `Bearer ${e}`,
                        "Content-Type": "application/json",
                    },
                });
            if (!n.ok) return null;
            return await n.json();
        } catch {
            return null;
        }
    },
    Gt = async (e) => {
        let t = await Mt(Ut.ANONYMOUS_ID);
        t || ((t = crypto.randomUUID()), await Nt(Ut.ANONYMOUS_ID, t));
        const n = chrome.runtime.getManifest().version;
        return e
            ? {
                  userID: e.account.uuid,
                  customIDs: {
                      anonymousID: t,
                      organizationID: e.organization.uuid,
                      organizationUUID: e.organization.uuid,
                      applicationSlug: "claude-browser-use",
                  },
                  custom: {
                      extensionVersion: n,
                      isMax: e.account.has_claude_max,
                      isPro: e.account.has_claude_pro,
                      orgType: e.organization.organization_type,
                  },
                  privateAttributes: { email: e.account.email },
              }
            : {
                  customIDs: { anonymousID: t },
                  custom: { extensionVersion: n },
              };
    },
    Wt = async () => {
        if (!qt)
            try {
                const e = s(),
                    t = await Vt(),
                    n = await Gt(t),
                    r = {
                        environment: {
                            tier:
                                "production" === e.environment
                                    ? "production"
                                    : "development",
                        },
                    };
                (qt = new Lt.StatsigClient(e.statsigClientApiKey || "", n, r)),
                    await qt.initializeAsync();
            } catch (e) {}
    },
    Ht = (e) =>
        btoa(String.fromCharCode(...e))
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=/g, ""),
    Jt = async (e, t) => {
        await Ft({
            [Ut.ACCESS_TOKEN]: e.accessToken,
            [Ut.REFRESH_TOKEN]: e.refreshToken,
            [Ut.TOKEN_EXPIRY]: e.expiresAt,
            [Ut.OAUTH_STATE]: t,
        });
    },
    Yt = async (e, t) => {
        try {
            const n = await fetch(t.TOKEN_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({
                    grant_type: "refresh_token",
                    client_id: t.CLIENT_ID,
                    refresh_token: e,
                }),
            });
            if (!n.ok) {
                const e = await n.text();
                return {
                    success: !1,
                    error: `Token refresh failed: ${n.status} ${e}`,
                };
            }
            const r = await n.json();
            return r.error
                ? { success: !1, error: r.error_description || r.error }
                : {
                      success: !0,
                      accessToken: r.access_token,
                      refreshToken: r.refresh_token || e,
                      expiresAt: r.expires_in
                          ? Date.now() + 1e3 * r.expires_in
                          : void 0,
                  };
        } catch (n) {
            return {
                success: !1,
                error:
                    n instanceof Error
                        ? n.message
                        : "Network error during token refresh",
            };
        }
    },
    Xt = async () => {
        try {
            const e = await Kt([
                Ut.ACCESS_TOKEN,
                Ut.REFRESH_TOKEN,
                Ut.TOKEN_EXPIRY,
            ]);
            if (!e[Ut.ACCESS_TOKEN]) return { isValid: !1, isRefreshed: !1 };
            const t = Date.now(),
                n = e[Ut.TOKEN_EXPIRY],
                r = !!n && t < n;
            if (!(!!n && t >= n - 36e5)) return { isValid: r, isRefreshed: !1 };
            if (!e[Ut.REFRESH_TOKEN]) return { isValid: r, isRefreshed: !1 };
            const o = s();
            for (let s = 0; s < 3; s++) {
                const t = await Yt(e[Ut.REFRESH_TOKEN], o.oauth);
                if (t.success)
                    return await Jt(t), { isValid: !0, isRefreshed: !0 };
                if (2 === s)
                    return (
                        await $t([
                            Ut.ACCESS_TOKEN,
                            Ut.REFRESH_TOKEN,
                            Ut.TOKEN_EXPIRY,
                        ]),
                        { isValid: r, isRefreshed: !1 }
                    );
            }
            return { isValid: r, isRefreshed: !1 };
        } catch {
            return { isValid: !1, isRefreshed: !1 };
        }
    },
    Qt = async () => {
        if (!(await Xt()).isValid) return;
        return (await Mt(Ut.ACCESS_TOKEN)) || void 0;
    },
    Zt = async (e, t) => {
        try {
            const o = new URLSearchParams(new URL(e).search),
                i = o.get("code"),
                a = o.get("error"),
                c = o.get("error_description"),
                u = o.get("state");
            if (a) {
                return {
                    success: !1,
                    error: `Authentication failed: ${a}${c ? " - " + c : ""}`,
                };
            }
            if (!i)
                return { success: !1, error: "No authorization code received" };
            const l = (await Mt(Ut.CODE_VERIFIER)) || "",
                d = s(),
                f = await (async (e, t, n, r) => {
                    try {
                        const s = await fetch(r.TOKEN_URL, {
                            method: "POST",
                            headers: {
                                "Content-Type":
                                    "application/x-www-form-urlencoded",
                            },
                            body: new URLSearchParams({
                                grant_type: "authorization_code",
                                client_id: r.CLIENT_ID,
                                code: e,
                                redirect_uri: r.REDIRECT_URI,
                                state: t,
                                code_verifier: n,
                            }),
                        });
                        if (!s.ok) {
                            const e = await s.text();
                            return {
                                success: !1,
                                error: `Token exchange failed: ${s.status} ${e}`,
                            };
                        }
                        const o = await s.json();
                        return o.error
                            ? {
                                  success: !1,
                                  error: o.error_description || o.error,
                              }
                            : {
                                  success: !0,
                                  accessToken: o.access_token,
                                  refreshToken: o.refresh_token,
                                  expiresAt: o.expires_in
                                      ? Date.now() + 1e3 * o.expires_in
                                      : void 0,
                              };
                    } catch (a) {
                        return {
                            success: !1,
                            error:
                                a instanceof Error
                                    ? a.message
                                    : "Network error during token exchange",
                        };
                    }
                })(i, u || "", l, d.oauth);
            if (f.success) {
                await Jt(f, u || void 0),
                    await (async () => {
                        if (qt)
                            try {
                                const e = await Vt(),
                                    t = await Gt(e);
                                await qt.updateUserAsync(t);
                            } catch (a) {}
                    })();
                let e = "https://claude.ai";
                try {
                    const t = ((n = "extension_landing_page_url"),
                    qt
                        ? qt.getDynamicConfig(n)
                        : { get: (e, t = "") => t }).get("relative_url", "");
                    t && (e = `https://claude.ai${t}`);
                } catch (r) {}
                return (
                    t && (await chrome.tabs.update(t, { url: e })),
                    { success: !0, message: "Authentication successful!" }
                );
            }
            return {
                success: !1,
                error:
                    f.error ||
                    "Failed to exchange authorization code for token",
            };
        } catch (o) {
            return {
                success: !1,
                error:
                    o instanceof Error
                        ? o.message
                        : "An unexpected error occurred during authentication",
            };
        }
        var n;
    },
    en = async () => {
        await zt();
    },
    tn = async () => {
        const e = s(),
            t = ((e) => {
                const t = new Uint8Array(e);
                return crypto.getRandomValues(t), Ht(t);
            })(32),
            n = Ht(crypto.getRandomValues(new Uint8Array(32))),
            r = await (async (e) => {
                const t = new TextEncoder().encode(e),
                    n = await crypto.subtle.digest("SHA-256", t);
                return Ht(new Uint8Array(n));
            })(n);
        await Ft({ [Ut.OAUTH_STATE]: t, [Ut.CODE_VERIFIER]: n });
        const o = new URLSearchParams({
                client_id: e.oauth.CLIENT_ID,
                response_type: "code",
                scope: e.oauth.SCOPES_STR,
                redirect_uri: e.oauth.REDIRECT_URI,
                state: t,
                code_challenge: r,
                code_challenge_method: "S256",
            }),
            i = `${e.oauth.AUTHORIZE_URL}?${o.toString()}`;
        chrome.tabs.create({ url: i });
    },
    nn = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    rn = globalThis,
    sn = "10.8.0";
function on() {
    return an(rn), rn;
}
function an(e) {
    const t = (e.__SENTRY__ = e.__SENTRY__ || {});
    return (t.version = t.version || sn), (t[sn] = t[sn] || {});
}
function cn(e, t, n = rn) {
    const r = (n.__SENTRY__ = n.__SENTRY__ || {}),
        s = (r[sn] = r[sn] || {});
    return s[e] || (s[e] = t());
}
const un = ["debug", "info", "warn", "error", "log", "assert", "trace"],
    ln = {};
function dn(e) {
    if (!("console" in rn)) return e();
    const t = rn.console,
        n = {},
        r = Object.keys(ln);
    r.forEach((e) => {
        const r = ln[e];
        (n[e] = t[e]), (t[e] = r);
    });
    try {
        return e();
    } finally {
        r.forEach((e) => {
            t[e] = n[e];
        });
    }
}
function fn() {
    return pn().enabled;
}
function hn(e, ...t) {
    nn &&
        fn() &&
        dn(() => {
            rn.console[e](`Sentry Logger [${e}]:`, ...t);
        });
}
function pn() {
    return nn ? cn("loggerSettings", () => ({ enabled: !1 })) : { enabled: !1 };
}
const _n = {
        enable: function () {
            pn().enabled = !0;
        },
        disable: function () {
            pn().enabled = !1;
        },
        isEnabled: fn,
        log: function (...e) {
            hn("log", ...e);
        },
        warn: function (...e) {
            hn("warn", ...e);
        },
        error: function (...e) {
            hn("error", ...e);
        },
    },
    gn = "?",
    mn = /\(error: (.*)\)/,
    vn = /captureMessage|captureException/;
function yn(...e) {
    const t = e.sort((e, t) => e[0] - t[0]).map((e) => e[1]);
    return (e, n = 0, r = 0) => {
        const s = [],
            o = e.split("\n");
        for (let i = n; i < o.length; i++) {
            let e = o[i];
            e.length > 1024 && (e = e.slice(0, 1024));
            const n = mn.test(e) ? e.replace(mn, "$1") : e;
            if (!n.match(/\S*Error: /)) {
                for (const e of t) {
                    const t = e(n);
                    if (t) {
                        s.push(t);
                        break;
                    }
                }
                if (s.length >= 50 + r) break;
            }
        }
        return (function (e) {
            if (!e.length) return [];
            const t = Array.from(e);
            /sentryWrapped/.test(bn(t).function || "") && t.pop();
            t.reverse(),
                vn.test(bn(t).function || "") &&
                    (t.pop(), vn.test(bn(t).function || "") && t.pop());
            return t
                .slice(0, 50)
                .map((e) => ({
                    ...e,
                    filename: e.filename || bn(t).filename,
                    function: e.function || gn,
                }));
        })(s.slice(r));
    };
}
function bn(e) {
    return e[e.length - 1] || {};
}
const En = "<anonymous>";
function Sn(e) {
    try {
        return (e && "function" == typeof e && e.name) || En;
    } catch {
        return En;
    }
}
function kn(e) {
    const t = e.exception;
    if (t) {
        const e = [];
        try {
            return (
                t.values.forEach((t) => {
                    t.stacktrace.frames && e.push(...t.stacktrace.frames);
                }),
                e
            );
        } catch {
            return;
        }
    }
}
const wn = {},
    xn = {};
function On(e, t) {
    (wn[e] = wn[e] || []), wn[e].push(t);
}
function In(e, t) {
    if (!xn[e]) {
        xn[e] = !0;
        try {
            t();
        } catch (n) {
            nn && _n.error(`Error while instrumenting ${e}`, n);
        }
    }
}
function Dn(e, t) {
    const n = e && wn[e];
    if (n)
        for (const s of n)
            try {
                s(t);
            } catch (r) {
                nn &&
                    _n.error(
                        `Error while triggering instrumentation handler.\nType: ${e}\nName: ${Sn(
                            s
                        )}\nError:`,
                        r
                    );
            }
}
let Cn = null;
function Tn() {
    (Cn = rn.onerror),
        (rn.onerror = function (e, t, n, r, s) {
            return (
                Dn("error", { column: r, error: s, line: n, msg: e, url: t }),
                !!Cn && Cn.apply(this, arguments)
            );
        }),
        (rn.onerror.__SENTRY_INSTRUMENTED__ = !0);
}
let Pn = null;
function An() {
    (Pn = rn.onunhandledrejection),
        (rn.onunhandledrejection = function (e) {
            return (
                Dn("unhandledrejection", e), !Pn || Pn.apply(this, arguments)
            );
        }),
        (rn.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0);
}
const Rn = Object.prototype.toString;
function jn(e) {
    switch (Rn.call(e)) {
        case "[object Error]":
        case "[object Exception]":
        case "[object DOMException]":
        case "[object WebAssembly.Exception]":
            return !0;
        default:
            return qn(e, Error);
    }
}
function Ln(e, t) {
    return Rn.call(e) === `[object ${t}]`;
}
function Un(e) {
    return Ln(e, "ErrorEvent");
}
function Mn(e) {
    return Ln(e, "DOMError");
}
function Nn(e) {
    return Ln(e, "String");
}
function $n(e) {
    return (
        "object" == typeof e &&
        null !== e &&
        "__sentry_template_string__" in e &&
        "__sentry_template_values__" in e
    );
}
function Kn(e) {
    return (
        null === e || $n(e) || ("object" != typeof e && "function" != typeof e)
    );
}
function Fn(e) {
    return Ln(e, "Object");
}
function Bn(e) {
    return "undefined" != typeof Event && qn(e, Event);
}
function zn(e) {
    return Boolean(e?.then && "function" == typeof e.then);
}
function qn(e, t) {
    try {
        return e instanceof t;
    } catch {
        return !1;
    }
}
function Vn(e) {
    return !("object" != typeof e || null === e || (!e.__isVue && !e._isVue));
}
const Gn = rn;
function Wn(e, t = {}) {
    if (!e) return "<unknown>";
    try {
        let n = e;
        const r = 5,
            s = [];
        let o = 0,
            i = 0;
        const a = " > ",
            c = a.length;
        let u;
        const l = Array.isArray(t) ? t : t.keyAttrs,
            d = (!Array.isArray(t) && t.maxStringLength) || 80;
        for (
            ;
            n &&
            o++ < r &&
            ((u = Hn(n, l)),
            !("html" === u || (o > 1 && i + s.length * c + u.length >= d)));

        )
            s.push(u), (i += u.length), (n = n.parentNode);
        return s.reverse().join(a);
    } catch {
        return "<unknown>";
    }
}
function Hn(e, t) {
    const n = e,
        r = [];
    if (!n?.tagName) return "";
    if (Gn.HTMLElement && n instanceof HTMLElement && n.dataset) {
        if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
        if (n.dataset.sentryElement) return n.dataset.sentryElement;
    }
    r.push(n.tagName.toLowerCase());
    const s = t?.length
        ? t.filter((e) => n.getAttribute(e)).map((e) => [e, n.getAttribute(e)])
        : null;
    if (s?.length)
        s.forEach((e) => {
            r.push(`[${e[0]}="${e[1]}"]`);
        });
    else {
        n.id && r.push(`#${n.id}`);
        const e = n.className;
        if (e && Nn(e)) {
            const t = e.split(/\s+/);
            for (const e of t) r.push(`.${e}`);
        }
    }
    const o = ["aria-label", "type", "name", "title", "alt"];
    for (const i of o) {
        const e = n.getAttribute(i);
        e && r.push(`[${i}="${e}"]`);
    }
    return r.join("");
}
function Jn() {
    try {
        return Gn.document.location.href;
    } catch {
        return "";
    }
}
function Yn(e, t = 0) {
    return "string" != typeof e || 0 === t || e.length <= t
        ? e
        : `${e.slice(0, t)}...`;
}
function Xn(e, t) {
    if (!Array.isArray(e)) return "";
    const n = [];
    for (let r = 0; r < e.length; r++) {
        const t = e[r];
        try {
            Vn(t) ? n.push("[VueViewModel]") : n.push(String(t));
        } catch {
            n.push("[value cannot be serialized]");
        }
    }
    return n.join(t);
}
function Qn(e, t, n = !1) {
    return (
        !!Nn(e) &&
        (Ln(t, "RegExp") ? t.test(e) : !!Nn(t) && (n ? e === t : e.includes(t)))
    );
}
function Zn(e, t = [], n = !1) {
    return t.some((t) => Qn(e, t, n));
}
function er(e, t, n) {
    if (!(t in e)) return;
    const r = e[t];
    if ("function" != typeof r) return;
    const s = n(r);
    "function" == typeof s && nr(s, r);
    try {
        e[t] = s;
    } catch {
        nn && _n.log(`Failed to replace method "${t}" in object`, e);
    }
}
function tr(e, t, n) {
    try {
        Object.defineProperty(e, t, {
            value: n,
            writable: !0,
            configurable: !0,
        });
    } catch {
        nn &&
            _n.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
}
function nr(e, t) {
    try {
        const n = t.prototype || {};
        (e.prototype = t.prototype = n), tr(e, "__sentry_original__", t);
    } catch {}
}
function rr(e) {
    return e.__sentry_original__;
}
function sr(e) {
    if (jn(e))
        return { message: e.message, name: e.name, stack: e.stack, ...ir(e) };
    if (Bn(e)) {
        const t = {
            type: e.type,
            target: or(e.target),
            currentTarget: or(e.currentTarget),
            ...ir(e),
        };
        return (
            "undefined" != typeof CustomEvent &&
                qn(e, CustomEvent) &&
                (t.detail = e.detail),
            t
        );
    }
    return e;
}
function or(e) {
    try {
        return (
            (t = e),
            "undefined" != typeof Element && qn(t, Element)
                ? Wn(e)
                : Object.prototype.toString.call(e)
        );
    } catch {
        return "<unknown>";
    }
    var t;
}
function ir(e) {
    if ("object" == typeof e && null !== e) {
        const t = {};
        for (const n in e)
            Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    }
    return {};
}
function ar(
    e = (function () {
        const e = rn;
        return e.crypto || e.msCrypto;
    })()
) {
    let t = () => 16 * Math.random();
    try {
        if (e?.randomUUID) return e.randomUUID().replace(/-/g, "");
        e?.getRandomValues &&
            (t = () => {
                const t = new Uint8Array(1);
                return e.getRandomValues(t), t[0];
            });
    } catch {}
    return "10000000100040008000100000000000".replace(/[018]/g, (e) =>
        (e ^ ((15 & t()) >> (e / 4))).toString(16)
    );
}
function cr(e) {
    return e.exception?.values?.[0];
}
function ur(e) {
    const { message: t, event_id: n } = e;
    if (t) return t;
    const r = cr(e);
    return r
        ? r.type && r.value
            ? `${r.type}: ${r.value}`
            : r.type || r.value || n || "<unknown>"
        : n || "<unknown>";
}
function lr(e, t, n) {
    const r = (e.exception = e.exception || {}),
        s = (r.values = r.values || []),
        o = (s[0] = s[0] || {});
    o.value || (o.value = t || ""), o.type || (o.type = "Error");
}
function dr(e, t) {
    const n = cr(e);
    if (!n) return;
    const r = n.mechanism;
    if (
        ((n.mechanism = { type: "generic", handled: !0, ...r, ...t }),
        t && "data" in t)
    ) {
        const e = { ...r?.data, ...t.data };
        n.mechanism.data = e;
    }
}
function fr(e) {
    if (
        (function (e) {
            try {
                return e.__sentry_captured__;
            } catch {}
        })(e)
    )
        return !0;
    try {
        tr(e, "__sentry_captured__", !0);
    } catch {}
    return !1;
}
function hr() {
    return Date.now() / 1e3;
}
let pr;
function _r() {
    return (
        pr ??
        (pr = (function () {
            const { performance: e } = rn;
            if (!e?.now || !e.timeOrigin) return hr;
            const t = e.timeOrigin;
            return () => (t + e.now()) / 1e3;
        })())
    )();
}
function gr(e) {
    const t = _r(),
        n = {
            sid: ar(),
            init: !0,
            timestamp: t,
            started: t,
            duration: 0,
            status: "ok",
            errors: 0,
            ignoreDuration: !1,
            toJSON: () =>
                (function (e) {
                    return {
                        sid: `${e.sid}`,
                        init: e.init,
                        started: new Date(1e3 * e.started).toISOString(),
                        timestamp: new Date(1e3 * e.timestamp).toISOString(),
                        status: e.status,
                        errors: e.errors,
                        did:
                            "number" == typeof e.did || "string" == typeof e.did
                                ? `${e.did}`
                                : void 0,
                        duration: e.duration,
                        abnormal_mechanism: e.abnormal_mechanism,
                        attrs: {
                            release: e.release,
                            environment: e.environment,
                            ip_address: e.ipAddress,
                            user_agent: e.userAgent,
                        },
                    };
                })(n),
        };
    return e && mr(n, e), n;
}
function mr(e, t = {}) {
    if (
        (t.user &&
            (!e.ipAddress &&
                t.user.ip_address &&
                (e.ipAddress = t.user.ip_address),
            e.did ||
                t.did ||
                (e.did = t.user.id || t.user.email || t.user.username)),
        (e.timestamp = t.timestamp || _r()),
        t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism),
        t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration),
        t.sid && (e.sid = 32 === t.sid.length ? t.sid : ar()),
        void 0 !== t.init && (e.init = t.init),
        !e.did && t.did && (e.did = `${t.did}`),
        "number" == typeof t.started && (e.started = t.started),
        e.ignoreDuration)
    )
        e.duration = void 0;
    else if ("number" == typeof t.duration) e.duration = t.duration;
    else {
        const t = e.timestamp - e.started;
        e.duration = t >= 0 ? t : 0;
    }
    t.release && (e.release = t.release),
        t.environment && (e.environment = t.environment),
        !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress),
        !e.userAgent && t.userAgent && (e.userAgent = t.userAgent),
        "number" == typeof t.errors && (e.errors = t.errors),
        t.status && (e.status = t.status);
}
function vr(e, t, n = 2) {
    if (!t || "object" != typeof t || n <= 0) return t;
    if (e && 0 === Object.keys(t).length) return e;
    const r = { ...e };
    for (const s in t)
        Object.prototype.hasOwnProperty.call(t, s) &&
            (r[s] = vr(r[s], t[s], n - 1));
    return r;
}
function yr() {
    return ar();
}
function br() {
    return ar().substring(16);
}
const Er = "_sentrySpan";
function Sr(e, t) {
    t ? tr(e, Er, t) : delete e[Er];
}
function kr(e) {
    return e[Er];
}
class wr {
    constructor() {
        (this._notifyingListeners = !1),
            (this._scopeListeners = []),
            (this._eventProcessors = []),
            (this._breadcrumbs = []),
            (this._attachments = []),
            (this._user = {}),
            (this._tags = {}),
            (this._extra = {}),
            (this._contexts = {}),
            (this._sdkProcessingMetadata = {}),
            (this._propagationContext = {
                traceId: yr(),
                sampleRand: Math.random(),
            });
    }
    clone() {
        const e = new wr();
        return (
            (e._breadcrumbs = [...this._breadcrumbs]),
            (e._tags = { ...this._tags }),
            (e._extra = { ...this._extra }),
            (e._contexts = { ...this._contexts }),
            this._contexts.flags &&
                (e._contexts.flags = {
                    values: [...this._contexts.flags.values],
                }),
            (e._user = this._user),
            (e._level = this._level),
            (e._session = this._session),
            (e._transactionName = this._transactionName),
            (e._fingerprint = this._fingerprint),
            (e._eventProcessors = [...this._eventProcessors]),
            (e._attachments = [...this._attachments]),
            (e._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }),
            (e._propagationContext = { ...this._propagationContext }),
            (e._client = this._client),
            (e._lastEventId = this._lastEventId),
            Sr(e, kr(this)),
            e
        );
    }
    setClient(e) {
        this._client = e;
    }
    setLastEventId(e) {
        this._lastEventId = e;
    }
    getClient() {
        return this._client;
    }
    lastEventId() {
        return this._lastEventId;
    }
    addScopeListener(e) {
        this._scopeListeners.push(e);
    }
    addEventProcessor(e) {
        return this._eventProcessors.push(e), this;
    }
    setUser(e) {
        return (
            (this._user = e || {
                email: void 0,
                id: void 0,
                ip_address: void 0,
                username: void 0,
            }),
            this._session && mr(this._session, { user: e }),
            this._notifyScopeListeners(),
            this
        );
    }
    getUser() {
        return this._user;
    }
    setTags(e) {
        return (
            (this._tags = { ...this._tags, ...e }),
            this._notifyScopeListeners(),
            this
        );
    }
    setTag(e, t) {
        return (
            (this._tags = { ...this._tags, [e]: t }),
            this._notifyScopeListeners(),
            this
        );
    }
    setExtras(e) {
        return (
            (this._extra = { ...this._extra, ...e }),
            this._notifyScopeListeners(),
            this
        );
    }
    setExtra(e, t) {
        return (
            (this._extra = { ...this._extra, [e]: t }),
            this._notifyScopeListeners(),
            this
        );
    }
    setFingerprint(e) {
        return (this._fingerprint = e), this._notifyScopeListeners(), this;
    }
    setLevel(e) {
        return (this._level = e), this._notifyScopeListeners(), this;
    }
    setTransactionName(e) {
        return (this._transactionName = e), this._notifyScopeListeners(), this;
    }
    setContext(e, t) {
        return (
            null === t ? delete this._contexts[e] : (this._contexts[e] = t),
            this._notifyScopeListeners(),
            this
        );
    }
    setSession(e) {
        return (
            e ? (this._session = e) : delete this._session,
            this._notifyScopeListeners(),
            this
        );
    }
    getSession() {
        return this._session;
    }
    update(e) {
        if (!e) return this;
        const t = "function" == typeof e ? e(this) : e,
            n = t instanceof wr ? t.getScopeData() : Fn(t) ? e : void 0,
            {
                tags: r,
                extra: s,
                user: o,
                contexts: i,
                level: a,
                fingerprint: c = [],
                propagationContext: u,
            } = n || {};
        return (
            (this._tags = { ...this._tags, ...r }),
            (this._extra = { ...this._extra, ...s }),
            (this._contexts = { ...this._contexts, ...i }),
            o && Object.keys(o).length && (this._user = o),
            a && (this._level = a),
            c.length && (this._fingerprint = c),
            u && (this._propagationContext = u),
            this
        );
    }
    clear() {
        return (
            (this._breadcrumbs = []),
            (this._tags = {}),
            (this._extra = {}),
            (this._user = {}),
            (this._contexts = {}),
            (this._level = void 0),
            (this._transactionName = void 0),
            (this._fingerprint = void 0),
            (this._session = void 0),
            Sr(this, void 0),
            (this._attachments = []),
            this.setPropagationContext({
                traceId: yr(),
                sampleRand: Math.random(),
            }),
            this._notifyScopeListeners(),
            this
        );
    }
    addBreadcrumb(e, t) {
        const n = "number" == typeof t ? t : 100;
        if (n <= 0) return this;
        const r = {
            timestamp: hr(),
            ...e,
            message: e.message ? Yn(e.message, 2048) : e.message,
        };
        return (
            this._breadcrumbs.push(r),
            this._breadcrumbs.length > n &&
                ((this._breadcrumbs = this._breadcrumbs.slice(-n)),
                this._client?.recordDroppedEvent(
                    "buffer_overflow",
                    "log_item"
                )),
            this._notifyScopeListeners(),
            this
        );
    }
    getLastBreadcrumb() {
        return this._breadcrumbs[this._breadcrumbs.length - 1];
    }
    clearBreadcrumbs() {
        return (this._breadcrumbs = []), this._notifyScopeListeners(), this;
    }
    addAttachment(e) {
        return this._attachments.push(e), this;
    }
    clearAttachments() {
        return (this._attachments = []), this;
    }
    getScopeData() {
        return {
            breadcrumbs: this._breadcrumbs,
            attachments: this._attachments,
            contexts: this._contexts,
            tags: this._tags,
            extra: this._extra,
            user: this._user,
            level: this._level,
            fingerprint: this._fingerprint || [],
            eventProcessors: this._eventProcessors,
            propagationContext: this._propagationContext,
            sdkProcessingMetadata: this._sdkProcessingMetadata,
            transactionName: this._transactionName,
            span: kr(this),
        };
    }
    setSDKProcessingMetadata(e) {
        return (
            (this._sdkProcessingMetadata = vr(
                this._sdkProcessingMetadata,
                e,
                2
            )),
            this
        );
    }
    setPropagationContext(e) {
        return (this._propagationContext = e), this;
    }
    getPropagationContext() {
        return this._propagationContext;
    }
    captureException(e, t) {
        const n = t?.event_id || ar();
        if (!this._client)
            return (
                nn &&
                    _n.warn(
                        "No client configured on scope - will not capture exception!"
                    ),
                n
            );
        const r = new Error("Sentry syntheticException");
        return (
            this._client.captureException(
                e,
                {
                    originalException: e,
                    syntheticException: r,
                    ...t,
                    event_id: n,
                },
                this
            ),
            n
        );
    }
    captureMessage(e, t, n) {
        const r = n?.event_id || ar();
        if (!this._client)
            return (
                nn &&
                    _n.warn(
                        "No client configured on scope - will not capture message!"
                    ),
                r
            );
        const s = new Error(e);
        return (
            this._client.captureMessage(
                e,
                t,
                {
                    originalException: e,
                    syntheticException: s,
                    ...n,
                    event_id: r,
                },
                this
            ),
            r
        );
    }
    captureEvent(e, t) {
        const n = t?.event_id || ar();
        return this._client
            ? (this._client.captureEvent(e, { ...t, event_id: n }, this), n)
            : (nn &&
                  _n.warn(
                      "No client configured on scope - will not capture event!"
                  ),
              n);
    }
    _notifyScopeListeners() {
        this._notifyingListeners ||
            ((this._notifyingListeners = !0),
            this._scopeListeners.forEach((e) => {
                e(this);
            }),
            (this._notifyingListeners = !1));
    }
}
class xr {
    constructor(e, t) {
        let n, r;
        (n = e || new wr()),
            (r = t || new wr()),
            (this._stack = [{ scope: n }]),
            (this._isolationScope = r);
    }
    withScope(e) {
        const t = this._pushScope();
        let n;
        try {
            n = e(t);
        } catch (r) {
            throw (this._popScope(), r);
        }
        return zn(n)
            ? n.then(
                  (e) => (this._popScope(), e),
                  (e) => {
                      throw (this._popScope(), e);
                  }
              )
            : (this._popScope(), n);
    }
    getClient() {
        return this.getStackTop().client;
    }
    getScope() {
        return this.getStackTop().scope;
    }
    getIsolationScope() {
        return this._isolationScope;
    }
    getStackTop() {
        return this._stack[this._stack.length - 1];
    }
    _pushScope() {
        const e = this.getScope().clone();
        return this._stack.push({ client: this.getClient(), scope: e }), e;
    }
    _popScope() {
        return !(this._stack.length <= 1) && !!this._stack.pop();
    }
}
function Or() {
    const e = an(on());
    return (e.stack =
        e.stack ||
        new xr(
            cn("defaultCurrentScope", () => new wr()),
            cn("defaultIsolationScope", () => new wr())
        ));
}
function Ir(e) {
    return Or().withScope(e);
}
function Dr(e, t) {
    const n = Or();
    return n.withScope(() => ((n.getStackTop().scope = e), t(e)));
}
function Cr(e) {
    return Or().withScope(() => e(Or().getIsolationScope()));
}
function Tr(e) {
    const t = an(e);
    return t.acs
        ? t.acs
        : {
              withIsolationScope: Cr,
              withScope: Ir,
              withSetScope: Dr,
              withSetIsolationScope: (e, t) => Cr(t),
              getCurrentScope: () => Or().getScope(),
              getIsolationScope: () => Or().getIsolationScope(),
          };
}
function Pr() {
    return Tr(on()).getCurrentScope();
}
function Ar() {
    return Tr(on()).getIsolationScope();
}
function Rr() {
    return Pr().getClient();
}
function jr(e) {
    const t = e.getPropagationContext(),
        { traceId: n, parentSpanId: r, propagationSpanId: s } = t,
        o = { trace_id: n, span_id: s || br() };
    return r && (o.parent_span_id = r), o;
}
const Lr = "sentry.profile_id",
    Ur = "sentry.exclusive_time";
function Mr(e) {
    return { scope: e._sentryScope, isolationScope: e._sentryIsolationScope };
}
const Nr = /^sentry-/;
function $r(e) {
    const t = (function (e) {
        if (!e || (!Nn(e) && !Array.isArray(e))) return;
        if (Array.isArray(e))
            return e.reduce((e, t) => {
                const n = Kr(t);
                return (
                    Object.entries(n).forEach(([t, n]) => {
                        e[t] = n;
                    }),
                    e
                );
            }, {});
        return Kr(e);
    })(e);
    if (!t) return;
    const n = Object.entries(t).reduce((e, [t, n]) => {
        if (t.match(Nr)) {
            e[t.slice(7)] = n;
        }
        return e;
    }, {});
    return Object.keys(n).length > 0 ? n : void 0;
}
function Kr(e) {
    return e
        .split(",")
        .map((e) =>
            e.split("=").map((e) => {
                try {
                    return decodeURIComponent(e.trim());
                } catch {
                    return;
                }
            })
        )
        .reduce((e, [t, n]) => (t && n && (e[t] = n), e), {});
}
const Fr = /^o(\d+)\./,
    Br = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
function zr(e, t = !1) {
    const {
        host: n,
        path: r,
        pass: s,
        port: o,
        projectId: i,
        protocol: a,
        publicKey: c,
    } = e;
    return `${a}://${c}${t && s ? `:${s}` : ""}@${n}${o ? `:${o}` : ""}/${
        r ? `${r}/` : r
    }${i}`;
}
function qr(e) {
    return {
        protocol: e.protocol,
        publicKey: e.publicKey || "",
        pass: e.pass || "",
        host: e.host,
        port: e.port || "",
        path: e.path || "",
        projectId: e.projectId,
    };
}
function Vr(e) {
    const t = e.getOptions(),
        { host: n } = e.getDsn() || {};
    let r;
    return (
        t.orgId
            ? (r = String(t.orgId))
            : n &&
              (r = (function (e) {
                  const t = e.match(Fr);
                  return t?.[1];
              })(n)),
        r
    );
}
function Gr(e) {
    const t =
        "string" == typeof e
            ? (function (e) {
                  const t = Br.exec(e);
                  if (!t) return void dn(() => {});
                  const [n, r, s = "", o = "", i = "", a = ""] = t.slice(1);
                  let c = "",
                      u = a;
                  const l = u.split("/");
                  if (
                      (l.length > 1 &&
                          ((c = l.slice(0, -1).join("/")), (u = l.pop())),
                      u)
                  ) {
                      const e = u.match(/^\d+/);
                      e && (u = e[0]);
                  }
                  return qr({
                      host: o,
                      pass: s,
                      path: c,
                      projectId: u,
                      port: i,
                      protocol: n,
                      publicKey: r,
                  });
              })(e)
            : qr(e);
    if (
        t &&
        (function (e) {
            if (!nn) return !0;
            const { port: t, projectId: n, protocol: r } = e;
            return !(
                ["protocol", "publicKey", "host", "projectId"].find(
                    (t) =>
                        !e[t] &&
                        (_n.error(`Invalid Sentry Dsn: ${t} missing`), !0)
                ) ||
                (n.match(/^\d+$/)
                    ? (function (e) {
                          return "http" === e || "https" === e;
                      })(r)
                        ? t &&
                          isNaN(parseInt(t, 10)) &&
                          (_n.error(`Invalid Sentry Dsn: Invalid port ${t}`), 1)
                        : (_n.error(
                              `Invalid Sentry Dsn: Invalid protocol ${r}`
                          ),
                          1)
                    : (_n.error(`Invalid Sentry Dsn: Invalid projectId ${n}`),
                      1))
            );
        })(t)
    )
        return t;
}
let Wr = !1;
function Hr(e) {
    const { spanId: t, traceId: n, isRemote: r } = e.spanContext(),
        s = r ? t : Qr(e).parent_span_id,
        o = Mr(e).scope;
    return {
        parent_span_id: s,
        span_id: r ? o?.getPropagationContext().propagationSpanId || br() : t,
        trace_id: n,
    };
}
function Jr(e) {
    return e && e.length > 0
        ? e.map(
              ({
                  context: { spanId: e, traceId: t, traceFlags: n, ...r },
                  attributes: s,
              }) => ({
                  span_id: e,
                  trace_id: t,
                  sampled: 1 === n,
                  attributes: s,
                  ...r,
              })
          )
        : void 0;
}
function Yr(e) {
    return "number" == typeof e
        ? Xr(e)
        : Array.isArray(e)
        ? e[0] + e[1] / 1e9
        : e instanceof Date
        ? Xr(e.getTime())
        : _r();
}
function Xr(e) {
    return e > 9999999999 ? e / 1e3 : e;
}
function Qr(e) {
    if (
        (function (e) {
            return "function" == typeof e.getSpanJSON;
        })(e)
    )
        return e.getSpanJSON();
    const { spanId: t, traceId: n } = e.spanContext();
    if (
        (function (e) {
            const t = e;
            return !!(
                t.attributes &&
                t.startTime &&
                t.name &&
                t.endTime &&
                t.status
            );
        })(e)
    ) {
        const {
            attributes: r,
            startTime: s,
            name: o,
            endTime: i,
            status: a,
            links: c,
        } = e;
        return {
            span_id: t,
            trace_id: n,
            data: r,
            description: o,
            parent_span_id:
                "parentSpanId" in e
                    ? e.parentSpanId
                    : "parentSpanContext" in e
                    ? e.parentSpanContext?.spanId
                    : void 0,
            start_timestamp: Yr(s),
            timestamp: Yr(i) || void 0,
            status: Zr(a),
            op: r["sentry.op"],
            origin: r["sentry.origin"],
            links: Jr(c),
        };
    }
    return { span_id: t, trace_id: n, start_timestamp: 0, data: {} };
}
function Zr(e) {
    if (e && 0 !== e.code)
        return 1 === e.code ? "ok" : e.message || "unknown_error";
}
function es(e) {
    return e._sentryRootSpan || e;
}
function ts() {
    Wr || (dn(() => {}), (Wr = !0));
}
const ns = "production";
function rs(e, t) {
    const n = t.getOptions(),
        { publicKey: r } = t.getDsn() || {},
        s = {
            environment: n.environment || ns,
            release: n.release,
            public_key: r,
            trace_id: e,
            org_id: Vr(t),
        };
    return t.emit("createDsc", s), s;
}
function ss(e) {
    const t = Rr();
    if (!t) return {};
    const n = es(e),
        r = Qr(n),
        s = r.data,
        o = n.spanContext().traceState,
        i =
            o?.get("sentry.sample_rate") ??
            s["sentry.sample_rate"] ??
            s["sentry.previous_trace_sample_rate"];
    function a(e) {
        return (
            ("number" != typeof i && "string" != typeof i) ||
                (e.sample_rate = `${i}`),
            e
        );
    }
    const c = n._frozenDsc;
    if (c) return a(c);
    const u = o?.get("sentry.dsc"),
        l = u && $r(u);
    if (l) return a(l);
    const d = rs(e.spanContext().traceId, t),
        f = s["sentry.source"],
        h = r.description;
    return (
        "url" !== f && h && (d.transaction = h),
        (function () {
            if ("boolean" == typeof __SENTRY_TRACING__ && !__SENTRY_TRACING__)
                return !1;
            const e = Rr()?.getOptions();
            return !(!e || (null == e.tracesSampleRate && !e.tracesSampler));
        })() &&
            ((d.sampled = String(
                (function (e) {
                    const { traceFlags: t } = e.spanContext();
                    return 1 === t;
                })(n)
            )),
            (d.sample_rand =
                o?.get("sentry.sample_rand") ??
                Mr(n).scope?.getPropagationContext().sampleRand.toString())),
        a(d),
        t.emit("createDsc", d, n),
        d
    );
}
function os(e, t = 100, n = 1 / 0) {
    try {
        return as("", e, t, n);
    } catch (r) {
        return { ERROR: `**non-serializable** (${r})` };
    }
}
function is(e, t = 3, n = 102400) {
    const r = os(e, t);
    return (
        (s = r),
        (function (e) {
            return ~-encodeURI(e).split(/%..|./).length;
        })(JSON.stringify(s)) > n
            ? is(e, t - 1, n)
            : r
    );
    var s;
}
function as(
    e,
    t,
    n = 1 / 0,
    r = 1 / 0,
    s = (function () {
        const e = new WeakSet();
        function t(t) {
            return !!e.has(t) || (e.add(t), !1);
        }
        function n(t) {
            e.delete(t);
        }
        return [t, n];
    })()
) {
    const [o, i] = s;
    if (
        null == t ||
        ["boolean", "string"].includes(typeof t) ||
        ("number" == typeof t && Number.isFinite(t))
    )
        return t;
    const a = (function (e, t) {
        try {
            if ("domain" === e && t && "object" == typeof t && t._events)
                return "[Domain]";
            if ("domainEmitter" === e) return "[DomainEmitter]";
            if ("undefined" != typeof globalThis && t === globalThis)
                return "[Global]";
            if ("undefined" != typeof window && t === window) return "[Window]";
            if ("undefined" != typeof document && t === document)
                return "[Document]";
            if (Vn(t)) return "[VueViewModel]";
            if (
                Fn((n = t)) &&
                "nativeEvent" in n &&
                "preventDefault" in n &&
                "stopPropagation" in n
            )
                return "[SyntheticEvent]";
            if ("number" == typeof t && !Number.isFinite(t)) return `[${t}]`;
            if ("function" == typeof t) return `[Function: ${Sn(t)}]`;
            if ("symbol" == typeof t) return `[${String(t)}]`;
            if ("bigint" == typeof t) return `[BigInt: ${String(t)}]`;
            const r = (function (e) {
                const t = Object.getPrototypeOf(e);
                return t?.constructor ? t.constructor.name : "null prototype";
            })(t);
            return /^HTML(\w*)Element$/.test(r)
                ? `[HTMLElement: ${r}]`
                : `[object ${r}]`;
        } catch (r) {
            return `**non-serializable** (${r})`;
        }
        var n;
    })(e, t);
    if (!a.startsWith("[object ")) return a;
    if (t.__sentry_skip_normalization__) return t;
    const c =
        "number" == typeof t.__sentry_override_normalization_depth__
            ? t.__sentry_override_normalization_depth__
            : n;
    if (0 === c) return a.replace("object ", "");
    if (o(t)) return "[Circular ~]";
    const u = t;
    if (u && "function" == typeof u.toJSON)
        try {
            return as("", u.toJSON(), c - 1, r, s);
        } catch {}
    const l = Array.isArray(t) ? [] : {};
    let d = 0;
    const f = sr(t);
    for (const h in f) {
        if (!Object.prototype.hasOwnProperty.call(f, h)) continue;
        if (d >= r) {
            l[h] = "[MaxProperties ~]";
            break;
        }
        const e = f[h];
        (l[h] = as(h, e, c - 1, r, s)), d++;
    }
    return i(t), l;
}
function cs(e, t = []) {
    return [e, t];
}
function us(e, t) {
    const [n, r] = e;
    return [n, [...r, t]];
}
function ls(e, t) {
    const n = e[1];
    for (const r of n) {
        if (t(r, r[0].type)) return !0;
    }
    return !1;
}
function ds(e) {
    const t = an(rn);
    return t.encodePolyfill ? t.encodePolyfill(e) : new TextEncoder().encode(e);
}
function fs(e) {
    const [t, n] = e;
    let r = JSON.stringify(t);
    function s(e) {
        "string" == typeof r
            ? (r = "string" == typeof e ? r + e : [ds(r), e])
            : r.push("string" == typeof e ? ds(e) : e);
    }
    for (const o of n) {
        const [e, t] = o;
        if (
            (s(`\n${JSON.stringify(e)}\n`),
            "string" == typeof t || t instanceof Uint8Array)
        )
            s(t);
        else {
            let e;
            try {
                e = JSON.stringify(t);
            } catch {
                e = JSON.stringify(os(t));
            }
            s(e);
        }
    }
    return "string" == typeof r
        ? r
        : (function (e) {
              const t = e.reduce((e, t) => e + t.length, 0),
                  n = new Uint8Array(t);
              let r = 0;
              for (const s of e) n.set(s, r), (r += s.length);
              return n;
          })(r);
}
function hs(e) {
    const t = "string" == typeof e.data ? ds(e.data) : e.data;
    return [
        {
            type: "attachment",
            length: t.length,
            filename: e.filename,
            content_type: e.contentType,
            attachment_type: e.attachmentType,
        },
        t,
    ];
}
const ps = {
    session: "session",
    sessions: "session",
    attachment: "attachment",
    transaction: "transaction",
    event: "error",
    client_report: "internal",
    user_report: "default",
    profile: "profile",
    profile_chunk: "profile",
    replay_event: "replay",
    replay_recording: "replay",
    check_in: "monitor",
    feedback: "feedback",
    span: "span",
    raw_security: "security",
    log: "log_item",
};
function _s(e) {
    return ps[e];
}
function gs(e) {
    if (!e?.sdk) return;
    const { name: t, version: n } = e.sdk;
    return { name: t, version: n };
}
function ms(e, t) {
    if (!t?.length || !e.description) return !1;
    for (const n of t) {
        if (ys(n)) {
            if (Qn(e.description, n)) return !0;
            continue;
        }
        if (!n.name && !n.op) continue;
        const t = !n.name || Qn(e.description, n.name),
            r = !n.op || (e.op && Qn(e.op, n.op));
        if (t && r) return !0;
    }
    return !1;
}
function vs(e, t) {
    const n = t.parent_span_id,
        r = t.span_id;
    if (n) for (const s of e) s.parent_span_id === r && (s.parent_span_id = n);
}
function ys(e) {
    return "string" == typeof e || e instanceof RegExp;
}
function bs(e, t, n, r) {
    const s = gs(n),
        o = e.type && "replay_event" !== e.type ? e.type : "event";
    !(function (e, t) {
        if (!t) return e;
        const n = e.sdk || {};
        e.sdk = {
            ...n,
            name: n.name || t.name,
            version: n.version || t.version,
            integrations: [
                ...(e.sdk?.integrations || []),
                ...(t.integrations || []),
            ],
            packages: [...(e.sdk?.packages || []), ...(t.packages || [])],
            settings:
                e.sdk?.settings || t.settings
                    ? { ...e.sdk?.settings, ...t.settings }
                    : void 0,
        };
    })(e, n?.sdk);
    const i = (function (e, t, n, r) {
        const s = e.sdkProcessingMetadata?.dynamicSamplingContext;
        return {
            event_id: e.event_id,
            sent_at: new Date().toISOString(),
            ...(t && { sdk: t }),
            ...(!!n && r && { dsn: zr(r) }),
            ...(s && { trace: s }),
        };
    })(e, s, r, t);
    delete e.sdkProcessingMetadata;
    return cs(i, [[{ type: o }, e]]);
}
function Es(e) {
    return new ks((t) => {
        t(e);
    });
}
function Ss(e) {
    return new ks((t, n) => {
        n(e);
    });
}
class ks {
    constructor(e) {
        (this._state = 0), (this._handlers = []), this._runExecutor(e);
    }
    then(e, t) {
        return new ks((n, r) => {
            this._handlers.push([
                !1,
                (t) => {
                    if (e)
                        try {
                            n(e(t));
                        } catch (s) {
                            r(s);
                        }
                    else n(t);
                },
                (e) => {
                    if (t)
                        try {
                            n(t(e));
                        } catch (s) {
                            r(s);
                        }
                    else r(e);
                },
            ]),
                this._executeHandlers();
        });
    }
    catch(e) {
        return this.then((e) => e, e);
    }
    finally(e) {
        return new ks((t, n) => {
            let r, s;
            return this.then(
                (t) => {
                    (s = !1), (r = t), e && e();
                },
                (t) => {
                    (s = !0), (r = t), e && e();
                }
            ).then(() => {
                s ? n(r) : t(r);
            });
        });
    }
    _executeHandlers() {
        if (0 === this._state) return;
        const e = this._handlers.slice();
        (this._handlers = []),
            e.forEach((e) => {
                e[0] ||
                    (1 === this._state && e[1](this._value),
                    2 === this._state && e[2](this._value),
                    (e[0] = !0));
            });
    }
    _runExecutor(e) {
        const t = (e, t) => {
                0 === this._state &&
                    (zn(t)
                        ? t.then(n, r)
                        : ((this._state = e),
                          (this._value = t),
                          this._executeHandlers()));
            },
            n = (e) => {
                t(1, e);
            },
            r = (e) => {
                t(2, e);
            };
        try {
            e(n, r);
        } catch (s) {
            r(s);
        }
    }
}
function ws(e, t, n, r = 0) {
    return new ks((s, o) => {
        const i = e[r];
        if (null === t || "function" != typeof i) s(t);
        else {
            const a = i({ ...t }, n);
            nn &&
                i.id &&
                null === a &&
                _n.log(`Event processor "${i.id}" dropped event`),
                zn(a)
                    ? a.then((t) => ws(e, t, n, r + 1).then(s)).then(null, o)
                    : ws(e, a, n, r + 1)
                          .then(s)
                          .then(null, o);
        }
    });
}
function xs(e, t) {
    const {
        fingerprint: n,
        span: r,
        breadcrumbs: s,
        sdkProcessingMetadata: o,
    } = t;
    !(function (e, t) {
        const {
            extra: n,
            tags: r,
            user: s,
            contexts: o,
            level: i,
            transactionName: a,
        } = t;
        Object.keys(n).length && (e.extra = { ...n, ...e.extra });
        Object.keys(r).length && (e.tags = { ...r, ...e.tags });
        Object.keys(s).length && (e.user = { ...s, ...e.user });
        Object.keys(o).length && (e.contexts = { ...o, ...e.contexts });
        i && (e.level = i);
        a && "transaction" !== e.type && (e.transaction = a);
    })(e, t),
        r &&
            (function (e, t) {
                (e.contexts = { trace: Hr(t), ...e.contexts }),
                    (e.sdkProcessingMetadata = {
                        dynamicSamplingContext: ss(t),
                        ...e.sdkProcessingMetadata,
                    });
                const n = es(t),
                    r = Qr(n).description;
                r &&
                    !e.transaction &&
                    "transaction" === e.type &&
                    (e.transaction = r);
            })(e, r),
        (function (e, t) {
            (e.fingerprint = e.fingerprint
                ? Array.isArray(e.fingerprint)
                    ? e.fingerprint
                    : [e.fingerprint]
                : []),
                t && (e.fingerprint = e.fingerprint.concat(t));
            e.fingerprint.length || delete e.fingerprint;
        })(e, n),
        (function (e, t) {
            const n = [...(e.breadcrumbs || []), ...t];
            e.breadcrumbs = n.length ? n : void 0;
        })(e, s),
        (function (e, t) {
            e.sdkProcessingMetadata = { ...e.sdkProcessingMetadata, ...t };
        })(e, o);
}
function Os(e, t) {
    const {
        extra: n,
        tags: r,
        user: s,
        contexts: o,
        level: i,
        sdkProcessingMetadata: a,
        breadcrumbs: c,
        fingerprint: u,
        eventProcessors: l,
        attachments: d,
        propagationContext: f,
        transactionName: h,
        span: p,
    } = t;
    Is(e, "extra", n),
        Is(e, "tags", r),
        Is(e, "user", s),
        Is(e, "contexts", o),
        (e.sdkProcessingMetadata = vr(e.sdkProcessingMetadata, a, 2)),
        i && (e.level = i),
        h && (e.transactionName = h),
        p && (e.span = p),
        c.length && (e.breadcrumbs = [...e.breadcrumbs, ...c]),
        u.length && (e.fingerprint = [...e.fingerprint, ...u]),
        l.length && (e.eventProcessors = [...e.eventProcessors, ...l]),
        d.length && (e.attachments = [...e.attachments, ...d]),
        (e.propagationContext = { ...e.propagationContext, ...f });
}
function Is(e, t, n) {
    e[t] = vr(e[t], n, 1);
}
let Ds, Cs, Ts;
function Ps(e, t, n, r, s, o) {
    const { normalizeDepth: i = 3, normalizeMaxBreadth: a = 1e3 } = e,
        c = {
            ...t,
            event_id: t.event_id || n.event_id || ar(),
            timestamp: t.timestamp || hr(),
        },
        u = n.integrations || e.integrations.map((e) => e.name);
    !(function (e, t) {
        const {
            environment: n,
            release: r,
            dist: s,
            maxValueLength: o = 250,
        } = t;
        (e.environment = e.environment || n || ns),
            !e.release && r && (e.release = r);
        !e.dist && s && (e.dist = s);
        const i = e.request;
        i?.url && (i.url = Yn(i.url, o));
    })(c, e),
        (function (e, t) {
            t.length > 0 &&
                ((e.sdk = e.sdk || {}),
                (e.sdk.integrations = [...(e.sdk.integrations || []), ...t]));
        })(c, u),
        s && s.emit("applyFrameMetadata", t),
        void 0 === t.type &&
            (function (e, t) {
                const n = (function (e) {
                    const t = rn._sentryDebugIds;
                    if (!t) return {};
                    const n = Object.keys(t);
                    return (
                        (Ts && n.length === Cs) ||
                            ((Cs = n.length),
                            (Ts = n.reduce((n, r) => {
                                Ds || (Ds = {});
                                const s = Ds[r];
                                if (s) n[s[0]] = s[1];
                                else {
                                    const s = e(r);
                                    for (let e = s.length - 1; e >= 0; e--) {
                                        const o = s[e],
                                            i = o?.filename,
                                            a = t[r];
                                        if (i && a) {
                                            (n[i] = a), (Ds[r] = [i, a]);
                                            break;
                                        }
                                    }
                                }
                                return n;
                            }, {}))),
                        Ts
                    );
                })(t);
                e.exception?.values?.forEach((e) => {
                    e.stacktrace?.frames?.forEach((e) => {
                        e.filename && (e.debug_id = n[e.filename]);
                    });
                });
            })(c, e.stackParser);
    const l = (function (e, t) {
        if (!t) return e;
        const n = e ? e.clone() : new wr();
        return n.update(t), n;
    })(r, n.captureContext);
    n.mechanism && dr(c, n.mechanism);
    const d = s ? s.getEventProcessors() : [],
        f = cn("globalScope", () => new wr()).getScopeData();
    if (o) {
        Os(f, o.getScopeData());
    }
    if (l) {
        Os(f, l.getScopeData());
    }
    const h = [...(n.attachments || []), ...f.attachments];
    h.length && (n.attachments = h), xs(c, f);
    return ws([...d, ...f.eventProcessors], c, n).then(
        (e) => (
            e &&
                (function (e) {
                    const t = {};
                    if (
                        (e.exception?.values?.forEach((e) => {
                            e.stacktrace?.frames?.forEach((e) => {
                                e.debug_id &&
                                    (e.abs_path
                                        ? (t[e.abs_path] = e.debug_id)
                                        : e.filename &&
                                          (t[e.filename] = e.debug_id),
                                    delete e.debug_id);
                            });
                        }),
                        0 === Object.keys(t).length)
                    )
                        return;
                    (e.debug_meta = e.debug_meta || {}),
                        (e.debug_meta.images = e.debug_meta.images || []);
                    const n = e.debug_meta.images;
                    Object.entries(t).forEach(([e, t]) => {
                        n.push({
                            type: "sourcemap",
                            code_file: e,
                            debug_id: t,
                        });
                    });
                })(e),
            "number" == typeof i && i > 0
                ? (function (e, t, n) {
                      if (!e) return null;
                      const r = {
                          ...e,
                          ...(e.breadcrumbs && {
                              breadcrumbs: e.breadcrumbs.map((e) => ({
                                  ...e,
                                  ...(e.data && { data: os(e.data, t, n) }),
                              })),
                          }),
                          ...(e.user && { user: os(e.user, t, n) }),
                          ...(e.contexts && { contexts: os(e.contexts, t, n) }),
                          ...(e.extra && { extra: os(e.extra, t, n) }),
                      };
                      e.contexts?.trace &&
                          r.contexts &&
                          ((r.contexts.trace = e.contexts.trace),
                          e.contexts.trace.data &&
                              (r.contexts.trace.data = os(
                                  e.contexts.trace.data,
                                  t,
                                  n
                              )));
                      e.spans &&
                          (r.spans = e.spans.map((e) => ({
                              ...e,
                              ...(e.data && { data: os(e.data, t, n) }),
                          })));
                      e.contexts?.flags &&
                          r.contexts &&
                          (r.contexts.flags = os(e.contexts.flags, 3, n));
                      return r;
                  })(e, i, a)
                : e
        )
    );
}
function As(e, t) {
    return Pr().captureEvent(e, t);
}
function Rs(e) {
    const t = Ar(),
        n = Pr(),
        { userAgent: r } = rn.navigator || {},
        s = gr({
            user: n.getUser() || t.getUser(),
            ...(r && { userAgent: r }),
            ...e,
        }),
        o = t.getSession();
    return (
        "ok" === o?.status && mr(o, { status: "exited" }),
        js(),
        t.setSession(s),
        s
    );
}
function js() {
    const e = Ar(),
        t = Pr().getSession() || e.getSession();
    t &&
        (function (e) {
            let t = {};
            "ok" === e.status && (t = { status: "exited" }), mr(e, t);
        })(t),
        Ls(),
        e.setSession();
}
function Ls() {
    const e = Ar(),
        t = Rr(),
        n = e.getSession();
    n && t && t.captureSession(n);
}
function Us(e = !1) {
    e ? js() : Ls();
}
function Ms(e, t, n) {
    return (
        t ||
        `${(function (e) {
            return `${(function (e) {
                const t = e.protocol ? `${e.protocol}:` : "",
                    n = e.port ? `:${e.port}` : "";
                return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
            })(e)}${e.projectId}/envelope/`;
        })(e)}?${(function (e, t) {
            const n = { sentry_version: "7" };
            return (
                e.publicKey && (n.sentry_key = e.publicKey),
                t && (n.sentry_client = `${t.name}/${t.version}`),
                new URLSearchParams(n).toString()
            );
        })(e, n)}`
    );
}
const Ns = [];
function $s(e) {
    const t = e.defaultIntegrations || [],
        n = e.integrations;
    let r;
    if (
        (t.forEach((e) => {
            e.isDefaultInstance = !0;
        }),
        Array.isArray(n))
    )
        r = [...t, ...n];
    else if ("function" == typeof n) {
        const e = n(t);
        r = Array.isArray(e) ? e : [e];
    } else r = t;
    return (function (e) {
        const t = {};
        return (
            e.forEach((e) => {
                const { name: n } = e,
                    r = t[n];
                (r && !r.isDefaultInstance && e.isDefaultInstance) ||
                    (t[n] = e);
            }),
            Object.values(t)
        );
    })(r);
}
function Ks(e, t) {
    for (const n of t) n?.afterAllSetup && n.afterAllSetup(e);
}
function Fs(e, t, n) {
    if (n[t.name])
        nn &&
            _n.log(
                `Integration skipped because it was already installed: ${t.name}`
            );
    else {
        if (
            ((n[t.name] = t),
            -1 === Ns.indexOf(t.name) &&
                "function" == typeof t.setupOnce &&
                (t.setupOnce(), Ns.push(t.name)),
            t.setup && "function" == typeof t.setup && t.setup(e),
            "function" == typeof t.preprocessEvent)
        ) {
            const n = t.preprocessEvent.bind(t);
            e.on("preprocessEvent", (t, r) => n(t, r, e));
        }
        if ("function" == typeof t.processEvent) {
            const n = t.processEvent.bind(t),
                r = Object.assign((t, r) => n(t, r, e), { id: t.name });
            e.addEventProcessor(r);
        }
        nn && _n.log(`Integration installed: ${t.name}`);
    }
}
function Bs(e) {
    const t = [];
    e.message && t.push(e.message);
    try {
        const n = e.exception.values[e.exception.values.length - 1];
        n?.value &&
            (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`));
    } catch {}
    return t;
}
const zs = "Not capturing exception because it's already been captured.",
    qs = "Discarded session because of missing or non-string release",
    Vs = Symbol.for("SentryInternalError"),
    Gs = Symbol.for("SentryDoNotSendEventError");
function Ws(e) {
    return { message: e, [Vs]: !0 };
}
function Hs(e) {
    return { message: e, [Gs]: !0 };
}
function Js(e) {
    return !!e && "object" == typeof e && Vs in e;
}
function Ys(e) {
    return !!e && "object" == typeof e && Gs in e;
}
class Xs {
    constructor(e) {
        if (
            ((this._options = e),
            (this._integrations = {}),
            (this._numProcessing = 0),
            (this._outcomes = {}),
            (this._hooks = {}),
            (this._eventProcessors = []),
            e.dsn
                ? (this._dsn = Gr(e.dsn))
                : nn &&
                  _n.warn("No DSN provided, client will not send events."),
            this._dsn)
        ) {
            const t = Ms(
                this._dsn,
                e.tunnel,
                e._metadata ? e._metadata.sdk : void 0
            );
            this._transport = e.transport({
                tunnel: this._options.tunnel,
                recordDroppedEvent: this.recordDroppedEvent.bind(this),
                ...e.transportOptions,
                url: t,
            });
        }
    }
    captureException(e, t, n) {
        const r = ar();
        if (fr(e)) return nn && _n.log(zs), r;
        const s = { event_id: r, ...t };
        return (
            this._process(
                this.eventFromException(e, s).then((e) =>
                    this._captureEvent(e, s, n)
                )
            ),
            s.event_id
        );
    }
    captureMessage(e, t, n, r) {
        const s = { event_id: ar(), ...n },
            o = $n(e) ? e : String(e),
            i = Kn(e)
                ? this.eventFromMessage(o, t, s)
                : this.eventFromException(e, s);
        return (
            this._process(i.then((e) => this._captureEvent(e, s, r))),
            s.event_id
        );
    }
    captureEvent(e, t, n) {
        const r = ar();
        if (t?.originalException && fr(t.originalException))
            return nn && _n.log(zs), r;
        const s = { event_id: r, ...t },
            o = e.sdkProcessingMetadata || {},
            i = o.capturedSpanScope,
            a = o.capturedSpanIsolationScope;
        return this._process(this._captureEvent(e, s, i || n, a)), s.event_id;
    }
    captureSession(e) {
        this.sendSession(e), mr(e, { init: !1 });
    }
    getDsn() {
        return this._dsn;
    }
    getOptions() {
        return this._options;
    }
    getSdkMetadata() {
        return this._options._metadata;
    }
    getTransport() {
        return this._transport;
    }
    flush(e) {
        const t = this._transport;
        return t
            ? (this.emit("flush"),
              this._isClientDoneProcessing(e).then((n) =>
                  t.flush(e).then((e) => n && e)
              ))
            : Es(!0);
    }
    close(e) {
        return this.flush(e).then(
            (e) => ((this.getOptions().enabled = !1), this.emit("close"), e)
        );
    }
    getEventProcessors() {
        return this._eventProcessors;
    }
    addEventProcessor(e) {
        this._eventProcessors.push(e);
    }
    init() {
        (this._isEnabled() ||
            this._options.integrations.some(({ name: e }) =>
                e.startsWith("Spotlight")
            )) &&
            this._setupIntegrations();
    }
    getIntegrationByName(e) {
        return this._integrations[e];
    }
    addIntegration(e) {
        const t = this._integrations[e.name];
        Fs(this, e, this._integrations), t || Ks(this, [e]);
    }
    sendEvent(e, t = {}) {
        this.emit("beforeSendEvent", e, t);
        let n = bs(e, this._dsn, this._options._metadata, this._options.tunnel);
        for (const s of t.attachments || []) n = us(n, hs(s));
        const r = this.sendEnvelope(n);
        r && r.then((t) => this.emit("afterSendEvent", e, t), null);
    }
    sendSession(e) {
        const { release: t, environment: n = ns } = this._options;
        if ("aggregates" in e) {
            const r = e.attrs || {};
            if (!r.release && !t) return void (nn && _n.warn(qs));
            (r.release = r.release || t),
                (r.environment = r.environment || n),
                (e.attrs = r);
        } else {
            if (!e.release && !t) return void (nn && _n.warn(qs));
            (e.release = e.release || t), (e.environment = e.environment || n);
        }
        this.emit("beforeSendSession", e);
        const r = (function (e, t, n, r) {
            const s = gs(n);
            return cs(
                {
                    sent_at: new Date().toISOString(),
                    ...(s && { sdk: s }),
                    ...(!!r && t && { dsn: zr(t) }),
                },
                [
                    "aggregates" in e
                        ? [{ type: "sessions" }, e]
                        : [{ type: "session" }, e.toJSON()],
                ]
            );
        })(e, this._dsn, this._options._metadata, this._options.tunnel);
        this.sendEnvelope(r);
    }
    recordDroppedEvent(e, t, n = 1) {
        if (this._options.sendClientReports) {
            const r = `${e}:${t}`;
            nn &&
                _n.log(
                    `Recording outcome: "${r}"${n > 1 ? ` (${n} times)` : ""}`
                ),
                (this._outcomes[r] = (this._outcomes[r] || 0) + n);
        }
    }
    on(e, t) {
        const n = (this._hooks[e] = this._hooks[e] || []);
        return (
            n.push(t),
            () => {
                const e = n.indexOf(t);
                e > -1 && n.splice(e, 1);
            }
        );
    }
    emit(e, ...t) {
        const n = this._hooks[e];
        n && n.forEach((e) => e(...t));
    }
    sendEnvelope(e) {
        return (
            this.emit("beforeEnvelope", e),
            this._isEnabled() && this._transport
                ? this._transport
                      .send(e)
                      .then(
                          null,
                          (e) => (
                              nn &&
                                  _n.error("Error while sending envelope:", e),
                              e
                          )
                      )
                : (nn && _n.error("Transport disabled"), Es({}))
        );
    }
    _setupIntegrations() {
        const { integrations: e } = this._options;
        (this._integrations = (function (e, t) {
            const n = {};
            return (
                t.forEach((t) => {
                    t && Fs(e, t, n);
                }),
                n
            );
        })(this, e)),
            Ks(this, e);
    }
    _updateSessionFromEvent(e, t) {
        let n = "fatal" === t.level,
            r = !1;
        const s = t.exception?.values;
        if (s) {
            r = !0;
            for (const e of s) {
                const t = e.mechanism;
                if (!1 === t?.handled) {
                    n = !0;
                    break;
                }
            }
        }
        const o = "ok" === e.status;
        ((o && 0 === e.errors) || (o && n)) &&
            (mr(e, {
                ...(n && { status: "crashed" }),
                errors: e.errors || Number(r || n),
            }),
            this.captureSession(e));
    }
    _isClientDoneProcessing(e) {
        return new ks((t) => {
            let n = 0;
            const r = setInterval(() => {
                0 == this._numProcessing
                    ? (clearInterval(r), t(!0))
                    : ((n += 1), e && n >= e && (clearInterval(r), t(!1)));
            }, 1);
        });
    }
    _isEnabled() {
        return !1 !== this.getOptions().enabled && void 0 !== this._transport;
    }
    _prepareEvent(e, t, n, r) {
        const s = this.getOptions(),
            o = Object.keys(this._integrations);
        return (
            !t.integrations && o?.length && (t.integrations = o),
            this.emit("preprocessEvent", e, t),
            e.type || r.setLastEventId(e.event_id || t.event_id),
            Ps(s, e, t, n, this, r).then((e) => {
                if (null === e) return e;
                this.emit("postprocessEvent", e, t),
                    (e.contexts = { trace: jr(n), ...e.contexts });
                const r = (function (e, t) {
                    const n = t.getPropagationContext();
                    return n.dsc || rs(n.traceId, e);
                })(this, n);
                return (
                    (e.sdkProcessingMetadata = {
                        dynamicSamplingContext: r,
                        ...e.sdkProcessingMetadata,
                    }),
                    e
                );
            })
        );
    }
    _captureEvent(e, t = {}, n = Pr(), r = Ar()) {
        return (
            nn &&
                Qs(e) &&
                _n.log(`Captured error event \`${Bs(e)[0] || "<unknown>"}\``),
            this._processEvent(e, t, n, r).then(
                (e) => e.event_id,
                (e) => {
                    nn &&
                        (Ys(e)
                            ? _n.log(e.message)
                            : Js(e)
                            ? _n.warn(e.message)
                            : _n.warn(e));
                }
            )
        );
    }
    _processEvent(e, t, n, r) {
        const s = this.getOptions(),
            { sampleRate: o } = s,
            i = Zs(e),
            a = Qs(e),
            c = e.type || "error",
            u = `before send for type \`${c}\``,
            l =
                void 0 === o
                    ? void 0
                    : (function (e) {
                          if ("boolean" == typeof e) return Number(e);
                          const t = "string" == typeof e ? parseFloat(e) : e;
                          return "number" != typeof t ||
                              isNaN(t) ||
                              t < 0 ||
                              t > 1
                              ? void 0
                              : t;
                      })(o);
        if (a && "number" == typeof l && Math.random() > l)
            return (
                this.recordDroppedEvent("sample_rate", "error"),
                Ss(
                    Hs(
                        `Discarding event because it's not included in the random sample (sampling rate = ${o})`
                    )
                )
            );
        const d = "replay_event" === c ? "replay" : c;
        return this._prepareEvent(e, t, n, r)
            .then((e) => {
                if (null === e)
                    throw (
                        (this.recordDroppedEvent("event_processor", d),
                        Hs(
                            "An event processor returned `null`, will not send event."
                        ))
                    );
                if (t.data && !0 === t.data.__sentry__) return e;
                const n = (function (e, t, n, r) {
                    const {
                        beforeSend: s,
                        beforeSendTransaction: o,
                        beforeSendSpan: i,
                        ignoreSpans: a,
                    } = t;
                    let c = n;
                    if (Qs(c) && s) return s(c, r);
                    if (Zs(c)) {
                        if (i || a) {
                            const t = (function (e) {
                                const {
                                    trace_id: t,
                                    parent_span_id: n,
                                    span_id: r,
                                    status: s,
                                    origin: o,
                                    data: i,
                                    op: a,
                                } = e.contexts?.trace ?? {};
                                return {
                                    data: i ?? {},
                                    description: e.transaction,
                                    op: a,
                                    parent_span_id: n,
                                    span_id: r ?? "",
                                    start_timestamp: e.start_timestamp ?? 0,
                                    status: s,
                                    timestamp: e.timestamp,
                                    trace_id: t ?? "",
                                    origin: o,
                                    profile_id: i?.[Lr],
                                    exclusive_time: i?.[Ur],
                                    measurements: e.measurements,
                                    is_segment: !0,
                                };
                            })(c);
                            if (a?.length && ms(t, a)) return null;
                            if (i) {
                                const e = i(t);
                                e
                                    ? (c = vr(n, {
                                          type: "transaction",
                                          timestamp: (u = e).timestamp,
                                          start_timestamp: u.start_timestamp,
                                          transaction: u.description,
                                          contexts: {
                                              trace: {
                                                  trace_id: u.trace_id,
                                                  span_id: u.span_id,
                                                  parent_span_id:
                                                      u.parent_span_id,
                                                  op: u.op,
                                                  status: u.status,
                                                  origin: u.origin,
                                                  data: {
                                                      ...u.data,
                                                      ...(u.profile_id && {
                                                          [Lr]: u.profile_id,
                                                      }),
                                                      ...(u.exclusive_time && {
                                                          [Ur]: u.exclusive_time,
                                                      }),
                                                  },
                                              },
                                          },
                                          measurements: u.measurements,
                                      }))
                                    : ts();
                            }
                            if (c.spans) {
                                const t = [],
                                    n = c.spans;
                                for (const e of n)
                                    if (a?.length && ms(e, a)) vs(n, e);
                                    else if (i) {
                                        const n = i(e);
                                        n ? t.push(n) : (ts(), t.push(e));
                                    } else t.push(e);
                                const r = c.spans.length - t.length;
                                r &&
                                    e.recordDroppedEvent(
                                        "before_send",
                                        "span",
                                        r
                                    ),
                                    (c.spans = t);
                            }
                        }
                        if (o) {
                            if (c.spans) {
                                const e = c.spans.length;
                                c.sdkProcessingMetadata = {
                                    ...n.sdkProcessingMetadata,
                                    spanCountBeforeProcessing: e,
                                };
                            }
                            return o(c, r);
                        }
                    }
                    var u;
                    return c;
                })(this, s, e, t);
                return (function (e, t) {
                    const n = `${t} must return \`null\` or a valid event.`;
                    if (zn(e))
                        return e.then(
                            (e) => {
                                if (!Fn(e) && null !== e) throw Ws(n);
                                return e;
                            },
                            (e) => {
                                throw Ws(`${t} rejected with ${e}`);
                            }
                        );
                    if (!Fn(e) && null !== e) throw Ws(n);
                    return e;
                })(n, u);
            })
            .then((s) => {
                if (null === s) {
                    if ((this.recordDroppedEvent("before_send", d), i)) {
                        const t = 1 + (e.spans || []).length;
                        this.recordDroppedEvent("before_send", "span", t);
                    }
                    throw Hs(`${u} returned \`null\`, will not send event.`);
                }
                const o = n.getSession() || r.getSession();
                if ((a && o && this._updateSessionFromEvent(o, s), i)) {
                    const e =
                        (s.sdkProcessingMetadata?.spanCountBeforeProcessing ||
                            0) - (s.spans ? s.spans.length : 0);
                    e > 0 && this.recordDroppedEvent("before_send", "span", e);
                }
                const c = s.transaction_info;
                if (i && c && s.transaction !== e.transaction) {
                    const e = "custom";
                    s.transaction_info = { ...c, source: e };
                }
                return this.sendEvent(s, t), s;
            })
            .then(null, (e) => {
                if (Ys(e) || Js(e)) throw e;
                throw (
                    (this.captureException(e, {
                        mechanism: { handled: !1, type: "internal" },
                        data: { __sentry__: !0 },
                        originalException: e,
                    }),
                    Ws(
                        `Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: ${e}`
                    ))
                );
            });
    }
    _process(e) {
        this._numProcessing++,
            e.then(
                (e) => (this._numProcessing--, e),
                (e) => (this._numProcessing--, e)
            );
    }
    _clearOutcomes() {
        const e = this._outcomes;
        return (
            (this._outcomes = {}),
            Object.entries(e).map(([e, t]) => {
                const [n, r] = e.split(":");
                return { reason: n, category: r, quantity: t };
            })
        );
    }
    _flushOutcomes() {
        nn && _n.log("Flushing outcomes...");
        const e = this._clearOutcomes();
        if (0 === e.length) return void (nn && _n.log("No outcomes to send"));
        if (!this._dsn)
            return void (
                nn && _n.log("No dsn provided, will not send outcomes")
            );
        nn && _n.log("Sending outcomes:", e);
        const t =
            ((n = e),
            cs((r = this._options.tunnel && zr(this._dsn)) ? { dsn: r } : {}, [
                [
                    { type: "client_report" },
                    { timestamp: hr(), discarded_events: n },
                ],
            ]));
        var n, r;
        this.sendEnvelope(t);
    }
}
function Qs(e) {
    return void 0 === e.type;
}
function Zs(e) {
    return "transaction" === e.type;
}
function eo(e, t) {
    const n =
        (function (e) {
            return to().get(e);
        })(e) ?? [];
    if (0 === n.length) return;
    const r = e.getOptions(),
        s = (function (e, t, n, r) {
            const s = {};
            return (
                t?.sdk &&
                    (s.sdk = { name: t.sdk.name, version: t.sdk.version }),
                n && r && (s.dsn = zr(r)),
                cs(s, [
                    ((o = e),
                    [
                        {
                            type: "log",
                            item_count: o.length,
                            content_type:
                                "application/vnd.sentry.items.log+json",
                        },
                        { items: o },
                    ]),
                ])
            );
            var o;
        })(n, r._metadata, r.tunnel, e.getDsn());
    to().set(e, []), e.emit("flushLogs"), e.sendEnvelope(s);
}
function to() {
    return cn("clientToLogBufferMap", () => new WeakMap());
}
function no(e, t) {
    !0 === t.debug && (nn ? _n.enable() : dn(() => {}));
    Pr().update(t.initialScope);
    const n = new e(t);
    return (
        (function (e) {
            Pr().setClient(e);
        })(n),
        n.init(),
        n
    );
}
const ro = Symbol.for("SentryBufferFullError");
function so(e) {
    const t = [];
    function n(e) {
        return t.splice(t.indexOf(e), 1)[0] || Promise.resolve(void 0);
    }
    return {
        $: t,
        add: function (r) {
            if (!(void 0 === e || t.length < e)) return Ss(ro);
            const s = r();
            return (
                -1 === t.indexOf(s) && t.push(s),
                s.then(() => n(s)).then(null, () => n(s).then(null, () => {})),
                s
            );
        },
        drain: function (e) {
            return new ks((n, r) => {
                let s = t.length;
                if (!s) return n(!0);
                const o = setTimeout(() => {
                    e && e > 0 && n(!1);
                }, e);
                t.forEach((e) => {
                    Es(e).then(() => {
                        --s || (clearTimeout(o), n(!0));
                    }, r);
                });
            });
        },
    };
}
function oo(e, { statusCode: t, headers: n }, r = Date.now()) {
    const s = { ...e },
        o = n?.["x-sentry-rate-limits"],
        i = n?.["retry-after"];
    if (o)
        for (const a of o.trim().split(",")) {
            const [e, t, , , n] = a.split(":", 5),
                o = parseInt(e, 10),
                i = 1e3 * (isNaN(o) ? 60 : o);
            if (t)
                for (const a of t.split(";"))
                    ("metric_bucket" === a &&
                        n &&
                        !n.split(";").includes("custom")) ||
                        (s[a] = r + i);
            else s.all = r + i;
        }
    else
        i
            ? (s.all =
                  r +
                  (function (e, t = Date.now()) {
                      const n = parseInt(`${e}`, 10);
                      if (!isNaN(n)) return 1e3 * n;
                      const r = Date.parse(`${e}`);
                      return isNaN(r) ? 6e4 : r - t;
                  })(i, r))
            : 429 === t && (s.all = r + 6e4);
    return s;
}
function io(e, t, n = so(e.bufferSize || 64)) {
    let r = {};
    return {
        send: function (s) {
            const o = [];
            if (
                (ls(s, (t, n) => {
                    const s = _s(n);
                    !(function (e, t, n = Date.now()) {
                        return (
                            (function (e, t) {
                                return e[t] || e.all || 0;
                            })(e, t) > n
                        );
                    })(r, s)
                        ? o.push(t)
                        : e.recordDroppedEvent("ratelimit_backoff", s);
                }),
                0 === o.length)
            )
                return Es({});
            const i = cs(s[0], o),
                a = (t) => {
                    ls(i, (n, r) => {
                        e.recordDroppedEvent(t, _s(r));
                    });
                };
            return n
                .add(() =>
                    t({ body: fs(i) }).then(
                        (e) => (
                            void 0 !== e.statusCode &&
                                (e.statusCode < 200 || e.statusCode >= 300) &&
                                nn &&
                                _n.warn(
                                    `Sentry responded with status code ${e.statusCode} to sent event.`
                                ),
                            (r = oo(r, e)),
                            e
                        ),
                        (e) => {
                            throw (
                                (a("network_error"),
                                nn &&
                                    _n.error(
                                        "Encountered error running transport request:",
                                        e
                                    ),
                                e)
                            );
                        }
                    )
                )
                .then(
                    (e) => e,
                    (e) => {
                        if (e === ro)
                            return (
                                nn &&
                                    _n.error(
                                        "Skipped sending event because buffer is full."
                                    ),
                                a("queue_overflow"),
                                Es({})
                            );
                        throw e;
                    }
                );
        },
        flush: (e) => n.drain(e),
    };
}
function ao(e) {
    if (!e) return {};
    const t = e.match(
        /^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/
    );
    if (!t) return {};
    const n = t[6] || "",
        r = t[8] || "";
    return {
        host: t[4],
        path: t[5],
        protocol: t[2],
        search: n,
        hash: r,
        relative: t[5] + n + r,
    };
}
function co(e) {
    "aggregates" in e
        ? void 0 === e.attrs?.ip_address &&
          (e.attrs = { ...e.attrs, ip_address: "{{auto}}" })
        : void 0 === e.ipAddress && (e.ipAddress = "{{auto}}");
}
const uo = 100;
function lo(e, t) {
    const n = Rr(),
        r = Ar();
    if (!n) return;
    const { beforeBreadcrumb: s = null, maxBreadcrumbs: o = uo } =
        n.getOptions();
    if (o <= 0) return;
    const i = { timestamp: hr(), ...e },
        a = s ? dn(() => s(i, t)) : i;
    null !== a &&
        (n.emit && n.emit("beforeAddBreadcrumb", a, t), r.addBreadcrumb(a, o));
}
let fo;
const ho = new WeakMap(),
    po = () => ({
        name: "FunctionToString",
        setupOnce() {
            fo = Function.prototype.toString;
            try {
                Function.prototype.toString = function (...e) {
                    const t = rr(this),
                        n = ho.has(Rr()) && void 0 !== t ? t : this;
                    return fo.apply(n, e);
                };
            } catch {}
        },
        setup(e) {
            ho.set(e, !0);
        },
    }),
    _o = [
        /^Script error\.?$/,
        /^Javascript error: Script error\.? on line 0$/,
        /^ResizeObserver loop completed with undelivered notifications.$/,
        /^Cannot redefine property: googletag$/,
        /^Can't find variable: gmo$/,
        /^undefined is not an object \(evaluating 'a\.[A-Z]'\)$/,
        'can\'t redefine non-configurable property "solana"',
        "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
        "Can't find variable: _AutofillCallbackHandler",
        /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/,
        /^Java exception was raised during method invocation$/,
    ],
    go = (e = {}) => {
        let t;
        return {
            name: "EventFilters",
            setup(n) {
                const r = n.getOptions();
                t = vo(e, r);
            },
            processEvent(n, r, s) {
                if (!t) {
                    const n = s.getOptions();
                    t = vo(e, n);
                }
                return (function (e, t) {
                    if (e.type) {
                        if (
                            "transaction" === e.type &&
                            (function (e, t) {
                                if (!t?.length) return !1;
                                const n = e.transaction;
                                return !!n && Zn(n, t);
                            })(e, t.ignoreTransactions)
                        )
                            return (
                                nn &&
                                    _n.warn(
                                        `Event dropped due to being matched by \`ignoreTransactions\` option.\nEvent: ${ur(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                    } else {
                        if (
                            (function (e, t) {
                                if (!t?.length) return !1;
                                return Bs(e).some((e) => Zn(e, t));
                            })(e, t.ignoreErrors)
                        )
                            return (
                                nn &&
                                    _n.warn(
                                        `Event dropped due to being matched by \`ignoreErrors\` option.\nEvent: ${ur(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                        if (
                            (function (e) {
                                if (!e.exception?.values?.length) return !1;
                                return (
                                    !e.message &&
                                    !e.exception.values.some(
                                        (e) =>
                                            e.stacktrace ||
                                            (e.type && "Error" !== e.type) ||
                                            e.value
                                    )
                                );
                            })(e)
                        )
                            return (
                                nn &&
                                    _n.warn(
                                        `Event dropped due to not having an error message, error type or stacktrace.\nEvent: ${ur(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                        if (
                            (function (e, t) {
                                if (!t?.length) return !1;
                                const n = yo(e);
                                return !!n && Zn(n, t);
                            })(e, t.denyUrls)
                        )
                            return (
                                nn &&
                                    _n.warn(
                                        `Event dropped due to being matched by \`denyUrls\` option.\nEvent: ${ur(
                                            e
                                        )}.\nUrl: ${yo(e)}`
                                    ),
                                !0
                            );
                        if (
                            !(function (e, t) {
                                if (!t?.length) return !0;
                                const n = yo(e);
                                return !n || Zn(n, t);
                            })(e, t.allowUrls)
                        )
                            return (
                                nn &&
                                    _n.warn(
                                        `Event dropped due to not being matched by \`allowUrls\` option.\nEvent: ${ur(
                                            e
                                        )}.\nUrl: ${yo(e)}`
                                    ),
                                !0
                            );
                    }
                    return !1;
                })(n, t)
                    ? null
                    : n;
            },
        };
    },
    mo = (e = {}) => ({ ...go(e), name: "InboundFilters" });
function vo(e = {}, t = {}) {
    return {
        allowUrls: [...(e.allowUrls || []), ...(t.allowUrls || [])],
        denyUrls: [...(e.denyUrls || []), ...(t.denyUrls || [])],
        ignoreErrors: [
            ...(e.ignoreErrors || []),
            ...(t.ignoreErrors || []),
            ...(e.disableErrorDefaults ? [] : _o),
        ],
        ignoreTransactions: [
            ...(e.ignoreTransactions || []),
            ...(t.ignoreTransactions || []),
        ],
    };
}
function yo(e) {
    try {
        const t = [...(e.exception?.values ?? [])]
                .reverse()
                .find(
                    (e) =>
                        void 0 === e.mechanism?.parent_id &&
                        e.stacktrace?.frames?.length
                ),
            n = t?.stacktrace?.frames;
        return n
            ? (function (e = []) {
                  for (let t = e.length - 1; t >= 0; t--) {
                      const n = e[t];
                      if (
                          n &&
                          "<anonymous>" !== n.filename &&
                          "[native code]" !== n.filename
                      )
                          return n.filename || null;
                  }
                  return null;
              })(n)
            : null;
    } catch {
        return nn && _n.error(`Cannot extract url for event ${ur(e)}`), null;
    }
}
function bo(e, t, n, r, s, o) {
    if (!s.exception?.values || !o || !qn(o.originalException, Error)) return;
    const i =
        s.exception.values.length > 0
            ? s.exception.values[s.exception.values.length - 1]
            : void 0;
    i &&
        (s.exception.values = Eo(
            e,
            t,
            r,
            o.originalException,
            n,
            s.exception.values,
            i,
            0
        ));
}
function Eo(e, t, n, r, s, o, i, a) {
    if (o.length >= n + 1) return o;
    let c = [...o];
    if (qn(r[s], Error)) {
        So(i, a);
        const o = e(t, r[s]),
            u = c.length;
        ko(o, s, u, a), (c = Eo(e, t, n, r[s], s, [o, ...c], o, u));
    }
    return (
        Array.isArray(r.errors) &&
            r.errors.forEach((r, o) => {
                if (qn(r, Error)) {
                    So(i, a);
                    const u = e(t, r),
                        l = c.length;
                    ko(u, `errors[${o}]`, l, a),
                        (c = Eo(e, t, n, r, s, [u, ...c], u, l));
                }
            }),
        c
    );
}
function So(e, t) {
    (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
        (e.mechanism = {
            ...e.mechanism,
            ...("AggregateError" === e.type && { is_exception_group: !0 }),
            exception_id: t,
        });
}
function ko(e, t, n, r) {
    (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
        (e.mechanism = {
            ...e.mechanism,
            type: "chained",
            source: t,
            exception_id: n,
            parent_id: r,
        });
}
function wo() {
    "console" in rn &&
        un.forEach(function (e) {
            e in rn.console &&
                er(rn.console, e, function (t) {
                    return (
                        (ln[e] = t),
                        function (...t) {
                            Dn("console", { args: t, level: e });
                            const n = ln[e];
                            n?.apply(rn.console, t);
                        }
                    );
                });
        });
}
function xo(e) {
    return "warn" === e
        ? "warning"
        : ["fatal", "error", "warning", "log", "info", "debug"].includes(e)
        ? e
        : "log";
}
const Oo = () => {
    let e;
    return {
        name: "Dedupe",
        processEvent(t) {
            if (t.type) return t;
            try {
                if (
                    (function (e, t) {
                        if (!t) return !1;
                        if (
                            (function (e, t) {
                                const n = e.message,
                                    r = t.message;
                                if (!n && !r) return !1;
                                if ((n && !r) || (!n && r)) return !1;
                                if (n !== r) return !1;
                                if (!Do(e, t)) return !1;
                                if (!Io(e, t)) return !1;
                                return !0;
                            })(e, t)
                        )
                            return !0;
                        if (
                            (function (e, t) {
                                const n = Co(t),
                                    r = Co(e);
                                if (!n || !r) return !1;
                                if (n.type !== r.type || n.value !== r.value)
                                    return !1;
                                if (!Do(e, t)) return !1;
                                if (!Io(e, t)) return !1;
                                return !0;
                            })(e, t)
                        )
                            return !0;
                        return !1;
                    })(t, e)
                )
                    return (
                        nn &&
                            _n.warn(
                                "Event dropped due to being a duplicate of previously captured event."
                            ),
                        null
                    );
            } catch {}
            return (e = t);
        },
    };
};
function Io(e, t) {
    let n = kn(e),
        r = kn(t);
    if (!n && !r) return !0;
    if ((n && !r) || (!n && r)) return !1;
    if (r.length !== n.length) return !1;
    for (let s = 0; s < r.length; s++) {
        const e = r[s],
            t = n[s];
        if (
            e.filename !== t.filename ||
            e.lineno !== t.lineno ||
            e.colno !== t.colno ||
            e.function !== t.function
        )
            return !1;
    }
    return !0;
}
function Do(e, t) {
    let n = e.fingerprint,
        r = t.fingerprint;
    if (!n && !r) return !0;
    if ((n && !r) || (!n && r)) return !1;
    try {
        return !(n.join("") !== r.join(""));
    } catch {
        return !1;
    }
}
function Co(e) {
    return e.exception?.values?.[0];
}
function To(e) {
    return void 0 === e
        ? void 0
        : e >= 400 && e < 500
        ? "warning"
        : e >= 500
        ? "error"
        : void 0;
}
const Po = rn;
function Ao(e) {
    return (
        e &&
        /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString())
    );
}
function Ro() {
    if ("string" == typeof EdgeRuntime) return !0;
    if (
        !(function () {
            if (!("fetch" in Po)) return !1;
            try {
                return (
                    new Headers(),
                    new Request("http://www.example.com"),
                    new Response(),
                    !0
                );
            } catch {
                return !1;
            }
        })()
    )
        return !1;
    if (Ao(Po.fetch)) return !0;
    let e = !1;
    const t = Po.document;
    if (t && "function" == typeof t.createElement)
        try {
            const n = t.createElement("iframe");
            (n.hidden = !0),
                t.head.appendChild(n),
                n.contentWindow?.fetch && (e = Ao(n.contentWindow.fetch)),
                t.head.removeChild(n);
        } catch (n) {
            nn &&
                _n.warn(
                    "Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",
                    n
                );
        }
    return e;
}
function jo(e, t) {
    const n = "fetch";
    On(n, e),
        In(n, () =>
            (function (e, t = !1) {
                if (t && !Ro()) return;
                er(rn, "fetch", function (e) {
                    return function (...t) {
                        const n = new Error(),
                            { method: r, url: s } = (function (e) {
                                if (0 === e.length)
                                    return { method: "GET", url: "" };
                                if (2 === e.length) {
                                    const [t, n] = e;
                                    return {
                                        url: Uo(t),
                                        method: Lo(n, "method")
                                            ? String(n.method).toUpperCase()
                                            : "GET",
                                    };
                                }
                                const t = e[0];
                                return {
                                    url: Uo(t),
                                    method: Lo(t, "method")
                                        ? String(t.method).toUpperCase()
                                        : "GET",
                                };
                            })(t),
                            o = {
                                args: t,
                                fetchData: { method: r, url: s },
                                startTimestamp: 1e3 * _r(),
                                virtualError: n,
                                headers: Mo(t),
                            };
                        return (
                            Dn("fetch", { ...o }),
                            e.apply(rn, t).then(
                                async (e) => (
                                    Dn("fetch", {
                                        ...o,
                                        endTimestamp: 1e3 * _r(),
                                        response: e,
                                    }),
                                    e
                                ),
                                (e) => {
                                    if (
                                        (Dn("fetch", {
                                            ...o,
                                            endTimestamp: 1e3 * _r(),
                                            error: e,
                                        }),
                                        jn(e) &&
                                            void 0 === e.stack &&
                                            ((e.stack = n.stack),
                                            tr(e, "framesToPop", 1)),
                                        e instanceof TypeError &&
                                            ("Failed to fetch" === e.message ||
                                                "Load failed" === e.message ||
                                                "NetworkError when attempting to fetch resource." ===
                                                    e.message))
                                    )
                                        try {
                                            const t = new URL(o.fetchData.url);
                                            e.message = `${e.message} (${t.host})`;
                                        } catch {}
                                    throw e;
                                }
                            )
                        );
                    };
                });
            })(0, t)
        );
}
function Lo(e, t) {
    return !!e && "object" == typeof e && !!e[t];
}
function Uo(e) {
    return "string" == typeof e
        ? e
        : e
        ? Lo(e, "url")
            ? e.url
            : e.toString
            ? e.toString()
            : ""
        : "";
}
function Mo(e) {
    const [t, n] = e;
    try {
        if ("object" == typeof n && null !== n && "headers" in n && n.headers)
            return new Headers(n.headers);
        if (((r = t), "undefined" != typeof Request && qn(r, Request)))
            return new Headers(t.headers);
    } catch {}
    var r;
}
const No = rn;
let $o = 0;
function Ko() {
    return $o > 0;
}
function Fo(e, t = {}) {
    if ("function" != typeof e) return e;
    try {
        const t = e.__sentry_wrapped__;
        if (t) return "function" == typeof t ? t : e;
        if (rr(e)) return e;
    } catch {
        return e;
    }
    const n = function (...n) {
        try {
            const r = n.map((e) => Fo(e, t));
            return e.apply(this, r);
        } catch (r) {
            throw (
                ($o++,
                setTimeout(() => {
                    $o--;
                }),
                (function (...e) {
                    const t = Tr(on());
                    if (2 === e.length) {
                        const [n, r] = e;
                        return n ? t.withSetScope(n, r) : t.withScope(r);
                    }
                    t.withScope(e[0]);
                })((e) => {
                    var s;
                    e.addEventProcessor(
                        (e) => (
                            t.mechanism && (lr(e, void 0), dr(e, t.mechanism)),
                            (e.extra = { ...e.extra, arguments: n }),
                            e
                        )
                    ),
                        (s = r),
                        Pr().captureException(s, void 0);
                }),
                r)
            );
        }
    };
    try {
        for (const t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    } catch {}
    nr(n, e), tr(e, "__sentry_wrapped__", n);
    try {
        Object.getOwnPropertyDescriptor(n, "name").configurable &&
            Object.defineProperty(n, "name", { get: () => e.name });
    } catch {}
    return n;
}
function Bo(e, t) {
    const n = Vo(e, t),
        r = { type: Ho(t), value: Jo(t) };
    return (
        n.length && (r.stacktrace = { frames: n }),
        void 0 === r.type &&
            "" === r.value &&
            (r.value = "Unrecoverable error caught"),
        r
    );
}
function zo(e, t, n, r) {
    const s = Rr(),
        o = s?.getOptions().normalizeDepth,
        i = (function (e) {
            for (const t in e)
                if (Object.prototype.hasOwnProperty.call(e, t)) {
                    const n = e[t];
                    if (n instanceof Error) return n;
                }
            return;
        })(t),
        a = { __serialized__: is(t, o) };
    if (i) return { exception: { values: [Bo(e, i)] }, extra: a };
    const c = {
        exception: {
            values: [
                {
                    type: Bn(t)
                        ? t.constructor.name
                        : r
                        ? "UnhandledRejection"
                        : "Error",
                    value: Qo(t, { isUnhandledRejection: r }),
                },
            ],
        },
        extra: a,
    };
    if (n) {
        const t = Vo(e, n);
        t.length && (c.exception.values[0].stacktrace = { frames: t });
    }
    return c;
}
function qo(e, t) {
    return { exception: { values: [Bo(e, t)] } };
}
function Vo(e, t) {
    const n = t.stacktrace || t.stack || "",
        r = (function (e) {
            if (e && Go.test(e.message)) return 1;
            return 0;
        })(t),
        s = (function (e) {
            if ("number" == typeof e.framesToPop) return e.framesToPop;
            return 0;
        })(t);
    try {
        return e(n, r, s);
    } catch {}
    return [];
}
const Go = /Minified React error #\d+;/i;
function Wo(e) {
    return (
        "undefined" != typeof WebAssembly &&
        void 0 !== WebAssembly.Exception &&
        e instanceof WebAssembly.Exception
    );
}
function Ho(e) {
    const t = e?.name;
    if (!t && Wo(e)) {
        return e.message && Array.isArray(e.message) && 2 == e.message.length
            ? e.message[0]
            : "WebAssembly.Exception";
    }
    return t;
}
function Jo(e) {
    const t = e?.message;
    return Wo(e)
        ? Array.isArray(e.message) && 2 == e.message.length
            ? e.message[1]
            : "wasm exception"
        : t
        ? t.error && "string" == typeof t.error.message
            ? t.error.message
            : t
        : "No error message";
}
function Yo(e, t, n, r, s) {
    let o;
    if (Un(t) && t.error) {
        return qo(e, t.error);
    }
    if (Mn(t) || Ln(t, "DOMException")) {
        const s = t;
        if ("stack" in t) o = qo(e, t);
        else {
            const t = s.name || (Mn(s) ? "DOMError" : "DOMException"),
                i = s.message ? `${t}: ${s.message}` : t;
            (o = Xo(e, i, n, r)), lr(o, i);
        }
        return (
            "code" in s &&
                (o.tags = { ...o.tags, "DOMException.code": `${s.code}` }),
            o
        );
    }
    if (jn(t)) return qo(e, t);
    if (Fn(t) || Bn(t)) {
        return (o = zo(e, t, n, s)), dr(o, { synthetic: !0 }), o;
    }
    return (o = Xo(e, t, n, r)), lr(o, `${t}`), dr(o, { synthetic: !0 }), o;
}
function Xo(e, t, n, r) {
    const s = {};
    if (r && n) {
        const r = Vo(e, n);
        r.length &&
            (s.exception = {
                values: [{ value: t, stacktrace: { frames: r } }],
            }),
            dr(s, { synthetic: !0 });
    }
    if ($n(t)) {
        const { __sentry_template_string__: e, __sentry_template_values__: n } =
            t;
        return (s.logentry = { message: e, params: n }), s;
    }
    return (s.message = t), s;
}
function Qo(e, { isUnhandledRejection: t }) {
    const n = (function (e, t = 40) {
            const n = Object.keys(sr(e));
            n.sort();
            const r = n[0];
            if (!r) return "[object has no keys]";
            if (r.length >= t) return Yn(r, t);
            for (let s = n.length; s > 0; s--) {
                const e = n.slice(0, s).join(", ");
                if (!(e.length > t)) return s === n.length ? e : Yn(e, t);
            }
            return "";
        })(e),
        r = t ? "promise rejection" : "exception";
    if (Un(e))
        return `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\``;
    if (Bn(e)) {
        return `Event \`${(function (e) {
            try {
                const t = Object.getPrototypeOf(e);
                return t ? t.constructor.name : void 0;
            } catch {}
        })(e)}\` (type=${e.type}) captured as ${r}`;
    }
    return `Object captured as ${r} with keys: ${n}`;
}
class Zo extends Xs {
    constructor(e) {
        const t =
            ((n = e),
            {
                release:
                    "string" == typeof __SENTRY_RELEASE__
                        ? __SENTRY_RELEASE__
                        : No.SENTRY_RELEASE?.id,
                sendClientReports: !0,
                parentSpanIsAlwaysRootSpan: !0,
                ...n,
            });
        var n;
        !(function (e, t, n = [t], r = "npm") {
            const s = e._metadata || {};
            s.sdk ||
                (s.sdk = {
                    name: `sentry.javascript.${t}`,
                    packages: n.map((e) => ({
                        name: `${r}:@sentry/${e}`,
                        version: sn,
                    })),
                    version: sn,
                }),
                (e._metadata = s);
        })(t, "browser", ["browser"], No.SENTRY_SDK_SOURCE || "npm"),
            t._metadata?.sdk &&
                (t._metadata.sdk.settings = {
                    infer_ip: t.sendDefaultPii ? "auto" : "never",
                    ...t._metadata.sdk.settings,
                }),
            super(t);
        const {
            sendDefaultPii: r,
            sendClientReports: s,
            enableLogs: o,
        } = this._options;
        No.document &&
            (s || o) &&
            No.document.addEventListener("visibilitychange", () => {
                "hidden" === No.document.visibilityState &&
                    (s && this._flushOutcomes(), o && eo(this));
            }),
            o &&
                (this.on("flush", () => {
                    eo(this);
                }),
                this.on("afterCaptureLog", () => {
                    this._logFlushIdleTimeout &&
                        clearTimeout(this._logFlushIdleTimeout),
                        (this._logFlushIdleTimeout = setTimeout(() => {
                            eo(this);
                        }, 5e3));
                })),
            r && this.on("beforeSendSession", co);
    }
    eventFromException(e, t) {
        return (function (e, t, n, r) {
            const s = Yo(e, t, n?.syntheticException || void 0, r);
            return (
                dr(s),
                (s.level = "error"),
                n?.event_id && (s.event_id = n.event_id),
                Es(s)
            );
        })(this._options.stackParser, e, t, this._options.attachStacktrace);
    }
    eventFromMessage(e, t = "info", n) {
        return (function (e, t, n = "info", r, s) {
            const o = Xo(e, t, r?.syntheticException || void 0, s);
            return (
                (o.level = n), r?.event_id && (o.event_id = r.event_id), Es(o)
            );
        })(this._options.stackParser, e, t, n, this._options.attachStacktrace);
    }
    _prepareEvent(e, t, n, r) {
        return (
            (e.platform = e.platform || "javascript"),
            super._prepareEvent(e, t, n, r)
        );
    }
}
const ei = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    ti = rn;
let ni, ri, si, oi;
function ii() {
    if (!ti.document) return;
    const e = Dn.bind(null, "dom"),
        t = ai(e, !0);
    ti.document.addEventListener("click", t, !1),
        ti.document.addEventListener("keypress", t, !1),
        ["EventTarget", "Node"].forEach((t) => {
            const n = ti,
                r = n[t]?.prototype;
            r?.hasOwnProperty?.("addEventListener") &&
                (er(r, "addEventListener", function (t) {
                    return function (n, r, s) {
                        if ("click" === n || "keypress" == n)
                            try {
                                const r =
                                        (this.__sentry_instrumentation_handlers__ =
                                            this
                                                .__sentry_instrumentation_handlers__ ||
                                            {}),
                                    o = (r[n] = r[n] || { refCount: 0 });
                                if (!o.handler) {
                                    const r = ai(e);
                                    (o.handler = r), t.call(this, n, r, s);
                                }
                                o.refCount++;
                            } catch {}
                        return t.call(this, n, r, s);
                    };
                }),
                er(r, "removeEventListener", function (e) {
                    return function (t, n, r) {
                        if ("click" === t || "keypress" == t)
                            try {
                                const n =
                                        this
                                            .__sentry_instrumentation_handlers__ ||
                                        {},
                                    s = n[t];
                                s &&
                                    (s.refCount--,
                                    s.refCount <= 0 &&
                                        (e.call(this, t, s.handler, r),
                                        (s.handler = void 0),
                                        delete n[t]),
                                    0 === Object.keys(n).length &&
                                        delete this
                                            .__sentry_instrumentation_handlers__);
                            } catch {}
                        return e.call(this, t, n, r);
                    };
                }));
        });
}
function ai(e, t = !1) {
    return (n) => {
        if (!n || n._sentryCaptured) return;
        const r = (function (e) {
            try {
                return e.target;
            } catch {
                return null;
            }
        })(n);
        if (
            (function (e, t) {
                return (
                    "keypress" === e &&
                    (!t?.tagName ||
                        ("INPUT" !== t.tagName &&
                            "TEXTAREA" !== t.tagName &&
                            !t.isContentEditable))
                );
            })(n.type, r)
        )
            return;
        tr(n, "_sentryCaptured", !0),
            r && !r._sentryId && tr(r, "_sentryId", ar());
        const s = "keypress" === n.type ? "input" : n.type;
        if (
            !(function (e) {
                if (e.type !== ri) return !1;
                try {
                    if (!e.target || e.target._sentryId !== si) return !1;
                } catch {}
                return !0;
            })(n)
        ) {
            e({ event: n, name: s, global: t }),
                (ri = n.type),
                (si = r ? r._sentryId : void 0);
        }
        clearTimeout(ni),
            (ni = ti.setTimeout(() => {
                (si = void 0), (ri = void 0);
            }, 1e3));
    };
}
function ci(e) {
    const t = "history";
    On(t, e), In(t, ui);
}
function ui() {
    function e(e) {
        return function (...t) {
            const n = t.length > 2 ? t[2] : void 0;
            if (n) {
                const r = oi,
                    s = (function (e) {
                        try {
                            return new URL(e, ti.location.origin).toString();
                        } catch {
                            return e;
                        }
                    })(String(n));
                if (((oi = s), r === s)) return e.apply(this, t);
                Dn("history", { from: r, to: s });
            }
            return e.apply(this, t);
        };
    }
    ti.addEventListener("popstate", () => {
        const e = ti.location.href,
            t = oi;
        if (((oi = e), t === e)) return;
        Dn("history", { from: t, to: e });
    }),
        "history" in Po &&
            Po.history &&
            (er(ti.history, "pushState", e), er(ti.history, "replaceState", e));
}
const li = {};
function di(e) {
    li[e] = void 0;
}
const fi = "__sentry_xhr_v3__";
function hi() {
    if (!ti.XMLHttpRequest) return;
    const e = XMLHttpRequest.prototype;
    (e.open = new Proxy(e.open, {
        apply(e, t, n) {
            const r = new Error(),
                s = 1e3 * _r(),
                o = Nn(n[0]) ? n[0].toUpperCase() : void 0,
                i = (function (e) {
                    if (Nn(e)) return e;
                    try {
                        return e.toString();
                    } catch {}
                    return;
                })(n[1]);
            if (!o || !i) return e.apply(t, n);
            (t[fi] = { method: o, url: i, request_headers: {} }),
                "POST" === o &&
                    i.match(/sentry_key/) &&
                    (t.__sentry_own_request__ = !0);
            const a = () => {
                const e = t[fi];
                if (e && 4 === t.readyState) {
                    try {
                        e.status_code = t.status;
                    } catch {}
                    Dn("xhr", {
                        endTimestamp: 1e3 * _r(),
                        startTimestamp: s,
                        xhr: t,
                        virtualError: r,
                    });
                }
            };
            return (
                "onreadystatechange" in t &&
                "function" == typeof t.onreadystatechange
                    ? (t.onreadystatechange = new Proxy(t.onreadystatechange, {
                          apply: (e, t, n) => (a(), e.apply(t, n)),
                      }))
                    : t.addEventListener("readystatechange", a),
                (t.setRequestHeader = new Proxy(t.setRequestHeader, {
                    apply(e, t, n) {
                        const [r, s] = n,
                            o = t[fi];
                        return (
                            o &&
                                Nn(r) &&
                                Nn(s) &&
                                (o.request_headers[r.toLowerCase()] = s),
                            e.apply(t, n)
                        );
                    },
                })),
                e.apply(t, n)
            );
        },
    })),
        (e.send = new Proxy(e.send, {
            apply(e, t, n) {
                const r = t[fi];
                if (!r) return e.apply(t, n);
                void 0 !== n[0] && (r.body = n[0]);
                return (
                    Dn("xhr", { startTimestamp: 1e3 * _r(), xhr: t }),
                    e.apply(t, n)
                );
            },
        }));
}
function pi(
    e,
    t = (function (e) {
        const t = li[e];
        if (t) return t;
        let n = ti[e];
        if (Ao(n)) return (li[e] = n.bind(ti));
        const r = ti.document;
        if (r && "function" == typeof r.createElement)
            try {
                const t = r.createElement("iframe");
                (t.hidden = !0), r.head.appendChild(t);
                const s = t.contentWindow;
                s?.[e] && (n = s[e]), r.head.removeChild(t);
            } catch (s) {
                ei &&
                    _n.warn(
                        `Could not create sandbox iframe for ${e} check, bailing to window.${e}: `,
                        s
                    );
            }
        return n ? (li[e] = n.bind(ti)) : n;
    })("fetch")
) {
    let n = 0,
        r = 0;
    return io(e, function (s) {
        const o = s.body.length;
        (n += o), r++;
        const i = {
            body: s.body,
            method: "POST",
            referrerPolicy: "strict-origin",
            headers: e.headers,
            keepalive: n <= 6e4 && r < 15,
            ...e.fetchOptions,
        };
        if (!t) return di("fetch"), Ss("No fetch implementation available");
        try {
            return t(e.url, i).then(
                (e) => (
                    (n -= o),
                    r--,
                    {
                        statusCode: e.status,
                        headers: {
                            "x-sentry-rate-limits": e.headers.get(
                                "X-Sentry-Rate-Limits"
                            ),
                            "retry-after": e.headers.get("Retry-After"),
                        },
                    }
                )
            );
        } catch (a) {
            return di("fetch"), (n -= o), r--, Ss(a);
        }
    });
}
function _i(e, t, n, r) {
    const s = {
        filename: e,
        function: "<anonymous>" === t ? gn : t,
        in_app: !0,
    };
    return void 0 !== n && (s.lineno = n), void 0 !== r && (s.colno = r), s;
}
const gi = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
    mi =
        /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
    vi = /\((\S*)(?::(\d+))(?::(\d+))\)/,
    yi = /at (.+?) ?\(data:(.+?),/,
    bi =
        /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
    Ei = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
    Si = yn(
        ...[
            [
                30,
                (e) => {
                    const t = e.match(yi);
                    if (t)
                        return { filename: `<data:${t[2]}>`, function: t[1] };
                    const n = gi.exec(e);
                    if (n) {
                        const [, e, t, r] = n;
                        return _i(e, gn, +t, +r);
                    }
                    const r = mi.exec(e);
                    if (r) {
                        if (r[2] && 0 === r[2].indexOf("eval")) {
                            const e = vi.exec(r[2]);
                            e && ((r[2] = e[1]), (r[3] = e[2]), (r[4] = e[3]));
                        }
                        const [e, t] = ki(r[1] || gn, r[2]);
                        return _i(
                            t,
                            e,
                            r[3] ? +r[3] : void 0,
                            r[4] ? +r[4] : void 0
                        );
                    }
                },
            ],
            [
                50,
                (e) => {
                    const t = bi.exec(e);
                    if (t) {
                        if (t[3] && t[3].indexOf(" > eval") > -1) {
                            const e = Ei.exec(t[3]);
                            e &&
                                ((t[1] = t[1] || "eval"),
                                (t[3] = e[1]),
                                (t[4] = e[2]),
                                (t[5] = ""));
                        }
                        let e = t[3],
                            n = t[1] || gn;
                        return (
                            ([n, e] = ki(n, e)),
                            _i(
                                e,
                                n,
                                t[4] ? +t[4] : void 0,
                                t[5] ? +t[5] : void 0
                            )
                        );
                    }
                },
            ],
        ]
    ),
    ki = (e, t) => {
        const n = -1 !== e.indexOf("safari-extension"),
            r = -1 !== e.indexOf("safari-web-extension");
        return n || r
            ? [
                  -1 !== e.indexOf("@") ? e.split("@")[0] : gn,
                  n ? `safari-extension:${t}` : `safari-web-extension:${t}`,
              ]
            : [e, t];
    },
    wi = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    xi = 1024,
    Oi = (e = {}) => {
        const t = {
            console: !0,
            dom: !0,
            fetch: !0,
            history: !0,
            sentry: !0,
            xhr: !0,
            ...e,
        };
        return {
            name: "Breadcrumbs",
            setup(e) {
                var n;
                t.console &&
                    (function (e) {
                        const t = "console";
                        On(t, e), In(t, wo);
                    })(
                        (function (e) {
                            return function (t) {
                                if (Rr() !== e) return;
                                const n = {
                                    category: "console",
                                    data: {
                                        arguments: t.args,
                                        logger: "console",
                                    },
                                    level: xo(t.level),
                                    message: Xn(t.args, " "),
                                };
                                if ("assert" === t.level) {
                                    if (!1 !== t.args[0]) return;
                                    (n.message = `Assertion failed: ${
                                        Xn(t.args.slice(1), " ") ||
                                        "console.assert"
                                    }`),
                                        (n.data.arguments = t.args.slice(1));
                                }
                                lo(n, { input: t.args, level: t.level });
                            };
                        })(e)
                    ),
                    t.dom &&
                        ((n = (function (e, t) {
                            return function (n) {
                                if (Rr() !== e) return;
                                let r,
                                    s,
                                    o =
                                        "object" == typeof t
                                            ? t.serializeAttribute
                                            : void 0,
                                    i =
                                        "object" == typeof t &&
                                        "number" == typeof t.maxStringLength
                                            ? t.maxStringLength
                                            : void 0;
                                i &&
                                    i > xi &&
                                    (wi &&
                                        _n.warn(
                                            `\`dom.maxStringLength\` cannot exceed 1024, but a value of ${i} was configured. Sentry will use 1024 instead.`
                                        ),
                                    (i = xi)),
                                    "string" == typeof o && (o = [o]);
                                try {
                                    const e = n.event,
                                        t = (function (e) {
                                            return !!e && !!e.target;
                                        })(e)
                                            ? e.target
                                            : e;
                                    (r = Wn(t, {
                                        keyAttrs: o,
                                        maxStringLength: i,
                                    })),
                                        (s = (function (e) {
                                            if (!Gn.HTMLElement) return null;
                                            let t = e;
                                            for (let n = 0; n < 5; n++) {
                                                if (!t) return null;
                                                if (t instanceof HTMLElement) {
                                                    if (
                                                        t.dataset
                                                            .sentryComponent
                                                    )
                                                        return t.dataset
                                                            .sentryComponent;
                                                    if (t.dataset.sentryElement)
                                                        return t.dataset
                                                            .sentryElement;
                                                }
                                                t = t.parentNode;
                                            }
                                            return null;
                                        })(t));
                                } catch {
                                    r = "<unknown>";
                                }
                                if (0 === r.length) return;
                                const a = {
                                    category: `ui.${n.name}`,
                                    message: r,
                                };
                                s && (a.data = { "ui.component_name": s }),
                                    lo(a, {
                                        event: n.event,
                                        name: n.name,
                                        global: n.global,
                                    });
                            };
                        })(e, t.dom)),
                        On("dom", n),
                        In("dom", ii)),
                    t.xhr &&
                        (function (e) {
                            On("xhr", e), In("xhr", hi);
                        })(
                            (function (e) {
                                return function (t) {
                                    if (Rr() !== e) return;
                                    const {
                                            startTimestamp: n,
                                            endTimestamp: r,
                                        } = t,
                                        s = t.xhr[fi];
                                    if (!n || !r || !s) return;
                                    const {
                                            method: o,
                                            url: i,
                                            status_code: a,
                                            body: c,
                                        } = s,
                                        u = {
                                            method: o,
                                            url: i,
                                            status_code: a,
                                        },
                                        l = {
                                            xhr: t.xhr,
                                            input: c,
                                            startTimestamp: n,
                                            endTimestamp: r,
                                        },
                                        d = {
                                            category: "xhr",
                                            data: u,
                                            type: "http",
                                            level: To(a),
                                        };
                                    e.emit(
                                        "beforeOutgoingRequestBreadcrumb",
                                        d,
                                        l
                                    ),
                                        lo(d, l);
                                };
                            })(e)
                        ),
                    t.fetch &&
                        jo(
                            (function (e) {
                                return function (t) {
                                    if (Rr() !== e) return;
                                    const {
                                        startTimestamp: n,
                                        endTimestamp: r,
                                    } = t;
                                    if (
                                        r &&
                                        (!t.fetchData.url.match(/sentry_key/) ||
                                            "POST" !== t.fetchData.method)
                                    )
                                        if (
                                            (t.fetchData.method,
                                            t.fetchData.url,
                                            t.error)
                                        ) {
                                            const s = t.fetchData,
                                                o = {
                                                    data: t.error,
                                                    input: t.args,
                                                    startTimestamp: n,
                                                    endTimestamp: r,
                                                },
                                                i = {
                                                    category: "fetch",
                                                    data: s,
                                                    level: "error",
                                                    type: "http",
                                                };
                                            e.emit(
                                                "beforeOutgoingRequestBreadcrumb",
                                                i,
                                                o
                                            ),
                                                lo(i, o);
                                        } else {
                                            const s = t.response,
                                                o = {
                                                    ...t.fetchData,
                                                    status_code: s?.status,
                                                };
                                            t.fetchData.request_body_size,
                                                t.fetchData.response_body_size;
                                            const i = {
                                                    input: t.args,
                                                    response: s,
                                                    startTimestamp: n,
                                                    endTimestamp: r,
                                                },
                                                a = {
                                                    category: "fetch",
                                                    data: o,
                                                    type: "http",
                                                    level: To(o.status_code),
                                                };
                                            e.emit(
                                                "beforeOutgoingRequestBreadcrumb",
                                                a,
                                                i
                                            ),
                                                lo(a, i);
                                        }
                                };
                            })(e)
                        ),
                    t.history &&
                        ci(
                            (function (e) {
                                return function (t) {
                                    if (Rr() !== e) return;
                                    let n = t.from,
                                        r = t.to;
                                    const s = ao(No.location.href);
                                    let o = n ? ao(n) : void 0;
                                    const i = ao(r);
                                    o?.path || (o = s),
                                        s.protocol === i.protocol &&
                                            s.host === i.host &&
                                            (r = i.relative),
                                        s.protocol === o.protocol &&
                                            s.host === o.host &&
                                            (n = o.relative),
                                        lo({
                                            category: "navigation",
                                            data: { from: n, to: r },
                                        });
                                };
                            })(e)
                        ),
                    t.sentry &&
                        e.on(
                            "beforeSendEvent",
                            (function (e) {
                                return function (t) {
                                    Rr() === e &&
                                        lo(
                                            {
                                                category:
                                                    "sentry." +
                                                    ("transaction" === t.type
                                                        ? "transaction"
                                                        : "event"),
                                                event_id: t.event_id,
                                                level: t.level,
                                                message: ur(t),
                                            },
                                            { event: t }
                                        );
                                };
                            })(e)
                        );
            },
        };
    };
const Ii = [
        "EventTarget",
        "Window",
        "Node",
        "ApplicationCache",
        "AudioTrackList",
        "BroadcastChannel",
        "ChannelMergerNode",
        "CryptoOperation",
        "EventSource",
        "FileReader",
        "HTMLUnknownElement",
        "IDBDatabase",
        "IDBRequest",
        "IDBTransaction",
        "KeyOperation",
        "MediaController",
        "MessagePort",
        "ModalWindow",
        "Notification",
        "SVGElementInstance",
        "Screen",
        "SharedWorker",
        "TextTrack",
        "TextTrackCue",
        "TextTrackList",
        "WebSocket",
        "WebSocketWorker",
        "Worker",
        "XMLHttpRequest",
        "XMLHttpRequestEventTarget",
        "XMLHttpRequestUpload",
    ],
    Di = (e = {}) => {
        const t = {
            XMLHttpRequest: !0,
            eventTarget: !0,
            requestAnimationFrame: !0,
            setInterval: !0,
            setTimeout: !0,
            unregisterOriginalCallbacks: !1,
            ...e,
        };
        return {
            name: "BrowserApiErrors",
            setupOnce() {
                t.setTimeout && er(No, "setTimeout", Ci),
                    t.setInterval && er(No, "setInterval", Ci),
                    t.requestAnimationFrame &&
                        er(No, "requestAnimationFrame", Ti),
                    t.XMLHttpRequest &&
                        "XMLHttpRequest" in No &&
                        er(XMLHttpRequest.prototype, "send", Pi);
                const e = t.eventTarget;
                if (e) {
                    (Array.isArray(e) ? e : Ii).forEach((e) =>
                        (function (e, t) {
                            const n = No,
                                r = n[e]?.prototype;
                            if (!r?.hasOwnProperty?.("addEventListener"))
                                return;
                            er(r, "addEventListener", function (n) {
                                return function (r, s, o) {
                                    try {
                                        "function" == typeof s.handleEvent &&
                                            (s.handleEvent = Fo(s.handleEvent, {
                                                mechanism: {
                                                    data: {
                                                        function: "handleEvent",
                                                        handler: Sn(s),
                                                        target: e,
                                                    },
                                                    handled: !1,
                                                    type: "instrument",
                                                },
                                            }));
                                    } catch {}
                                    return (
                                        t.unregisterOriginalCallbacks &&
                                            (function (e, t, n) {
                                                e &&
                                                    "object" == typeof e &&
                                                    "removeEventListener" in
                                                        e &&
                                                    "function" ==
                                                        typeof e.removeEventListener &&
                                                    e.removeEventListener(t, n);
                                            })(this, r, s),
                                        n.apply(this, [
                                            r,
                                            Fo(s, {
                                                mechanism: {
                                                    data: {
                                                        function:
                                                            "addEventListener",
                                                        handler: Sn(s),
                                                        target: e,
                                                    },
                                                    handled: !1,
                                                    type: "instrument",
                                                },
                                            }),
                                            o,
                                        ])
                                    );
                                };
                            }),
                                er(r, "removeEventListener", function (e) {
                                    return function (t, n, r) {
                                        try {
                                            const s = n.__sentry_wrapped__;
                                            s && e.call(this, t, s, r);
                                        } catch {}
                                        return e.call(this, t, n, r);
                                    };
                                });
                        })(e, t)
                    );
                }
            },
        };
    };
function Ci(e) {
    return function (...t) {
        const n = t[0];
        return (
            (t[0] = Fo(n, {
                mechanism: {
                    data: { function: Sn(e) },
                    handled: !1,
                    type: "instrument",
                },
            })),
            e.apply(this, t)
        );
    };
}
function Ti(e) {
    return function (t) {
        return e.apply(this, [
            Fo(t, {
                mechanism: {
                    data: { function: "requestAnimationFrame", handler: Sn(e) },
                    handled: !1,
                    type: "instrument",
                },
            }),
        ]);
    };
}
function Pi(e) {
    return function (...t) {
        const n = this;
        return (
            ["onload", "onerror", "onprogress", "onreadystatechange"].forEach(
                (e) => {
                    e in n &&
                        "function" == typeof n[e] &&
                        er(n, e, function (t) {
                            const n = {
                                    mechanism: {
                                        data: { function: e, handler: Sn(t) },
                                        handled: !1,
                                        type: "instrument",
                                    },
                                },
                                r = rr(t);
                            return (
                                r && (n.mechanism.data.handler = Sn(r)),
                                Fo(t, n)
                            );
                        });
                }
            ),
            e.apply(this, t)
        );
    };
}
const Ai = () => ({
        name: "BrowserSession",
        setupOnce() {
            void 0 !== No.document
                ? (Rs({ ignoreDuration: !0 }),
                  Us(),
                  ci(({ from: e, to: t }) => {
                      void 0 !== e &&
                          e !== t &&
                          (Rs({ ignoreDuration: !0 }), Us());
                  }))
                : wi &&
                  _n.warn(
                      "Using the `browserSessionIntegration` in non-browser environments is not supported."
                  );
        },
    }),
    Ri = (e = {}) => {
        const t = { onerror: !0, onunhandledrejection: !0, ...e };
        return {
            name: "GlobalHandlers",
            setupOnce() {
                Error.stackTraceLimit = 50;
            },
            setup(e) {
                t.onerror &&
                    (!(function (e) {
                        !(function (e) {
                            const t = "error";
                            On(t, e), In(t, Tn);
                        })((t) => {
                            const { stackParser: n, attachStacktrace: r } =
                                Li();
                            if (Rr() !== e || Ko()) return;
                            const {
                                    msg: s,
                                    url: o,
                                    line: i,
                                    column: a,
                                    error: c,
                                } = t,
                                u = (function (e, t, n, r) {
                                    const s = (e.exception = e.exception || {}),
                                        o = (s.values = s.values || []),
                                        i = (o[0] = o[0] || {}),
                                        a = (i.stacktrace = i.stacktrace || {}),
                                        c = (a.frames = a.frames || []),
                                        u = r,
                                        l = n,
                                        d =
                                            (function (e) {
                                                if (!Nn(e) || 0 === e.length)
                                                    return;
                                                if (e.startsWith("data:")) {
                                                    const t =
                                                        e.match(
                                                            /^data:([^;]+)/
                                                        );
                                                    return `<data:${
                                                        t
                                                            ? t[1]
                                                            : "text/javascript"
                                                    }${
                                                        e.includes("base64,")
                                                            ? ",base64"
                                                            : ""
                                                    }>`;
                                                }
                                                return e.slice(0, 1024);
                                            })(t) ?? Jn();
                                    0 === c.length &&
                                        c.push({
                                            colno: u,
                                            filename: d,
                                            function: gn,
                                            in_app: !0,
                                            lineno: l,
                                        });
                                    return e;
                                })(Yo(n, c || s, void 0, r, !1), o, i, a);
                            (u.level = "error"),
                                As(u, {
                                    originalException: c,
                                    mechanism: {
                                        handled: !1,
                                        type: "auto.browser.global_handlers.onerror",
                                    },
                                });
                        });
                    })(e),
                    ji("onerror")),
                    t.onunhandledrejection &&
                        (!(function (e) {
                            !(function (e) {
                                const t = "unhandledrejection";
                                On(t, e), In(t, An);
                            })((t) => {
                                const { stackParser: n, attachStacktrace: r } =
                                    Li();
                                if (Rr() !== e || Ko()) return;
                                const s = (function (e) {
                                        if (Kn(e)) return e;
                                        try {
                                            if ("reason" in e) return e.reason;
                                            if (
                                                "detail" in e &&
                                                "reason" in e.detail
                                            )
                                                return e.detail.reason;
                                        } catch {}
                                        return e;
                                    })(t),
                                    o = Kn(s)
                                        ? {
                                              exception: {
                                                  values: [
                                                      {
                                                          type: "UnhandledRejection",
                                                          value: `Non-Error promise rejection captured with value: ${String(
                                                              s
                                                          )}`,
                                                      },
                                                  ],
                                              },
                                          }
                                        : Yo(n, s, void 0, r, !0);
                                (o.level = "error"),
                                    As(o, {
                                        originalException: s,
                                        mechanism: {
                                            handled: !1,
                                            type: "auto.browser.global_handlers.onunhandledrejection",
                                        },
                                    });
                            });
                        })(e),
                        ji("onunhandledrejection"));
            },
        };
    };
function ji(e) {
    wi && _n.log(`Global Handler attached: ${e}`);
}
function Li() {
    const e = Rr();
    return e?.getOptions() || { stackParser: () => [], attachStacktrace: !1 };
}
const Ui = () => ({
        name: "HttpContext",
        preprocessEvent(e) {
            if (!No.navigator && !No.location && !No.document) return;
            const t = (function () {
                    const e = Jn(),
                        { referrer: t } = No.document || {},
                        { userAgent: n } = No.navigator || {};
                    return {
                        url: e,
                        headers: {
                            ...(t && { Referer: t }),
                            ...(n && { "User-Agent": n }),
                        },
                    };
                })(),
                n = { ...t.headers, ...e.request?.headers };
            e.request = { ...t, ...e.request, headers: n };
        },
    }),
    Mi = (e = {}) => {
        const t = e.limit || 5,
            n = e.key || "cause";
        return {
            name: "LinkedErrors",
            preprocessEvent(e, r, s) {
                bo(Bo, s.getOptions().stackParser, n, t, e, r);
            },
        };
    };
function Ni() {
    return (
        !!(function () {
            if (void 0 === No.window) return !1;
            const e = No;
            if (e.nw) return !1;
            const t = e.chrome || e.browser;
            if (!t?.runtime?.id) return !1;
            const n = Jn(),
                r = [
                    "chrome-extension",
                    "moz-extension",
                    "ms-browser-extension",
                    "safari-web-extension",
                ];
            return !(No === No.top && r.some((e) => n.startsWith(`${e}://`)));
        })() && (wi && dn(() => {}), !0)
    );
}
function $i(e) {
    return [mo(), po(), Di(), Oi(), Ri(), Mi(), Oo(), Ui(), Ai()];
}
const Ki = () => {
    const e = $i().filter(
        (e) =>
            !["BrowserApiErrors", "Breadcrumbs", "GlobalHandlers"].includes(
                e.name
            )
    );
    !(function (e = {}) {
        const t = !e.skipBrowserExtensionCheck && Ni(),
            n = {
                ...e,
                enabled: !t && e.enabled,
                stackParser:
                    ((r = e.stackParser || Si),
                    Array.isArray(r) ? yn(...r) : r),
                integrations: $s({
                    integrations: e.integrations,
                    defaultIntegrations:
                        null == e.defaultIntegrations
                            ? $i()
                            : e.defaultIntegrations,
                }),
                transport: e.transport || pi,
            };
        var r;
        no(Zo, n);
    })({
        dsn: "https://60bea3ee4ef1022e4035b23ba50f44d0@o1158394.ingest.us.sentry.io/4509876992278529",
        transport: pi,
        stackParser: Si,
        integrations: e,
        beforeSend: (e) => (
            (e.contexts = {
                ...e.contexts,
                extension: {
                    id: chrome.runtime.id,
                    version: chrome.runtime.getManifest().version,
                    environment: "production",
                },
            }),
            e
        ),
    });
};
export {
    Ut as S,
    Mt as a,
    s as b,
    Xt as c,
    Kt as d,
    tn as e,
    Wt as f,
    Qt as g,
    en as h,
    Ki as i,
    Zt as j,
    Nt as s,
};
