import {
  r as e,
  p as t,
  v as n,
  s as a,
  K as r,
  j as o,
  H as s,
  I as i,
  c,
  d as l,
  i as d,
  U as u,
  V as m,
  P as p,
  f as h,
  k as f,
  h as x,
  _ as g,
  W as v,
  Y as y,
  e as b,
  Z as w,
  A as C,
  R as j,
  l as M,
  m as E,
  D as N,
  C as k,
  o as _,
  $ as S,
  X as A,
  B as L,
  G as D,
  a0 as T,
  z as Z,
  E as R,
  F as H,
  a1 as V,
  M as F,
  a as I,
  u as P,
  L as O,
  N as K,
  O as B,
  Q as z,
} from "./Main-CWmOU7_i.js"
import { SavedPromptsService as G } from "./SavedPromptsService-Dtt1cD7h.js"
import {
  a as $,
  S as W,
  s as U,
  e as Y,
  f as q,
  i as X,
} from "./SentryService-B5QbSxHr.js"
const J = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,28H188V24a12,12,0,0,0-24,0v4H92V24a12,12,0,0,0-24,0v4H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28ZM68,52a12,12,0,0,0,24,0h72a12,12,0,0,0,24,0h16V76H52V52ZM52,204V100H204V204Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,48V88H40V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
          opacity: "0.2",
        }),
        e.createElement("path", {
          d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,48H48V48H72v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,34H182V24a6,6,0,0,0-12,0V34H86V24a6,6,0,0,0-12,0V34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34ZM48,46H74V56a6,6,0,0,0,12,0V46h84V56a6,6,0,0,0,12,0V46h26a2,2,0,0,1,2,2V82H46V48A2,2,0,0,1,48,46ZM208,210H48a2,2,0,0,1-2-2V94H210V208A2,2,0,0,1,208,210Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,36H180V24a4,4,0,0,0-8,0V36H84V24a4,4,0,0,0-8,0V36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36ZM48,44H76V56a4,4,0,0,0,8,0V44h88V56a4,4,0,0,0,8,0V44h28a4,4,0,0,1,4,4V84H44V48A4,4,0,0,1,48,44ZM208,212H48a4,4,0,0,1-4-4V92H212V208A4,4,0,0,1,208,212Z",
        })
      ),
    ],
  ]),
  Q = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M128,20A108,108,0,1,0,236,128,108.12,108.12,0,0,0,128,20Zm0,192a84,84,0,1,1,84-84A84.09,84.09,0,0,1,128,212Zm68-84a12,12,0,0,1-12,12H128a12,12,0,0,1-12-12V72a12,12,0,0,1,24,0v44h44A12,12,0,0,1,196,128Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,128a96,96,0,1,1-96-96A96,96,0,0,1,224,128Z",
          opacity: "0.2",
        }),
        e.createElement("path", {
          d: "M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm56,112H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48a8,8,0,0,1,0,16Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M128,26A102,102,0,1,0,230,128,102.12,102.12,0,0,0,128,26Zm0,192a90,90,0,1,1,90-90A90.1,90.1,0,0,1,128,218Zm62-90a6,6,0,0,1-6,6H128a6,6,0,0,1-6-6V72a6,6,0,0,1,12,0v50h50A6,6,0,0,1,190,128Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M128,28A100,100,0,1,0,228,128,100.11,100.11,0,0,0,128,28Zm0,192a92,92,0,1,1,92-92A92.1,92.1,0,0,1,128,220Zm60-92a4,4,0,0,1-4,4H128a4,4,0,0,1-4-4V72a4,4,0,0,1,8,0v52h52A4,4,0,0,1,188,128Z",
        })
      ),
    ],
  ]),
  ee = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,44H32A12,12,0,0,0,20,56V192a20,20,0,0,0,20,20H216a20,20,0,0,0,20-20V56A12,12,0,0,0,224,44Zm-96,83.72L62.85,68h130.3ZM92.79,128,44,172.72V83.28Zm17.76,16.28,9.34,8.57a12,12,0,0,0,16.22,0l9.34-8.57L193.15,188H62.85ZM163.21,128,212,83.28v89.44Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", { d: "M224,56l-96,88L32,56Z", opacity: "0.2" }),
        e.createElement("path", {
          d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,50H32a6,6,0,0,0-6,6V192a14,14,0,0,0,14,14H216a14,14,0,0,0,14-14V56A6,6,0,0,0,224,50Zm-96,85.86L47.42,62H208.58ZM101.67,128,38,186.36V69.64Zm8.88,8.14L124,148.42a6,6,0,0,0,8.1,0l13.4-12.28L208.58,194H47.43ZM154.33,128,218,69.64V186.36Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,52H32a4,4,0,0,0-4,4V192a12,12,0,0,0,12,12H216a12,12,0,0,0,12-12V56A4,4,0,0,0,224,52Zm-96,86.57L42.28,60H213.72ZM104.63,128,36,190.91V65.09Zm5.92,5.43L125.3,147a4,4,0,0,0,5.4,0l14.75-13.52L213.72,196H42.28ZM151.37,128,220,65.09V190.91Z",
        })
      ),
    ],
  ]),
  te = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M219.71,117.38a12,12,0,0,0-7.25-8.52L161.28,88.39l10.59-70.61a12,12,0,0,0-20.64-10l-112,120a12,12,0,0,0,4.31,19.33l51.18,20.47L84.13,238.22a12,12,0,0,0,20.64,10l112-120A12,12,0,0,0,219.71,117.38ZM113.6,203.55l6.27-41.77a12,12,0,0,0-7.41-12.92L68.74,131.37,142.4,52.45l-6.27,41.77a12,12,0,0,0,7.41,12.92l43.72,17.49Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M96,240l16-80L48,136,160,16,144,96l64,24Z",
          opacity: "0.2",
        }),
        e.createElement("path", {
          d: "M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M213.85,125.46l-112,120a8,8,0,0,1-13.69-7l14.66-73.33L45.19,143.49a8,8,0,0,1-3-13l112-120a8,8,0,0,1,13.69,7L153.18,90.9l57.63,21.61a8,8,0,0,1,3,12.95Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M213.84,118.63a6,6,0,0,0-3.73-4.25L150.88,92.17l15-75a6,6,0,0,0-10.27-5.27l-112,120a6,6,0,0,0,2.28,9.71l59.23,22.21-15,75a6,6,0,0,0,3.14,6.52A6.07,6.07,0,0,0,96,246a6,6,0,0,0,4.39-1.91l112-120A6,6,0,0,0,213.84,118.63ZM106,220.46l11.85-59.28a6,6,0,0,0-3.77-6.8l-55.6-20.85,91.46-98L138.12,94.82a6,6,0,0,0,3.77,6.8l55.6,20.85Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M211.89,119.09a4,4,0,0,0-2.49-2.84l-60.81-22.8,15.33-76.67a4,4,0,0,0-6.84-3.51l-112,120a4,4,0,0,0-1,3.64,4,4,0,0,0,2.49,2.84l60.81,22.8L92.08,239.22a4,4,0,0,0,6.84,3.51l112-120A4,4,0,0,0,211.89,119.09ZM102.68,227l13.24-66.2a4,4,0,0,0-2.52-4.53L55,134.36,153.32,29l-13.24,66.2a4,4,0,0,0,2.52,4.53L201,121.64Z",
        })
      ),
    ],
  ]),
  ne = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,20H40A20,20,0,0,0,20,40V216a20,20,0,0,0,20,20H216a20,20,0,0,0,20-20V40A20,20,0,0,0,216,20Zm-4,192H44V44H212ZM112,176V120a12,12,0,0,1,21.43-7.41A40,40,0,0,1,192,148v28a12,12,0,0,1-24,0V148a16,16,0,0,0-32,0v28a12,12,0,0,1-24,0ZM96,120v56a12,12,0,0,1-24,0V120a12,12,0,0,1,24,0ZM68,80A16,16,0,1,1,84,96,16,16,0,0,1,68,80Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M224,40V216a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8H216A8,8,0,0,1,224,40Z",
          opacity: "0.2",
        }),
        e.createElement("path", {
          d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24Zm0,192H40V40H216V216ZM96,112v64a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0Zm88,28v36a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140ZM100,84A12,12,0,1,1,88,72,12,12,0,0,1,100,84Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24ZM96,176a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0ZM88,96a12,12,0,1,1,12-12A12,12,0,0,1,88,96Zm96,80a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,26H40A14,14,0,0,0,26,40V216a14,14,0,0,0,14,14H216a14,14,0,0,0,14-14V40A14,14,0,0,0,216,26Zm2,190a2,2,0,0,1-2,2H40a2,2,0,0,1-2-2V40a2,2,0,0,1,2-2H216a2,2,0,0,1,2,2ZM94,112v64a6,6,0,0,1-12,0V112a6,6,0,0,1,12,0Zm88,28v36a6,6,0,0,1-12,0V140a22,22,0,0,0-44,0v36a6,6,0,0,1-12,0V112a6,6,0,0,1,12,0v2.11A34,34,0,0,1,182,140ZM98,84A10,10,0,1,1,88,74,10,10,0,0,1,98,84Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24Zm0,192H40V40H216V216ZM96,112v64a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0Zm88,28v36a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140ZM100,84A12,12,0,1,1,88,72,12,12,0,0,1,100,84Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M216,28H40A12,12,0,0,0,28,40V216a12,12,0,0,0,12,12H216a12,12,0,0,0,12-12V40A12,12,0,0,0,216,28Zm4,188a4,4,0,0,1-4,4H40a4,4,0,0,1-4-4V40a4,4,0,0,1,4-4H216a4,4,0,0,1,4,4ZM92,112v64a4,4,0,0,1-8,0V112a4,4,0,0,1,8,0Zm88,28v36a4,4,0,0,1-8,0V140a24,24,0,0,0-48,0v36a4,4,0,0,1-8,0V112a4,4,0,0,1,8,0v6.87A32,32,0,0,1,180,140ZM96,84a8,8,0,1,1-8-8A8,8,0,0,1,96,84Z",
        })
      ),
    ],
  ]),
  ae = new Map([
    [
      "bold",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M76,64A12,12,0,0,1,88,52H216a12,12,0,0,1,0,24H88A12,12,0,0,1,76,64Zm140,52H88a12,12,0,0,0,0,24H216a12,12,0,0,0,0-24Zm0,64H88a12,12,0,0,0,0,24H216a12,12,0,0,0,0-24ZM44,112a16,16,0,1,0,16,16A16,16,0,0,0,44,112Zm0-64A16,16,0,1,0,60,64,16,16,0,0,0,44,48Zm0,128a16,16,0,1,0,16,16A16,16,0,0,0,44,176Z",
        })
      ),
    ],
    [
      "duotone",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", { d: "M216,64V192H88V64Z", opacity: "0.2" }),
        e.createElement("path", {
          d: "M80,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H88A8,8,0,0,1,80,64Zm136,56H88a8,8,0,1,0,0,16H216a8,8,0,0,0,0-16Zm0,64H88a8,8,0,1,0,0,16H216a8,8,0,0,0,0-16ZM44,52A12,12,0,1,0,56,64,12,12,0,0,0,44,52Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,116Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,180Z",
        })
      ),
    ],
    [
      "fill",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM68,188a12,12,0,1,1,12-12A12,12,0,0,1,68,188Zm0-48a12,12,0,1,1,12-12A12,12,0,0,1,68,140Zm0-48A12,12,0,1,1,80,80,12,12,0,0,1,68,92Zm124,92H104a8,8,0,0,1,0-16h88a8,8,0,0,1,0,16Zm0-48H104a8,8,0,0,1,0-16h88a8,8,0,0,1,0,16Zm0-48H104a8,8,0,0,1,0-16h88a8,8,0,0,1,0,16Z",
        })
      ),
    ],
    [
      "light",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M82,64a6,6,0,0,1,6-6H216a6,6,0,0,1,0,12H88A6,6,0,0,1,82,64Zm134,58H88a6,6,0,0,0,0,12H216a6,6,0,0,0,0-12Zm0,64H88a6,6,0,0,0,0,12H216a6,6,0,0,0,0-12ZM44,54A10,10,0,1,0,54,64,10,10,0,0,0,44,54Zm0,128a10,10,0,1,0,10,10A10,10,0,0,0,44,182Zm0-64a10,10,0,1,0,10,10A10,10,0,0,0,44,118Z",
        })
      ),
    ],
    [
      "regular",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M80,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H88A8,8,0,0,1,80,64Zm136,56H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Zm0,64H88a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16ZM44,52A12,12,0,1,0,56,64,12,12,0,0,0,44,52Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,116Zm0,64a12,12,0,1,0,12,12A12,12,0,0,0,44,180Z",
        })
      ),
    ],
    [
      "thin",
      e.createElement(
        e.Fragment,
        null,
        e.createElement("path", {
          d: "M84,64a4,4,0,0,1,4-4H216a4,4,0,0,1,0,8H88A4,4,0,0,1,84,64Zm132,60H88a4,4,0,0,0,0,8H216a4,4,0,0,0,0-8Zm0,64H88a4,4,0,0,0,0,8H216a4,4,0,0,0,0-8ZM44,120a8,8,0,1,0,8,8A8,8,0,0,0,44,120Zm0-64a8,8,0,1,0,8,8A8,8,0,0,0,44,56Zm0,128a8,8,0,1,0,8,8A8,8,0,0,0,44,184Z",
        })
      ),
    ],
  ]),
  re = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: J }))
re.displayName = "CalendarBlankIcon"
const oe = re,
  se = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: Q }))
se.displayName = "ClockIcon"
const ie = se,
  ce = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: ee }))
ce.displayName = "EnvelopeIcon"
const le = ce,
  de = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: te }))
de.displayName = "LightningIcon"
const ue = de,
  me = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: ne }))
me.displayName = "LinkedinLogoIcon"
const pe = me,
  he = e.forwardRef((n, a) => e.createElement(t, { ref: a, ...n, weights: ae }))
he.displayName = "ListBulletsIcon"
const fe = he,
  xe = n("bug", [
    ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
    ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
    ["path", { d: "M9 7.13v-1a3.003 3.003 0 1 1 6 0v1", key: "d7y7pr" }],
    [
      "path",
      {
        d: "M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6",
        key: "xs1cw7",
      },
    ],
    ["path", { d: "M12 20v-9", key: "1qisl0" }],
    ["path", { d: "M6.53 9C4.6 8.8 3 7.1 3 5", key: "32zzws" }],
    ["path", { d: "M6 13H2", key: "82j7cp" }],
    ["path", { d: "M3 21c0-2.1 1.7-3.9 3.8-4", key: "4p0ekp" }],
    ["path", { d: "M20.97 5c0 2.1-1.6 3.8-3.5 4", key: "18gb23" }],
    ["path", { d: "M22 13h-4", key: "1jl80f" }],
    ["path", { d: "M17.2 17c2.1.1 3.8 1.9 3.8 4", key: "k3fwyw" }],
  ]),
  ge = n("log-out", [
    ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
    ["path", { d: "M21 12H9", key: "dn1m92" }],
    ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }],
  ]),
  ve = n("user", [
    ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
    ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }],
  ]),
  ye = () => {
    const [t, n] = e.useState(),
      [s, i] = e.useState(!0),
      { value: c } = a.useFeatureGate("crochet_can_skip_permissions"),
      l = e.useMemo(() => new r(() => !1), [])
    e.useEffect(() => {
      l.setCanSkipPermissions(c)
    }, [c, l])
    const d = e.useCallback(async () => {
      i(!0)
      try {
        await l.loadPermissions()
        const e = l.getPermissionsByScope()
        n(e)
      } catch (e) {
      } finally {
        i(!1)
      }
    }, [l])
    e.useEffect(() => {
      d()
    }, [d])
    const u = async (e) => {
        await l.revokePermission(e), d()
      },
      m = (e) =>
        "domain_transition" === e.scope.type
          ? `${e.scope.fromDomain} → ${e.scope.toDomain}`
          : e.scope.netloc || "Unknown domain"
    return s
      ? o.jsx("div", {
          className: "p-6 text-text-200",
          children: "Loading permissions...",
        })
      : o.jsx("div", {
          className: "permissions-tab",
          children: o.jsxs("div", {
            className: "space-y-6",
            children: [
              o.jsxs("div", {
                className:
                  "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                children: [
                  o.jsx("h3", {
                    className: "text-text-100 font-xl-bold",
                    children: "Your approved sites",
                  }),
                  o.jsx("p", {
                    className: "text-text-300 font-base mt-2 mb-6",
                    children:
                      "You have allowed Claude to take all actions (browse, click, type) on these sites.",
                  }),
                  t?.netloc && t.netloc.length > 0
                    ? o.jsx(be, {
                        permissions: t.netloc,
                        onRevoke: u,
                        formatScope: m,
                      })
                    : o.jsx("div", {
                        className: "text-text-400 font-base-sm pb-5",
                        children: "No sites have been approved yet",
                      }),
                ],
              }),
              t?.domain_transition &&
                t.domain_transition.length > 0 &&
                o.jsxs("div", {
                  className:
                    "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                  children: [
                    o.jsx("h3", {
                      className: "text-text-100 font-xl-bold",
                      children: "Domain Transitions",
                    }),
                    o.jsx("p", {
                      className: "text-text-300 font-base mt-2 mb-6",
                      children:
                        "Permissions for navigating between different domains.",
                    }),
                    o.jsx(we, {
                      permissions: t.domain_transition,
                      onRevoke: u,
                      formatScope: m,
                    }),
                  ],
                }),
            ],
          }),
        })
  },
  be = ({ permissions: e, onRevoke: t, formatScope: n }) =>
    o.jsx("div", {
      children: e.map((a, r) =>
        o.jsxs(
          s.Fragment,
          {
            children: [
              o.jsxs("div", {
                className: "py-4 flex items-center justify-between",
                children: [
                  o.jsxs("div", {
                    className: "flex-1",
                    children: [
                      o.jsx("div", {
                        className: "font-large text-text-100",
                        children: n(a),
                      }),
                      a.lastUsed &&
                        o.jsxs("div", {
                          className: "text-xs text-text-400 mt-1",
                          children: [
                            "Last used: ",
                            new Date(a.lastUsed).toLocaleString(),
                          ],
                        }),
                    ],
                  }),
                  o.jsx("button", {
                    onClick: () => t(a.id),
                    className:
                      "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                    children: "Revoke",
                  }),
                ],
              }),
              r < e.length - 1 &&
                o.jsx("div", { className: "border-b border-border-400" }),
            ],
          },
          a.id
        )
      ),
    }),
  we = ({ permissions: e, onRevoke: t, formatScope: n }) =>
    o.jsx("div", {
      children: e.map((a, r) =>
        o.jsxs(
          s.Fragment,
          {
            children: [
              o.jsxs("div", {
                className: "py-4 flex items-center justify-between",
                children: [
                  o.jsxs("div", {
                    className: "flex-1",
                    children: [
                      o.jsx("div", {
                        className: "font-large text-text-100",
                        children: n(a),
                      }),
                      a.lastUsed &&
                        o.jsxs("div", {
                          className: "text-xs text-text-400 mt-1",
                          children: [
                            "Last used: ",
                            new Date(a.lastUsed).toLocaleString(),
                          ],
                        }),
                    ],
                  }),
                  o.jsx("button", {
                    onClick: () => t(a.id),
                    className:
                      "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                    children: "Revoke",
                  }),
                ],
              }),
              r < e.length - 1 &&
                o.jsx("div", { className: "border-b border-border-400" }),
            ],
          },
          a.id
        )
      ),
    }),
  Ce = (e) =>
    o.jsx(i, {
      ...e,
      children: o.jsx("path", {
        d: "M9.72821 2.87934C10.0318 2.10869 10.9028 1.72933 11.6735 2.03266L14.4655 3.13226C15.236 3.43593 15.6145 4.30697 15.3112 5.07758L11.3903 15.0307C11.2954 15.2717 11.1394 15.4835 10.9391 15.6459L10.8513 15.7123L7.7077 17.8979C7.29581 18.1843 6.73463 17.9917 6.57294 17.5356L6.54657 17.4409L5.737 13.6987C5.67447 13.4092 5.69977 13.107 5.80829 12.8315L9.72821 2.87934ZM6.73798 13.1987C6.70201 13.2903 6.69385 13.3906 6.71454 13.4868L7.44501 16.8627L10.28 14.892L10.3376 14.8452C10.3909 14.7949 10.4325 14.7332 10.4597 14.6645L13.0974 7.96723L9.37567 6.50141L6.73798 13.1987ZM11.3073 2.96332C11.0504 2.86217 10.7601 2.98864 10.6589 3.24555L9.74188 5.57074L13.4636 7.03754L14.3806 4.71137C14.4817 4.45445 14.3552 4.16413 14.0983 4.06293L11.3073 2.96332Z",
      }),
    }),
  je = (e) =>
    o.jsx(i, {
      ...e,
      children: o.jsx("path", {
        d: "M11.3232 1.5C11.9365 1.50011 12.4881 1.87396 12.7158 2.44336L13.3379 4H17.5L17.6006 4.00977C17.8285 4.0563 18 4.25829 18 4.5C18 4.7417 17.8285 4.94371 17.6006 4.99023L17.5 5H15.9629L15.0693 16.6152C15.0091 17.3965 14.3578 17.9999 13.5742 18H6.42578C5.6912 17.9999 5.07237 17.4697 4.94824 16.7598L4.93066 16.6152L4.03711 5H2.5C2.22387 5 2.00002 4.77613 2 4.5C2 4.22386 2.22386 4 2.5 4H6.66211L7.28418 2.44336L7.33105 2.33887C7.58152 1.82857 8.10177 1.5001 8.67676 1.5H11.3232ZM5.92773 16.5381C5.94778 16.7985 6.16464 16.9999 6.42578 17H13.5742C13.8354 16.9999 14.0522 16.7985 14.0723 16.5381L14.9609 5H5.03906L5.92773 16.5381ZM8.5 8C8.77613 8 8.99998 8.22388 9 8.5V13.5C9 13.7761 8.77614 14 8.5 14C8.22386 14 8 13.7761 8 13.5V8.5C8.00002 8.22388 8.22387 8 8.5 8ZM11.5 8C11.7761 8 12 8.22386 12 8.5V13.5C12 13.7761 11.7761 14 11.5 14C11.2239 14 11 13.7761 11 13.5V8.5C11 8.22386 11.2239 8 11.5 8ZM8.67676 2.5C8.49802 2.5001 8.33492 2.59525 8.24609 2.74609L8.21289 2.81445L7.73828 4H12.2617L11.7871 2.81445C11.7112 2.62471 11.5276 2.50011 11.3232 2.5H8.67676Z",
      }),
    }),
  Me = (e) =>
    o.jsx(i, {
      ...e,
      children: o.jsx("path", {
        d: "M10 14C10.5523 14 11 14.4477 11 15C11 15.5523 10.5523 16 10 16C9.44772 16 9 15.5523 9 15C9 14.4477 9.44772 14 10 14ZM10 9C10.5523 9 11 9.44772 11 10C11 10.5523 10.5523 11 10 11C9.44772 11 9 10.5523 9 10C9 9.44772 9.44772 9 10 9ZM10 4C10.5523 4 11 4.44772 11 5C11 5.55228 10.5523 6 10 6C9.44772 6 9 5.55228 9 5C9 4.44772 9.44772 4 10 4Z",
      }),
    }),
  Ee = (e) =>
    o.jsx(i, {
      ...e,
      children: o.jsx("path", {
        d: "M11.5859 2C11.9837 2.00004 12.3652 2.15818 12.6465 2.43945L15.5605 5.35352C15.8418 5.63478 16 6.01629 16 6.41406V16.5C16 17.3284 15.3284 18 14.5 18H5.5C4.72334 18 4.08461 17.4097 4.00781 16.6533L4 16.5V3.5C4 2.67157 4.67157 2 5.5 2H11.5859ZM5.5 3C5.22386 3 5 3.22386 5 3.5V16.5C5 16.7761 5.22386 17 5.5 17H14.5C14.7761 17 15 16.7761 15 16.5V7H12.5C11.6716 7 11 6.32843 11 5.5V3H5.5ZM12.54 13.3037C12.6486 13.05 12.9425 12.9317 13.1963 13.04C13.45 13.1486 13.5683 13.4425 13.46 13.6963C13.1651 14.3853 12.589 15 11.7998 15C11.3132 14.9999 10.908 14.7663 10.5996 14.4258C10.2913 14.7661 9.88667 14.9999 9.40039 15C8.91365 15 8.50769 14.7665 8.19922 14.4258C7.89083 14.7661 7.48636 15 7 15C6.72386 15 6.5 14.7761 6.5 14.5C6.5 14.2239 6.72386 14 7 14C7.21245 14 7.51918 13.8199 7.74023 13.3037L7.77441 13.2373C7.86451 13.0913 8.02513 13 8.2002 13C8.40022 13.0001 8.58145 13.1198 8.66016 13.3037C8.88121 13.8198 9.18796 14 9.40039 14C9.61284 13.9998 9.9197 13.8197 10.1406 13.3037L10.1748 13.2373C10.2649 13.0915 10.4248 13.0001 10.5996 13C10.7997 13 10.9808 13.1198 11.0596 13.3037C11.2806 13.8198 11.5874 13.9999 11.7998 14C12.0122 14 12.319 13.8198 12.54 13.3037ZM12.54 9.30371C12.6486 9.05001 12.9425 8.93174 13.1963 9.04004C13.45 9.14863 13.5683 9.44253 13.46 9.69629C13.1651 10.3853 12.589 11 11.7998 11C11.3132 10.9999 10.908 10.7663 10.5996 10.4258C10.2913 10.7661 9.88667 10.9999 9.40039 11C8.91365 11 8.50769 10.7665 8.19922 10.4258C7.89083 10.7661 7.48636 11 7 11C6.72386 11 6.5 10.7761 6.5 10.5C6.5 10.2239 6.72386 10 7 10C7.21245 10 7.51918 9.8199 7.74023 9.30371L7.77441 9.2373C7.86451 9.09126 8.02513 9 8.2002 9C8.40022 9.00008 8.58145 9.11981 8.66016 9.30371C8.88121 9.8198 9.18796 10 9.40039 10C9.61284 9.99978 9.9197 9.81969 10.1406 9.30371L10.1748 9.2373C10.2649 9.09147 10.4248 9.00014 10.5996 9C10.7997 9 10.9808 9.11975 11.0596 9.30371C11.2806 9.8198 11.5874 9.99989 11.7998 10C12.0122 10 12.319 9.81985 12.54 9.30371ZM12 5.5C12 5.77614 12.2239 6 12.5 6H14.793L12 3.20703V5.5Z",
      }),
    }),
  Ne = [
    {
      category: "general",
      label: "General",
      prompts: [
        {
          prompt:
            "Summarize this page and extract the key insights, main arguments, and important data points.",
          command: "summarize",
        },
        {
          prompt:
            "Research this topic by visiting multiple authoritative websites and gathering key information. Open each source in a new tab, read through the content, and summarize the main findings from each source.",
          command: "research",
        },
        {
          prompt:
            "Compare prices and features for this product across at least 5 different websites. Create a comparison table showing: price, shipping costs, delivery time, return policy, and any special features or bundles. Highlight the best overall value and explain why.",
          command: "compare-prices",
        },
        {
          prompt:
            "Fill out this form or application with the information I provide. Before submitting, show me a screenshot of the completed form for review. If there are multiple steps, take a screenshot at each step so I can verify the information is correct.",
          command: "fill-form",
        },
        {
          prompt:
            "Extract all the important data from this page (tables, lists, contact info, prices, etc.) and organize it in a clear, structured format that I can easily copy.",
          command: "extract",
        },
        {
          prompt:
            "Find and click through all the links on this page to discover what's available. Create a summary of what each major section or link leads to.",
          command: "explore",
        },
      ],
    },
    {
      category: "email",
      label: "Email",
      prompts: [
        {
          prompt:
            "Go through my recent emails and help me unsubscribe from promotional/marketing emails. \n\nFocus on: retail promotions, marketing newsletters, sales emails, and automated promotional content. DO NOT unsubscribe from: transactional emails (receipts, shipping notifications), account security emails, or emails that appear to be personal/conversational. \n\nStart with emails from the last 2 weeks. Before unsubscribing from anything, give me a full list of the different emails you plan to unsubscribe from so I can confirm you're identifying the right types of emails. When you do this, make sure to ask me if there's any of those emails you should not unsubscribe from.\n\nFor each promotional email you find: (1) Look for and click the native \"unsubscribe\" button from google (top of the email, next to sender email address); (2) Keep a running list of what you've unsubscribed from.",
          command: "unsubscribe",
        },
        {
          prompt:
            "Go through my email inbox and archive all emails where: (A) I don't need to take any actions; AND (B) where the email does not appear to be from an actual human (personal tone, specific to me, conversational).\n\nIf an email only meets one of those two criteria, don't archive it.\n\nEmails to archive covers things like general notifications, calendar invitations / acceptances, promotions etc.\n\nRemember – the archive button is the one that is second on the left. It has a down arrow sign within a folder. Make sure that you are not clicking the 'labels' button (second from the right, rectangular type of button that points right), and don't press \"move to\" as well (third from the right, folder icon with right arrow). DO NOT MARK AS SPAM (which is third button from left, the exclamation mark (\"report spam\" button).\n\nBefore you click to archive the first time, take a screenshot when you hover on the \"archive\" button to confirm that you are taking the action intended.\n\nAfter you click to archive, make sure to take a screenshot before taking any further actions so that you don't get lost.\n\nAlso archive any google automatic reminder emails for following up on emails I've sent in the past that haven't gotten a response.",
          command: "archive",
        },
        {
          prompt:
            "Go through my inbox and draft thoughtful responses to emails that require my attention. For each email that needs a response: \n\n1) Read the full context and any previous thread messages within that same email chain; (2) Draft a response that maintains my professional tone while being warm and helpful; (3) Save as a draft but DO NOT send. Once you've written the draft, Click on the \"back\" button in the top bar, which is the far left button and directly on left of the archive button, which takes you back to inbox and automatically saves the draft. Focus on emails from the last 3 days.\n\nOnly click into emails that you think need a response when looking at the sender and subject line – don't click into automated notifications, calendar invites etc.\n\nFor an email that needs a response, make sure you click in and expand each of the previous emails within the chain. You can see the collapsed preview state in the middle / top side of the email chain, with the number of how many previous emails are in the thread. Make sure to click into each one to get all the context, don't skip out on this.\n\nAfter you've drafted the email, click on the \"back to inbox\" button (left pointing arrow) that is the far left button on the top bar (the button is on the left of the archive button). This will take you back to inbox, and you can then go onto the next email.",
          command: "draft-responses",
        },
        {
          prompt:
            "Extract action items and deadlines from all unread emails and create a prioritized task list.",
          command: "actions",
        },
        {
          prompt:
            "Go through my sent emails from the last week and identify any that haven't received a response. Create a list of who I'm waiting to hear back from and what about.",
          command: "follow-ups",
        },
        {
          prompt:
            "Review my email drafts folder and help me finish or send any drafts that have been sitting there. Show me each draft and ask what action to take.",
          command: "review-drafts",
        },
      ],
    },
    {
      category: "docs",
      label: "Docs",
      prompts: [
        {
          prompt:
            "Create a comprehensive document from my outline, researching and writing each section with proper formatting.",
          command: "create-doc",
        },
        {
          prompt:
            "Review this document for clarity, grammar, structure, and factual accuracy, then implement improvements.",
          command: "review",
        },
        {
          prompt:
            "Generate an executive summary and key takeaways from this long document.",
          command: "summarize-doc",
        },
        {
          prompt:
            "Convert this document to different formats while preserving all formatting, images, and data.",
          command: "convert",
        },
        {
          prompt:
            "Merge multiple documents into one cohesive file, removing duplicates and organizing content logically.",
          command: "merge",
        },
        {
          prompt:
            "Create a presentation from this document with slides, speaker notes, and visual elements.",
          command: "present",
        },
      ],
    },
    {
      category: "calendar",
      label: "Calendar",
      prompts: [
        {
          prompt:
            "Find the optimal meeting time for all participants across different time zones and schedule it.",
          command: "schedule",
        },
        {
          prompt:
            "Analyze my calendar patterns and suggest ways to optimize for productivity and work-life balance.",
          command: "optimize",
        },
        {
          prompt:
            "Resolve all scheduling conflicts by proposing alternative times and notifying affected parties.",
          command: "conflicts",
        },
        {
          prompt:
            "Block focus time for deep work based on my priorities and energy patterns throughout the day.",
          command: "focus",
        },
        {
          prompt:
            "Plan a multi-day event with sessions, breaks, and logistics, sending invites to all participants.",
          command: "event",
        },
        {
          prompt:
            "Create recurring meetings with smart scheduling that avoids holidays and conflicts.",
          command: "recurring",
        },
      ],
    },
    {
      category: "linkedin",
      label: "LinkedIn",
      prompts: [
        {
          prompt:
            "Write an engaging LinkedIn post about this topic that will resonate with my professional network.",
          command: "post",
        },
        {
          prompt:
            "Optimize my entire LinkedIn profile with keywords, compelling descriptions, and strategic positioning.",
          command: "profile",
        },
        {
          prompt:
            "Identify and connect with relevant professionals in my industry with personalized messages.",
          command: "network",
        },
        {
          prompt:
            "Search for jobs matching my skills, apply with tailored resumes, and track application status.",
          command: "jobs",
        },
        {
          prompt:
            "Research this company's culture, recent news, and key employees to prepare for outreach or interviews.",
          command: "company",
        },
        {
          prompt:
            "Analyze my LinkedIn analytics and suggest content strategies to increase engagement and reach.",
          command: "analytics",
        },
      ],
    },
  ]
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ function ke({
  options: t,
  onSelect: n,
  value: a,
  initialKey: r,
  testId: s,
  itemClassName: i,
}) {
  const [l, d] = e.useState(a || r),
    u = e.useRef(null),
    m = e.useRef(null),
    [p, h] = e.useState(!1),
    f = e.useRef(!1)
  e.useEffect(() => {
    void 0 !== a && d(a)
  }, [a]),
    e.useEffect(() => {
      const e = u.current,
        t = e?.parentElement
      if (e && t) {
        const n = window.getComputedStyle(t),
          a = parseFloat(n.paddingLeft),
          r = parseFloat(n.borderRadius),
          o = Math.max(0, r - a),
          s = m.current
        if (l && s) {
          const { offsetLeft: t, offsetWidth: n } = s,
            r = e.offsetWidth
          if (r > 0) {
            const s = 100 - ((t + n - a) / r) * 100,
              i = ((t - a) / r) * 100
            ;(e.style.clipPath = `inset(0 ${s > 0 ? s : 0}% 0 ${
              i <= 100 ? i : 100
            }% round ${o}px)`),
              f.current ||
                ((f.current = !0),
                requestAnimationFrame(() => {
                  h(!0)
                }))
          }
        } else e.style.clipPath = `rect(0% ${2 * o}px 100% 0% round ${o}px)`
      }
    }, [l])
  const x =
    "flex items-center justify-center h-[28px] min-w-7 gap-1.5 px-3 rounded-lg cursor-pointer"
  return o.jsxs("div", {
    className:
      "group/segmented-control relative inline-flex w-fit h-8 text-sm font-medium bg-bg-300 p-0.5 rounded-[.625rem]",
    children: [
      t.map((e) =>
        o.jsx(
          "button",
          {
            ref: l === e.key ? m : null,
            onClick: () => {
              return (t = e.key), d(t), void n?.(t)
              var t
            },
            "aria-label": e.ariaLabel,
            className: c(
              x,
              "relative z-10 text-text-500 hover:text-text-300 transition-colors duration-[250ms]",
              l === e.key && "!text-text-100",
              i
            ),
            "data-testid": `${s}-${e.key}`,
            children: e.label,
          },
          e.key
        )
      ),
      o.jsx("div", {
        "aria-hidden": !0,
        className: c(
          "pointer-events-none absolute inset-0 p-0.5 rounded-[.625rem] transition-[opacity] duration-[250ms]",
          !l && "opacity-0"
        ),
        style: {
          filter: "drop-shadow(0px 0px 0.5px hsl(var(--border-300)/30%))",
        },
        children: o.jsx("div", {
          ref: u,
          className: c(
            "flex bg-bg-000",
            p && "transition-[clip-path] duration-[250ms] ease"
          ),
          style: { clipPath: "rect(0% 0% 100% 0%)" },
          children: t.map((e) =>
            o.jsx(
              "div",
              { className: c(x, "text-text-100", i), children: e.label },
              e.key
            )
          ),
        }),
      }),
    ],
  })
}
function _e(e) {
  const t = e + "CollectionProvider",
    [n, a] = l(t),
    [r, i] = n(t, { collectionRef: { current: null }, itemMap: new Map() }),
    c = (e) => {
      const { scope: t, children: n } = e,
        a = s.useRef(null),
        i = s.useRef(new Map()).current
      return o.jsx(r, { scope: t, itemMap: i, collectionRef: a, children: n })
    }
  c.displayName = t
  const m = e + "CollectionSlot",
    p = u(m),
    h = s.forwardRef((e, t) => {
      const { scope: n, children: a } = e,
        r = i(m, n),
        s = d(t, r.collectionRef)
      return o.jsx(p, { ref: s, children: a })
    })
  h.displayName = m
  const f = e + "CollectionItemSlot",
    x = "data-radix-collection-item",
    g = u(f),
    v = s.forwardRef((e, t) => {
      const { scope: n, children: a, ...r } = e,
        c = s.useRef(null),
        l = d(t, c),
        u = i(f, n)
      return (
        s.useEffect(
          () => (
            u.itemMap.set(c, { ref: c, ...r }),
            () => {
              u.itemMap.delete(c)
            }
          )
        ),
        o.jsx(g, { [x]: "", ref: l, children: a })
      )
    })
  return (
    (v.displayName = f),
    [
      { Provider: c, Slot: h, ItemSlot: v },
      function (t) {
        const n = i(e + "CollectionConsumer", t)
        return s.useCallback(() => {
          const e = n.collectionRef.current
          if (!e) return []
          const t = Array.from(e.querySelectorAll(`[${x}]`))
          return Array.from(n.itemMap.values()).sort(
            (e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current)
          )
        }, [n.collectionRef, n.itemMap])
      },
      a,
    ]
  )
}
Ne.flatMap((e) => e.prompts)
var Se = e.createContext(void 0)
function Ae(t) {
  const n = e.useContext(Se)
  return t || n || "ltr"
}
var Le = 0
function De() {
  const e = document.createElement("span")
  return (
    e.setAttribute("data-radix-focus-guard", ""),
    (e.tabIndex = 0),
    (e.style.outline = "none"),
    (e.style.opacity = "0"),
    (e.style.position = "fixed"),
    (e.style.pointerEvents = "none"),
    e
  )
}
var Te = "focusScope.autoFocusOnMount",
  Ze = "focusScope.autoFocusOnUnmount",
  Re = { bubbles: !1, cancelable: !0 },
  He = e.forwardRef((t, n) => {
    const {
        loop: a = !1,
        trapped: r = !1,
        onMountAutoFocus: s,
        onUnmountAutoFocus: i,
        ...c
      } = t,
      [l, u] = e.useState(null),
      h = m(s),
      f = m(i),
      x = e.useRef(null),
      g = d(n, (e) => u(e)),
      v = e.useRef({
        paused: !1,
        pause() {
          this.paused = !0
        },
        resume() {
          this.paused = !1
        },
      }).current
    e.useEffect(() => {
      if (r) {
        let e = function (e) {
            if (v.paused || !l) return
            const t = e.target
            l.contains(t) ? (x.current = t) : Pe(x.current, { select: !0 })
          },
          t = function (e) {
            if (v.paused || !l) return
            const t = e.relatedTarget
            null !== t && (l.contains(t) || Pe(x.current, { select: !0 }))
          },
          n = function (e) {
            if (document.activeElement === document.body)
              for (const t of e) t.removedNodes.length > 0 && Pe(l)
          }
        document.addEventListener("focusin", e),
          document.addEventListener("focusout", t)
        const a = new MutationObserver(n)
        return (
          l && a.observe(l, { childList: !0, subtree: !0 }),
          () => {
            document.removeEventListener("focusin", e),
              document.removeEventListener("focusout", t),
              a.disconnect()
          }
        )
      }
    }, [r, l, v.paused]),
      e.useEffect(() => {
        if (l) {
          Oe.add(v)
          const t = document.activeElement
          if (!l.contains(t)) {
            const n = new CustomEvent(Te, Re)
            l.addEventListener(Te, h),
              l.dispatchEvent(n),
              n.defaultPrevented ||
                (!(function (e, { select: t = !1 } = {}) {
                  const n = document.activeElement
                  for (const a of e)
                    if ((Pe(a, { select: t }), document.activeElement !== n))
                      return
                })(((e = Ve(l)), e.filter((e) => "A" !== e.tagName)), {
                  select: !0,
                }),
                document.activeElement === t && Pe(l))
          }
          return () => {
            l.removeEventListener(Te, h),
              setTimeout(() => {
                const e = new CustomEvent(Ze, Re)
                l.addEventListener(Ze, f),
                  l.dispatchEvent(e),
                  e.defaultPrevented || Pe(t ?? document.body, { select: !0 }),
                  l.removeEventListener(Ze, f),
                  Oe.remove(v)
              }, 0)
          }
        }
        var e
      }, [l, h, f, v])
    const y = e.useCallback(
      (e) => {
        if (!a && !r) return
        if (v.paused) return
        const t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
          n = document.activeElement
        if (t && n) {
          const t = e.currentTarget,
            [r, o] = (function (e) {
              const t = Ve(e),
                n = Fe(t, e),
                a = Fe(t.reverse(), e)
              return [n, a]
            })(t)
          r && o
            ? e.shiftKey || n !== o
              ? e.shiftKey &&
                n === r &&
                (e.preventDefault(), a && Pe(o, { select: !0 }))
              : (e.preventDefault(), a && Pe(r, { select: !0 }))
            : n === t && e.preventDefault()
        }
      },
      [a, r, v.paused]
    )
    return o.jsx(p.div, { tabIndex: -1, ...c, ref: g, onKeyDown: y })
  })
function Ve(e) {
  const t = [],
    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (e) => {
        const t = "INPUT" === e.tagName && "hidden" === e.type
        return e.disabled || e.hidden || t
          ? NodeFilter.FILTER_SKIP
          : e.tabIndex >= 0
          ? NodeFilter.FILTER_ACCEPT
          : NodeFilter.FILTER_SKIP
      },
    })
  for (; n.nextNode(); ) t.push(n.currentNode)
  return t
}
function Fe(e, t) {
  for (const n of e) if (!Ie(n, { upTo: t })) return n
}
function Ie(e, { upTo: t }) {
  if ("hidden" === getComputedStyle(e).visibility) return !0
  for (; e; ) {
    if (void 0 !== t && e === t) return !1
    if ("none" === getComputedStyle(e).display) return !0
    e = e.parentElement
  }
  return !1
}
function Pe(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement
    e.focus({ preventScroll: !0 }),
      e !== n &&
        (function (e) {
          return e instanceof HTMLInputElement && "select" in e
        })(e) &&
        t &&
        e.select()
  }
}
He.displayName = "FocusScope"
var Oe = (function () {
  let e = []
  return {
    add(t) {
      const n = e[0]
      t !== n && n?.pause(), (e = Ke(e, t)), e.unshift(t)
    },
    remove(t) {
      ;(e = Ke(e, t)), e[0]?.resume()
    },
  }
})()
function Ke(e, t) {
  const n = [...e],
    a = n.indexOf(t)
  return -1 !== a && n.splice(a, 1), n
}
var Be = "rovingFocusGroup.onEntryFocus",
  ze = { bubbles: !1, cancelable: !0 },
  Ge = "RovingFocusGroup",
  [$e, We, Ue] = _e(Ge),
  [Ye, qe] = l(Ge, [Ue]),
  [Xe, Je] = Ye(Ge),
  Qe = e.forwardRef((e, t) =>
    o.jsx($e.Provider, {
      scope: e.__scopeRovingFocusGroup,
      children: o.jsx($e.Slot, {
        scope: e.__scopeRovingFocusGroup,
        children: o.jsx(et, { ...e, ref: t }),
      }),
    })
  )
Qe.displayName = Ge
var et = e.forwardRef((t, n) => {
    const {
        __scopeRovingFocusGroup: a,
        orientation: r,
        loop: s = !1,
        dir: i,
        currentTabStopId: c,
        defaultCurrentTabStopId: l,
        onCurrentTabStopIdChange: u,
        onEntryFocus: h,
        preventScrollOnEntryFocus: g = !1,
        ...v
      } = t,
      y = e.useRef(null),
      b = d(n, y),
      w = Ae(i),
      [C, j] = x({ prop: c, defaultProp: l ?? null, onChange: u, caller: Ge }),
      [M, E] = e.useState(!1),
      N = m(h),
      k = We(a),
      _ = e.useRef(!1),
      [S, A] = e.useState(0)
    return (
      e.useEffect(() => {
        const e = y.current
        if (e)
          return e.addEventListener(Be, N), () => e.removeEventListener(Be, N)
      }, [N]),
      o.jsx(Xe, {
        scope: a,
        orientation: r,
        dir: w,
        loop: s,
        currentTabStopId: C,
        onItemFocus: e.useCallback((e) => j(e), [j]),
        onItemShiftTab: e.useCallback(() => E(!0), []),
        onFocusableItemAdd: e.useCallback(() => A((e) => e + 1), []),
        onFocusableItemRemove: e.useCallback(() => A((e) => e - 1), []),
        children: o.jsx(p.div, {
          tabIndex: M || 0 === S ? -1 : 0,
          "data-orientation": r,
          ...v,
          ref: b,
          style: { outline: "none", ...t.style },
          onMouseDown: f(t.onMouseDown, () => {
            _.current = !0
          }),
          onFocus: f(t.onFocus, (e) => {
            const t = !_.current
            if (e.target === e.currentTarget && t && !M) {
              const t = new CustomEvent(Be, ze)
              if ((e.currentTarget.dispatchEvent(t), !t.defaultPrevented)) {
                const e = k().filter((e) => e.focusable)
                rt(
                  [e.find((e) => e.active), e.find((e) => e.id === C), ...e]
                    .filter(Boolean)
                    .map((e) => e.ref.current),
                  g
                )
              }
            }
            _.current = !1
          }),
          onBlur: f(t.onBlur, () => E(!1)),
        }),
      })
    )
  }),
  tt = "RovingFocusGroupItem",
  nt = e.forwardRef((t, n) => {
    const {
        __scopeRovingFocusGroup: a,
        focusable: r = !0,
        active: s = !1,
        tabStopId: i,
        children: c,
        ...l
      } = t,
      d = h(),
      u = i || d,
      m = Je(tt, a),
      x = m.currentTabStopId === u,
      g = We(a),
      {
        onFocusableItemAdd: v,
        onFocusableItemRemove: y,
        currentTabStopId: b,
      } = m
    return (
      e.useEffect(() => {
        if (r) return v(), () => y()
      }, [r, v, y]),
      o.jsx($e.ItemSlot, {
        scope: a,
        id: u,
        focusable: r,
        active: s,
        children: o.jsx(p.span, {
          tabIndex: x ? 0 : -1,
          "data-orientation": m.orientation,
          ...l,
          ref: n,
          onMouseDown: f(t.onMouseDown, (e) => {
            r ? m.onItemFocus(u) : e.preventDefault()
          }),
          onFocus: f(t.onFocus, () => m.onItemFocus(u)),
          onKeyDown: f(t.onKeyDown, (e) => {
            if ("Tab" === e.key && e.shiftKey) return void m.onItemShiftTab()
            if (e.target !== e.currentTarget) return
            const t = (function (e, t, n) {
              const a = (function (e, t) {
                return "rtl" !== t
                  ? e
                  : "ArrowLeft" === e
                  ? "ArrowRight"
                  : "ArrowRight" === e
                  ? "ArrowLeft"
                  : e
              })(e.key, n)
              return ("vertical" === t &&
                ["ArrowLeft", "ArrowRight"].includes(a)) ||
                ("horizontal" === t && ["ArrowUp", "ArrowDown"].includes(a))
                ? void 0
                : at[a]
            })(e, m.orientation, m.dir)
            if (void 0 !== t) {
              if (e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) return
              e.preventDefault()
              let r = g()
                .filter((e) => e.focusable)
                .map((e) => e.ref.current)
              if ("last" === t) r.reverse()
              else if ("prev" === t || "next" === t) {
                "prev" === t && r.reverse()
                const o = r.indexOf(e.currentTarget)
                r = m.loop
                  ? ((a = o + 1), (n = r).map((e, t) => n[(a + t) % n.length]))
                  : r.slice(o + 1)
              }
              setTimeout(() => rt(r))
            }
            var n, a
          }),
          children:
            "function" == typeof c
              ? c({ isCurrentTabStop: x, hasTabStop: null != b })
              : c,
        }),
      })
    )
  })
nt.displayName = tt
var at = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last",
}
function rt(e, t = !1) {
  const n = document.activeElement
  for (const a of e) {
    if (a === n) return
    if ((a.focus({ preventScroll: t }), document.activeElement !== n)) return
  }
}
var ot = Qe,
  st = nt,
  it = new WeakMap(),
  ct = new WeakMap(),
  lt = {},
  dt = 0,
  ut = function (e) {
    return e && (e.host || ut(e.parentNode))
  },
  mt = function (e, t, n, a) {
    var r = (function (e, t) {
      return t
        .map(function (t) {
          if (e.contains(t)) return t
          var n = ut(t)
          return n && e.contains(n) ? n : null
        })
        .filter(function (e) {
          return Boolean(e)
        })
    })(t, Array.isArray(e) ? e : [e])
    lt[n] || (lt[n] = new WeakMap())
    var o = lt[n],
      s = [],
      i = new Set(),
      c = new Set(r),
      l = function (e) {
        e && !i.has(e) && (i.add(e), l(e.parentNode))
      }
    r.forEach(l)
    var d = function (e) {
      e &&
        !c.has(e) &&
        Array.prototype.forEach.call(e.children, function (e) {
          if (i.has(e)) d(e)
          else
            try {
              var t = e.getAttribute(a),
                r = null !== t && "false" !== t,
                c = (it.get(e) || 0) + 1,
                l = (o.get(e) || 0) + 1
              it.set(e, c),
                o.set(e, l),
                s.push(e),
                1 === c && r && ct.set(e, !0),
                1 === l && e.setAttribute(n, "true"),
                r || e.setAttribute(a, "true")
            } catch (u) {}
        })
    }
    return (
      d(t),
      i.clear(),
      dt++,
      function () {
        s.forEach(function (e) {
          var t = it.get(e) - 1,
            r = o.get(e) - 1
          it.set(e, t),
            o.set(e, r),
            t || (ct.has(e) || e.removeAttribute(a), ct.delete(e)),
            r || e.removeAttribute(n)
        }),
          --dt ||
            ((it = new WeakMap()),
            (it = new WeakMap()),
            (ct = new WeakMap()),
            (lt = {}))
      }
    )
  },
  pt = function (e, t, n) {
    void 0 === n && (n = "data-aria-hidden")
    var a = Array.from(Array.isArray(e) ? e : [e]),
      r = (function (e) {
        return "undefined" == typeof document
          ? null
          : (Array.isArray(e) ? e[0] : e).ownerDocument.body
      })(e)
    return r
      ? (a.push.apply(a, Array.from(r.querySelectorAll("[aria-live], script"))),
        mt(a, r, n, "aria-hidden"))
      : function () {
          return null
        }
  },
  ht = "right-scroll-bar-position",
  ft = "width-before-scroll-bar"
function xt(e, t) {
  return "function" == typeof e ? e(t) : e && (e.current = t), e
}
var gt = "undefined" != typeof window ? e.useLayoutEffect : e.useEffect,
  vt = new WeakMap()
function yt(t, n) {
  var a,
    r,
    o,
    s =
      ((a = null),
      (r = function (e) {
        return t.forEach(function (t) {
          return xt(t, e)
        })
      }),
      ((o = e.useState(function () {
        return {
          value: a,
          callback: r,
          facade: {
            get current() {
              return o.value
            },
            set current(e) {
              var t = o.value
              t !== e && ((o.value = e), o.callback(e, t))
            },
          },
        }
      })[0]).callback = r),
      o.facade)
  return (
    gt(
      function () {
        var e = vt.get(s)
        if (e) {
          var n = new Set(e),
            a = new Set(t),
            r = s.current
          n.forEach(function (e) {
            a.has(e) || xt(e, null)
          }),
            a.forEach(function (e) {
              n.has(e) || xt(e, r)
            })
        }
        vt.set(s, t)
      },
      [t]
    ),
    s
  )
}
function bt(e) {
  return e
}
var wt = function (t) {
  var n = t.sideCar,
    a = v(t, ["sideCar"])
  if (!n)
    throw new Error(
      "Sidecar: please provide `sideCar` property to import the right car"
    )
  var r = n.read()
  if (!r) throw new Error("Sidecar medium not found")
  return e.createElement(r, g({}, a))
}
wt.isSideCarExport = !0
var Ct = (function (e) {
    void 0 === e && (e = {})
    var t = (function (e, t) {
      void 0 === t && (t = bt)
      var n = [],
        a = !1
      return {
        read: function () {
          if (a)
            throw new Error(
              "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
            )
          return n.length ? n[n.length - 1] : e
        },
        useMedium: function (e) {
          var r = t(e, a)
          return (
            n.push(r),
            function () {
              n = n.filter(function (e) {
                return e !== r
              })
            }
          )
        },
        assignSyncMedium: function (e) {
          for (a = !0; n.length; ) {
            var t = n
            ;(n = []), t.forEach(e)
          }
          n = {
            push: function (t) {
              return e(t)
            },
            filter: function () {
              return n
            },
          }
        },
        assignMedium: function (e) {
          a = !0
          var t = []
          if (n.length) {
            var r = n
            ;(n = []), r.forEach(e), (t = n)
          }
          var o = function () {
              var n = t
              ;(t = []), n.forEach(e)
            },
            s = function () {
              return Promise.resolve().then(o)
            }
          s(),
            (n = {
              push: function (e) {
                t.push(e), s()
              },
              filter: function (e) {
                return (t = t.filter(e)), n
              },
            })
        },
      }
    })(null)
    return (t.options = g({ async: !0, ssr: !1 }, e)), t
  })(),
  jt = function () {},
  Mt = e.forwardRef(function (t, n) {
    var a = e.useRef(null),
      r = e.useState({
        onScrollCapture: jt,
        onWheelCapture: jt,
        onTouchMoveCapture: jt,
      }),
      o = r[0],
      s = r[1],
      i = t.forwardProps,
      c = t.children,
      l = t.className,
      d = t.removeScrollBar,
      u = t.enabled,
      m = t.shards,
      p = t.sideCar,
      h = t.noRelative,
      f = t.noIsolation,
      x = t.inert,
      y = t.allowPinchZoom,
      b = t.as,
      w = void 0 === b ? "div" : b,
      C = t.gapMode,
      j = v(t, [
        "forwardProps",
        "children",
        "className",
        "removeScrollBar",
        "enabled",
        "shards",
        "sideCar",
        "noRelative",
        "noIsolation",
        "inert",
        "allowPinchZoom",
        "as",
        "gapMode",
      ]),
      M = p,
      E = yt([a, n]),
      N = g(g({}, j), o)
    return e.createElement(
      e.Fragment,
      null,
      u &&
        e.createElement(M, {
          sideCar: Ct,
          removeScrollBar: d,
          shards: m,
          noRelative: h,
          noIsolation: f,
          inert: x,
          setCallbacks: s,
          allowPinchZoom: !!y,
          lockRef: a,
          gapMode: C,
        }),
      i
        ? e.cloneElement(e.Children.only(c), g(g({}, N), { ref: E }))
        : e.createElement(w, g({}, N, { className: l, ref: E }), c)
    )
  })
;(Mt.defaultProps = { enabled: !0, removeScrollBar: !0, inert: !1 }),
  (Mt.classNames = { fullWidth: ft, zeroRight: ht })
function Et() {
  if (!document) return null
  var e = document.createElement("style")
  e.type = "text/css"
  var t = (function () {
    if ("undefined" != typeof __webpack_nonce__) return __webpack_nonce__
  })()
  return t && e.setAttribute("nonce", t), e
}
var Nt = function () {
    var e = 0,
      t = null
    return {
      add: function (n) {
        var a, r
        0 == e &&
          (t = Et()) &&
          ((r = n),
          (a = t).styleSheet
            ? (a.styleSheet.cssText = r)
            : a.appendChild(document.createTextNode(r)),
          (function (e) {
            ;(
              document.head || document.getElementsByTagName("head")[0]
            ).appendChild(e)
          })(t)),
          e++
      },
      remove: function () {
        !--e && t && (t.parentNode && t.parentNode.removeChild(t), (t = null))
      },
    }
  },
  kt = function () {
    var t,
      n =
        ((t = Nt()),
        function (n, a) {
          e.useEffect(
            function () {
              return (
                t.add(n),
                function () {
                  t.remove()
                }
              )
            },
            [n && a]
          )
        })
    return function (e) {
      var t = e.styles,
        a = e.dynamic
      return n(t, a), null
    }
  },
  _t = { left: 0, top: 0, right: 0, gap: 0 },
  St = function (e) {
    return parseInt(e || "", 10) || 0
  },
  At = function (e) {
    if ((void 0 === e && (e = "margin"), "undefined" == typeof window))
      return _t
    var t = (function (e) {
        var t = window.getComputedStyle(document.body),
          n = t["padding" === e ? "paddingLeft" : "marginLeft"],
          a = t["padding" === e ? "paddingTop" : "marginTop"],
          r = t["padding" === e ? "paddingRight" : "marginRight"]
        return [St(n), St(a), St(r)]
      })(e),
      n = document.documentElement.clientWidth,
      a = window.innerWidth
    return {
      left: t[0],
      top: t[1],
      right: t[2],
      gap: Math.max(0, a - n + t[2] - t[0]),
    }
  },
  Lt = kt(),
  Dt = "data-scroll-locked",
  Tt = function (e, t, n, a) {
    var r = e.left,
      o = e.top,
      s = e.right,
      i = e.gap
    return (
      void 0 === n && (n = "margin"),
      "\n  ."
        .concat("with-scroll-bars-hidden", " {\n   overflow: hidden ")
        .concat(a, ";\n   padding-right: ")
        .concat(i, "px ")
        .concat(a, ";\n  }\n  body[")
        .concat(Dt, "] {\n    overflow: hidden ")
        .concat(a, ";\n    overscroll-behavior: contain;\n    ")
        .concat(
          [
            t && "position: relative ".concat(a, ";"),
            "margin" === n &&
              "\n    padding-left: "
                .concat(r, "px;\n    padding-top: ")
                .concat(o, "px;\n    padding-right: ")
                .concat(
                  s,
                  "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: "
                )
                .concat(i, "px ")
                .concat(a, ";\n    "),
            "padding" === n &&
              "padding-right: ".concat(i, "px ").concat(a, ";"),
          ]
            .filter(Boolean)
            .join(""),
          "\n  }\n  \n  ."
        )
        .concat(ht, " {\n    right: ")
        .concat(i, "px ")
        .concat(a, ";\n  }\n  \n  .")
        .concat(ft, " {\n    margin-right: ")
        .concat(i, "px ")
        .concat(a, ";\n  }\n  \n  .")
        .concat(ht, " .")
        .concat(ht, " {\n    right: 0 ")
        .concat(a, ";\n  }\n  \n  .")
        .concat(ft, " .")
        .concat(ft, " {\n    margin-right: 0 ")
        .concat(a, ";\n  }\n  \n  body[")
        .concat(Dt, "] {\n    ")
        .concat("--removed-body-scroll-bar-size", ": ")
        .concat(i, "px;\n  }\n")
    )
  },
  Zt = function () {
    var e = parseInt(document.body.getAttribute(Dt) || "0", 10)
    return isFinite(e) ? e : 0
  },
  Rt = function (t) {
    var n = t.noRelative,
      a = t.noImportant,
      r = t.gapMode,
      o = void 0 === r ? "margin" : r
    e.useEffect(function () {
      return (
        document.body.setAttribute(Dt, (Zt() + 1).toString()),
        function () {
          var e = Zt() - 1
          e <= 0
            ? document.body.removeAttribute(Dt)
            : document.body.setAttribute(Dt, e.toString())
        }
      )
    }, [])
    var s = e.useMemo(
      function () {
        return At(o)
      },
      [o]
    )
    return e.createElement(Lt, { styles: Tt(s, !n, o, a ? "" : "!important") })
  },
  Ht = !1
if ("undefined" != typeof window)
  try {
    var Vt = Object.defineProperty({}, "passive", {
      get: function () {
        return (Ht = !0), !0
      },
    })
    window.addEventListener("test", Vt, Vt),
      window.removeEventListener("test", Vt, Vt)
  } catch (ar) {
    Ht = !1
  }
var Ft = !!Ht && { passive: !1 },
  It = function (e, t) {
    if (!(e instanceof Element)) return !1
    var n = window.getComputedStyle(e)
    return (
      "hidden" !== n[t] &&
      !(
        n.overflowY === n.overflowX &&
        !(function (e) {
          return "TEXTAREA" === e.tagName
        })(e) &&
        "visible" === n[t]
      )
    )
  },
  Pt = function (e, t) {
    var n = t.ownerDocument,
      a = t
    do {
      if (
        ("undefined" != typeof ShadowRoot &&
          a instanceof ShadowRoot &&
          (a = a.host),
        Ot(e, a))
      ) {
        var r = Kt(e, a)
        if (r[1] > r[2]) return !0
      }
      a = a.parentNode
    } while (a && a !== n.body)
    return !1
  },
  Ot = function (e, t) {
    return "v" === e
      ? (function (e) {
          return It(e, "overflowY")
        })(t)
      : (function (e) {
          return It(e, "overflowX")
        })(t)
  },
  Kt = function (e, t) {
    return "v" === e
      ? [(n = t).scrollTop, n.scrollHeight, n.clientHeight]
      : (function (e) {
          return [e.scrollLeft, e.scrollWidth, e.clientWidth]
        })(t)
    var n
  },
  Bt = function (e) {
    return "changedTouches" in e
      ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
      : [0, 0]
  },
  zt = function (e) {
    return [e.deltaX, e.deltaY]
  },
  Gt = function (e) {
    return e && "current" in e ? e.current : e
  },
  $t = function (e) {
    return "\n  .block-interactivity-"
      .concat(e, " {pointer-events: none;}\n  .allow-interactivity-")
      .concat(e, " {pointer-events: all;}\n")
  },
  Wt = 0,
  Ut = []
function Yt(e) {
  for (var t = null; null !== e; )
    e instanceof ShadowRoot && ((t = e.host), (e = e.host)), (e = e.parentNode)
  return t
}
const qt =
  ((Xt = function (t) {
    var n = e.useRef([]),
      a = e.useRef([0, 0]),
      r = e.useRef(),
      o = e.useState(Wt++)[0],
      s = e.useState(kt)[0],
      i = e.useRef(t)
    e.useEffect(
      function () {
        i.current = t
      },
      [t]
    ),
      e.useEffect(
        function () {
          if (t.inert) {
            document.body.classList.add("block-interactivity-".concat(o))
            var e = y([t.lockRef.current], (t.shards || []).map(Gt), !0).filter(
              Boolean
            )
            return (
              e.forEach(function (e) {
                return e.classList.add("allow-interactivity-".concat(o))
              }),
              function () {
                document.body.classList.remove(
                  "block-interactivity-".concat(o)
                ),
                  e.forEach(function (e) {
                    return e.classList.remove("allow-interactivity-".concat(o))
                  })
              }
            )
          }
        },
        [t.inert, t.lockRef.current, t.shards]
      )
    var c = e.useCallback(function (e, t) {
        if (
          ("touches" in e && 2 === e.touches.length) ||
          ("wheel" === e.type && e.ctrlKey)
        )
          return !i.current.allowPinchZoom
        var n,
          o = Bt(e),
          s = a.current,
          c = "deltaX" in e ? e.deltaX : s[0] - o[0],
          l = "deltaY" in e ? e.deltaY : s[1] - o[1],
          d = e.target,
          u = Math.abs(c) > Math.abs(l) ? "h" : "v"
        if ("touches" in e && "h" === u && "range" === d.type) return !1
        var m = Pt(u, d)
        if (!m) return !0
        if ((m ? (n = u) : ((n = "v" === u ? "h" : "v"), (m = Pt(u, d))), !m))
          return !1
        if (
          (!r.current && "changedTouches" in e && (c || l) && (r.current = n),
          !n)
        )
          return !0
        var p = r.current || n
        return (function (e, t, n, a) {
          var r = (function (e, t) {
              return "h" === e && "rtl" === t ? -1 : 1
            })(e, window.getComputedStyle(t).direction),
            o = r * a,
            s = n.target,
            i = t.contains(s),
            c = !1,
            l = o > 0,
            d = 0,
            u = 0
          do {
            if (!s) break
            var m = Kt(e, s),
              p = m[0],
              h = m[1] - m[2] - r * p
            ;(p || h) && Ot(e, s) && ((d += h), (u += p))
            var f = s.parentNode
            s = f && f.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? f.host : f
          } while ((!i && s !== document.body) || (i && (t.contains(s) || t === s)))
          return (
            ((l && Math.abs(d) < 1) || (!l && Math.abs(u) < 1)) && (c = !0), c
          )
        })(p, t, e, "h" === p ? c : l)
      }, []),
      l = e.useCallback(function (e) {
        var t = e
        if (Ut.length && Ut[Ut.length - 1] === s) {
          var a = "deltaY" in t ? zt(t) : Bt(t),
            r = n.current.filter(function (e) {
              return (
                e.name === t.type &&
                (e.target === t.target || t.target === e.shadowParent) &&
                ((n = e.delta), (r = a), n[0] === r[0] && n[1] === r[1])
              )
              var n, r
            })[0]
          if (r && r.should) t.cancelable && t.preventDefault()
          else if (!r) {
            var o = (i.current.shards || [])
              .map(Gt)
              .filter(Boolean)
              .filter(function (e) {
                return e.contains(t.target)
              })
            ;(o.length > 0 ? c(t, o[0]) : !i.current.noIsolation) &&
              t.cancelable &&
              t.preventDefault()
          }
        }
      }, []),
      d = e.useCallback(function (e, t, a, r) {
        var o = { name: e, delta: t, target: a, should: r, shadowParent: Yt(a) }
        n.current.push(o),
          setTimeout(function () {
            n.current = n.current.filter(function (e) {
              return e !== o
            })
          }, 1)
      }, []),
      u = e.useCallback(function (e) {
        ;(a.current = Bt(e)), (r.current = void 0)
      }, []),
      m = e.useCallback(function (e) {
        d(e.type, zt(e), e.target, c(e, t.lockRef.current))
      }, []),
      p = e.useCallback(function (e) {
        d(e.type, Bt(e), e.target, c(e, t.lockRef.current))
      }, [])
    e.useEffect(function () {
      return (
        Ut.push(s),
        t.setCallbacks({
          onScrollCapture: m,
          onWheelCapture: m,
          onTouchMoveCapture: p,
        }),
        document.addEventListener("wheel", l, Ft),
        document.addEventListener("touchmove", l, Ft),
        document.addEventListener("touchstart", u, Ft),
        function () {
          ;(Ut = Ut.filter(function (e) {
            return e !== s
          })),
            document.removeEventListener("wheel", l, Ft),
            document.removeEventListener("touchmove", l, Ft),
            document.removeEventListener("touchstart", u, Ft)
        }
      )
    }, [])
    var h = t.removeScrollBar,
      f = t.inert
    return e.createElement(
      e.Fragment,
      null,
      f ? e.createElement(s, { styles: $t(o) }) : null,
      h
        ? e.createElement(Rt, { noRelative: t.noRelative, gapMode: t.gapMode })
        : null
    )
  }),
  Ct.useMedium(Xt),
  wt)
var Xt,
  Jt = e.forwardRef(function (t, n) {
    return e.createElement(Mt, g({}, t, { ref: n, sideCar: qt }))
  })
Jt.classNames = Mt.classNames
var Qt = ["Enter", " "],
  en = ["ArrowUp", "PageDown", "End"],
  tn = ["ArrowDown", "PageUp", "Home", ...en],
  nn = { ltr: [...Qt, "ArrowRight"], rtl: [...Qt, "ArrowLeft"] },
  an = { ltr: ["ArrowLeft"], rtl: ["ArrowRight"] },
  rn = "Menu",
  [on, sn, cn] = _e(rn),
  [ln, dn] = l(rn, [cn, b, qe]),
  un = b(),
  mn = qe(),
  [pn, hn] = ln(rn),
  [fn, xn] = ln(rn),
  gn = (t) => {
    const {
        __scopeMenu: n,
        open: a = !1,
        children: r,
        dir: s,
        onOpenChange: i,
        modal: c = !0,
      } = t,
      l = un(n),
      [d, u] = e.useState(null),
      p = e.useRef(!1),
      h = m(i),
      f = Ae(s)
    return (
      e.useEffect(() => {
        const e = () => {
            ;(p.current = !0),
              document.addEventListener("pointerdown", t, {
                capture: !0,
                once: !0,
              }),
              document.addEventListener("pointermove", t, {
                capture: !0,
                once: !0,
              })
          },
          t = () => (p.current = !1)
        return (
          document.addEventListener("keydown", e, { capture: !0 }),
          () => {
            document.removeEventListener("keydown", e, { capture: !0 }),
              document.removeEventListener("pointerdown", t, { capture: !0 }),
              document.removeEventListener("pointermove", t, { capture: !0 })
          }
        )
      }, []),
      o.jsx(j, {
        ...l,
        children: o.jsx(pn, {
          scope: n,
          open: a,
          onOpenChange: h,
          content: d,
          onContentChange: u,
          children: o.jsx(fn, {
            scope: n,
            onClose: e.useCallback(() => h(!1), [h]),
            isUsingKeyboardRef: p,
            dir: f,
            modal: c,
            children: r,
          }),
        }),
      })
    )
  }
gn.displayName = rn
var vn = e.forwardRef((e, t) => {
  const { __scopeMenu: n, ...a } = e,
    r = un(n)
  return o.jsx(C, { ...r, ...a, ref: t })
})
vn.displayName = "MenuAnchor"
var yn = "MenuPortal",
  [bn, wn] = ln(yn, { forceMount: void 0 }),
  Cn = (e) => {
    const { __scopeMenu: t, forceMount: n, children: a, container: r } = e,
      s = hn(yn, t)
    return o.jsx(bn, {
      scope: t,
      forceMount: n,
      children: o.jsx(M, {
        present: n || s.open,
        children: o.jsx(E, { asChild: !0, container: r, children: a }),
      }),
    })
  }
Cn.displayName = yn
var jn = "MenuContent",
  [Mn, En] = ln(jn),
  Nn = e.forwardRef((e, t) => {
    const n = wn(jn, e.__scopeMenu),
      { forceMount: a = n.forceMount, ...r } = e,
      s = hn(jn, e.__scopeMenu),
      i = xn(jn, e.__scopeMenu)
    return o.jsx(on.Provider, {
      scope: e.__scopeMenu,
      children: o.jsx(M, {
        present: a || s.open,
        children: o.jsx(on.Slot, {
          scope: e.__scopeMenu,
          children: i.modal
            ? o.jsx(kn, { ...r, ref: t })
            : o.jsx(_n, { ...r, ref: t }),
        }),
      }),
    })
  }),
  kn = e.forwardRef((t, n) => {
    const a = hn(jn, t.__scopeMenu),
      r = e.useRef(null),
      s = d(n, r)
    return (
      e.useEffect(() => {
        const e = r.current
        if (e) return pt(e)
      }, []),
      o.jsx(An, {
        ...t,
        ref: s,
        trapFocus: a.open,
        disableOutsidePointerEvents: a.open,
        disableOutsideScroll: !0,
        onFocusOutside: f(t.onFocusOutside, (e) => e.preventDefault(), {
          checkForDefaultPrevented: !1,
        }),
        onDismiss: () => a.onOpenChange(!1),
      })
    )
  }),
  _n = e.forwardRef((e, t) => {
    const n = hn(jn, e.__scopeMenu)
    return o.jsx(An, {
      ...e,
      ref: t,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      disableOutsideScroll: !1,
      onDismiss: () => n.onOpenChange(!1),
    })
  }),
  Sn = u("MenuContent.ScrollLock"),
  An = e.forwardRef((t, n) => {
    const {
        __scopeMenu: a,
        loop: r = !1,
        trapFocus: s,
        onOpenAutoFocus: i,
        onCloseAutoFocus: c,
        disableOutsidePointerEvents: l,
        onEntryFocus: u,
        onEscapeKeyDown: m,
        onPointerDownOutside: p,
        onFocusOutside: h,
        onInteractOutside: x,
        onDismiss: g,
        disableOutsideScroll: v,
        ...y
      } = t,
      b = hn(jn, a),
      w = xn(jn, a),
      C = un(a),
      j = mn(a),
      M = sn(a),
      [E, _] = e.useState(null),
      S = e.useRef(null),
      A = d(n, S, b.onContentChange),
      L = e.useRef(0),
      D = e.useRef(""),
      T = e.useRef(0),
      Z = e.useRef(null),
      R = e.useRef("right"),
      H = e.useRef(0),
      V = v ? Jt : e.Fragment,
      F = v ? { as: Sn, allowPinchZoom: !0 } : void 0,
      I = (e) => {
        const t = D.current + e,
          n = M().filter((e) => !e.disabled),
          a = document.activeElement,
          r = n.find((e) => e.ref.current === a)?.textValue,
          o = (function (e, t, n) {
            const a = t.length > 1 && Array.from(t).every((e) => e === t[0]),
              r = a ? t[0] : t,
              o = n ? e.indexOf(n) : -1
            let s =
              ((i = e),
              (c = Math.max(o, 0)),
              i.map((e, t) => i[(c + t) % i.length]))
            var i, c
            1 === r.length && (s = s.filter((e) => e !== n))
            const l = s.find((e) => e.toLowerCase().startsWith(r.toLowerCase()))
            return l !== n ? l : void 0
          })(
            n.map((e) => e.textValue),
            t,
            r
          ),
          s = n.find((e) => e.textValue === o)?.ref.current
        !(function e(t) {
          ;(D.current = t),
            window.clearTimeout(L.current),
            "" !== t && (L.current = window.setTimeout(() => e(""), 1e3))
        })(t),
          s && setTimeout(() => s.focus())
      }
    e.useEffect(() => () => window.clearTimeout(L.current), []),
      e.useEffect(() => {
        const e = document.querySelectorAll("[data-radix-focus-guard]")
        return (
          document.body.insertAdjacentElement("afterbegin", e[0] ?? De()),
          document.body.insertAdjacentElement("beforeend", e[1] ?? De()),
          Le++,
          () => {
            1 === Le &&
              document
                .querySelectorAll("[data-radix-focus-guard]")
                .forEach((e) => e.remove()),
              Le--
          }
        )
      }, [])
    const P = e.useCallback(
      (e) =>
        R.current === Z.current?.side &&
        (function (e, t) {
          if (!t) return !1
          const n = { x: e.clientX, y: e.clientY }
          return (function (e, t) {
            const { x: n, y: a } = e
            let r = !1
            for (let o = 0, s = t.length - 1; o < t.length; s = o++) {
              const e = t[o],
                i = t[s],
                c = e.x,
                l = e.y,
                d = i.x,
                u = i.y
              l > a != u > a &&
                n < ((d - c) * (a - l)) / (u - l) + c &&
                (r = !r)
            }
            return r
          })(n, t)
        })(e, Z.current?.area),
      []
    )
    return o.jsx(Mn, {
      scope: a,
      searchRef: D,
      onItemEnter: e.useCallback(
        (e) => {
          P(e) && e.preventDefault()
        },
        [P]
      ),
      onItemLeave: e.useCallback(
        (e) => {
          P(e) || (S.current?.focus(), _(null))
        },
        [P]
      ),
      onTriggerLeave: e.useCallback(
        (e) => {
          P(e) && e.preventDefault()
        },
        [P]
      ),
      pointerGraceTimerRef: T,
      onPointerGraceIntentChange: e.useCallback((e) => {
        Z.current = e
      }, []),
      children: o.jsx(V, {
        ...F,
        children: o.jsx(He, {
          asChild: !0,
          trapped: s,
          onMountAutoFocus: f(i, (e) => {
            e.preventDefault(), S.current?.focus({ preventScroll: !0 })
          }),
          onUnmountAutoFocus: c,
          children: o.jsx(N, {
            asChild: !0,
            disableOutsidePointerEvents: l,
            onEscapeKeyDown: m,
            onPointerDownOutside: p,
            onFocusOutside: h,
            onInteractOutside: x,
            onDismiss: g,
            children: o.jsx(ot, {
              asChild: !0,
              ...j,
              dir: w.dir,
              orientation: "vertical",
              loop: r,
              currentTabStopId: E,
              onCurrentTabStopIdChange: _,
              onEntryFocus: f(u, (e) => {
                w.isUsingKeyboardRef.current || e.preventDefault()
              }),
              preventScrollOnEntryFocus: !0,
              children: o.jsx(k, {
                role: "menu",
                "aria-orientation": "vertical",
                "data-state": na(b.open),
                "data-radix-menu-content": "",
                dir: w.dir,
                ...C,
                ...y,
                ref: A,
                style: { outline: "none", ...y.style },
                onKeyDown: f(y.onKeyDown, (e) => {
                  const t =
                      e.target.closest("[data-radix-menu-content]") ===
                      e.currentTarget,
                    n = e.ctrlKey || e.altKey || e.metaKey,
                    a = 1 === e.key.length
                  t &&
                    ("Tab" === e.key && e.preventDefault(), !n && a && I(e.key))
                  const r = S.current
                  if (e.target !== r) return
                  if (!tn.includes(e.key)) return
                  e.preventDefault()
                  const o = M()
                    .filter((e) => !e.disabled)
                    .map((e) => e.ref.current)
                  en.includes(e.key) && o.reverse(),
                    (function (e) {
                      const t = document.activeElement
                      for (const n of e) {
                        if (n === t) return
                        if ((n.focus(), document.activeElement !== t)) return
                      }
                    })(o)
                }),
                onBlur: f(t.onBlur, (e) => {
                  e.currentTarget.contains(e.target) ||
                    (window.clearTimeout(L.current), (D.current = ""))
                }),
                onPointerMove: f(
                  t.onPointerMove,
                  oa((e) => {
                    const t = e.target,
                      n = H.current !== e.clientX
                    if (e.currentTarget.contains(t) && n) {
                      const t = e.clientX > H.current ? "right" : "left"
                      ;(R.current = t), (H.current = e.clientX)
                    }
                  })
                ),
              }),
            }),
          }),
        }),
      }),
    })
  })
Nn.displayName = jn
var Ln = e.forwardRef((e, t) => {
  const { __scopeMenu: n, ...a } = e
  return o.jsx(p.div, { role: "group", ...a, ref: t })
})
Ln.displayName = "MenuGroup"
var Dn = e.forwardRef((e, t) => {
  const { __scopeMenu: n, ...a } = e
  return o.jsx(p.div, { ...a, ref: t })
})
Dn.displayName = "MenuLabel"
var Tn = "MenuItem",
  Zn = "menu.itemSelect",
  Rn = e.forwardRef((t, n) => {
    const { disabled: a = !1, onSelect: r, ...s } = t,
      i = e.useRef(null),
      c = xn(Tn, t.__scopeMenu),
      l = En(Tn, t.__scopeMenu),
      u = d(n, i),
      m = e.useRef(!1)
    return o.jsx(Hn, {
      ...s,
      ref: u,
      disabled: a,
      onClick: f(t.onClick, () => {
        const e = i.current
        if (!a && e) {
          const t = new CustomEvent(Zn, { bubbles: !0, cancelable: !0 })
          e.addEventListener(Zn, (e) => r?.(e), { once: !0 }),
            w(e, t),
            t.defaultPrevented ? (m.current = !1) : c.onClose()
        }
      }),
      onPointerDown: (e) => {
        t.onPointerDown?.(e), (m.current = !0)
      },
      onPointerUp: f(t.onPointerUp, (e) => {
        m.current || e.currentTarget?.click()
      }),
      onKeyDown: f(t.onKeyDown, (e) => {
        const t = "" !== l.searchRef.current
        a ||
          (t && " " === e.key) ||
          (Qt.includes(e.key) && (e.currentTarget.click(), e.preventDefault()))
      }),
    })
  })
Rn.displayName = Tn
var Hn = e.forwardRef((t, n) => {
    const { __scopeMenu: a, disabled: r = !1, textValue: s, ...i } = t,
      c = En(Tn, a),
      l = mn(a),
      u = e.useRef(null),
      m = d(n, u),
      [h, x] = e.useState(!1),
      [g, v] = e.useState("")
    return (
      e.useEffect(() => {
        const e = u.current
        e && v((e.textContent ?? "").trim())
      }, [i.children]),
      o.jsx(on.ItemSlot, {
        scope: a,
        disabled: r,
        textValue: s ?? g,
        children: o.jsx(st, {
          asChild: !0,
          ...l,
          focusable: !r,
          children: o.jsx(p.div, {
            role: "menuitem",
            "data-highlighted": h ? "" : void 0,
            "aria-disabled": r || void 0,
            "data-disabled": r ? "" : void 0,
            ...i,
            ref: m,
            onPointerMove: f(
              t.onPointerMove,
              oa((e) => {
                if (r) c.onItemLeave(e)
                else if ((c.onItemEnter(e), !e.defaultPrevented)) {
                  e.currentTarget.focus({ preventScroll: !0 })
                }
              })
            ),
            onPointerLeave: f(
              t.onPointerLeave,
              oa((e) => c.onItemLeave(e))
            ),
            onFocus: f(t.onFocus, () => x(!0)),
            onBlur: f(t.onBlur, () => x(!1)),
          }),
        }),
      })
    )
  }),
  Vn = e.forwardRef((e, t) => {
    const { checked: n = !1, onCheckedChange: a, ...r } = e
    return o.jsx(Gn, {
      scope: e.__scopeMenu,
      checked: n,
      children: o.jsx(Rn, {
        role: "menuitemcheckbox",
        "aria-checked": aa(n) ? "mixed" : n,
        ...r,
        ref: t,
        "data-state": ra(n),
        onSelect: f(r.onSelect, () => a?.(!!aa(n) || !n), {
          checkForDefaultPrevented: !1,
        }),
      }),
    })
  })
Vn.displayName = "MenuCheckboxItem"
var Fn = "MenuRadioGroup",
  [In, Pn] = ln(Fn, { value: void 0, onValueChange: () => {} }),
  On = e.forwardRef((e, t) => {
    const { value: n, onValueChange: a, ...r } = e,
      s = m(a)
    return o.jsx(In, {
      scope: e.__scopeMenu,
      value: n,
      onValueChange: s,
      children: o.jsx(Ln, { ...r, ref: t }),
    })
  })
On.displayName = Fn
var Kn = "MenuRadioItem",
  Bn = e.forwardRef((e, t) => {
    const { value: n, ...a } = e,
      r = Pn(Kn, e.__scopeMenu),
      s = n === r.value
    return o.jsx(Gn, {
      scope: e.__scopeMenu,
      checked: s,
      children: o.jsx(Rn, {
        role: "menuitemradio",
        "aria-checked": s,
        ...a,
        ref: t,
        "data-state": ra(s),
        onSelect: f(a.onSelect, () => r.onValueChange?.(n), {
          checkForDefaultPrevented: !1,
        }),
      }),
    })
  })
Bn.displayName = Kn
var zn = "MenuItemIndicator",
  [Gn, $n] = ln(zn, { checked: !1 }),
  Wn = e.forwardRef((e, t) => {
    const { __scopeMenu: n, forceMount: a, ...r } = e,
      s = $n(zn, n)
    return o.jsx(M, {
      present: a || aa(s.checked) || !0 === s.checked,
      children: o.jsx(p.span, { ...r, ref: t, "data-state": ra(s.checked) }),
    })
  })
Wn.displayName = zn
var Un = e.forwardRef((e, t) => {
  const { __scopeMenu: n, ...a } = e
  return o.jsx(p.div, {
    role: "separator",
    "aria-orientation": "horizontal",
    ...a,
    ref: t,
  })
})
Un.displayName = "MenuSeparator"
var Yn = e.forwardRef((e, t) => {
  const { __scopeMenu: n, ...a } = e,
    r = un(n)
  return o.jsx(_, { ...r, ...a, ref: t })
})
Yn.displayName = "MenuArrow"
var [qn, Xn] = ln("MenuSub"),
  Jn = "MenuSubTrigger",
  Qn = e.forwardRef((t, n) => {
    const a = hn(Jn, t.__scopeMenu),
      r = xn(Jn, t.__scopeMenu),
      s = Xn(Jn, t.__scopeMenu),
      i = En(Jn, t.__scopeMenu),
      c = e.useRef(null),
      { pointerGraceTimerRef: l, onPointerGraceIntentChange: d } = i,
      u = { __scopeMenu: t.__scopeMenu },
      m = e.useCallback(() => {
        c.current && window.clearTimeout(c.current), (c.current = null)
      }, [])
    return (
      e.useEffect(() => m, [m]),
      e.useEffect(() => {
        const e = l.current
        return () => {
          window.clearTimeout(e), d(null)
        }
      }, [l, d]),
      o.jsx(vn, {
        asChild: !0,
        ...u,
        children: o.jsx(Hn, {
          id: s.triggerId,
          "aria-haspopup": "menu",
          "aria-expanded": a.open,
          "aria-controls": s.contentId,
          "data-state": na(a.open),
          ...t,
          ref: S(n, s.onTriggerChange),
          onClick: (e) => {
            t.onClick?.(e),
              t.disabled ||
                e.defaultPrevented ||
                (e.currentTarget.focus(), a.open || a.onOpenChange(!0))
          },
          onPointerMove: f(
            t.onPointerMove,
            oa((e) => {
              i.onItemEnter(e),
                e.defaultPrevented ||
                  t.disabled ||
                  a.open ||
                  c.current ||
                  (i.onPointerGraceIntentChange(null),
                  (c.current = window.setTimeout(() => {
                    a.onOpenChange(!0), m()
                  }, 100)))
            })
          ),
          onPointerLeave: f(
            t.onPointerLeave,
            oa((e) => {
              m()
              const t = a.content?.getBoundingClientRect()
              if (t) {
                const n = a.content?.dataset.side,
                  r = "right" === n,
                  o = r ? -5 : 5,
                  s = t[r ? "left" : "right"],
                  c = t[r ? "right" : "left"]
                i.onPointerGraceIntentChange({
                  area: [
                    { x: e.clientX + o, y: e.clientY },
                    { x: s, y: t.top },
                    { x: c, y: t.top },
                    { x: c, y: t.bottom },
                    { x: s, y: t.bottom },
                  ],
                  side: n,
                }),
                  window.clearTimeout(l.current),
                  (l.current = window.setTimeout(
                    () => i.onPointerGraceIntentChange(null),
                    300
                  ))
              } else {
                if ((i.onTriggerLeave(e), e.defaultPrevented)) return
                i.onPointerGraceIntentChange(null)
              }
            })
          ),
          onKeyDown: f(t.onKeyDown, (e) => {
            const n = "" !== i.searchRef.current
            t.disabled ||
              (n && " " === e.key) ||
              (nn[r.dir].includes(e.key) &&
                (a.onOpenChange(!0), a.content?.focus(), e.preventDefault()))
          }),
        }),
      })
    )
  })
Qn.displayName = Jn
var ea = "MenuSubContent",
  ta = e.forwardRef((t, n) => {
    const a = wn(jn, t.__scopeMenu),
      { forceMount: r = a.forceMount, ...s } = t,
      i = hn(jn, t.__scopeMenu),
      c = xn(jn, t.__scopeMenu),
      l = Xn(ea, t.__scopeMenu),
      u = e.useRef(null),
      m = d(n, u)
    return o.jsx(on.Provider, {
      scope: t.__scopeMenu,
      children: o.jsx(M, {
        present: r || i.open,
        children: o.jsx(on.Slot, {
          scope: t.__scopeMenu,
          children: o.jsx(An, {
            id: l.contentId,
            "aria-labelledby": l.triggerId,
            ...s,
            ref: m,
            align: "start",
            side: "rtl" === c.dir ? "left" : "right",
            disableOutsidePointerEvents: !1,
            disableOutsideScroll: !1,
            trapFocus: !1,
            onOpenAutoFocus: (e) => {
              c.isUsingKeyboardRef.current && u.current?.focus(),
                e.preventDefault()
            },
            onCloseAutoFocus: (e) => e.preventDefault(),
            onFocusOutside: f(t.onFocusOutside, (e) => {
              e.target !== l.trigger && i.onOpenChange(!1)
            }),
            onEscapeKeyDown: f(t.onEscapeKeyDown, (e) => {
              c.onClose(), e.preventDefault()
            }),
            onKeyDown: f(t.onKeyDown, (e) => {
              const t = e.currentTarget.contains(e.target),
                n = an[c.dir].includes(e.key)
              t &&
                n &&
                (i.onOpenChange(!1), l.trigger?.focus(), e.preventDefault())
            }),
          }),
        }),
      }),
    })
  })
function na(e) {
  return e ? "open" : "closed"
}
function aa(e) {
  return "indeterminate" === e
}
function ra(e) {
  return aa(e) ? "indeterminate" : e ? "checked" : "unchecked"
}
function oa(e) {
  return (t) => ("mouse" === t.pointerType ? e(t) : void 0)
}
ta.displayName = ea
var sa = gn,
  ia = vn,
  ca = Cn,
  la = Nn,
  da = Ln,
  ua = Dn,
  ma = Rn,
  pa = Vn,
  ha = On,
  fa = Bn,
  xa = Wn,
  ga = Un,
  va = Yn,
  ya = Qn,
  ba = ta,
  wa = "DropdownMenu",
  [Ca, ja] = l(wa, [dn]),
  Ma = dn(),
  [Ea, Na] = Ca(wa),
  ka = (t) => {
    const {
        __scopeDropdownMenu: n,
        children: a,
        dir: r,
        open: s,
        defaultOpen: i,
        onOpenChange: c,
        modal: l = !0,
      } = t,
      d = Ma(n),
      u = e.useRef(null),
      [m, p] = x({ prop: s, defaultProp: i ?? !1, onChange: c, caller: wa })
    return o.jsx(Ea, {
      scope: n,
      triggerId: h(),
      triggerRef: u,
      contentId: h(),
      open: m,
      onOpenChange: p,
      onOpenToggle: e.useCallback(() => p((e) => !e), [p]),
      modal: l,
      children: o.jsx(sa, {
        ...d,
        open: m,
        onOpenChange: p,
        dir: r,
        modal: l,
        children: a,
      }),
    })
  }
ka.displayName = wa
var _a = "DropdownMenuTrigger",
  Sa = e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, disabled: a = !1, ...r } = e,
      s = Na(_a, n),
      i = Ma(n)
    return o.jsx(ia, {
      asChild: !0,
      ...i,
      children: o.jsx(p.button, {
        type: "button",
        id: s.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": s.open,
        "aria-controls": s.open ? s.contentId : void 0,
        "data-state": s.open ? "open" : "closed",
        "data-disabled": a ? "" : void 0,
        disabled: a,
        ...r,
        ref: S(t, s.triggerRef),
        onPointerDown: f(e.onPointerDown, (e) => {
          a ||
            0 !== e.button ||
            !1 !== e.ctrlKey ||
            (s.onOpenToggle(), s.open || e.preventDefault())
        }),
        onKeyDown: f(e.onKeyDown, (e) => {
          a ||
            (["Enter", " "].includes(e.key) && s.onOpenToggle(),
            "ArrowDown" === e.key && s.onOpenChange(!0),
            ["Enter", " ", "ArrowDown"].includes(e.key) && e.preventDefault())
        }),
      }),
    })
  })
Sa.displayName = _a
var Aa = (e) => {
  const { __scopeDropdownMenu: t, ...n } = e,
    a = Ma(t)
  return o.jsx(ca, { ...a, ...n })
}
Aa.displayName = "DropdownMenuPortal"
var La = "DropdownMenuContent",
  Da = e.forwardRef((t, n) => {
    const { __scopeDropdownMenu: a, ...r } = t,
      s = Na(La, a),
      i = Ma(a),
      c = e.useRef(!1)
    return o.jsx(la, {
      id: s.contentId,
      "aria-labelledby": s.triggerId,
      ...i,
      ...r,
      ref: n,
      onCloseAutoFocus: f(t.onCloseAutoFocus, (e) => {
        c.current || s.triggerRef.current?.focus(),
          (c.current = !1),
          e.preventDefault()
      }),
      onInteractOutside: f(t.onInteractOutside, (e) => {
        const t = e.detail.originalEvent,
          n = 0 === t.button && !0 === t.ctrlKey,
          a = 2 === t.button || n
        ;(s.modal && !a) || (c.current = !0)
      }),
      style: {
        ...t.style,
        "--radix-dropdown-menu-content-transform-origin":
          "var(--radix-popper-transform-origin)",
        "--radix-dropdown-menu-content-available-width":
          "var(--radix-popper-available-width)",
        "--radix-dropdown-menu-content-available-height":
          "var(--radix-popper-available-height)",
        "--radix-dropdown-menu-trigger-width":
          "var(--radix-popper-anchor-width)",
        "--radix-dropdown-menu-trigger-height":
          "var(--radix-popper-anchor-height)",
      },
    })
  })
Da.displayName = La
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(da, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuGroup"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ua, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuLabel"
var Ta = e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ma, { ...r, ...a, ref: t })
})
Ta.displayName = "DropdownMenuItem"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(pa, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuCheckboxItem"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ha, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuRadioGroup"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(fa, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuRadioItem"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(xa, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuItemIndicator"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ga, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuSeparator"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(va, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuArrow"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ya, { ...r, ...a, ref: t })
}).displayName = "DropdownMenuSubTrigger"
e.forwardRef((e, t) => {
  const { __scopeDropdownMenu: n, ...a } = e,
    r = Ma(n)
  return o.jsx(ba, {
    ...r,
    ...a,
    ref: t,
    style: {
      ...e.style,
      "--radix-dropdown-menu-content-transform-origin":
        "var(--radix-popper-transform-origin)",
      "--radix-dropdown-menu-content-available-width":
        "var(--radix-popper-available-width)",
      "--radix-dropdown-menu-content-available-height":
        "var(--radix-popper-available-height)",
      "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-dropdown-menu-trigger-height":
        "var(--radix-popper-anchor-height)",
    },
  })
}).displayName = "DropdownMenuSubContent"
var Za = ka,
  Ra = Sa,
  Ha = Aa,
  Va = Da,
  Fa = Ta
function Ia({ trigger: e, children: t, unstyledTrigger: n = !1, ...a }) {
  return o.jsx(Pa, {
    ...a,
    trigger: e
      ? n
        ? o.jsx(Ra, { asChild: !0, children: e })
        : o.jsx(Oa, { children: e })
      : o.jsx(Oa, {}),
    children: t,
  })
}
function Pa({
  matchTriggerWidth: e = !1,
  children: t,
  open: n,
  onOpenChange: a,
  trigger: r,
  ...s
}) {
  const i = e ? { width: "var(--radix-dropdown-menu-trigger-width)" } : void 0
  return o.jsxs(Za, {
    open: n,
    onOpenChange: a,
    children: [
      r,
      o.jsx(Ha, {
        children: o.jsx(Va, {
          ...s,
          style: i,
          className: c(
            "z-50 bg-bg-000 border-[0.5px] border-border-300 rounded-xl shadow-lg",
            "p-1.5 min-w-40",
            "animate-in fade-in-0 zoom-in-95",
            s.className
          ),
          children: t,
        }),
      }),
    ],
  })
}
const Oa = ({ children: e }) =>
    o.jsx(Ra, {
      asChild: !0,
      children: o.jsx("button", {
        className:
          "opacity-0 group-hover:opacity-100 p-1 text-text-300 hover:bg-bg-100 rounded transition-all",
        children: e || o.jsx(Me, { size: 16 }),
      }),
    }),
  Ka = s.forwardRef(
    ({ children: e, icon: t, danger: n, disabled: a, className: r, ...s }, i) =>
      o.jsx(Fa, {
        ref: i,
        disabled: a,
        className: c(
          "font-base py-1.5 px-2 rounded-lg cursor-pointer",
          "whitespace-nowrap overflow-hidden text-ellipsis",
          "outline-none select-none",
          "text-sm",
          "data-[highlighted]:bg-bg-200",
          "data-[highlighted]:text-text-000",
          "text-text-300",
          n && "!text-danger-000 data-[highlighted]:bg-danger-900",
          a && "opacity-50 pointer-events-none",
          r
        ),
        ...s,
        children: o.jsxs("div", {
          className: "flex items-center gap-2.5 py-0.5",
          children: [t, o.jsx("span", { children: e })],
        }),
      })
  )
Ka.displayName = "DropdownItem"
const Ba = (e) =>
  o.jsx(i, {
    ...e,
    children: o.jsx("path", {
      d: "M10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5ZM10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5899 6.41015 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM12.6094 7.1875C12.7819 6.97187 13.0969 6.93687 13.3125 7.10938C13.5281 7.28188 13.5631 7.59687 13.3906 7.8125L9.39062 12.8125C9.30178 12.9236 9.16935 12.9912 9.02734 12.999C8.92097 13.0049 8.81649 12.9768 8.72852 12.9199L8.64648 12.8535L6.64648 10.8535L6.58203 10.7754C6.45387 10.5813 6.47562 10.3173 6.64648 10.1465C6.81735 9.97562 7.08131 9.95387 7.27539 10.082L7.35352 10.1465L8.95801 11.751L12.6094 7.1875Z",
    }),
  })
function za({ toast: t, onClose: n }) {
  const [a, r] = e.useState(!1)
  e.useEffect(() => {
    const e = setTimeout(() => {
      s()
    }, 3e3)
    return () => clearTimeout(e)
  }, [t.id])
  const s = () => {
    r(!0),
      setTimeout(() => {
        n(t.id)
      }, 200)
  }
  return o.jsxs("div", {
    className: c(
      "flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg",
      "bg-bg-000 border-[0.5px] border-border-300",
      "min-w-[300px] transition-all duration-200 ease-out",
      a
        ? ["opacity-0 translate-x-full"]
        : ["animate-toast-slide-in", "opacity-100 translate-x-0"]
    ),
    style: { animation: a ? void 0 : "toast-slide-in 0.3s ease-out" },
    children: [
      "success" === t.type &&
        o.jsx(Ba, {
          size: 16,
          className: "text-accent-secondary-100 flex-shrink-0",
        }),
      o.jsx("p", {
        className: "text-text-200 font-base flex-1",
        children: t.message,
      }),
      o.jsx("button", {
        onClick: s,
        className:
          "p-1 hover:bg-bg-100 rounded transition-colors flex-shrink-0",
        children: o.jsx(A, { size: 14, className: "text-text-300" }),
      }),
    ],
  })
}
function Ga() {
  const [t, n] = e.useState([]),
    a = (e, t = "success") => {
      const a = Date.now().toString()
      n((n) => [...n, { id: a, message: e, type: t }])
    },
    r = (e) => {
      n((t) => t.filter((t) => t.id !== e))
    }
  return (
    e.useEffect(
      () => (
        (window.showToast = a),
        () => {
          delete window.showToast
        }
      ),
      []
    ),
    0 === t.length
      ? null
      : o.jsx("div", {
          className: "fixed top-4 right-4 z-50 flex flex-col gap-2",
          children: t.map((e) => o.jsx(za, { toast: e, onClose: r }, e.id)),
        })
  )
}
function $a() {
  const [t, n] = e.useState([]),
    [r, s] = e.useState(null),
    [i, c] = e.useState(!1),
    [l, d] = e.useState("my-tasks"),
    { showToast: u } = {
      showToast: (e, t = "success") => {
        const n = window
        n.showToast && n.showToast(e, t)
      },
    },
    { value: m } = a.useFeatureGate("crochet_browse_shortcuts"),
    { value: p } = a.useFeatureGate("chrome_scheduled_tasks"),
    h = (e) => {
      switch (e) {
        case "general":
        default:
          return o.jsx(ue, {
            size: 18,
            weight: "light",
            className: "text-text-300",
          })
        case "email":
          return o.jsx(le, {
            size: 18,
            weight: "light",
            className: "text-text-300",
          })
        case "docs":
          return o.jsx(Ee, { size: 16, className: "text-text-300" })
        case "calendar":
          return o.jsx(oe, {
            size: 18,
            weight: "light",
            className: "text-text-300",
          })
        case "linkedin":
          return o.jsx(pe, {
            size: 18,
            weight: "light",
            className: "text-text-300",
          })
      }
    },
    f = async () => {
      const e = await G.getAllPrompts()
      n(e.sort((e, t) => t.createdAt - e.createdAt))
    },
    x = t.filter((e) => e.repeatType && "none" !== e.repeatType),
    g = t.filter((e) => !e.repeatType || "none" === e.repeatType),
    v = (e) => {
      if (!e.repeatType || "none" === e.repeatType) return ""
      const t = e.specificTime
          ? new Date(`2000-01-01T${e.specificTime}`).toLocaleTimeString(
              "en-US",
              { hour: "numeric", minute: "2-digit", hour12: !0 }
            )
          : "",
        n = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
        ],
        a = [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
        r = t ? ` at ${t}` : ""
      switch (e.repeatType) {
        case "once":
          if (e.specificDate) {
            const [t, n, o] = e.specificDate.split("-").map(Number)
            return `${a[n - 1]} ${o}, ${t}${r}`
          }
          return `Once${r}`
        case "daily":
          return `Daily${r}`
        case "weekly":
          return `Weekly on ${n[e.dayOfWeek || 0]}${r}`
        case "monthly":
          return `Monthly on day ${e.dayOfMonth || 1}${r}`
        case "annually":
          if (e.monthAndDay) {
            const [t, n] = e.monthAndDay.split("-").map(Number)
            return `Annually on ${a[t - 1]} ${n}${r}`
          }
          return `Annually${r}`
        default:
          return ""
      }
    }
  e.useEffect(() => {
    f()
  }, [])
  const y = async (e) => {
    confirm("Are you sure you want to delete this prompt?") &&
      (await G.deletePrompt(e),
      r?.id === e && (s(null), c(!1)),
      f(),
      u("Shortcut deleted successfully"))
  }
  return o.jsxs(o.Fragment, {
    children: [
      o.jsx(Ga, {}),
      o.jsxs("div", {
        className: "space-y-6",
        children: [
          o.jsxs("div", {
            className:
              "bg-bg-100 border-[0.5px] border-border-300 rounded-xl px-6 pt-6 pb-6 md:px-8 md:pt-8 md:pb-8",
            children: [
              o.jsxs("div", {
                className: "flex items-start justify-between mb-2",
                children: [
                  o.jsxs("div", {
                    children: [
                      o.jsx("h3", {
                        className: "text-text-100 font-xl-bold",
                        children: "Shortcuts",
                      }),
                      o.jsx("p", {
                        className: "text-text-300 font-base mt-1",
                        children: p
                          ? "Type / in the chat to use shortcuts or run them on schedule"
                          : "Type / in the chat to use shortcuts",
                      }),
                    ],
                  }),
                  o.jsx(L, {
                    onClick: () => {
                      s(null), c(!0)
                    },
                    prepend: o.jsx(D, { size: 16 }),
                    size: "sm",
                    className: "ml-2",
                    children: "Create shortcut",
                  }),
                ],
              }),
              m &&
                o.jsx("div", {
                  className: "mt-6",
                  children: o.jsx(ke, {
                    value: l,
                    onSelect: (e) => d(e),
                    options: [
                      { key: "my-tasks", label: "My shortcuts" },
                      { key: "browse", label: "Browse" },
                    ],
                  }),
                }),
              "my-tasks" !== l && m
                ? "browse" === l && m
                  ? o.jsx("div", {
                      className: "space-y-8 mt-6",
                      children: Ne.map((e) =>
                        o.jsxs(
                          "div",
                          {
                            children: [
                              o.jsxs("div", {
                                className: "flex items-center gap-2 mb-4",
                                children: [
                                  h(e.category),
                                  o.jsx("h4", {
                                    className: "text-text-200 font-base-bold",
                                    children: e.label,
                                  }),
                                ],
                              }),
                              o.jsx("div", {
                                className:
                                  "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                                children: e.prompts.map((t, n) =>
                                  o.jsx(
                                    Wa,
                                    {
                                      template: t,
                                      onUse: () => {
                                        s({
                                          id: "",
                                          ...t,
                                          createdAt: Date.now(),
                                          lastUsedAt: void 0,
                                          usageCount: 0,
                                        }),
                                          c(!0)
                                      },
                                    },
                                    `${e.category}-${n}`
                                  )
                                ),
                              }),
                            ],
                          },
                          e.category
                        )
                      ),
                    })
                  : null
                : o.jsxs("div", {
                    className: "space-y-8 mt-6",
                    children: [
                      x.length > 0 &&
                        o.jsxs("div", {
                          children: [
                            o.jsxs("div", {
                              className: "flex items-center gap-2 mb-4",
                              children: [
                                o.jsx(ie, {
                                  size: 18,
                                  weight: "light",
                                  className: "text-text-300",
                                }),
                                o.jsx("h4", {
                                  className: "text-text-200 font-base-bold",
                                  children: "Scheduled",
                                }),
                              ],
                            }),
                            o.jsx("div", {
                              className:
                                "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                              children: x.map((e) =>
                                o.jsx(
                                  Ua,
                                  {
                                    prompt: e,
                                    scheduleText: v(e),
                                    onEdit: () => {
                                      s(e), c(!0)
                                    },
                                    onDelete: () => y(e.id),
                                  },
                                  e.id
                                )
                              ),
                            }),
                          ],
                        }),
                      g.length > 0 &&
                        o.jsxs("div", {
                          children: [
                            x.length > 0 &&
                              o.jsxs("div", {
                                className: "flex items-center gap-2 mb-4",
                                children: [
                                  o.jsx(fe, {
                                    size: 18,
                                    weight: "light",
                                    className: "text-text-300",
                                  }),
                                  o.jsx("h4", {
                                    className: "text-text-200 font-base-bold",
                                    children: "Other",
                                  }),
                                ],
                              }),
                            o.jsx("div", {
                              className:
                                "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                              children: g.map((e) =>
                                o.jsx(
                                  Ua,
                                  {
                                    prompt: e,
                                    onEdit: () => {
                                      s(e), c(!0)
                                    },
                                    onDelete: () => y(e.id),
                                  },
                                  e.id
                                )
                              ),
                            }),
                          ],
                        }),
                      0 === t.length &&
                        o.jsxs("div", {
                          className: "bg-bg-200 rounded-xl p-12 text-center",
                          children: [
                            o.jsxs("picture", {
                              children: [
                                o.jsx("source", {
                                  srcSet:
                                    "data:image/svg+xml,%3csvg%20width='80'%20height='69'%20viewBox='0%200%2080%2069'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20filter='url(%23filter0_d_5136_3558)'%3e%3cpath%20d='M5%2019C5%2013.3995%205%2010.5992%206.08993%208.46009C7.04867%206.57847%208.57847%205.04867%2010.4601%204.08993C12.5992%203%2015.3995%203%2021%203H59.0648C64.6654%203%2067.4656%203%2069.6047%204.08993C71.4864%205.04867%2073.0162%206.57847%2073.9749%208.46009C75.0648%2010.5992%2075.0648%2013.3995%2075.0648%2019V46C75.0648%2051.6005%2075.0648%2054.4008%2073.9749%2056.5399C73.0162%2058.4215%2071.4864%2059.9513%2069.6047%2060.9101C67.4656%2062%2064.6654%2062%2059.0648%2062H21C15.3995%2062%2012.5992%2062%2010.4601%2060.9101C8.57847%2059.9513%207.04867%2058.4215%206.08993%2056.5399C5%2054.4008%205%2051.6005%205%2046V19Z'%20fill='%2330302E'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M59.0645%202.75C61.8606%202.75%2063.9733%202.74945%2065.6533%202.88672C67.3361%203.02421%2068.6072%203.30141%2069.7178%203.86719C71.6464%204.84987%2073.2146%206.41806%2074.1973%208.34668C74.7632%209.45736%2075.0402%2010.7291%2075.1777%2012.4121C75.315%2014.0921%2075.3145%2016.2041%2075.3145%2019V46C75.3145%2048.7959%2075.315%2050.9079%2075.1777%2052.5879C75.0402%2054.2709%2074.7632%2055.5426%2074.1973%2056.6533C73.2146%2058.5819%2071.6464%2060.1501%2069.7178%2061.1328C68.6072%2061.6986%2067.3361%2061.9758%2065.6533%2062.1133C63.9733%2062.2505%2061.8606%2062.25%2059.0645%2062.25H21C18.2041%2062.25%2016.0921%2062.2505%2014.4121%2062.1133C12.7292%2061.9758%2011.4573%2061.6987%2010.3467%2061.1328C8.41802%2060.1501%206.84989%2058.582%205.86719%2056.6533C5.30129%2055.5427%205.02422%2054.2708%204.88672%2052.5879C4.74949%2050.9079%204.75%2048.7959%204.75%2046V19C4.75%2016.2041%204.74949%2014.0921%204.88672%2012.4121C5.02422%2010.7292%205.30129%209.45734%205.86719%208.34668C6.84989%206.41802%208.41802%204.84989%2010.3467%203.86719C11.4573%203.30129%2012.7292%203.02422%2014.4121%202.88672C16.0921%202.74949%2018.2041%202.75%2021%202.75H59.0645Z'%20stroke='%23DEDCD1'%20stroke-opacity='0.3'%20stroke-width='0.5'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M14.4844%2019.2899L16.6109%2012.6917L17.5147%2012.7101L15.3882%2019.3083L14.4844%2019.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='15'%20width='32.0373'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2030.2899L16.6109%2023.6917L17.5147%2023.7101L15.3882%2030.3083L14.4844%2030.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='26'%20width='44.1435'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2041.2899L16.6109%2034.6917L17.5147%2034.7101L15.3882%2041.3083L14.4844%2041.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='37'%20width='38.9607'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2052.2899L16.6109%2045.6917L17.5147%2045.7101L15.3882%2052.3083L14.4844%2052.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='48'%20width='34.6778'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3c/g%3e%3cdefs%3e%3cfilter%20id='filter0_d_5136_3558'%20x='0.5'%20y='0.5'%20width='79.0645'%20height='68'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeOffset%20dy='2'/%3e%3cfeGaussianBlur%20stdDeviation='2'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200.05%200'/%3e%3cfeBlend%20mode='normal'%20in2='BackgroundImageFix'%20result='effect1_dropShadow_5136_3558'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect1_dropShadow_5136_3558'%20result='shape'/%3e%3c/filter%3e%3c/defs%3e%3c/svg%3e",
                                  media: "(prefers-color-scheme: dark)",
                                }),
                                o.jsx("img", {
                                  src: "data:image/svg+xml,%3csvg%20width='80'%20height='69'%20viewBox='0%200%2080%2069'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20filter='url(%23filter0_d_5136_3446)'%3e%3cpath%20d='M5%2019C5%2013.3995%205%2010.5992%206.08993%208.46009C7.04867%206.57847%208.57847%205.04867%2010.4601%204.08993C12.5992%203%2015.3995%203%2021%203H59.0648C64.6654%203%2067.4656%203%2069.6047%204.08993C71.4864%205.04867%2073.0162%206.57847%2073.9749%208.46009C75.0648%2010.5992%2075.0648%2013.3995%2075.0648%2019V46C75.0648%2051.6005%2075.0648%2054.4008%2073.9749%2056.5399C73.0162%2058.4215%2071.4864%2059.9513%2069.6047%2060.9101C67.4656%2062%2064.6654%2062%2059.0648%2062H21C15.3995%2062%2012.5992%2062%2010.4601%2060.9101C8.57847%2059.9513%207.04867%2058.4215%206.08993%2056.5399C5%2054.4008%205%2051.6005%205%2046V19Z'%20fill='white'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M59.0645%202.75C61.8606%202.75%2063.9733%202.74945%2065.6533%202.88672C67.3361%203.02421%2068.6072%203.30141%2069.7178%203.86719C71.6464%204.84987%2073.2146%206.41806%2074.1973%208.34668C74.7632%209.45736%2075.0402%2010.7291%2075.1777%2012.4121C75.315%2014.0921%2075.3145%2016.2041%2075.3145%2019V46C75.3145%2048.7959%2075.315%2050.9079%2075.1777%2052.5879C75.0402%2054.2709%2074.7632%2055.5426%2074.1973%2056.6533C73.2146%2058.5819%2071.6464%2060.1501%2069.7178%2061.1328C68.6072%2061.6986%2067.3361%2061.9758%2065.6533%2062.1133C63.9733%2062.2505%2061.8606%2062.25%2059.0645%2062.25H21C18.2041%2062.25%2016.0921%2062.2505%2014.4121%2062.1133C12.7292%2061.9758%2011.4573%2061.6987%2010.3467%2061.1328C8.41802%2060.1501%206.84989%2058.582%205.86719%2056.6533C5.30129%2055.5427%205.02422%2054.2708%204.88672%2052.5879C4.74949%2050.9079%204.75%2048.7959%204.75%2046V19C4.75%2016.2041%204.74949%2014.0921%204.88672%2012.4121C5.02422%2010.7292%205.30129%209.45734%205.86719%208.34668C6.84989%206.41802%208.41802%204.84989%2010.3467%203.86719C11.4573%203.30129%2012.7292%203.02422%2014.4121%202.88672C16.0921%202.74949%2018.2041%202.75%2021%202.75H59.0645Z'%20stroke='%231F1E1D'%20stroke-opacity='0.3'%20stroke-width='0.5'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M14.4844%2019.2899L16.6109%2012.6917L17.5147%2012.7101L15.3882%2019.3083L14.4844%2019.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='15'%20width='32.0373'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2030.2899L16.6109%2023.6917L17.5147%2023.7101L15.3882%2030.3083L14.4844%2030.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='26'%20width='44.1435'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2041.2899L16.6109%2034.6917L17.5147%2034.7101L15.3882%2041.3083L14.4844%2041.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='37'%20width='38.9607'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2052.2899L16.6109%2045.6917L17.5147%2045.7101L15.3882%2052.3083L14.4844%2052.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='48'%20width='34.6778'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3c/g%3e%3cdefs%3e%3cfilter%20id='filter0_d_5136_3446'%20x='0.5'%20y='0.5'%20width='79.0645'%20height='68'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeOffset%20dy='2'/%3e%3cfeGaussianBlur%20stdDeviation='2'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200.05%200'/%3e%3cfeBlend%20mode='normal'%20in2='BackgroundImageFix'%20result='effect1_dropShadow_5136_3446'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect1_dropShadow_5136_3446'%20result='shape'/%3e%3c/filter%3e%3c/defs%3e%3c/svg%3e",
                                  alt: "Tasks illustration",
                                  className: "w-24 h-24 mx-auto mb-1",
                                }),
                              ],
                            }),
                            o.jsx("p", {
                              className: "text-text-300 max-w-[200px] mx-auto",
                              children: m
                                ? o.jsxs(o.Fragment, {
                                    children: [
                                      "Create your first shortcut or",
                                      " ",
                                      o.jsx("button", {
                                        onClick: () => d("browse"),
                                        className:
                                          "text-text-200 underline hover:text-text-100 transition-colors cursor-pointer",
                                        children: "explore examples",
                                      }),
                                      " ",
                                      "to get started",
                                    ],
                                  })
                                : "Create your first shortcut to get started",
                            }),
                          ],
                        }),
                    ],
                  }),
            ],
          }),
          i &&
            o.jsx(Ya, {
              prompt: r,
              onClose: () => {
                c(!1), s(null)
              },
              onSave: (e) => {
                f(),
                  c(!1),
                  s(null),
                  u(
                    e
                      ? "Shortcut updated successfully"
                      : "Shortcut added successfully"
                  )
              },
            }),
        ],
      }),
    ],
  })
}
function Wa({ template: e, onUse: t }) {
  return o.jsxs("button", {
    onClick: t,
    className:
      "relative group bg-bg-000 border-[0.5px] border-border-300 rounded-2xl p-4 hover:border-border-200 transition-all shadow-[0_2px_4px_0_rgba(0,0,0,0.04)] hover:shadow-[0_4px_20px_0_rgba(0,0,0,0.08)] w-full text-left cursor-pointer",
    children: [
      o.jsxs("div", {
        className: "flex items-start justify-between gap-2 mb-2",
        children: [
          o.jsx("div", {
            className: "flex-1 min-w-0",
            children:
              e.command &&
              o.jsxs("div", {
                className:
                  "font-large-bold text-text-200 relative overflow-hidden",
                children: [
                  o.jsxs("div", {
                    className: "whitespace-nowrap",
                    children: [
                      o.jsx("span", {
                        className: "text-text-500/50 font-mono",
                        children: "/",
                      }),
                      o.jsx("span", {
                        className: "ml-0.5",
                        children: e.command,
                      }),
                    ],
                  }),
                  o.jsx("div", {
                    className:
                      "absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-bg-000 to-transparent pointer-events-none",
                  }),
                ],
              }),
          }),
          o.jsx("button", {
            onClick: (e) => {
              e.stopPropagation(), t()
            },
            className:
              "opacity-0 group-hover:opacity-100 p-1 text-text-300 hover:bg-bg-100 rounded-lg transition-all border-[0.5px] border-border-300",
            children: o.jsx(D, { size: 16 }),
          }),
        ],
      }),
      o.jsx("div", {
        className: "bg-bg-100 rounded-lg p-3",
        children: o.jsx("div", {
          className:
            "text-sm text-text-300 h-24 overflow-y-auto whitespace-pre-wrap",
          children: e.prompt,
        }),
      }),
    ],
  })
}
function Ua({ prompt: e, scheduleText: t, onEdit: n, onDelete: a }) {
  return o.jsxs("div", {
    onClick: n,
    className:
      "relative group bg-bg-000 border-[0.5px] border-border-300 rounded-2xl p-4 hover:border-border-200 transition-all shadow-[0_2px_4px_0_rgba(0,0,0,0.04)] hover:shadow-[0_4px_20px_0_rgba(0,0,0,0.08)] w-full cursor-pointer",
    children: [
      o.jsxs("div", {
        className: "flex items-start justify-between gap-2 mb-2",
        children: [
          o.jsx("div", {
            className: "flex-1 min-w-0 text-left",
            children:
              e.command &&
              o.jsxs("div", {
                className:
                  "font-large-bold text-text-200 relative overflow-hidden",
                children: [
                  o.jsxs("div", {
                    className: "whitespace-nowrap",
                    children: [
                      o.jsx("span", {
                        className: "text-text-500/50 font-mono",
                        children: "/",
                      }),
                      o.jsx("span", {
                        className: "ml-0.5",
                        children: e.command,
                      }),
                    ],
                  }),
                  o.jsx("div", {
                    className:
                      "absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-bg-000 to-transparent pointer-events-none",
                  }),
                ],
              }),
          }),
          o.jsx("div", {
            onClick: (e) => e.stopPropagation(),
            children: o.jsxs(Ia, {
              unstyledTrigger: !0,
              trigger: o.jsx("button", {
                className:
                  "p-1 hover:bg-bg-200 rounded transition-colors relative z-10",
                children: o.jsx(Me, { size: 16, className: "text-text-300" }),
              }),
              children: [
                o.jsx(Ka, {
                  icon: o.jsx(Ce, { size: 14 }),
                  onSelect: () => {
                    n()
                  },
                  children: "Edit",
                }),
                o.jsx(Ka, {
                  icon: o.jsx(je, { size: 14 }),
                  danger: !0,
                  onSelect: () => {
                    a()
                  },
                  children: "Delete",
                }),
              ],
            }),
          }),
        ],
      }),
      o.jsx("div", {
        className: "bg-bg-100 rounded-lg p-3 w-full text-left",
        children: o.jsx("div", {
          className:
            "text-sm text-text-300 h-24 overflow-y-auto whitespace-pre-wrap",
          children: e.prompt,
        }),
      }),
      t &&
        o.jsx("div", {
          className: "mt-3",
          children: o.jsx("div", {
            className: "text-text-300",
            children: o.jsx("span", { className: "text-xs", children: t }),
          }),
        }),
    ],
  })
}
function Ya({ prompt: t, onClose: n, onSave: a }) {
  const [r, s] = e.useState(t?.command || ""),
    [i, c] = e.useState(t?.prompt || ""),
    [l, d] = e.useState(""),
    [u, m] = e.useState(!1),
    p = "" === t?.id,
    h = e.useRef(null),
    [f, x] = e.useState(Boolean(t?.repeatType && "none" !== t.repeatType)),
    [g, v] = e.useState(
      t?.repeatType && "none" !== t.repeatType ? t.repeatType : "once"
    ),
    [y, b] = e.useState(t?.specificTime || "09:00"),
    [w, C] = e.useState(t?.dayOfWeek ?? 0),
    [j, M] = e.useState(t?.dayOfMonth || 1),
    [E, N] = e.useState(
      (t?.monthAndDay && parseInt(t.monthAndDay.split("-")[0])) || 1
    ),
    [k, _] = e.useState(
      (t?.monthAndDay && parseInt(t.monthAndDay.split("-")[1])) || 1
    ),
    [S, A] = e.useState(t?.specificDate || ""),
    [D, F] = e.useState(t?.url || "")
  e.useEffect(() => {
    setTimeout(() => {
      h.current?.focus()
    }, 100),
      (t && !p) ||
        chrome.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
          if (e[0]?.url)
            try {
              const t = new URL(e[0].url).origin
              t.startsWith("http") && F(t)
            } catch {}
        })
  }, [t, p]),
    e.useEffect(() => {
      const e = (e) => {
        if ("Enter" === e.key) {
          const t = document.activeElement
          "INPUT" === t?.tagName ||
            "TEXTAREA" === t?.tagName ||
            (e.preventDefault(), I())
        }
      }
      return (
        document.addEventListener("keydown", e),
        () => document.removeEventListener("keydown", e)
      )
    }, [r, i])
  const I = async () => {
    if ((m(!0), r.trim() && i.trim()))
      try {
        if (t && !p) {
          const e = {
            prompt: i.trim(),
            command: r.trim(),
            url: D.trim() || void 0,
          }
          f
            ? ((e.repeatType = g),
              (e.specificTime = y),
              "once" === g && (e.specificDate = S),
              "weekly" === g && (e.dayOfWeek = w),
              "monthly" === g && (e.dayOfMonth = j),
              "annually" === g &&
                (e.monthAndDay = `${E.toString().padStart(2, "0")}-${k
                  .toString()
                  .padStart(2, "0")}`))
            : ((e.repeatType = void 0),
              (e.specificTime = void 0),
              (e.specificDate = void 0),
              (e.dayOfWeek = void 0),
              (e.dayOfMonth = void 0),
              (e.monthAndDay = void 0)),
            await G.updatePrompt(t.id, e)
        } else {
          const e = {
            prompt: i.trim(),
            command: r.trim(),
            url: D.trim() || void 0,
            createdAt: Date.now(),
            usageCount: 0,
          }
          f &&
            ((e.repeatType = g),
            (e.specificTime = y),
            "once" === g && (e.specificDate = S),
            "weekly" === g && (e.dayOfWeek = w),
            "monthly" === g && (e.dayOfMonth = j),
            "annually" === g &&
              (e.monthAndDay = `${E.toString().padStart(2, "0")}-${k
                .toString()
                .padStart(2, "0")}`)),
            await G.savePrompt(e)
        }
        a(!(!t || p))
      } catch (ar) {
        d(ar instanceof Error ? ar.message : "Failed to save")
      }
  }
  return o.jsxs(T, {
    isOpen: !0,
    onClose: n,
    title: t && !p ? "Edit shortcut" : "Create shortcut",
    children: [
      o.jsxs("div", {
        className: "space-y-4",
        children: [
          o.jsxs("div", {
            children: [
              o.jsx("span", {
                className: "text-sm font-medium text-text-200 block mb-1",
                children: "Name",
              }),
              o.jsx(Z, {
                ref: h,
                type: "text",
                value: r,
                onChange: (e) => {
                  const t = e.target.value
                    .replace(/\s/g, "-")
                    .replace(/[^a-zA-Z0-9-_]/g, "")
                  s(t), l && d("")
                },
                prepend: o.jsx("span", {
                  className: "text-text-300",
                  children: "/",
                }),
                placeholder: "task-name",
                error:
                  u && !r.trim()
                    ? "Name is required"
                    : l?.includes("already in use")
                    ? l
                    : void 0,
              }),
            ],
          }),
          o.jsxs("div", {
            children: [
              o.jsx("span", {
                className: "text-sm font-medium text-text-200 block mb-1",
                children: "Prompt",
              }),
              o.jsx(R, {
                required: !0,
                value: i,
                onChange: (e) => c(e.target.value),
                className: "min-h-32 max-h-64 overflow-y-auto",
                placeholder: "Enter your prompt text...",
                error: u && !i.trim() ? "Prompt is required" : void 0,
              }),
            ],
          }),
          o.jsxs("div", {
            children: [
              o.jsx("span", {
                className: "text-sm font-medium text-text-200 block mb-1",
                children: "Start from",
              }),
              o.jsx(Z, {
                type: "url",
                value: D,
                onChange: (e) => F(e.target.value),
                placeholder: "https://example.com",
                fullWidth: !0,
              }),
            ],
          }),
          o.jsx(H, {
            scheduleEnabled: f,
            setScheduleEnabled: x,
            repeatType: g,
            setRepeatType: v,
            specificDate: S,
            setSpecificDate: A,
            dayOfWeek: w,
            setDayOfWeek: C,
            dayOfMonth: j,
            setDayOfMonth: M,
            month: E,
            setMonth: N,
            day: k,
            setDay: _,
            specificTime: y,
            setSpecificTime: b,
            monthLabels: [
              "January",
              "February",
              "March",
              "April",
              "May",
              "June",
              "July",
              "August",
              "September",
              "October",
              "November",
              "December",
            ],
            daysOfWeekLabels: [
              "Sunday",
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday",
            ],
            compact: !1,
          }),
          l &&
            !l.includes("already in use") &&
            o.jsx("div", { className: "text-danger-000 text-sm", children: l }),
        ],
      }),
      o.jsxs(V, {
        children: [
          o.jsx(L, { onClick: n, variant: "ghost", children: "Cancel" }),
          o.jsx(L, {
            onClick: I,
            children: t && !p ? "Save changes" : "Create shortcut",
          }),
        ],
      }),
    ],
  })
}
const qa = ({ apiKey: e, setApiKey: t, onSave: n, saved: a, apiBaseUrl, setApiBaseUrl }) =>
    o.jsxs("div", {
      className: "max-w-md",
      children: [
        o.jsx("h2", {
          className: "font-xl-bold text-text-100 mb-4",
          children: "API configuration (internal)",
        }),
        o.jsxs("div", {
          className: "space-y-4",
          children: [
            o.jsxs("div", {
              children: [
                o.jsx("label", {
                  htmlFor: "apiBaseUrl",
                  className: "font-label block mb-2 text-text-200",
                  children: "Anthropic API base URL",
                }),
                o.jsx("input", {
                  id: "apiBaseUrl",
                  type: "text",
                  value: apiBaseUrl,
                  onChange: (e) => setApiBaseUrl(e.target.value),
                  placeholder: "Enter your Anthropic API base URL",
                  className:
                    "w-full px-3 py-2 mb-4 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                }),
                o.jsx("label", {
                  htmlFor: "apiKey",
                  className: "font-label block mb-2 text-text-200",
                  children: "Anthropic API Key",
                }),
                o.jsx("input", {
                  id: "apiKey",
                  type: "password",
                  value: e,
                  onChange: (e) => t(e.target.value),
                  placeholder: "Enter your Anthropic API key",
                  className:
                    "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                }),
                o.jsxs("p", {
                  className: "mt-2 font-caption text-text-300",
                  children: [
                    "Get your API key from",
                    " ",
                    o.jsx("a", {
                      href: "https://console.anthropic.com/account/keys",
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "text-accent-main-200 hover:underline",
                      children: "console.anthropic.com",
                    }),
                  ],
                }),
              ],
            }),
            o.jsx("button", {
              onClick: n,
              className:
                "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
              children: "Save API Key",
            }),
            a &&
              o.jsx("div", {
                className: "font-base-sm text-text-200",
                children: "Settings saved successfully!",
              }),
          ],
        }),
      ],
    }),
  Xa = ({
    selectedModel: t,
    setSelectedModel: n,
    availableModels: a,
    systemPrompt: r,
    setSystemPrompt: s,
    debugMode: i,
    setDebugMode: c,
    onModelSave: l,
    onPromptSave: d,
    onResetPrompt: u,
    saved: m,
    setSaved: p,
    allowEditSystemPrompt: h,
  }) => {
    const [f, x] = e.useState(!1),
      [g, v] = e.useState(!1),
      [y, b] = e.useState(!1),
      [w, C] = e.useState("")
    e.useEffect(() => {
      $(W.SHOW_TRACE_IDS).then((e) => {
        void 0 !== e && x(e)
      })
    }, []),
      e.useEffect(() => {
        $(W.SHOW_SYSTEM_REMINDERS).then((e) => {
          void 0 !== e && v(e)
        })
      }, []),
      e.useEffect(() => {
        t && !a.includes(t) && (b(!0), C(t))
      }, [t, a])
    return o.jsxs("div", {
      className: "max-w-2xl",
      children: [
        o.jsx("h2", {
          className: "font-xl-bold text-text-100 mb-4",
          children: "Model & Prompt Configuration",
        }),
        o.jsxs("div", {
          className: "space-y-6",
          children: [
            o.jsxs("div", {
              className: "space-y-4",
              children: [
                o.jsx("h3", {
                  className: "font-large-bold text-text-100",
                  children: "Model Selection",
                }),
                o.jsxs("div", {
                  children: [
                    o.jsx("div", {
                      className: "mb-2",
                      children: o.jsx("label", {
                        htmlFor: "modelSelect",
                        className: "font-label block text-text-200",
                        children: "Choose Claude Model",
                      }),
                    }),
                    o.jsx("select", {
                      id: "modelSelect",
                      value: y ? "__custom__" : t,
                      onChange: (e) => {
                        const t = e.target.value
                        "__custom__" === t ? (b(!0), n(w)) : (b(!1), n(t))
                      },
                      disabled: 0 === a.length,
                      className:
                        "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-200 disabled:text-text-400 bg-bg-000 text-text-100 font-base",
                      children:
                        a.length > 0
                          ? [
                              ...a.map((e) =>
                                o.jsx("option", { value: e, children: e }, e)
                              ),
                              o.jsx(
                                "option",
                                {
                                  value: "__custom__",
                                  children: "Enter custom model...",
                                },
                                "__custom__"
                              ),
                            ]
                          : null,
                    }),
                    y &&
                      o.jsxs("div", {
                        className: "mt-3",
                        children: [
                          o.jsx("label", {
                            htmlFor: "customModel",
                            className: "font-label block mb-2 text-text-200",
                            children: "Custom Model Name",
                          }),
                          o.jsx("input", {
                            id: "customModel",
                            type: "text",
                            value: w,
                            onChange: (e) => {
                              C(e.target.value), n(e.target.value)
                            },
                            placeholder: "e.g., claude-3-5-sonnet-20241022",
                            className:
                              "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                          }),
                        ],
                      }),
                    o.jsx("p", {
                      className: "mt-2 font-caption text-text-300",
                      children: y
                        ? "Enter a custom model identifier"
                        : "Select from models available to you",
                    }),
                  ],
                }),
                o.jsx("button", {
                  onClick: l,
                  disabled: !t,
                  className:
                    "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-400 disabled:cursor-not-allowed font-button-lg",
                  children: "Save Model Selection",
                }),
              ],
            }),
            h && o.jsx("div", { className: "border-t border-border-300" }),
            h &&
              o.jsxs("div", {
                className: "space-y-4",
                children: [
                  o.jsx("h3", {
                    className: "font-large-bold text-text-100",
                    children: "System Prompt",
                  }),
                  o.jsxs("div", {
                    children: [
                      o.jsx("label", {
                        htmlFor: "systemPrompt",
                        className: "font-label block mb-2 text-text-200",
                        children: "Customize System Prompt",
                      }),
                      o.jsx("textarea", {
                        id: "systemPrompt",
                        value: r,
                        onChange: (e) => s(e.target.value),
                        placeholder: "Enter custom system prompt...",
                        className:
                          "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-code bg-bg-000 text-text-100",
                        rows: 12,
                      }),
                      o.jsx("p", {
                        className: "mt-2 font-caption text-text-300",
                        children:
                          "Customize the instructions given to Claude for browser automation tasks.",
                      }),
                    ],
                  }),
                  o.jsxs("div", {
                    className: "flex gap-3",
                    children: [
                      o.jsx("button", {
                        onClick: d,
                        className:
                          "flex-1 bg-text-100 text-oncolor-100 py-2 px-4 rounded-md hover:bg-text-200 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
                        children: "Save System Prompt",
                      }),
                      o.jsx("button", {
                        onClick: u,
                        className:
                          "px-4 py-2 border border-border-200 rounded-md hover:bg-bg-200 focus:outline-none focus:ring-2 focus:ring-border-100 text-text-200 font-button",
                        children: "Reset to Default",
                      }),
                    ],
                  }),
                ],
              }),
            o.jsx("div", { className: "border-t border-border-300" }),
            o.jsxs("div", {
              className: "space-y-4",
              children: [
                o.jsxs("h3", {
                  className:
                    "font-large-bold text-text-100 flex items-center gap-2",
                  children: [
                    o.jsx(xe, { className: "w-5 h-5" }),
                    "(Ant-only) Debug Settings",
                  ],
                }),
                o.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    o.jsxs("label", {
                      className: "flex items-center gap-3 cursor-pointer",
                      children: [
                        o.jsx("input", {
                          type: "checkbox",
                          checked: i,
                          onChange: (e) =>
                            (async (e) => {
                              c(e),
                                await U(W.DEBUG_MODE, e),
                                p(!0),
                                setTimeout(() => p(!1), 2e3)
                            })(e.target.checked),
                          className:
                            "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                        }),
                        o.jsxs("div", {
                          children: [
                            o.jsx("p", {
                              className: "font-base text-text-100",
                              children: "Show tool result details",
                            }),
                            o.jsx("p", {
                              className: "font-caption text-text-300",
                              children:
                                "Enable expandable tool result blocks to view parameters and outputs",
                            }),
                          ],
                        }),
                      ],
                    }),
                    o.jsxs("label", {
                      className: "flex items-center gap-3 cursor-pointer",
                      children: [
                        o.jsx("input", {
                          type: "checkbox",
                          checked: f,
                          onChange: (e) =>
                            (async (e) => {
                              x(e),
                                await U(W.SHOW_TRACE_IDS, e),
                                p(!0),
                                setTimeout(() => p(!1), 2e3)
                            })(e.target.checked),
                          className:
                            "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                        }),
                        o.jsxs("div", {
                          children: [
                            o.jsx("p", {
                              className: "font-base text-text-100",
                              children: "Show trace IDs",
                            }),
                            o.jsx("p", {
                              className: "font-caption text-text-300",
                              children:
                                "Display trace IDs at the beginning of each response stream",
                            }),
                          ],
                        }),
                      ],
                    }),
                    o.jsxs("label", {
                      className: "flex items-center gap-3 cursor-pointer",
                      children: [
                        o.jsx("input", {
                          type: "checkbox",
                          checked: g,
                          onChange: (e) =>
                            (async (e) => {
                              v(e),
                                await U(W.SHOW_SYSTEM_REMINDERS, e),
                                p(!0),
                                setTimeout(() => p(!1), 2e3)
                            })(e.target.checked),
                          className:
                            "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                        }),
                        o.jsxs("div", {
                          children: [
                            o.jsx("p", {
                              className: "font-base text-text-100",
                              children: "Show system reminders",
                            }),
                            o.jsx("p", {
                              className: "font-caption text-text-300",
                              children:
                                "Display system reminder tags for debugging tab context changes",
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            m &&
              o.jsx("div", {
                className: "font-base-sm text-text-200",
                children: "Settings saved successfully!",
              }),
          ],
        }),
      ],
    })
  },
  Ja = () => {
    const [t, n] = e.useState(""),
      { sendNotification: a } = F(),
      r = s.useRef(null)
    s.useEffect(
      () => () => {
        r.current && clearTimeout(r.current)
      },
      []
    )
    const i = (e, t, n) => ({
        role: "assistant",
        content: e,
        id: `msg_staging_${Math.random().toString(36).substring(2, 11)}`,
        model: "claude-sonnet-4-20250514",
        stop_reason: n ? "tool_use" : "end_turn",
        stop_sequence: null,
        type: "message",
        usage: {
          input_tokens: t.input,
          output_tokens: t.output,
          cache_creation_input_tokens: t.cacheCreation || 0,
          cache_read_input_tokens: t.cacheRead || 0,
        },
      }),
      c = async (e, t) => {
        try {
          await U(W.TEST_DATA_MESSAGES, t),
            n(`Loaded ${e} - Reload the side panel to use`),
            r.current && clearTimeout(r.current),
            (r.current = setTimeout(() => n(""), 3e3))
        } catch (a) {
          n(`Error loading test data: ${a}`)
        }
      }
    return o.jsxs("div", {
      className: "space-y-6",
      children: [
        o.jsxs("div", {
          children: [
            o.jsx("h2", {
              className: "text-lg font-medium text-text-100 mb-4",
              children: "Development Testing Tools",
            }),
            o.jsx("p", {
              className: "text-sm text-text-300 mb-6",
              children:
                "Tools for testing and debugging the extension during development.",
            }),
          ],
        }),
        o.jsxs("div", {
          className: "space-y-4",
          children: [
            o.jsx("h3", {
              className: "text-md font-medium text-text-100 mb-3",
              children: "Test Conversations",
            }),
            o.jsxs("div", {
              className: "flex flex-wrap gap-3",
              children: [
                o.jsx("button", {
                  onClick: () => {
                    const e = [
                      {
                        role: "user",
                        content: [
                          { type: "text", text: "what's on the screen?" },
                        ],
                      },
                      i(
                        [
                          {
                            type: "text",
                            text: "I'll take a screenshot to see what's currently on the screen.",
                          },
                        ],
                        { input: 147, output: 66, cacheCreation: 10234 }
                      ),
                    ]
                    c("Simple Conversation", e)
                  },
                  className:
                    "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                  children: "Load Simple Conversation",
                }),
                o.jsx("button", {
                  onClick: () => {
                    const e = []
                    for (let t = 0; t < 50; t++)
                      e.push({
                        role: "user",
                        content: [
                          {
                            type: "text",
                            text: `Question ${t + 1}: Tell me about item ${
                              t + 1
                            }`,
                          },
                        ],
                      }),
                        e.push(
                          i(
                            [
                              {
                                type: "text",
                                text: `Here's information about item ${
                                  t + 1
                                }. `.repeat(50),
                              },
                            ],
                            {
                              input: 2e3 + 100 * t,
                              output: 500,
                              cacheRead: 1e3,
                            }
                          )
                        )
                    c("Long Conversation", e)
                  },
                  className:
                    "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                  children: "Load Long Conversation",
                }),
                o.jsx("button", {
                  onClick: () => {
                    const e = [],
                      t =
                        "This is a test message that simulates a long conversation. ".repeat(
                          1e3
                        ),
                      n = Math.floor(72e4 / (2 * t.length))
                    for (let r = 0; r < n; r++)
                      e.push({
                        role: "user",
                        content: [
                          { type: "text", text: `Question ${r + 1}: ${t}` },
                        ],
                      }),
                        e.push(
                          i(
                            [{ type: "text", text: `Response ${r + 1}: ${t}` }],
                            {
                              input: 1e4 + 500 * r,
                              output: 5e3 + 100 * r,
                              cacheRead: 2e3,
                            }
                          )
                        )
                    const a = e[e.length - 1]
                    a &&
                      "usage" in a &&
                      a.usage &&
                      ((a.usage.input_tokens = 10),
                      (a.usage.cache_creation_input_tokens = 15e4),
                      (a.usage.cache_read_input_tokens = 3e4),
                      (a.usage.output_tokens = 5e3)),
                      c("Near Context Limit", e)
                  },
                  className:
                    "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                  children: "Load Near Context Limit",
                }),
                o.jsx("button", {
                  onClick: () => {
                    const e = [
                      {
                        role: "user",
                        content: [
                          {
                            type: "text",
                            text: "Navigate to google.com and search for 'weather'",
                          },
                        ],
                      },
                      i(
                        [
                          {
                            type: "text",
                            text: "I'll navigate to Google and search for weather information.",
                          },
                          {
                            type: "tool_use",
                            id: "toolu_01_navigate",
                            name: "navigate",
                            input: { url: "https://google.com" },
                          },
                        ],
                        { input: 200, output: 100, cacheCreation: 5e3 },
                        !0
                      ),
                      {
                        role: "user",
                        content: [
                          {
                            type: "tool_result",
                            tool_use_id: "toolu_01_navigate",
                            content: "Navigated to google.com",
                          },
                        ],
                      },
                      i(
                        [
                          {
                            type: "text",
                            text: "Now I'll search for 'weather' on Google.",
                          },
                          {
                            type: "tool_use",
                            id: "toolu_02_type",
                            name: "computer",
                            input: { action: "type", text: "weather" },
                          },
                        ],
                        { input: 300, output: 150, cacheRead: 4e3 },
                        !0
                      ),
                    ]
                    c("Tool Use Conversation", e)
                  },
                  className:
                    "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                  children: "Load Tool Use Conversation",
                }),
                o.jsx("button", {
                  onClick: async () => {
                    try {
                      await chrome.storage.local.remove("test_data_messages"),
                        n("Test data cleared"),
                        r.current && clearTimeout(r.current),
                        (r.current = setTimeout(() => n(""), 3e3))
                    } catch (e) {
                      n(`Error clearing test data: ${e}`)
                    }
                  },
                  className:
                    "px-4 py-2 bg-danger-100 text-oncolor-100 rounded hover:bg-danger-200 transition-colors",
                  children: "Clear Test Data",
                }),
              ],
            }),
          ],
        }),
        o.jsxs("div", {
          className: "space-y-4",
          children: [
            o.jsx("h3", {
              className: "text-md font-medium text-text-100 mb-3",
              children: "Test Notifications",
            }),
            o.jsxs("div", {
              className: "flex flex-wrap gap-3",
              children: [
                o.jsx("button", {
                  onClick: () => {
                    a({
                      title: "Claude had to pause",
                      body: "Your permission is needed to continue",
                    }),
                      n("Sent permission notification"),
                      r.current && clearTimeout(r.current),
                      (r.current = setTimeout(() => n(""), 3e3))
                  },
                  className:
                    "px-4 py-2 bg-accent-secondary-100 text-oncolor-100 rounded hover:bg-accent-secondary-200 transition-colors",
                  children: "Test Permission Notification",
                }),
                o.jsx("button", {
                  onClick: () => {
                    a({
                      title: "Claude is done",
                      body: "Your task is completed. Ready to check in?",
                    }),
                      n("Sent completion notification"),
                      r.current && clearTimeout(r.current),
                      (r.current = setTimeout(() => n(""), 3e3))
                  },
                  className:
                    "px-4 py-2 bg-accent-secondary-100 text-oncolor-100 rounded hover:bg-accent-secondary-200 transition-colors",
                  children: "Test Completion Notification",
                }),
              ],
            }),
            t &&
              o.jsx("div", {
                className: "mt-4 p-3 bg-bg-200 rounded text-sm text-text-200",
                children: t,
              }),
          ],
        }),
        o.jsxs("div", {
          className: "mt-6 p-4 bg-bg-200 rounded",
          children: [
            o.jsx("h3", {
              className: "text-sm font-medium text-text-200 mb-2",
              children: "How it works:",
            }),
            o.jsxs("ul", {
              className: "text-sm text-text-300 space-y-1",
              children: [
                o.jsx("li", {
                  children: "• Test data is saved to chrome.storage.local",
                }),
                o.jsx("li", {
                  children:
                    "• The side panel reads this data on initialization",
                }),
                o.jsx("li", {
                  children: "• No direct manipulation of message state",
                }),
                o.jsx("li", {
                  children: "• Reload the side panel after loading test data",
                }),
              ],
            }),
          ],
        }),
      ],
    })
  },
  Qa = ({ children: e, isActive: t, onClick: n }) =>
    o.jsx("button", {
      onClick: n,
      className: c(
        "block w-full text-left whitespace-nowrap transition-all ease-in-out active:scale-95 cursor-pointer",
        "font-base rounded-lg px-3 py-3",
        t
          ? "bg-bg-300 font-medium text-text-000"
          : "text-text-200 hover:bg-bg-200 hover:text-text-100"
      ),
      children: e,
    }),
  er = ({ children: e, className: t, narrow: n }) =>
    o.jsx("main", {
      className: c(
        "mx-auto mt-4 w-full flex-1 px-4 md:pl-8 lg:mt-6",
        n ? "max-w-4xl" : "max-w-7xl",
        t
      ),
      children: e,
    }),
  tr = ({
    children: e,
    className: t,
    contentClassName: n,
    sticky: a,
    fixed: r,
    mdTitle: s,
    large: i,
    narrow: l,
  }) => {
    const d = !e && !s,
      u = i
    return o.jsx("header", {
      className: c(
        "flex w-full bg-bg-100",
        a && "sticky top-0 z-50",
        r && "fixed top-0 z-50",
        "h-12",
        u && ["mx-auto md:h-24 md:items-end", l ? "max-w-4xl" : "max-w-7xl"],
        t
      ),
      "aria-hidden": d,
      children: o.jsx("div", {
        className: c(
          "flex w-full items-center justify-between gap-4",
          "pl-11 lg:pl-8",
          n,
          u ? "px-4 md:pl-8" : "pr-3"
        ),
        children: s
          ? o.jsxs(o.Fragment, {
              children: [
                o.jsx("h1", {
                  className: c(
                    "text-text-200 flex items-center gap-2 max-md:hidden min-w-0",
                    "font-heading",
                    u ? "text-2xl" : "text-lg"
                  ),
                  children: o.jsx("span", {
                    className: "truncate",
                    children: s,
                  }),
                }),
                o.jsx("div", {}),
                e,
              ],
            })
          : e,
      }),
    })
  }
function nr() {
  const { userProfile: t, isAuthenticated: n } = I(),
    { resetAnalytics: r } = P(),
    { value: s } = a.useFeatureGate("chrome_scheduled_tasks"),
    { value: i } = a.useFeatureGate("chrome_extension_show_user_email"),
    { value: c } = a.useFeatureGate("crochet_default_debug_mode"),
    { value: l } = a.useFeatureGate("chrome_ext_allow_api_key"),
    { value: d } = a.useFeatureGate("chrome_ext_edit_system_prompt"),
    [u, m] = e.useState(""),
    [apiBaseUrl, setApiBaseUrl] = e.useState(""),
    [p, h] = e.useState(""),
    [f, x] = e.useState(!1),
    [g, v] = e.useState("permissions"),
    [y, b] = e.useState([]),
    [w, C] = e.useState(""),
    [j, M] = e.useState(!1),
    E = a.useDynamicConfig("chrome_ext_models").value,
    { value: N } = a.useDynamicConfig("crochet_settings_subtitle"),
    k = N?.subtitle
  e.useEffect(() => {
    Y([
      W.ANTHROPIC_API_KEY,
      W.SELECTED_MODEL,
      W.SYSTEM_PROMPT,
      W.DEBUG_MODE,
    ]).then((e) => {
      e[W.ANTHROPIC_API_KEY] && m(e[W.ANTHROPIC_API_KEY]),
        e[W.SELECTED_MODEL] && h(e[W.SELECTED_MODEL]),
        e[W.SYSTEM_PROMPT] && C(e[W.SYSTEM_PROMPT]),
        void 0 !== e[W.DEBUG_MODE] ? M(e[W.DEBUG_MODE]) : M(c || !1)
    });
    setApiBaseUrl(localStorage.getItem("apiBaseUrl"))
  }, [c]),
    e.useEffect(() => {
      const e = () => {
          const e = window.location.hash.slice(1)
          return [
            "api",
            "permissions",
            "model",
            "scheduled",
            "prompts",
            "testdata",
          ].includes(e)
            ? e
            : "permissions"
        },
        t = () => {
          v(e())
        }
      return (
        v(e()),
        window.addEventListener("hashchange", t),
        () => {
          window.removeEventListener("hashchange", t)
        }
      )
    }, [])
  const _ = (e) => {
    v(e), (window.location.hash = e)
  }
  e.useEffect(() => {
    U(W.SCHEDULED_TASKS_ENABLED, s)
  }, [s]),
    e.useEffect(() => {
      E.options && b(E.options)
    }, [E.options])
  return o.jsxs(o.Fragment, {
    children: [
      o.jsxs(tr, {
        large: !0,
        mdTitle:
          n || u
            ? o.jsxs("div", {
                className: "flex flex-col pl-3",
                children: [
                  o.jsx("span", { children: "Claude for Chrome settings" }),
                  k &&
                    o.jsx("span", {
                      className:
                        "font-claude-response-small text-text-500 mt-0.5",
                      children: k,
                    }),
                ],
              })
            : void 0,
        sticky: !0,
        children: [
          n &&
            t &&
            i &&
            o.jsxs("div", {
              className:
                "flex items-center gap-2 px-3 py-2 bg-bg-000 border border-border-200 rounded-lg",
              children: [
                o.jsx(ve, { className: "w-4 h-4 text-text-300" }),
                o.jsx("span", {
                  className: "font-base-sm text-text-200",
                  children: t.account.email,
                }),
              ],
            }),
          !n &&
            u &&
            o.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                o.jsxs("div", {
                  className:
                    "flex items-center gap-2 px-3 py-2 bg-bg-000 border border-border-200 rounded-lg",
                  children: [
                    o.jsx(ve, { className: "w-4 h-4 text-text-300" }),
                    o.jsx("span", {
                      className: "font-base-sm text-text-200",
                      children: "API Key Mode",
                    }),
                  ],
                }),
                o.jsx("button", {
                  onClick: async () => {
                    try {
                      await q()
                    } catch (e) {}
                  },
                  className:
                    "px-3 py-2 bg-accent-main-100 text-oncolor-100 rounded-lg font-base-sm hover:bg-accent-main-200 transition-colors",
                  children: "Login",
                }),
              ],
            }),
        ],
      }),
      o.jsxs(er, {
        children: [
          o.jsxs("div", {
            className: "mb-4 md:hidden pl-3",
            children: [
              o.jsx("h1", {
                className:
                  "font-heading text-text-200 flex items-center gap-1.5",
                children: "Settings",
              }),
              k &&
                o.jsx("p", {
                  className: "font-claude-response-small text-text-500 mt-1",
                  children: k,
                }),
            ],
          }),
          n || u
            ? o.jsxs("div", {
                className:
                  "grid md:grid-cols-[220px_minmax(0px,_1fr)] gap-x-8 w-full max-w-6xl my-4 md:my-8",
                children: [
                  o.jsxs("nav", {
                    className:
                      "w-full overflow-x-auto -m-2 p-2 self-start md:sticky md:top-4 relative z-10 mb-4 md:mb-0",
                    children: [
                      o.jsxs("ul", {
                        className: "flex gap-1 md:flex-col mb-0",
                        children: [
                          l &&
                            o.jsx("li", {
                              children: o.jsx(Qa, {
                                href: "/settings/api",
                                isActive: "api" === g,
                                onClick: () => _("api"),
                                children: "API configuration (internal)",
                              }),
                            }),
                          l &&
                            o.jsx("li", {
                              children: o.jsx(Qa, {
                                href: "/settings/model",
                                isActive: "model" === g,
                                onClick: () => _("model"),
                                children: "Model selection (internal)",
                              }),
                            }),
                          o.jsx("li", {
                            children: o.jsx(Qa, {
                              href: "/settings/permissions",
                              isActive: "permissions" === g,
                              onClick: () => _("permissions"),
                              children: "Permissions",
                            }),
                          }),
                          o.jsx("li", {
                            children: o.jsx(Qa, {
                              href: "/settings/prompts",
                              isActive: "prompts" === g,
                              onClick: () => _("prompts"),
                              children: "Shortcuts",
                            }),
                          }),
                          l &&
                            o.jsx("li", {
                              children: o.jsx(Qa, {
                                href: "/settings/testdata",
                                isActive: "testdata" === g,
                                onClick: () => _("testdata"),
                                children: "Dev Testing (Internal)",
                              }),
                            }),
                        ],
                      }),
                      n &&
                        o.jsx(o.Fragment, {
                          children: o.jsx("div", {
                            className:
                              "mt-8 pt-8 border-t-[0.5px] border-border-300",
                            children: o.jsxs("button", {
                              onClick: async () => {
                                try {
                                  await chrome.runtime.sendMessage({
                                    type: "logout",
                                  }),
                                    await r(),
                                    window.location.reload()
                                } catch (e) {
                                  alert("Failed to logout. Please try again.")
                                }
                              },
                              className:
                                "w-full flex items-center gap-2 px-3 py-3 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                              children: [
                                o.jsx(ge, { className: "w-4 h-4" }),
                                "Logout",
                              ],
                            }),
                          }),
                        }),
                    ],
                  }),
                  o.jsxs("div", {
                    children: [
                      "api" === g &&
                        l &&
                        o.jsx(qa, {
                          apiKey: u,
                          setApiKey: m,
                          apiBaseUrl,
                          setApiBaseUrl,
                          onSave: async () => {
                            localStorage.setItem('apiBaseUrl', apiBaseUrl);
                            await U(W.ANTHROPIC_API_KEY, u),
                              x(!0),
                              setTimeout(() => x(!1), 2e3)
                          },
                          saved: f,
                        }),
                      "model" === g &&
                        l &&
                        o.jsx(Xa, {
                          selectedModel: p,
                          setSelectedModel: h,
                          availableModels: y,
                          systemPrompt: w,
                          setSystemPrompt: C,
                          debugMode: j,
                          setDebugMode: M,
                          onModelSave: async () => {
                            await U(W.SELECTED_MODEL, p),
                              x(!0),
                              setTimeout(() => x(!1), 2e3)
                          },
                          onPromptSave: async () => {
                            await U(W.SYSTEM_PROMPT, w),
                              x(!0),
                              setTimeout(() => x(!1), 2e3)
                          },
                          onResetPrompt: () => {
                            C("")
                          },
                          saved: f,
                          setSaved: x,
                          allowEditSystemPrompt: d,
                        }),
                      "permissions" === g && o.jsx(ye, {}),
                      "prompts" === g && o.jsx($a, {}),
                      "testdata" === g && l && o.jsx(Ja, {}),
                    ],
                  }),
                ],
              })
            : o.jsx("div", {
                className:
                  "flex flex-col items-center justify-center min-h-[400px]",
                children: o.jsx(O, {}),
              }),
        ],
      }),
    ],
  })
}
X(),
  K(),
  B.createRoot(document.getElementById("root")).render(
    o.jsx(s.StrictMode, {
      children: o.jsx(z, { pageName: "Options", children: o.jsx(nr, {}) }),
    })
  )
