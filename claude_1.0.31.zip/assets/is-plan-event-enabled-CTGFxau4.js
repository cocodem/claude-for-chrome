function l(l,e){var n,o;return"boolean"==typeof(null==e?void 0:e.enabled)?e.enabled:null===(o=null===(n=null==l?void 0:l.__default)||void 0===n?void 0:n.enabled)||void 0===o||o}export{l as i};
