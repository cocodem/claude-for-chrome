import {
    i as e,
    j as t,
    f as a,
    s,
    S as n,
    k as r,
    l as i,
} from "./SentryService-D1JZ-Jmf.js";
async function o(e) {
    chrome.sidePanel.setOptions({
        tabId: e,
        path: `sidepanel.html?tabId=${encodeURIComponent(e)}`,
        enabled: !0,
    }),
        chrome.sidePanel.open({ tabId: e });
}
async function c(e) {
    try {
        await chrome.tabs.sendMessage(e, { type: "HIDE_AGENT_INDICATORS" });
    } catch (t) {}
}
async function d(e) {
    const t = e.id;
    t && (await o(t));
}
e(),
    chrome.runtime.onInstalled.addListener((e) => {
        chrome.storage.local.remove(["updateAvailable"]),
            t(),
            e.reason === chrome.runtime.OnInstalledReason.INSTALL && a();
    }),
    chrome.runtime.onStartup.addListener(() => {
        t();
    }),
    chrome.action.onClicked.addListener(d),
    chrome.commands.onCommand.addListener((e) => {
        "toggle-side-panel" === e &&
            chrome.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
                const t = e[0];
                t && d(t);
            });
    }),
    chrome.runtime.onUpdateAvailable.addListener((e) => {
        s(n.UPDATE_AVAILABLE, !0);
    }),
    chrome.runtime.onMessage.addListener(
        (e, a, s) => (
            (async () => {
                if ("open_side_panel" === e.type) {
                    const t = e.tabId || a.tab?.id;
                    if (!t) return void s({ success: !1 });
                    if ((await o(t), e.prompt)) {
                        const t = async (a = 0) => {
                            try {
                                await new Promise((t, a) => {
                                    chrome.runtime.sendMessage(
                                        {
                                            type: "POPULATE_INPUT_TEXT",
                                            prompt: e.prompt,
                                        },
                                        () => {
                                            chrome.runtime.lastError
                                                ? a(
                                                      new Error(
                                                          chrome.runtime.lastError.message
                                                      )
                                                  )
                                                : t();
                                        }
                                    );
                                });
                            } catch (s) {
                                a < 3 &&
                                    (await new Promise((e) =>
                                        setTimeout(e, 500)
                                    ),
                                    await t(a + 1));
                            }
                        };
                        await t();
                    }
                    return void s({ success: !0 });
                }
                if ("resize_window" === e.type)
                    try {
                        const e = await chrome.windows.getCurrent(),
                            t = Math.min(e.width || 1366, 1366),
                            a = Math.min(e.height || 768, 768);
                        e.id &&
                            (await chrome.windows.update(e.id, {
                                width: t,
                                height: a,
                            })),
                            s({ success: !0 });
                    } catch (n) {
                        s({ success: !1, error: n.message });
                    }
                else if ("side_panel_closed" === e.type) {
                    const { tabId: t } = e;
                    await c(t), s({ success: !0 });
                } else if ("logout" === e.type)
                    try {
                        await r(), await t(), s({ success: !0 });
                    } catch (n) {}
            })(),
            !0
        )
    ),
    chrome.tabs.onRemoved.addListener(async (e) => {
        await c(e);
    }),
    chrome.runtime.onMessageExternal.addListener(
        (e, t, a) => (
            (async () => {
                if ("oauth_redirect" === e.type) {
                    const s = await i(e.redirect_uri, t?.tab?.id);
                    a(s);
                } else
                    "ping" === e.type
                        ? a({ success: !0, exists: !0 })
                        : "onboarding_task" === e.type &&
                          (chrome.runtime.sendMessage({
                              type: "POPULATE_INPUT_TEXT",
                              prompt: e.payload?.prompt,
                          }),
                          a({ success: !0 }));
            })(),
            !0
        )
    );
