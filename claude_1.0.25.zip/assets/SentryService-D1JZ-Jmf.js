import './request.js'

var e =
    "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
        ? self
        : {};
function t(e) {
    return e &&
        e.__esModule &&
        Object.prototype.hasOwnProperty.call(e, "default")
        ? e.default
        : e;
}
function n(e) {
    if (Object.prototype.hasOwnProperty.call(e, "__esModule")) return e;
    var t = e.default;
    if ("function" == typeof t) {
        var n = function e() {
            var n = !1;
            try {
                n = this instanceof e;
            } catch {}
            return n
                ? Reflect.construct(t, arguments, this.constructor)
                : t.apply(this, arguments);
        };
        n.prototype = t.prototype;
    } else n = {};
    return (
        Object.defineProperty(n, "__esModule", { value: !0 }),
        Object.keys(e).forEach(function (t) {
            var r = Object.getOwnPropertyDescriptor(e, t);
            Object.defineProperty(
                n,
                t,
                r.get
                    ? r
                    : {
                          enumerable: !0,
                          get: function () {
                              return e[t];
                          },
                      }
            );
        }),
        n
    );
}
var r = ((e) => (
    (e.ACCESS_TOKEN = "accessToken"),
    (e.REFRESH_TOKEN = "refreshToken"),
    (e.TOKEN_EXPIRY = "tokenExpiry"),
    (e.OAUTH_STATE = "oauthState"),
    (e.CODE_VERIFIER = "codeVerifier"),
    (e.ANTHROPIC_API_KEY = "anthropicApiKey"),
    (e.SELECTED_MODEL = "selectedModel"),
    (e.SYSTEM_PROMPT = "systemPrompt"),
    (e.DEBUG_MODE = "debugMode"),
    (e.BROWSER_CONTROL_PERMISSION_ACCEPTED =
        "browserControlPermissionAccepted"),
    (e.PERMISSION_STORAGE = "permissionStorage"),
    (e.SKIP_ALL_PERMISSIONS = "skipAllPermissions"),
    (e.SKIP_ALL_PERMISSIONS_CLICKED = "skipAllPermissionsClicked"),
    (e.ANONYMOUS_ID = "anonymousId"),
    (e.SCHEDULED_TASKS = "scheduledTasks"),
    (e.SCHEDULED_TASKS_ENABLED = "scheduledTasksEnabled"),
    (e.SCHEDULED_TASKS_PRELOADED = "scheduledTasksPreloaded"),
    (e.TEST_SCHEDULED_TASK = "testScheduledTask"),
    (e.TASK_RUN_LOGS = "taskRunLogs"),
    (e.TASK_RUN_STATS = "taskRunStats"),
    (e.SCHEDULED_TASK_LOGS = "scheduledTaskLogs"),
    (e.SCHEDULED_TASK_STATS = "scheduledTaskStats"),
    (e.TARGET_TAB_ID = "targetTabId"),
    (e.UPDATE_AVAILABLE = "updateAvailable"),
    (e.TIP_DISPLAY_COUNTS = "tipDisplayCounts"),
    e
))(r || {});
async function s(e) {
    return (await chrome.storage.local.get(e))[e];
}
async function o(e, t) {
    await chrome.storage.local.set({ [e]: t });
}
async function i(e) {
    const t = Array.isArray(e) ? e : [e];
    await chrome.storage.local.remove(t);
}
async function a(e) {
    return await chrome.storage.local.get(e);
}
async function c(e) {
    await chrome.storage.local.set(e);
}
const u = new Set(["anonymousId", "updateAvailable"]);
async function l() {
    const e = Object.values(r).filter((e) => !u.has(e));
    await i(e);
}
const d = {
        production: {
            STATSIG_CLIENT_API_KEY:
                "client-CyitfCoKlr6QZ2BXVfDZ3aDIE2fvWh4DTd4CIegPYQ8",
            SEGMENT_WRITE_KEY: "H7hVDRIBUrlBySLqJ15oAivgqhomdAKT",
        },
        development: {
            STATSIG_CLIENT_API_KEY:
                "client-FFBic9L5QkZYsnRDrIAvTimKS998hznw31H6KPBciH8",
            SEGMENT_WRITE_KEY: "hNex10EGp3coubOXQI1BIElYaZcA1o0u",
        },
    },
    f = {
        AUTHORIZE_URL: "https://claude.ai/oauth/authorize",
        TOKEN_URL: "https://console.anthropic.com/v1/oauth/token",
        SCOPES_STR: "user:profile user:inference",
        CLIENT_ID: "54511e87-7abf-4923-9d84-d6f24532e871",
        REDIRECT_URI:
            "chrome-extension://dihbgbndebgnbjfmelmegjepbnkhlgni/oauth_callback.html",
    },
    h = {
        development: f,
        production: {
            ...f,
            CLIENT_ID: "dae2cad8-15c5-43d2-9046-fcaecc135fa4",
            REDIRECT_URI:
                "chrome-extension://fcoeoabgfenejglbffodgkkbkcdhcgfn/oauth_callback.html",
        },
    },
    p = () => {
        const e = "production",
            t = d[e],
            n = h[e];
        return {
            environment: e,
            apiBaseUrl:
                globalThis.localStorage?.getItem("apiBaseUrl") ||
                "https://api.anthropic.com",
            statsigClientApiKey: t.STATSIG_CLIENT_API_KEY,
            segmentWriteKey: t.SEGMENT_WRITE_KEY,
            oauth: n,
        };
    };
var _,
    g,
    v = {},
    m = {},
    y = {},
    b = {};
function E() {
    return (
        _ ||
            ((_ = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Log = e.LogLevel = void 0);
                e.LogLevel = { None: 0, Error: 1, Warn: 2, Info: 3, Debug: 4 };
                class t {
                    static info(...n) {
                        t.level, e.LogLevel.Info;
                    }
                    static debug(...n) {
                        t.level, e.LogLevel.Debug;
                    }
                    static warn(...n) {
                        t.level, e.LogLevel.Warn;
                    }
                    static error(...n) {
                        t.level, e.LogLevel.Error;
                    }
                }
                (e.Log = t), (t.level = e.LogLevel.Warn);
            })(b)),
        b
    );
}
function S() {
    return (
        g ||
            ((g = 1),
            (function (t) {
                var n, r, s;
                Object.defineProperty(t, "__esModule", { value: !0 }),
                    (t._getInstance =
                        t._getStatsigGlobalFlag =
                        t._getStatsigGlobal =
                            void 0);
                const o = E();
                t._getStatsigGlobal = () => {
                    try {
                        return "undefined" != typeof __STATSIG__
                            ? __STATSIG__
                            : l;
                    } catch (e) {
                        return l;
                    }
                };
                t._getStatsigGlobalFlag = (e) => (0, t._getStatsigGlobal)()[e];
                t._getInstance = (e) => {
                    const n = (0, t._getStatsigGlobal)();
                    return e
                        ? n.instances && n.instances[e]
                        : (n.instances &&
                              Object.keys(n.instances).length > 1 &&
                              o.Log.warn(
                                  "Call made to Statsig global instance without an SDK key but there is more than one client instance. If you are using mulitple clients, please specify the SDK key."
                              ),
                          n.firstInstance);
                };
                const i = "__STATSIG__",
                    a = "undefined" != typeof window ? window : {},
                    c = void 0 !== e ? e : {},
                    u = "undefined" != typeof globalThis ? globalThis : {},
                    l =
                        null !==
                            (s =
                                null !==
                                    (r =
                                        null !== (n = a[i]) && void 0 !== n
                                            ? n
                                            : c[i]) && void 0 !== r
                                    ? r
                                    : u[i]) && void 0 !== s
                            ? s
                            : { instance: t._getInstance };
                (a[i] = l), (c[i] = l), (u[i] = l);
            })(y)),
        y
    );
}
var k,
    w = {};
function x() {
    return (
        k ||
            ((k = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Diagnostics = void 0);
                const t = new Map(),
                    n = "start",
                    r = "end",
                    s = "statsig::diagnostics";
                function o(e, t, n, r) {
                    return Object.assign(
                        { key: n, action: t, step: r, timestamp: Date.now() },
                        e
                    );
                }
                function i(e, n) {
                    var r;
                    const s = null !== (r = t.get(e)) && void 0 !== r ? r : [];
                    s.push(n), t.set(e, s);
                }
                function a(e, t) {
                    if (t in e) return e[t];
                }
                e.Diagnostics = {
                    _getMarkers: (e) => t.get(e),
                    _markInitOverallStart: (e) => {
                        i(e, o({}, n, "overall"));
                    },
                    _markInitOverallEnd: (e, t, n) => {
                        i(
                            e,
                            o(
                                {
                                    success: t,
                                    error: t
                                        ? void 0
                                        : {
                                              name: "InitializeError",
                                              message: "Failed to initialize",
                                          },
                                    evaluationDetails: n,
                                },
                                r,
                                "overall"
                            )
                        );
                    },
                    _markInitNetworkReqStart: (e, t) => {
                        i(e, o(t, n, "initialize", "network_request"));
                    },
                    _markInitNetworkReqEnd: (e, t) => {
                        i(e, o(t, r, "initialize", "network_request"));
                    },
                    _markInitProcessStart: (e) => {
                        i(e, o({}, n, "initialize", "process"));
                    },
                    _markInitProcessEnd: (e, t) => {
                        i(e, o(t, r, "initialize", "process"));
                    },
                    _clearMarkers: (e) => {
                        t.delete(e);
                    },
                    _formatError(e) {
                        if (e && "object" == typeof e)
                            return {
                                code: a(e, "code"),
                                name: a(e, "name"),
                                message: a(e, "message"),
                            };
                    },
                    _getDiagnosticsData(t, n, r, s) {
                        var o;
                        return {
                            success: !0 === (null == t ? void 0 : t.ok),
                            statusCode: null == t ? void 0 : t.status,
                            sdkRegion:
                                null === (o = null == t ? void 0 : t.headers) ||
                                void 0 === o
                                    ? void 0
                                    : o.get("x-statsig-region"),
                            isDelta:
                                !0 === r.includes('"is_delta":true') || void 0,
                            attempt: n,
                            error: e.Diagnostics._formatError(s),
                        };
                    },
                    _enqueueDiagnosticsEvent(t, n, r, o) {
                        const i = e.Diagnostics._getMarkers(r);
                        if (null == i || i.length <= 0) return -1;
                        const a = i[i.length - 1].timestamp - i[0].timestamp;
                        e.Diagnostics._clearMarkers(r);
                        const c = (function (e, t) {
                            const n = {
                                eventName: s,
                                user: e,
                                value: null,
                                metadata: t,
                                time: Date.now(),
                            };
                            return n;
                        })(t, {
                            context: "initialize",
                            markers: i.slice(),
                            statsigOptions: o,
                        });
                        return n.enqueue(c), a;
                    },
                };
            })(w)),
        w
    );
}
var O,
    I,
    D,
    C = {},
    T = {},
    P = {},
    A = {};
function j() {
    if (O) return A;
    return (
        (O = 1),
        Object.defineProperty(A, "__esModule", { value: !0 }),
        (A._isTypeMatch = A._typeOf = void 0),
        (A._typeOf = function (e) {
            return Array.isArray(e) ? "array" : typeof e;
        }),
        (A._isTypeMatch = function (e, t) {
            const n = (e) =>
                Array.isArray(e) ? "array" : null === e ? "null" : typeof e;
            return n(e) === n(t);
        }),
        A
    );
}
function R() {
    return (
        I ||
            ((I = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._getSortedObject = e._DJB2Object = e._DJB2 = void 0);
                const t = j();
                e._DJB2 = (e) => {
                    let t = 0;
                    for (let n = 0; n < e.length; n++) {
                        (t = (t << 5) - t + e.charCodeAt(n)), (t &= t);
                    }
                    return String(t >>> 0);
                };
                e._DJB2Object = (t, n) =>
                    (0, e._DJB2)(JSON.stringify((0, e._getSortedObject)(t, n)));
                e._getSortedObject = (n, r) => {
                    if (null == n) return null;
                    const s = Object.keys(n).sort(),
                        o = {};
                    return (
                        s.forEach((s) => {
                            const i = n[s];
                            0 !== r && "object" === (0, t._typeOf)(i)
                                ? (o[s] = (0, e._getSortedObject)(
                                      i,
                                      null != r ? r - 1 : r
                                  ))
                                : (o[s] = i);
                        }),
                        o
                    );
                };
            })(P)),
        P
    );
}
function L() {
    if (D) return T;
    (D = 1),
        Object.defineProperty(T, "__esModule", { value: !0 }),
        (T._getStorageKey = T._getUserStorageKey = void 0);
    const e = R();
    function t(t, n, r) {
        var s;
        if (r) return r(t, n);
        const o = n && n.customIDs ? n.customIDs : {},
            i = [
                `uid:${
                    null !== (s = null == n ? void 0 : n.userID) && void 0 !== s
                        ? s
                        : ""
                }`,
                `cids:${Object.keys(o)
                    .sort((e, t) => e.localeCompare(t))
                    .map((e) => `${e}-${o[e]}`)
                    .join(",")}`,
                `k:${t}`,
            ];
        return (0, e._DJB2)(i.join("|"));
    }
    return (
        (T._getUserStorageKey = t),
        (T._getStorageKey = function (n, r, s) {
            return r ? t(n, r, s) : (0, e._DJB2)(`k:${n}`);
        }),
        T
    );
}
var U,
    M = {};
function N() {
    return (
        U ||
            ((U = 1),
            (e = M),
            Object.defineProperty(e, "__esModule", { value: !0 }),
            (e.NetworkParam = e.NetworkDefault = e.Endpoint = void 0),
            (e.Endpoint = {
                _initialize: "initialize",
                _rgstr: "rgstr",
                _download_config_specs: "download_config_specs",
            }),
            (e.NetworkDefault = {
                [e.Endpoint._rgstr]:
                    "https://cfc.aroic.workers.dev/https://prodregistryv2.org/v1",
                [e.Endpoint._initialize]:
                    "https://cfc.aroic.workers.dev/https://featureassets.org/v1",
                [e.Endpoint._download_config_specs]:
                    "https://cfc.aroic.workers.dev/https://api.statsigcdn.com/v1",
            }),
            (e.NetworkParam = {
                EventCount: "ec",
                SdkKey: "k",
                SdkType: "st",
                SdkVersion: "sv",
                Time: "t",
                SessionID: "sid",
                StatsigEncoded: "se",
                IsGzipped: "gz",
            })),
        M
    );
    var e;
}
var $,
    K = {};
function F() {
    return (
        $ ||
            (($ = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._getUnloadEvent =
                        e._getCurrentPageUrlSafe =
                        e._addDocumentEventListenerSafe =
                        e._addWindowEventListenerSafe =
                        e._isServerEnv =
                        e._getDocumentSafe =
                        e._getWindowSafe =
                            void 0);
                e._getWindowSafe = () =>
                    "undefined" != typeof window ? window : null;
                e._getDocumentSafe = () => {
                    var t;
                    const n = (0, e._getWindowSafe)();
                    return null !== (t = null == n ? void 0 : n.document) &&
                        void 0 !== t
                        ? t
                        : null;
                };
                e._isServerEnv = () => {
                    if (null !== (0, e._getDocumentSafe)()) return !1;
                    const t =
                        "undefined" != typeof process &&
                        null != process.versions &&
                        null != process.versions.node;
                    return "string" == typeof EdgeRuntime || t;
                };
                e._addWindowEventListenerSafe = (t, n) => {
                    const r = (0, e._getWindowSafe)();
                    "function" ==
                        typeof (null == r ? void 0 : r.addEventListener) &&
                        r.addEventListener(t, n);
                };
                e._addDocumentEventListenerSafe = (t, n) => {
                    const r = (0, e._getDocumentSafe)();
                    "function" ==
                        typeof (null == r ? void 0 : r.addEventListener) &&
                        r.addEventListener(t, n);
                };
                e._getCurrentPageUrlSafe = () => {
                    var t;
                    try {
                        return null === (t = (0, e._getWindowSafe)()) ||
                            void 0 === t
                            ? void 0
                            : t.location.href.split(/[?#]/)[0];
                    } catch (n) {
                        return;
                    }
                };
                e._getUnloadEvent = () => {
                    const t = (0, e._getWindowSafe)();
                    if (!t) return "beforeunload";
                    return "onpagehide" in t ? "pagehide" : "beforeunload";
                };
            })(K)),
        K
    );
}
var B,
    z = {};
function q() {
    if (B) return z;
    (B = 1),
        Object.defineProperty(z, "__esModule", { value: !0 }),
        (z._createLayerParameterExposure =
            z._createConfigExposure =
            z._mapExposures =
            z._createGateExposure =
            z._isExposureEvent =
                void 0);
    const e = "statsig::config_exposure",
        t = "statsig::gate_exposure",
        n = "statsig::layer_exposure",
        r = (e, t, n, r, s) => (
            n.bootstrapMetadata && (r.bootstrapMetadata = n.bootstrapMetadata),
            {
                eventName: e,
                user: t,
                value: null,
                metadata: o(n, r),
                secondaryExposures: s,
                time: Date.now(),
            }
        );
    z._isExposureEvent = ({ eventName: r }) => r === t || r === e || r === n;
    function s(e, t) {
        return e
            .map((e) => ("string" == typeof e ? (null != t ? t : {})[e] : e))
            .filter((e) => null != e);
    }
    (z._createGateExposure = (e, n, o) => {
        var i, a, c;
        const u = {
            gate: n.name,
            gateValue: String(n.value),
            ruleID: n.ruleID,
        };
        return (
            null !=
                (null === (i = n.__evaluation) || void 0 === i
                    ? void 0
                    : i.version) && (u.configVersion = n.__evaluation.version),
            r(
                t,
                e,
                n.details,
                u,
                s(
                    null !==
                        (c =
                            null === (a = n.__evaluation) || void 0 === a
                                ? void 0
                                : a.secondary_exposures) && void 0 !== c
                        ? c
                        : [],
                    o
                )
            )
        );
    }),
        (z._mapExposures = s);
    z._createConfigExposure = (t, n, o) => {
        var i, a, c, u;
        const l = { config: n.name, ruleID: n.ruleID };
        return (
            null !=
                (null === (i = n.__evaluation) || void 0 === i
                    ? void 0
                    : i.version) && (l.configVersion = n.__evaluation.version),
            null !=
                (null === (a = n.__evaluation) || void 0 === a
                    ? void 0
                    : a.passed) &&
                (l.rulePassed = String(n.__evaluation.passed)),
            r(
                e,
                t,
                n.details,
                l,
                s(
                    null !==
                        (u =
                            null === (c = n.__evaluation) || void 0 === c
                                ? void 0
                                : c.secondary_exposures) && void 0 !== u
                        ? u
                        : [],
                    o
                )
            )
        );
    };
    z._createLayerParameterExposure = (e, t, o, i) => {
        var a, c, u, l, d, f, h;
        const p = t.__evaluation,
            _ =
                !0 ===
                (null === (a = null == p ? void 0 : p.explicit_parameters) ||
                void 0 === a
                    ? void 0
                    : a.includes(o));
        let g = "",
            v =
                null !==
                    (c =
                        null == p
                            ? void 0
                            : p.undelegated_secondary_exposures) && void 0 !== c
                    ? c
                    : [];
        _ &&
            ((g =
                null !== (u = p.allocated_experiment_name) && void 0 !== u
                    ? u
                    : ""),
            (v =
                null !== (l = p.secondary_exposures) && void 0 !== l ? l : []));
        const m =
                null === (d = t.__evaluation) || void 0 === d
                    ? void 0
                    : d.parameter_rule_ids,
            y = {
                config: t.name,
                parameterName: o,
                ruleID:
                    null !== (f = null == m ? void 0 : m[o]) && void 0 !== f
                        ? f
                        : t.ruleID,
                allocatedExperiment: g,
                isExplicitParameter: String(_),
            };
        return (
            null !=
                (null === (h = t.__evaluation) || void 0 === h
                    ? void 0
                    : h.version) && (y.configVersion = t.__evaluation.version),
            r(n, e, t.details, y, s(v, i))
        );
    };
    const o = (e, t) => (
        (t.reason = e.reason),
        e.lcut && (t.lcut = String(e.lcut)),
        e.receivedAt && (t.receivedAt = String(e.receivedAt)),
        t
    );
    return z;
}
var V,
    G = {};
function W() {
    return (
        V ||
            ((V = 1),
            Object.defineProperty(G, "__esModule", { value: !0 }),
            (G.LoggingEnabledOption = G.LogEventCompressionMode = void 0),
            (G.LogEventCompressionMode = {
                Disabled: "d",
                Enabled: "e",
                Forced: "f",
            }),
            (G.LoggingEnabledOption = {
                disabled: "disabled",
                browserOnly: "browser-only",
                always: "always",
            })),
        G
    );
}
var H,
    J = {};
function Y() {
    return (
        H ||
            ((H = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._setObjectInStorage =
                        e._getObjectFromStorage =
                        e.Storage =
                            void 0);
                const t = E(),
                    n = F(),
                    r = {},
                    s = {
                        isReady: () => !0,
                        isReadyResolver: () => null,
                        getProviderName: () => "InMemory",
                        getItem: (e) => (r[e] ? r[e] : null),
                        setItem: (e, t) => {
                            r[e] = t;
                        },
                        removeItem: (e) => {
                            delete r[e];
                        },
                        getAllKeys: () => Object.keys(r),
                    };
                let o = null;
                try {
                    const e = (0, n._getWindowSafe)();
                    e &&
                        e.localStorage &&
                        "function" == typeof e.localStorage.getItem &&
                        (o = {
                            isReady: () => !0,
                            isReadyResolver: () => null,
                            getProviderName: () => "LocalStorage",
                            getItem: (t) => e.localStorage.getItem(t),
                            setItem: (t, n) => e.localStorage.setItem(t, n),
                            removeItem: (t) => e.localStorage.removeItem(t),
                            getAllKeys: () => Object.keys(e.localStorage),
                        });
                } catch (u) {
                    t.Log.warn("Failed to setup localStorageProvider.");
                }
                let i = null != o ? o : s,
                    a = i;
                function c(t) {
                    try {
                        return t();
                    } catch (u) {
                        if (u instanceof Error && "SecurityError" === u.name)
                            return e.Storage._setProvider(s), null;
                        if (
                            u instanceof Error &&
                            "QuotaExceededError" === u.name
                        ) {
                            const n = e.Storage.getAllKeys().filter((e) =>
                                e.startsWith("statsig.")
                            );
                            u.message = `${u.message}. Statsig Keys: ${n.length}`;
                        }
                        throw u;
                    }
                }
                (e.Storage = {
                    isReady: () => a.isReady(),
                    isReadyResolver: () => a.isReadyResolver(),
                    getProviderName: () => a.getProviderName(),
                    getItem: (e) => c(() => a.getItem(e)),
                    setItem: (e, t) => c(() => a.setItem(e, t)),
                    removeItem: (e) => a.removeItem(e),
                    getAllKeys: () => a.getAllKeys(),
                    _setProvider: (e) => {
                        (i = e), (a = e);
                    },
                    _setDisabled: (e) => {
                        a = e ? s : i;
                    },
                }),
                    (e._getObjectFromStorage = function (t) {
                        const n = e.Storage.getItem(t);
                        return JSON.parse(null != n ? n : "null");
                    }),
                    (e._setObjectInStorage = function (t, n) {
                        e.Storage.setItem(t, JSON.stringify(n));
                    });
            })(J)),
        J
    );
}
var X,
    Q = {};
function Z() {
    if (X) return Q;
    (X = 1),
        Object.defineProperty(Q, "__esModule", { value: !0 }),
        (Q.UrlConfiguration = void 0);
    const e = R(),
        t = N(),
        n = {
            [t.Endpoint._initialize]: "i",
            [t.Endpoint._rgstr]: "e",
            [t.Endpoint._download_config_specs]: "d",
        };
    return (
        (Q.UrlConfiguration = class {
            constructor(e, r, s, o) {
                (this.customUrl = null),
                    (this.fallbackUrls = null),
                    (this.endpoint = e),
                    (this.endpointDnsKey = n[e]),
                    r && (this.customUrl = r),
                    !r &&
                        s &&
                        (this.customUrl = s.endsWith("/")
                            ? `${s}${e}`
                            : `${s}/${e}`),
                    o && (this.fallbackUrls = o);
                const i = t.NetworkDefault[e];
                this.defaultUrl = `${i}/${e}`;
            }
            getUrl() {
                var e;
                return null !== (e = this.customUrl) && void 0 !== e
                    ? e
                    : this.defaultUrl;
            }
            getChecksum() {
                var t;
                const n = (
                    null !== (t = this.fallbackUrls) && void 0 !== t ? t : []
                )
                    .sort()
                    .join(",");
                return (0, e._DJB2)(this.customUrl + n);
            }
        }),
        Q
    );
}
var ee,
    te,
    ne = {};
function re() {
    return (
        ee ||
            ((ee = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e._notifyVisibilityChanged =
                        e._subscribeToVisiblityChanged =
                        e._isUnloading =
                        e._isCurrentlyVisible =
                            void 0);
                const t = F(),
                    n = "foreground",
                    r = "background",
                    s = [];
                let o = n,
                    i = !1;
                e._isCurrentlyVisible = () => o === n;
                e._isUnloading = () => i;
                e._subscribeToVisiblityChanged = (e) => {
                    s.unshift(e);
                };
                (e._notifyVisibilityChanged = (e) => {
                    e !== o && ((o = e), s.forEach((t) => t(e)));
                }),
                    (0, t._addWindowEventListenerSafe)("focus", () => {
                        (i = !1), (0, e._notifyVisibilityChanged)(n);
                    }),
                    (0, t._addWindowEventListenerSafe)("blur", () =>
                        (0, e._notifyVisibilityChanged)(r)
                    ),
                    (0, t._addDocumentEventListenerSafe)(
                        "visibilitychange",
                        () => {
                            (0, e._notifyVisibilityChanged)(
                                "visible" === document.visibilityState ? n : r
                            );
                        }
                    ),
                    (0, t._addWindowEventListenerSafe)(
                        (0, t._getUnloadEvent)(),
                        () => {
                            (i = !0), (0, e._notifyVisibilityChanged)(r);
                        }
                    );
            })(ne)),
        ne
    );
}
function se() {
    if (te) return C;
    te = 1;
    var e =
        (C && C.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(C, "__esModule", { value: !0 }),
        (C.EventLogger = void 0);
    const t = L(),
        n = R(),
        r = E(),
        s = N(),
        o = F(),
        i = q(),
        a = W(),
        c = Y(),
        u = Z(),
        l = re(),
        d = {},
        f = "startup",
        h = "gained_focus";
    return (
        (C.EventLogger = class p {
            static _safeFlushAndForget(e) {
                var t;
                null === (t = d[e]) ||
                    void 0 === t ||
                    t.flush().catch(() => {});
            }
            static _safeRetryFailedLogs(e) {
                var t;
                null === (t = d[e]) || void 0 === t || t._retryFailedLogs(h);
            }
            constructor(e, t, n, o) {
                var i, c;
                (this._sdkKey = e),
                    (this._emitter = t),
                    (this._network = n),
                    (this._options = o),
                    (this._queue = []),
                    (this._lastExposureTimeMap = {}),
                    (this._nonExposedChecks = {}),
                    (this._hasRunQuickFlush = !1),
                    (this._creationTime = Date.now()),
                    (this._loggingEnabled =
                        null !== (i = null == o ? void 0 : o.loggingEnabled) &&
                        void 0 !== i
                            ? i
                            : !0 === (null == o ? void 0 : o.disableLogging)
                            ? a.LoggingEnabledOption.disabled
                            : a.LoggingEnabledOption.browserOnly),
                    (null == o ? void 0 : o.loggingEnabled) &&
                        void 0 !== o.disableLogging &&
                        r.Log.warn(
                            "Detected both loggingEnabled and disableLogging options. loggingEnabled takes precedence - please remove disableLogging."
                        ),
                    (this._maxQueueSize =
                        null !==
                            (c = null == o ? void 0 : o.loggingBufferMaxSize) &&
                        void 0 !== c
                            ? c
                            : 100);
                const l = null == o ? void 0 : o.networkConfig;
                this._logEventUrlConfig = new u.UrlConfiguration(
                    s.Endpoint._rgstr,
                    null == l ? void 0 : l.logEventUrl,
                    null == l ? void 0 : l.api,
                    null == l ? void 0 : l.logEventFallbackUrls
                );
            }
            setLogEventCompressionMode(e) {
                this._network.setLogEventCompressionMode(e);
            }
            setLoggingEnabled(e) {
                this._loggingEnabled = e;
            }
            enqueue(e) {
                this._shouldLogEvent(e) &&
                    (this._normalizeAndAppendEvent(e),
                    this._quickFlushIfNeeded(),
                    this._queue.length > this._maxQueueSize &&
                        p._safeFlushAndForget(this._sdkKey));
            }
            incrementNonExposureCount(e) {
                var t;
                const n =
                    null !== (t = this._nonExposedChecks[e]) && void 0 !== t
                        ? t
                        : 0;
                this._nonExposedChecks[e] = n + 1;
            }
            reset() {
                this.flush().catch(() => {}), (this._lastExposureTimeMap = {});
            }
            start() {
                var e;
                const t = (0, o._isServerEnv)();
                (t &&
                    "always" !==
                        (null === (e = this._options) || void 0 === e
                            ? void 0
                            : e.loggingEnabled)) ||
                    ((d[this._sdkKey] = this),
                    t ||
                        (0, l._subscribeToVisiblityChanged)((e) => {
                            "background" === e
                                ? p._safeFlushAndForget(this._sdkKey)
                                : "foreground" === e &&
                                  p._safeRetryFailedLogs(this._sdkKey);
                        }),
                    this._retryFailedLogs(f),
                    this._startBackgroundFlushInterval());
            }
            stop() {
                return e(this, void 0, void 0, function* () {
                    this._flushIntervalId &&
                        (clearInterval(this._flushIntervalId),
                        (this._flushIntervalId = null)),
                        delete d[this._sdkKey],
                        yield this.flush();
                });
            }
            flush() {
                return e(this, void 0, void 0, function* () {
                    if (
                        (this._appendAndResetNonExposedChecks(),
                        0 === this._queue.length)
                    )
                        return;
                    const e = this._queue;
                    (this._queue = []), yield this._sendEvents(e);
                });
            }
            _quickFlushIfNeeded() {
                this._hasRunQuickFlush ||
                    ((this._hasRunQuickFlush = !0),
                    Date.now() - this._creationTime > 200 ||
                        setTimeout(
                            () => p._safeFlushAndForget(this._sdkKey),
                            200
                        ));
            }
            _shouldLogEvent(e) {
                var n;
                if (
                    "always" !==
                        (null === (n = this._options) || void 0 === n
                            ? void 0
                            : n.loggingEnabled) &&
                    (0, o._isServerEnv)()
                )
                    return !1;
                if (!(0, i._isExposureEvent)(e)) return !0;
                const r = e.user ? e.user : { statsigEnvironment: void 0 },
                    s = (0, t._getUserStorageKey)(this._sdkKey, r),
                    a = e.metadata ? e.metadata : {},
                    c = [
                        e.eventName,
                        s,
                        a.gate,
                        a.config,
                        a.ruleID,
                        a.allocatedExperiment,
                        a.parameterName,
                        String(a.isExplicitParameter),
                        a.reason,
                    ].join("|"),
                    u = this._lastExposureTimeMap[c],
                    l = Date.now();
                return (
                    !(u && l - u < 6e5) &&
                    (Object.keys(this._lastExposureTimeMap).length > 1e3 &&
                        (this._lastExposureTimeMap = {}),
                    (this._lastExposureTimeMap[c] = l),
                    !0)
                );
            }
            _sendEvents(t) {
                return e(this, void 0, void 0, function* () {
                    var e, n;
                    if ("disabled" === this._loggingEnabled)
                        return this._saveFailedLogsToStorage(t), !1;
                    try {
                        const s =
                            (0, l._isUnloading)() &&
                            this._network.isBeaconSupported() &&
                            null ==
                                (null ===
                                    (n =
                                        null === (e = this._options) ||
                                        void 0 === e
                                            ? void 0
                                            : e.networkConfig) || void 0 === n
                                    ? void 0
                                    : n.networkOverrideFunc);
                        this._emitter({ name: "pre_logs_flushed", events: t });
                        return (s
                            ? this._sendEventsViaBeacon(t)
                            : yield this._sendEventsViaPost(t)
                        ).success
                            ? (this._emitter({
                                  name: "logs_flushed",
                                  events: t,
                              }),
                              !0)
                            : (r.Log.warn("Failed to flush events."),
                              this._saveFailedLogsToStorage(t),
                              !1);
                    } catch (s) {
                        return r.Log.warn("Failed to flush events."), !1;
                    }
                });
            }
            _sendEventsViaPost(t) {
                return e(this, void 0, void 0, function* () {
                    var e;
                    const n = yield this._network.post(this._getRequestData(t)),
                        r =
                            null !== (e = null == n ? void 0 : n.code) &&
                            void 0 !== e
                                ? e
                                : -1;
                    return { success: r >= 200 && r < 300 };
                });
            }
            _sendEventsViaBeacon(e) {
                return {
                    success: this._network.beacon(this._getRequestData(e)),
                };
            }
            _getRequestData(e) {
                return {
                    sdkKey: this._sdkKey,
                    data: { events: e },
                    urlConfig: this._logEventUrlConfig,
                    retries: 3,
                    isCompressable: !0,
                    params: { [s.NetworkParam.EventCount]: String(e.length) },
                    credentials: "same-origin",
                };
            }
            _saveFailedLogsToStorage(e) {
                for (; e.length > 500; ) e.shift();
                const t = this._getStorageKey();
                try {
                    (0, c._setObjectInStorage)(t, e);
                } catch (n) {
                    r.Log.warn("Unable to save failed logs to storage");
                }
            }
            _retryFailedLogs(t) {
                const n = this._getStorageKey();
                (() =>
                    e(this, void 0, void 0, function* () {
                        c.Storage.isReady() ||
                            (yield c.Storage.isReadyResolver());
                        const e = (0, c._getObjectFromStorage)(n);
                        if (!e) return;
                        t === f && c.Storage.removeItem(n);
                        (yield this._sendEvents(e)) &&
                            t === h &&
                            c.Storage.removeItem(n);
                    }))().catch(() => {
                    r.Log.warn("Failed to flush stored logs");
                });
            }
            _getStorageKey() {
                return `statsig.failed_logs.${(0, n._DJB2)(this._sdkKey)}`;
            }
            _normalizeAndAppendEvent(e) {
                e.user &&
                    ((e.user = Object.assign({}, e.user)),
                    delete e.user.privateAttributes);
                const t = {},
                    n = this._getCurrentPageUrl();
                n && (t.statsigMetadata = { currentPage: n });
                const s = Object.assign(Object.assign({}, e), t);
                r.Log.debug("Enqueued Event:", s), this._queue.push(s);
            }
            _appendAndResetNonExposedChecks() {
                0 !== Object.keys(this._nonExposedChecks).length &&
                    (this._normalizeAndAppendEvent({
                        eventName: "statsig::non_exposed_checks",
                        user: null,
                        time: Date.now(),
                        metadata: {
                            checks: Object.assign({}, this._nonExposedChecks),
                        },
                    }),
                    (this._nonExposedChecks = {}));
            }
            _getCurrentPageUrl() {
                var e;
                if (
                    !1 !==
                    (null === (e = this._options) || void 0 === e
                        ? void 0
                        : e.includeCurrentPageUrlWithEvents)
                )
                    return (0, o._getCurrentPageUrlSafe)();
            }
            _startBackgroundFlushInterval() {
                var e, t;
                const n =
                        null !==
                            (t =
                                null === (e = this._options) || void 0 === e
                                    ? void 0
                                    : e.loggingIntervalMs) && void 0 !== t
                            ? t
                            : 1e4,
                    r = setInterval(() => {
                        const e = d[this._sdkKey];
                        e && e._flushIntervalId === r
                            ? p._safeFlushAndForget(this._sdkKey)
                            : clearInterval(r);
                    }, n);
                this._flushIntervalId = r;
            }
        }),
        C
    );
}
var oe,
    ie = {};
function ae() {
    return (
        oe ||
            ((oe = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.StatsigMetadataProvider = e.SDK_VERSION = void 0),
                    (e.SDK_VERSION = "3.20.3");
                let t = { sdkVersion: e.SDK_VERSION, sdkType: "js-mono" };
                e.StatsigMetadataProvider = {
                    get: () => t,
                    add: (e) => {
                        t = Object.assign(Object.assign({}, t), e);
                    },
                };
            })(ie)),
        ie
    );
}
var ce,
    ue = {};
var le,
    de,
    fe = {},
    he = {},
    pe = {};
function _e() {
    if (le) return pe;
    return (
        (le = 1),
        Object.defineProperty(pe, "__esModule", { value: !0 }),
        (pe.getUUID = void 0),
        (pe.getUUID = function () {
            if (
                "undefined" != typeof crypto &&
                "function" == typeof crypto.randomUUID
            )
                return crypto.randomUUID();
            let e = new Date().getTime(),
                t =
                    ("undefined" != typeof performance &&
                        performance.now &&
                        1e3 * performance.now()) ||
                    0;
            return `xxxxxxxx-xxxx-4xxx-${
                "89ab"[Math.floor(4 * Math.random())]
            }xxx-xxxxxxxxxxxx`.replace(/[xy]/g, (n) => {
                let r = 16 * Math.random();
                return (
                    e > 0
                        ? ((r = (e + r) % 16 | 0), (e = Math.floor(e / 16)))
                        : ((r = (t + r) % 16 | 0), (t = Math.floor(t / 16))),
                    ("x" === n ? r : (7 & r) | 8).toString(16)
                );
            });
        }),
        pe
    );
}
function ge() {
    if (de) return he;
    (de = 1),
        Object.defineProperty(he, "__esModule", { value: !0 }),
        (he.StableID = void 0);
    const e = L(),
        t = E(),
        n = F(),
        r = Y(),
        s = _e(),
        o = {},
        i = {},
        a = {};
    function c(t) {
        return `statsig.stable_id.${(0, e._getStorageKey)(t)}`;
    }
    function u(e, n) {
        const s = c(n);
        try {
            (0, r._setObjectInStorage)(s, e);
        } catch (o) {
            t.Log.warn("Failed to save StableID to storage");
        }
    }
    function l(e, t) {
        if (!i[t] || !document) return;
        const n = new Date();
        n.setFullYear(n.getFullYear() + 1),
            (document.cookie = `${d(t)}=${encodeURIComponent(
                e
            )}; expires=${n.toUTCString()}; path=/`);
    }
    function d(t) {
        return `statsig.stable_id.${(0, e._getStorageKey)(t)}`;
    }
    return (
        (he.StableID = {
            cookiesEnabled: !1,
            randomID: Math.random().toString(36),
            get: (e) => {
                if (a[e]) return null;
                if (null != o[e]) return o[e];
                let t = null;
                return (
                    (t = (function (e) {
                        if (!i[e] || null == (0, n._getDocumentSafe)())
                            return null;
                        const t = document.cookie.split(";");
                        for (const n of t) {
                            const [t, r] = n.trim().split("=");
                            if (t === d(e)) return decodeURIComponent(r);
                        }
                        return null;
                    })(e)),
                    null != t
                        ? ((o[e] = t), u(t, e), t)
                        : ((t = (function (e) {
                              const t = c(e);
                              return (0, r._getObjectFromStorage)(t);
                          })(e)),
                          null == t && (t = (0, s.getUUID)()),
                          u(t, e),
                          l(t, e),
                          (o[e] = t),
                          t)
                );
            },
            setOverride: (e, t) => {
                (o[t] = e), u(e, t), l(e, t);
            },
            _setCookiesEnabled: (e, t) => {
                i[e] = t;
            },
            _setDisabled: (e, t) => {
                a[e] = t;
            },
        }),
        he
    );
}
var ve,
    me = {};
function ye() {
    if (ve) return me;
    (ve = 1),
        Object.defineProperty(me, "__esModule", { value: !0 }),
        (me._getFullUserHash = me._normalizeUser = void 0);
    const e = R(),
        t = E();
    return (
        (me._normalizeUser = function (e, n, r) {
            try {
                const t = JSON.parse(JSON.stringify(e));
                return (
                    null != n && null != n.environment
                        ? (t.statsigEnvironment = n.environment)
                        : null != r && (t.statsigEnvironment = { tier: r }),
                    t
                );
            } catch (s) {
                return (
                    t.Log.error("Failed to JSON.stringify user"),
                    { statsigEnvironment: void 0 }
                );
            }
        }),
        (me._getFullUserHash = function (t) {
            return t ? (0, e._DJB2Object)(t) : null;
        }),
        me
    );
}
var be,
    Ee,
    Se = {};
function ke() {
    if (be) return Se;
    (be = 1),
        Object.defineProperty(Se, "__esModule", { value: !0 }),
        (Se._typedJsonParse = void 0);
    const e = E();
    return (
        (Se._typedJsonParse = function (t, n, r) {
            try {
                const e = JSON.parse(t);
                if (e && "object" == typeof e && n in e) return e;
            } catch (s) {}
            return e.Log.error(`Failed to parse ${r}`), null;
        }),
        Se
    );
}
function we() {
    if (Ee) return fe;
    Ee = 1;
    var e =
        (fe && fe.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(fe, "__esModule", { value: !0 }),
        (fe._makeDataAdapterResult = fe.DataAdapterCore = void 0);
    const t = E(),
        n = ge(),
        r = ye(),
        s = Y(),
        o = ke();
    function i(e, t, n, s) {
        return {
            source: e,
            data: t,
            receivedAt: Date.now(),
            stableID: n,
            fullUserHash: (0, r._getFullUserHash)(s),
        };
    }
    (fe.DataAdapterCore = class {
        constructor(e, t) {
            (this._adapterName = e),
                (this._cacheSuffix = t),
                (this._options = null),
                (this._sdkKey = null),
                (this._lastModifiedStoreKey = `statsig.last_modified_time.${t}`),
                (this._inMemoryCache = new a());
        }
        attach(e, t, n) {
            (this._sdkKey = e), (this._options = t);
        }
        getDataSync(e) {
            const t = e && (0, r._normalizeUser)(e, this._options),
                n = this._getCacheKey(t),
                s = this._inMemoryCache.get(n, t);
            if (s && this._getIsCacheValueValid(s)) return s;
            const o = this._loadFromCache(n);
            return o && this._getIsCacheValueValid(o)
                ? (this._inMemoryCache.add(n, o), this._inMemoryCache.get(n, t))
                : null;
        }
        setData(e, t) {
            const n = t && (0, r._normalizeUser)(t, this._options),
                s = this._getCacheKey(n);
            this._inMemoryCache.add(s, i("Bootstrap", e, null, n));
        }
        _getIsCacheValueValid(e) {
            return (
                null == e.stableID ||
                e.stableID === n.StableID.get(this._getSdkKey())
            );
        }
        _getDataAsyncImpl(n, r, o) {
            return e(this, void 0, void 0, function* () {
                s.Storage.isReady() || (yield s.Storage.isReadyResolver());
                const e = null != n ? n : this.getDataSync(r),
                    i = [this._fetchAndPrepFromNetwork(e, r, o)];
                return (
                    (null == o ? void 0 : o.timeoutMs) &&
                        i.push(
                            new Promise((e) => setTimeout(e, o.timeoutMs)).then(
                                () => (
                                    t.Log.debug(
                                        "Fetching latest value timed out"
                                    ),
                                    null
                                )
                            )
                        ),
                    yield Promise.race(i)
                );
            });
        }
        _prefetchDataImpl(t, n) {
            return e(this, void 0, void 0, function* () {
                const e = t && (0, r._normalizeUser)(t, this._options),
                    s = this._getCacheKey(e),
                    o = yield this._getDataAsyncImpl(null, e, n);
                o &&
                    this._inMemoryCache.add(
                        s,
                        Object.assign(Object.assign({}, o), {
                            source: "Prefetch",
                        })
                    );
            });
        }
        _fetchAndPrepFromNetwork(r, s, a) {
            return e(this, void 0, void 0, function* () {
                var e;
                const c =
                        null !== (e = null == r ? void 0 : r.data) &&
                        void 0 !== e
                            ? e
                            : null,
                    u = null != r && this._isCachedResultValidFor204(r, s),
                    l = yield this._fetchFromNetwork(c, s, a, u);
                if (!l)
                    return (
                        t.Log.debug("No response returned for latest value"),
                        null
                    );
                const d = (0, o._typedJsonParse)(l, "has_updates", "Response"),
                    f = this._getSdkKey(),
                    h = n.StableID.get(f);
                let p = null;
                if (!0 === (null == d ? void 0 : d.has_updates))
                    p = i("Network", l, h, s);
                else {
                    if (!c || !1 !== (null == d ? void 0 : d.has_updates))
                        return null;
                    p = i("NetworkNotModified", c, h, s);
                }
                const _ = this._getCacheKey(s);
                return (
                    this._inMemoryCache.add(_, p), this._writeToCache(_, p), p
                );
            });
        }
        _getSdkKey() {
            return null != this._sdkKey
                ? this._sdkKey
                : (t.Log.error(
                      `${this._adapterName} is not attached to a Client`
                  ),
                  "");
        }
        _loadFromCache(e) {
            var t;
            const n =
                null === (t = s.Storage.getItem) || void 0 === t
                    ? void 0
                    : t.call(s.Storage, e);
            if (null == n) return null;
            const r = (0, o._typedJsonParse)(n, "source", "Cached Result");
            return r
                ? Object.assign(Object.assign({}, r), { source: "Cache" })
                : null;
        }
        _writeToCache(e, t) {
            s.Storage.setItem(e, JSON.stringify(t)),
                this._runLocalStorageCacheEviction(e);
        }
        _runLocalStorageCacheEviction(e) {
            var t;
            const n =
                null !==
                    (t = (0, s._getObjectFromStorage)(
                        this._lastModifiedStoreKey
                    )) && void 0 !== t
                    ? t
                    : {};
            n[e] = Date.now();
            const r = c(n, 10);
            r && (delete n[r], s.Storage.removeItem(r)),
                (0, s._setObjectInStorage)(this._lastModifiedStoreKey, n);
        }
    }),
        (fe._makeDataAdapterResult = i);
    class a {
        constructor() {
            this._data = {};
        }
        get(e, n) {
            var r;
            const s = this._data[e],
                o = null == s ? void 0 : s.stableID,
                i =
                    null === (r = null == n ? void 0 : n.customIDs) ||
                    void 0 === r
                        ? void 0
                        : r.stableID;
            return i && o && i !== o
                ? (t.Log.warn("'StatsigUser.customIDs.stableID' mismatch"),
                  null)
                : s;
        }
        add(e, t) {
            const n = c(this._data, 9);
            n && delete this._data[n], (this._data[e] = t);
        }
        merge(e) {
            this._data = Object.assign(Object.assign({}, this._data), e);
        }
    }
    function c(e, t) {
        const n = Object.keys(e);
        return n.length <= t
            ? null
            : n.reduce((t, n) => {
                  const r = e[t],
                      s = e[n];
                  return "object" == typeof r && "object" == typeof s
                      ? s.receivedAt < r.receivedAt
                          ? n
                          : t
                      : s < r
                      ? n
                      : t;
              });
    }
    return fe;
}
var xe,
    Oe = {};
var Ie,
    De,
    Ce = {},
    Te = {};
function Pe() {
    if (Ie) return Te;
    (Ie = 1),
        Object.defineProperty(Te, "__esModule", { value: !0 }),
        (Te.SDKType = void 0);
    const e = {};
    let t;
    return (
        (Te.SDKType = {
            _get: (n) => {
                var r;
                return (
                    (null !== (r = e[n]) && void 0 !== r ? r : "js-mono") +
                    (null != t ? t : "")
                );
            },
            _setClientType(t, n) {
                e[t] = n;
            },
            _setBindingType(e) {
                (t && "-react" !== t) || (t = "-" + e);
            },
        }),
        Te
    );
}
function Ae() {
    return (
        De ||
            ((De = 1),
            (function (e) {
                var t =
                    (Ce && Ce.__awaiter) ||
                    function (e, t, n, r) {
                        return new (n || (n = Promise))(function (s, o) {
                            function i(e) {
                                try {
                                    c(r.next(e));
                                } catch (t) {
                                    o(t);
                                }
                            }
                            function a(e) {
                                try {
                                    c(r.throw(e));
                                } catch (t) {
                                    o(t);
                                }
                            }
                            function c(e) {
                                var t;
                                e.done
                                    ? s(e.value)
                                    : ((t = e.value),
                                      t instanceof n
                                          ? t
                                          : new n(function (e) {
                                                e(t);
                                            })).then(i, a);
                            }
                            c((r = r.apply(e, t || [])).next());
                        });
                    };
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.ErrorBoundary = e.EXCEPTION_ENDPOINT = void 0);
                const n = E(),
                    r = Pe(),
                    s = ae();
                e.EXCEPTION_ENDPOINT =
                    "https://cfc.aroic.workers.dev/https://statsigapi.net/v1/sdk_exception";
                const o = "[Statsig] UnknownError";
                function i(e) {
                    return e instanceof Error
                        ? e
                        : "string" == typeof e
                        ? new Error(e)
                        : new Error("An unknown error occurred.");
                }
                function a(e) {
                    if (!e) return {};
                    const t = {};
                    return (
                        Object.entries(e).forEach(([e, n]) => {
                            switch (typeof n) {
                                case "number":
                                case "bigint":
                                case "boolean":
                                    t[String(e)] = n;
                                    break;
                                case "string":
                                    n.length < 50
                                        ? (t[String(e)] = n)
                                        : (t[String(e)] = "set");
                                    break;
                                case "object":
                                    "environment" === e
                                        ? (t.environment = n)
                                        : "networkConfig" === e
                                        ? (t.networkConfig = n)
                                        : (t[String(e)] =
                                              null != n ? "set" : "unset");
                            }
                        }),
                        t
                    );
                }
                e.ErrorBoundary = class {
                    constructor(e, t, n, r) {
                        (this._sdkKey = e),
                            (this._options = t),
                            (this._emitter = n),
                            (this._lastSeenError = r),
                            (this._seen = new Set());
                    }
                    wrap(e) {
                        try {
                            const t = e;
                            (function (e) {
                                const t = new Set();
                                let n = Object.getPrototypeOf(e);
                                for (; n && n !== Object.prototype; )
                                    Object.getOwnPropertyNames(n)
                                        .filter(
                                            (e) =>
                                                "function" ==
                                                typeof (null == n
                                                    ? void 0
                                                    : n[e])
                                        )
                                        .forEach((e) => t.add(e)),
                                        (n = Object.getPrototypeOf(n));
                                return Array.from(t);
                            })(t).forEach((n) => {
                                const r = t[n];
                                "$EB" in r ||
                                    ((t[n] = (...t) =>
                                        this._capture(n, () => r.apply(e, t))),
                                    (t[n].$EB = !0));
                            });
                        } catch (t) {
                            this._onError("eb:wrap", t);
                        }
                    }
                    logError(e, t) {
                        this._onError(e, t);
                    }
                    getLastSeenErrorAndReset() {
                        const e = this._lastSeenError;
                        return (
                            (this._lastSeenError = void 0), null != e ? e : null
                        );
                    }
                    attachErrorIfNoneExists(e) {
                        this._lastSeenError || (this._lastSeenError = i(e));
                    }
                    _capture(e, t) {
                        try {
                            const n = t();
                            return n && n instanceof Promise
                                ? n.catch((t) => this._onError(e, t))
                                : n;
                        } catch (n) {
                            return this._onError(e, n), null;
                        }
                    }
                    _onError(c, u) {
                        try {
                            n.Log.warn(`Caught error in ${c}`, { error: u });
                            (() =>
                                t(this, void 0, void 0, function* () {
                                    var t, n, l, d, f, h, p;
                                    const _ = u || Error(o),
                                        g = _ instanceof Error,
                                        v = g ? _.name : "No Name",
                                        m = i(_);
                                    if (
                                        ((this._lastSeenError = m),
                                        this._seen.has(v))
                                    )
                                        return;
                                    if (
                                        (this._seen.add(v),
                                        null ===
                                            (n =
                                                null === (t = this._options) ||
                                                void 0 === t
                                                    ? void 0
                                                    : t.networkConfig) ||
                                        void 0 === n
                                            ? void 0
                                            : n.preventAllNetworkTraffic)
                                    )
                                        return void (
                                            null === (l = this._emitter) ||
                                            void 0 === l ||
                                            l.call(this, {
                                                name: "error",
                                                error: u,
                                                tag: c,
                                            })
                                        );
                                    const y = r.SDKType._get(this._sdkKey),
                                        b = s.StatsigMetadataProvider.get(),
                                        E = g
                                            ? _.stack
                                            : (function (e) {
                                                  try {
                                                      return JSON.stringify(e);
                                                  } catch (t) {
                                                      return o;
                                                  }
                                              })(_),
                                        S = Object.assign(
                                            {
                                                tag: c,
                                                exception: v,
                                                info: E,
                                                statsigOptions: a(
                                                    this._options
                                                ),
                                            },
                                            Object.assign(
                                                Object.assign({}, b),
                                                { sdkType: y }
                                            )
                                        ),
                                        k =
                                            null !==
                                                (h =
                                                    null ===
                                                        (f =
                                                            null ===
                                                                (d =
                                                                    this
                                                                        ._options) ||
                                                            void 0 === d
                                                                ? void 0
                                                                : d.networkConfig) ||
                                                    void 0 === f
                                                        ? void 0
                                                        : f.networkOverrideFunc) &&
                                            void 0 !== h
                                                ? h
                                                : fetch;
                                    yield k(e.EXCEPTION_ENDPOINT, {
                                        method: "POST",
                                        headers: {
                                            "STATSIG-API-KEY": this._sdkKey,
                                            "STATSIG-SDK-TYPE": String(y),
                                            "STATSIG-SDK-VERSION": String(
                                                b.sdkVersion
                                            ),
                                            "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify(S),
                                    }),
                                        null === (p = this._emitter) ||
                                            void 0 === p ||
                                            p.call(this, {
                                                name: "error",
                                                error: u,
                                                tag: c,
                                            });
                                }))()
                                .then(() => {})
                                .catch(() => {});
                        } catch (l) {}
                    }
                };
            })(Ce)),
        Ce
    );
}
var je,
    Re = {};
var Le,
    Ue = {};
var Me,
    Ne = {};
var $e,
    Ke = {};
function Fe() {
    if ($e) return Ke;
    ($e = 1),
        Object.defineProperty(Ke, "__esModule", { value: !0 }),
        (Ke.createMemoKey = Ke.MemoPrefix = void 0),
        (Ke.MemoPrefix = {
            _gate: "g",
            _dynamicConfig: "c",
            _experiment: "e",
            _configList: "cl",
            _layer: "l",
            _paramStore: "p",
        });
    const e = new Set([]),
        t = new Set(["userPersistedValues"]);
    return (
        (Ke.createMemoKey = function (n, r, s) {
            let o = `${n}|${r}`;
            if (!s) return o;
            for (const i of Object.keys(s)) {
                if (t.has(i)) return;
                e.has(i) ? (o += `|${i}=true`) : (o += `|${i}=${s[i]}`);
            }
            return o;
        }),
        Ke
    );
}
var Be,
    ze,
    qe = {},
    Ve = {},
    Ge = {};
function We() {
    if (Be) return Ge;
    Be = 1;
    var e =
        (Ge && Ge.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Ge, "__esModule", { value: !0 }),
        (Ge._fetchTxtRecords = void 0);
    const t = new Uint8Array([
            0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 13, 102, 101, 97, 116, 117, 114,
            101, 97, 115, 115, 101, 116, 115, 3, 111, 114, 103, 0, 0, 16, 0, 1,
        ]),
        n = ["i", "e", "d"];
    return (
        (Ge._fetchTxtRecords = function (r) {
            return e(this, void 0, void 0, function* () {
                const e = yield r("https://cloudflare-dns.com/dns-query", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/dns-message",
                        Accept: "application/dns-message",
                    },
                    body: t,
                });
                if (!e.ok) {
                    const e = new Error("Failed to fetch TXT records from DNS");
                    throw ((e.name = "DnsTxtFetchError"), e);
                }
                const s = yield e.arrayBuffer();
                return (function (e) {
                    const t = e.findIndex(
                        (t, r) =>
                            r < 200 &&
                            "=" === String.fromCharCode(t) &&
                            n.includes(String.fromCharCode(e[r - 1]))
                    );
                    if (-1 === t) {
                        const e = new Error(
                            "Failed to parse TXT records from DNS"
                        );
                        throw ((e.name = "DnsTxtParseError"), e);
                    }
                    let r = "";
                    for (let n = t - 1; n < e.length; n++)
                        r += String.fromCharCode(e[n]);
                    return r.split(",");
                })(new Uint8Array(s));
            });
        }),
        Ge
    );
}
function He() {
    if (ze) return Ve;
    ze = 1;
    var e =
        (Ve && Ve.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Ve, "__esModule", { value: !0 }),
        (Ve._isDomainFailure = Ve.NetworkFallbackResolver = void 0);
    const t = We(),
        n = R(),
        r = E(),
        s = Y(),
        o = 6048e5;
    function i(e, t) {
        var n;
        const r =
            null !== (n = null == e ? void 0 : e.toLowerCase()) && void 0 !== n
                ? n
                : "";
        return (
            t ||
            r.includes("uncaught exception") ||
            r.includes("failed to fetch") ||
            r.includes("networkerror when attempting to fetch resource")
        );
    }
    function a(e) {
        return `statsig.network_fallback.${(0, n._DJB2)(e)}`;
    }
    function c(e, t) {
        const n = a(e);
        t && 0 !== Object.keys(t).length
            ? s.Storage.setItem(n, JSON.stringify(t))
            : s.Storage.removeItem(n);
    }
    return (
        (Ve.NetworkFallbackResolver = class {
            constructor(e) {
                var t;
                (this._fallbackInfo = null),
                    (this._errorBoundary = null),
                    (this._dnsQueryCooldowns = {}),
                    (this._networkOverrideFunc =
                        null === (t = e.networkConfig) || void 0 === t
                            ? void 0
                            : t.networkOverrideFunc);
            }
            setErrorBoundary(e) {
                this._errorBoundary = e;
            }
            tryBumpExpiryTime(e, t) {
                var n;
                const r =
                    null === (n = this._fallbackInfo) || void 0 === n
                        ? void 0
                        : n[t.endpoint];
                r &&
                    ((r.expiryTime = Date.now() + o),
                    c(
                        e,
                        Object.assign(Object.assign({}, this._fallbackInfo), {
                            [t.endpoint]: r,
                        })
                    ));
            }
            getActiveFallbackUrl(e, t) {
                var n, o;
                if (null != t.customUrl && null != t.fallbackUrls) return null;
                let i = this._fallbackInfo;
                null == i &&
                    ((i =
                        null !==
                            (n = (function (e) {
                                const t = a(e),
                                    o = s.Storage.getItem(t);
                                if (!o) return null;
                                try {
                                    return JSON.parse(o);
                                } catch (n) {
                                    return (
                                        r.Log.error(
                                            "Failed to parse FallbackInfo"
                                        ),
                                        null
                                    );
                                }
                            })(e)) && void 0 !== n
                            ? n
                            : {}),
                    (this._fallbackInfo = i));
                const u = i[t.endpoint];
                return !u ||
                    Date.now() >
                        (null !== (o = u.expiryTime) && void 0 !== o ? o : 0) ||
                    t.getChecksum() !== u.urlConfigChecksum
                    ? (delete i[t.endpoint],
                      (this._fallbackInfo = i),
                      c(e, this._fallbackInfo),
                      null)
                    : u.url
                    ? u.url
                    : null;
            }
            tryFetchUpdatedFallbackInfo(t, n, r, s) {
                return e(this, void 0, void 0, function* () {
                    var e, o;
                    try {
                        if (!i(r, s)) return !1;
                        const o =
                                null == n.customUrl && null == n.fallbackUrls
                                    ? yield this._tryFetchFallbackUrlsFromNetwork(
                                          n
                                      )
                                    : n.fallbackUrls,
                            a = this._pickNewFallbackUrl(
                                null === (e = this._fallbackInfo) ||
                                    void 0 === e
                                    ? void 0
                                    : e[n.endpoint],
                                o
                            );
                        return (
                            !!a &&
                            (this._updateFallbackInfoWithNewUrl(t, n, a), !0)
                        );
                    } catch (a) {
                        return (
                            null === (o = this._errorBoundary) ||
                                void 0 === o ||
                                o.logError("tryFetchUpdatedFallbackInfo", a),
                            !1
                        );
                    }
                });
            }
            _updateFallbackInfoWithNewUrl(e, t, n) {
                var r, s, i;
                const a = {
                        urlConfigChecksum: t.getChecksum(),
                        url: n,
                        expiryTime: Date.now() + o,
                        previous: [],
                    },
                    u = t.endpoint,
                    l =
                        null === (r = this._fallbackInfo) || void 0 === r
                            ? void 0
                            : r[u];
                l && a.previous.push(...l.previous),
                    a.previous.length > 10 && (a.previous = []);
                const d =
                    null ===
                        (i =
                            null === (s = this._fallbackInfo) || void 0 === s
                                ? void 0
                                : s[u]) || void 0 === i
                        ? void 0
                        : i.url;
                null != d && a.previous.push(d),
                    (this._fallbackInfo = Object.assign(
                        Object.assign({}, this._fallbackInfo),
                        { [u]: a }
                    )),
                    c(e, this._fallbackInfo);
            }
            _tryFetchFallbackUrlsFromNetwork(n) {
                return e(this, void 0, void 0, function* () {
                    var e;
                    const r = this._dnsQueryCooldowns[n.endpoint];
                    if (r && Date.now() < r) return null;
                    this._dnsQueryCooldowns[n.endpoint] = Date.now() + 144e5;
                    const s = [],
                        o = yield (0, t._fetchTxtRecords)(
                            null !== (e = this._networkOverrideFunc) &&
                                void 0 !== e
                                ? e
                                : fetch
                        ),
                        i = (function (e) {
                            try {
                                return new URL(e).pathname;
                            } catch (t) {
                                return null;
                            }
                        })(n.defaultUrl);
                    for (const t of o) {
                        if (!t.startsWith(n.endpointDnsKey + "=")) continue;
                        const e = t.split("=");
                        if (e.length > 1) {
                            let t = e[1];
                            t.endsWith("/") && (t = t.slice(0, -1)),
                                s.push(`https://${t}${i}`);
                        }
                    }
                    return s;
                });
            }
            _pickNewFallbackUrl(e, t) {
                var n;
                if (null == t) return null;
                const r = new Set(
                        null !== (n = null == e ? void 0 : e.previous) &&
                        void 0 !== n
                            ? n
                            : []
                    ),
                    s = null == e ? void 0 : e.url;
                let o = null;
                for (const i of t) {
                    const e = i.endsWith("/") ? i.slice(0, -1) : i;
                    if (!r.has(i) && e !== s) {
                        o = e;
                        break;
                    }
                }
                return o;
            }
        }),
        (Ve._isDomainFailure = i),
        Ve
    );
}
var Je,
    Ye = {};
function Xe() {
    if (Je) return Ye;
    (Je = 1),
        Object.defineProperty(Ye, "__esModule", { value: !0 }),
        (Ye.SDKFlags = void 0);
    const e = {};
    return (
        (Ye.SDKFlags = {
            setFlags: (t, n) => {
                e[t] = n;
            },
            get: (t, n) => {
                var r, s;
                return (
                    null !==
                        (s =
                            null === (r = e[t]) || void 0 === r
                                ? void 0
                                : r[n]) &&
                    void 0 !== s &&
                    s
                );
            },
        }),
        Ye
    );
}
var Qe,
    Ze = {};
function et() {
    return (
        Qe ||
            ((Qe = 1),
            (function (e) {
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.StatsigSession = e.SessionID = void 0);
                const t = S(),
                    n = L(),
                    r = E(),
                    s = Y(),
                    o = _e(),
                    i = 18e5,
                    a = 144e5,
                    c = {};
                function u(e, n) {
                    return setTimeout(() => {
                        var n;
                        const r =
                            null === (n = (0, t._getStatsigGlobal)()) ||
                            void 0 === n
                                ? void 0
                                : n.instance(e);
                        r && r.$emt({ name: "session_expired" });
                    }, n);
                }
                function l(e) {
                    return `statsig.session_id.${(0, n._getStorageKey)(e)}`;
                }
                (e.SessionID = {
                    get: (t) => e.StatsigSession.get(t).data.sessionID,
                }),
                    (e.StatsigSession = {
                        get: (e) => {
                            null == c[e] &&
                                (c[e] = (function (e) {
                                    let t = (function (e) {
                                        const t = l(e);
                                        return (0, s._getObjectFromStorage)(t);
                                    })(e);
                                    const n = Date.now();
                                    t ||
                                        (t = {
                                            sessionID: (0, o.getUUID)(),
                                            startTime: n,
                                            lastUpdate: n,
                                        });
                                    return { data: t, sdkKey: e };
                                })(e));
                            return (function (e) {
                                const t = Date.now(),
                                    n = e.data,
                                    c = e.sdkKey;
                                if (
                                    (function ({ lastUpdate: e }) {
                                        return Date.now() - e > i;
                                    })(n) ||
                                    (function ({ startTime: e }) {
                                        return Date.now() - e > a;
                                    })(n)
                                ) {
                                    (n.sessionID = (0, o.getUUID)()),
                                        (n.startTime = t);
                                    const e =
                                        null === __STATSIG__ ||
                                        void 0 === __STATSIG__
                                            ? void 0
                                            : __STATSIG__.instance(c);
                                    e && e.$emt({ name: "session_expired" });
                                }
                                (n.lastUpdate = t),
                                    (function (e, t) {
                                        const n = l(t);
                                        try {
                                            (0, s._setObjectInStorage)(n, e);
                                        } catch (o) {
                                            r.Log.warn(
                                                "Failed to save SessionID"
                                            );
                                        }
                                    })(n, e.sdkKey),
                                    clearTimeout(e.idleTimeoutID),
                                    clearTimeout(e.ageTimeoutID);
                                const d = t - n.startTime;
                                return (
                                    (e.idleTimeoutID = u(c, i)),
                                    (e.ageTimeoutID = u(c, a - d)),
                                    e
                                );
                            })(c[e]);
                        },
                        overrideInitialSessionID: (e, t) => {
                            c[t] = (function (e, t) {
                                const n = Date.now();
                                return {
                                    data: {
                                        sessionID: e,
                                        startTime: n,
                                        lastUpdate: n,
                                    },
                                    sdkKey: t,
                                };
                            })(e, t);
                        },
                    });
            })(Ze)),
        Ze
    );
}
var tt,
    nt,
    rt = {};
function st() {
    return (
        tt ||
            ((tt = 1),
            Object.defineProperty(rt, "__esModule", { value: !0 }),
            (rt.ErrorTag = void 0),
            (rt.ErrorTag = { NetworkError: "NetworkError" })),
        rt
    );
}
function ot() {
    if (nt) return qe;
    nt = 1;
    var e =
        (qe && qe.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(qe, "__esModule", { value: !0 }),
        (qe.NetworkCore = void 0),
        S();
    const t = S(),
        n = x(),
        r = E(),
        s = N(),
        o = He(),
        i = Xe(),
        a = Pe(),
        c = F(),
        u = et(),
        l = ge(),
        d = st(),
        f = ae(),
        h = W(),
        p = re(),
        _ = new Set([408, 500, 502, 503, 504, 522, 524, 599]);
    qe.NetworkCore = class {
        constructor(e, t) {
            (this._emitter = t),
                (this._errorBoundary = null),
                (this._timeout = 1e4),
                (this._netConfig = {}),
                (this._options = {}),
                (this._leakyBucket = {}),
                (this._lastUsedInitUrl = null),
                e && (this._options = e),
                this._options.networkConfig &&
                    (this._netConfig = this._options.networkConfig),
                this._netConfig.networkTimeoutMs &&
                    (this._timeout = this._netConfig.networkTimeoutMs),
                (this._fallbackResolver = new o.NetworkFallbackResolver(
                    this._options
                )),
                this.setLogEventCompressionMode(
                    this._getLogEventCompressionMode(e)
                );
        }
        setLogEventCompressionMode(e) {
            this._options.logEventCompressionMode = e;
        }
        setErrorBoundary(e) {
            (this._errorBoundary = e),
                this._errorBoundary.wrap(this),
                this._errorBoundary.wrap(this._fallbackResolver),
                this._fallbackResolver.setErrorBoundary(e);
        }
        isBeaconSupported() {
            return (
                "undefined" != typeof navigator &&
                "function" == typeof navigator.sendBeacon
            );
        }
        getLastUsedInitUrlAndReset() {
            const e = this._lastUsedInitUrl;
            return (this._lastUsedInitUrl = null), e;
        }
        beacon(e) {
            if (!g(e)) return !1;
            const t = this._getInternalRequestArgs("POST", e),
                n = this._getPopulatedURL(t),
                r = navigator;
            return r.sendBeacon.bind(r)(n, t.body);
        }
        post(t) {
            return e(this, void 0, void 0, function* () {
                const e = this._getInternalRequestArgs("POST", t);
                return (
                    this._tryEncodeBody(e),
                    yield this._tryToCompressBody(e),
                    this._sendRequest(e)
                );
            });
        }
        get(e) {
            const t = this._getInternalRequestArgs("GET", e);
            return this._sendRequest(t);
        }
        _sendRequest(t) {
            return e(this, void 0, void 0, function* () {
                var o, i, a, c;
                if (!g(t)) return null;
                if (this._netConfig.preventAllNetworkTraffic) return null;
                const { method: u, body: l, retries: f, attempt: h } = t,
                    v = t.urlConfig.endpoint;
                if (this._isRateLimited(v))
                    return (
                        r.Log.warn(
                            `Request to ${v} was blocked because you are making requests too frequently.`
                        ),
                        null
                    );
                const y = null != h ? h : 1,
                    b =
                        "undefined" != typeof AbortController
                            ? new AbortController()
                            : null,
                    E = setTimeout(() => {
                        null == b ||
                            b.abort(`Timeout of ${this._timeout}ms expired.`);
                    }, this._timeout),
                    S = this._getPopulatedURL(t);
                let k = null;
                const w = (0, p._isUnloading)();
                try {
                    const e = {
                        method: u,
                        body: l,
                        headers: Object.assign({}, t.headers),
                        signal: null == b ? void 0 : b.signal,
                        priority: t.priority,
                        keepalive: w,
                    };
                    !(function (e, t) {
                        if (e.urlConfig.endpoint !== s.Endpoint._initialize)
                            return;
                        n.Diagnostics._markInitNetworkReqStart(e.sdkKey, {
                            attempt: t,
                        });
                    })(t, y);
                    const r = this._leakyBucket[v];
                    r &&
                        ((r.lastRequestTime = Date.now()),
                        (this._leakyBucket[v] = r));
                    const i =
                        null !== (o = this._netConfig.networkOverrideFunc) &&
                        void 0 !== o
                            ? o
                            : fetch;
                    if (((k = yield i(S, e)), clearTimeout(E), !k.ok)) {
                        const e = yield k.text().catch(() => "No Text"),
                            t = new Error(`NetworkError: ${S} ${e}`);
                        throw ((t.name = "NetworkError"), t);
                    }
                    const a = yield k.text();
                    return (
                        m(t, k, y, a),
                        this._fallbackResolver.tryBumpExpiryTime(
                            t.sdkKey,
                            t.urlConfig
                        ),
                        { body: a, code: k.status }
                    );
                } catch (O) {
                    const n = (function (e, t) {
                            if (
                                (null == e ? void 0 : e.signal.aborted) &&
                                "string" == typeof e.signal.reason
                            )
                                return e.signal.reason;
                            if ("string" == typeof t) return t;
                            if (t instanceof Error)
                                return `${t.name}: ${t.message}`;
                            return "Unknown Error";
                        })(b, O),
                        s =
                            ((null == (x = b) ? void 0 : x.signal.aborted) &&
                                "string" == typeof x.signal.reason &&
                                x.signal.reason.includes("Timeout")) ||
                            !1;
                    m(t, k, y, "", O);
                    if (
                        ((yield this._fallbackResolver.tryFetchUpdatedFallbackInfo(
                            t.sdkKey,
                            t.urlConfig,
                            n,
                            s
                        )) &&
                            (t.fallbackUrl =
                                this._fallbackResolver.getActiveFallbackUrl(
                                    t.sdkKey,
                                    t.urlConfig
                                )),
                        !f ||
                            y > f ||
                            !_.has(
                                null !== (i = null == k ? void 0 : k.status) &&
                                    void 0 !== i
                                    ? i
                                    : 500
                            ))
                    ) {
                        null === (a = this._emitter) ||
                            void 0 === a ||
                            a.call(this, {
                                name: "error",
                                error: O,
                                tag: d.ErrorTag.NetworkError,
                                requestArgs: t,
                            });
                        const e = `A networking error occurred during ${u} request to ${S}.`;
                        return (
                            r.Log.error(e, n, O),
                            null === (c = this._errorBoundary) ||
                                void 0 === c ||
                                c.attachErrorIfNoneExists(e),
                            null
                        );
                    }
                    return (
                        yield (function (t) {
                            return e(this, void 0, void 0, function* () {
                                yield new Promise((e) =>
                                    setTimeout(e, Math.min(t * t * 500, 3e4))
                                );
                            });
                        })(y),
                        this._sendRequest(
                            Object.assign(Object.assign({}, t), {
                                retries: f,
                                attempt: y + 1,
                            })
                        )
                    );
                }
                var x;
            });
        }
        _getLogEventCompressionMode(e) {
            let t = null == e ? void 0 : e.logEventCompressionMode;
            return (
                t ||
                    !0 !== (null == e ? void 0 : e.disableCompression) ||
                    (t = h.LogEventCompressionMode.Disabled),
                t || (t = h.LogEventCompressionMode.Enabled),
                t
            );
        }
        _isRateLimited(e) {
            var t;
            const n = Date.now(),
                r =
                    null !== (t = this._leakyBucket[e]) && void 0 !== t
                        ? t
                        : { count: 0, lastRequestTime: n },
                s = n - r.lastRequestTime,
                o = Math.floor(0.05 * s);
            return (
                (r.count = Math.max(0, r.count - o)),
                r.count >= 50 ||
                    ((r.count += 1),
                    (r.lastRequestTime = n),
                    (this._leakyBucket[e] = r),
                    !1)
            );
        }
        _getPopulatedURL(e) {
            var t;
            const n =
                null !== (t = e.fallbackUrl) && void 0 !== t
                    ? t
                    : e.urlConfig.getUrl();
            (e.urlConfig.endpoint !== s.Endpoint._initialize &&
                e.urlConfig.endpoint !== s.Endpoint._download_config_specs) ||
                (this._lastUsedInitUrl = n);
            const r = Object.assign(
                    {
                        [s.NetworkParam.SdkKey]: e.sdkKey,
                        [s.NetworkParam.SdkType]: a.SDKType._get(e.sdkKey),
                        [s.NetworkParam.SdkVersion]: f.SDK_VERSION,
                        [s.NetworkParam.Time]: String(Date.now()),
                        [s.NetworkParam.SessionID]: u.SessionID.get(e.sdkKey),
                    },
                    e.params
                ),
                o = Object.keys(r)
                    .map(
                        (e) =>
                            `${encodeURIComponent(e)}=${encodeURIComponent(
                                r[e]
                            )}`
                    )
                    .join("&");
            return `${n}${o ? `?${o}` : ""}`;
        }
        _tryEncodeBody(e) {
            var n;
            const o = (0, c._getWindowSafe)(),
                i = e.body;
            if (
                e.isStatsigEncodable &&
                !this._options.disableStatsigEncoding &&
                "string" == typeof i &&
                null == (0, t._getStatsigGlobalFlag)("no-encode") &&
                (null == o ? void 0 : o.btoa)
            )
                try {
                    (e.body = o.btoa(i).split("").reverse().join("")),
                        (e.params = Object.assign(
                            Object.assign(
                                {},
                                null !== (n = e.params) && void 0 !== n ? n : {}
                            ),
                            { [s.NetworkParam.StatsigEncoded]: "1" }
                        ));
                } catch (a) {
                    r.Log.warn(
                        `Request encoding failed for ${e.urlConfig.getUrl()}`,
                        a
                    );
                }
        }
        _tryToCompressBody(n) {
            return e(this, void 0, void 0, function* () {
                var e;
                const o = n.body;
                if (
                    "string" == typeof o &&
                    (function (e, n) {
                        if (!e.isCompressable) return !1;
                        if (
                            null !=
                                (0, t._getStatsigGlobalFlag)("no-compress") ||
                            "undefined" == typeof CompressionStream ||
                            "undefined" == typeof TextEncoder
                        )
                            return !1;
                        const r =
                                null != e.urlConfig.customUrl ||
                                null != e.urlConfig.fallbackUrls,
                            s =
                                !0 ===
                                i.SDKFlags.get(
                                    e.sdkKey,
                                    "enable_log_event_compression"
                                );
                        switch (n.logEventCompressionMode) {
                            case h.LogEventCompressionMode.Disabled:
                                return !1;
                            case h.LogEventCompressionMode.Enabled:
                                return !(r && !s);
                            case h.LogEventCompressionMode.Forced:
                                return !0;
                            default:
                                return !1;
                        }
                    })(n, this._options)
                )
                    try {
                        const t = new TextEncoder().encode(o),
                            i = new CompressionStream("gzip"),
                            a = i.writable.getWriter();
                        a.write(t).catch(r.Log.error),
                            a.close().catch(r.Log.error);
                        const c = i.readable.getReader(),
                            u = [];
                        let l;
                        for (; !(l = yield c.read()).done; ) u.push(l.value);
                        const d = u.reduce((e, t) => e + t.length, 0),
                            f = new Uint8Array(d);
                        let h = 0;
                        for (const e of u) f.set(e, h), (h += e.length);
                        (n.body = f),
                            (n.params = Object.assign(
                                Object.assign(
                                    {},
                                    null !== (e = n.params) && void 0 !== e
                                        ? e
                                        : {}
                                ),
                                { [s.NetworkParam.IsGzipped]: "1" }
                            ));
                    } catch (a) {
                        r.Log.warn(
                            `Request compression failed for ${n.urlConfig.getUrl()}`,
                            a
                        );
                    }
            });
        }
        _getInternalRequestArgs(e, t) {
            const n = this._fallbackResolver.getActiveFallbackUrl(
                    t.sdkKey,
                    t.urlConfig
                ),
                r = Object.assign(Object.assign({}, t), {
                    method: e,
                    fallbackUrl: n,
                });
            return "data" in t && v(r, t.data), r;
        }
    };
    const g = (e) =>
            !!e.sdkKey ||
            (r.Log.warn("Unable to make request without an SDK key"), !1),
        v = (e, t) => {
            const { sdkKey: n, fallbackUrl: r } = e,
                s = l.StableID.get(n),
                o = u.SessionID.get(n),
                i = a.SDKType._get(n);
            e.body = JSON.stringify(
                Object.assign(Object.assign({}, t), {
                    statsigMetadata: Object.assign(
                        Object.assign({}, f.StatsigMetadataProvider.get()),
                        {
                            stableID: s,
                            sessionID: o,
                            sdkType: i,
                            fallbackUrl: r,
                        }
                    ),
                })
            );
        };
    function m(e, t, r, o, i) {
        e.urlConfig.endpoint === s.Endpoint._initialize &&
            n.Diagnostics._markInitNetworkReqEnd(
                e.sdkKey,
                n.Diagnostics._getDiagnosticsData(t, r, o, i)
            );
    }
    return qe;
}
var it,
    at = {};
var ct,
    ut = {};
var lt,
    dt = {};
var ft,
    ht = {};
function pt() {
    if (ft) return ht;
    ft = 1;
    var e =
        (ht && ht.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(ht, "__esModule", { value: !0 }),
        (ht.StatsigClientBase = void 0),
        S();
    const t = S(),
        n = Ae(),
        r = se(),
        s = E(),
        o = Fe(),
        i = F(),
        a = et(),
        c = ge(),
        u = W(),
        l = Y();
    return (
        (ht.StatsigClientBase = class {
            constructor(e, o, u, d) {
                var f, h, p, _;
                (this.loadingStatus = "Uninitialized"),
                    (this._initializePromise = null),
                    (this._listeners = {});
                const g = this.$emt.bind(this);
                null != (null == d ? void 0 : d.logLevel) &&
                    (s.Log.level = d.logLevel),
                    (null == d ? void 0 : d.disableStorage) &&
                        l.Storage._setDisabled(!0),
                    (null == d ? void 0 : d.initialSessionID) &&
                        a.StatsigSession.overrideInitialSessionID(
                            d.initialSessionID,
                            e
                        ),
                    (null == d ? void 0 : d.storageProvider) &&
                        l.Storage._setProvider(d.storageProvider),
                    (null == d ? void 0 : d.enableCookies) &&
                        c.StableID._setCookiesEnabled(e, d.enableCookies),
                    (null == d ? void 0 : d.disableStableID) &&
                        c.StableID._setDisabled(e, !0),
                    (this._sdkKey = e),
                    (this._options = null != d ? d : {}),
                    (this._memoCache = {}),
                    (this.overrideAdapter =
                        null !== (f = null == d ? void 0 : d.overrideAdapter) &&
                        void 0 !== f
                            ? f
                            : null),
                    (this._logger = new r.EventLogger(e, g, u, d)),
                    (this._errorBoundary = new n.ErrorBoundary(e, d, g)),
                    this._errorBoundary.wrap(this),
                    this._errorBoundary.wrap(o),
                    this._errorBoundary.wrap(this._logger),
                    u.setErrorBoundary(this._errorBoundary),
                    (this.dataAdapter = o),
                    this.dataAdapter.attach(e, d, u),
                    (this.storageProvider = l.Storage),
                    null ===
                        (_ =
                            null ===
                                (p =
                                    null === (h = this.overrideAdapter) ||
                                    void 0 === h
                                        ? void 0
                                        : h.loadFromStorage) || void 0 === p
                                ? void 0
                                : p.call(h)) ||
                        void 0 === _ ||
                        _.catch((e) =>
                            this._errorBoundary.logError(
                                "OA::loadFromStorage",
                                e
                            )
                        ),
                    this._primeReadyRipcord(),
                    (function (e, n) {
                        var r;
                        if ((0, i._isServerEnv)()) return;
                        const o = (0, t._getStatsigGlobal)(),
                            a =
                                null !== (r = o.instances) && void 0 !== r
                                    ? r
                                    : {},
                            c = n;
                        null != a[e] &&
                            s.Log.warn(
                                "Creating multiple Statsig clients with the same SDK key can lead to unexpected behavior. Multi-instance support requires different SDK keys."
                            );
                        (a[e] = c), o.firstInstance || (o.firstInstance = c);
                        (o.instances = a), (__STATSIG__ = o);
                    })(e, this);
            }
            updateRuntimeOptions(e) {
                e.loggingEnabled
                    ? ((this._options.loggingEnabled = e.loggingEnabled),
                      this._logger.setLoggingEnabled(e.loggingEnabled))
                    : null != e.disableLogging &&
                      ((this._options.disableLogging = e.disableLogging),
                      this._logger.setLoggingEnabled(
                          e.disableLogging ? "disabled" : "browser-only"
                      )),
                    null != e.disableStorage &&
                        ((this._options.disableStorage = e.disableStorage),
                        l.Storage._setDisabled(e.disableStorage)),
                    null != e.enableCookies &&
                        ((this._options.enableCookies = e.enableCookies),
                        c.StableID._setCookiesEnabled(
                            this._sdkKey,
                            e.enableCookies
                        )),
                    e.logEventCompressionMode
                        ? this._logger.setLogEventCompressionMode(
                              e.logEventCompressionMode
                          )
                        : e.disableCompression &&
                          this._logger.setLogEventCompressionMode(
                              u.LogEventCompressionMode.Disabled
                          );
            }
            flush() {
                return this._logger.flush();
            }
            shutdown() {
                return e(this, void 0, void 0, function* () {
                    this.$emt({ name: "pre_shutdown" }),
                        this._setStatus("Uninitialized", null),
                        (this._initializePromise = null),
                        yield this._logger.stop();
                });
            }
            on(e, t) {
                this._listeners[e] || (this._listeners[e] = []),
                    this._listeners[e].push(t);
            }
            off(e, t) {
                if (this._listeners[e]) {
                    const n = this._listeners[e].indexOf(t);
                    -1 !== n && this._listeners[e].splice(n, 1);
                }
            }
            $on(e, t) {
                (t.__isInternal = !0), this.on(e, t);
            }
            $emt(e) {
                var t;
                const n = (t) => {
                    try {
                        t(e);
                    } catch (n) {
                        if (!0 === t.__isInternal)
                            return void this._errorBoundary.logError(
                                `__emit:${e.name}`,
                                n
                            );
                        s.Log.error(
                            "An error occurred in a StatsigClientEvent listener. This is not an issue with Statsig.",
                            e
                        );
                    }
                };
                this._listeners[e.name] &&
                    this._listeners[e.name].forEach((e) => n(e)),
                    null === (t = this._listeners["*"]) ||
                        void 0 === t ||
                        t.forEach(n);
            }
            _setStatus(e, t) {
                (this.loadingStatus = e),
                    (this._memoCache = {}),
                    this.$emt({ name: "values_updated", status: e, values: t });
            }
            _enqueueExposure(e, t, n) {
                !0 !== (null == n ? void 0 : n.disableExposureLog)
                    ? this._logger.enqueue(t)
                    : this._logger.incrementNonExposureCount(e);
            }
            _memoize(e, t) {
                return (n, r) => {
                    if (this._options.disableEvaluationMemoization)
                        return t(n, r);
                    const s = (0, o.createMemoKey)(e, n, r);
                    return s
                        ? (s in this._memoCache ||
                              (Object.keys(this._memoCache).length >= 3e3 &&
                                  (this._memoCache = {}),
                              (this._memoCache[s] = t(n, r))),
                          this._memoCache[s])
                        : t(n, r);
                };
            }
        }),
        ht
    );
}
var _t,
    gt = {};
var vt,
    mt = {};
var yt,
    bt = {};
var Et,
    St = {};
var kt,
    wt,
    xt = {};
function Ot() {
    return (
        wt ||
            ((wt = 1),
            (function (e) {
                var t =
                        (m && m.__createBinding) ||
                        (Object.create
                            ? function (e, t, n, r) {
                                  void 0 === r && (r = n);
                                  var s = Object.getOwnPropertyDescriptor(t, n);
                                  (s &&
                                      !("get" in s
                                          ? !t.__esModule
                                          : s.writable || s.configurable)) ||
                                      (s = {
                                          enumerable: !0,
                                          get: function () {
                                              return t[n];
                                          },
                                      }),
                                      Object.defineProperty(e, r, s);
                              }
                            : function (e, t, n, r) {
                                  void 0 === r && (r = n), (e[r] = t[n]);
                              }),
                    n =
                        (m && m.__exportStar) ||
                        function (e, n) {
                            for (var r in e)
                                "default" === r ||
                                    Object.prototype.hasOwnProperty.call(
                                        n,
                                        r
                                    ) ||
                                    t(n, e, r);
                        };
                Object.defineProperty(e, "__esModule", { value: !0 }),
                    (e.Storage =
                        e.Log =
                        e.EventLogger =
                        e.Diagnostics =
                            void 0),
                    S();
                const r = S(),
                    s = x();
                Object.defineProperty(e, "Diagnostics", {
                    enumerable: !0,
                    get: function () {
                        return s.Diagnostics;
                    },
                });
                const o = se();
                Object.defineProperty(e, "EventLogger", {
                    enumerable: !0,
                    get: function () {
                        return o.EventLogger;
                    },
                });
                const i = E();
                Object.defineProperty(e, "Log", {
                    enumerable: !0,
                    get: function () {
                        return i.Log;
                    },
                });
                const a = ae(),
                    c = Y();
                Object.defineProperty(e, "Storage", {
                    enumerable: !0,
                    get: function () {
                        return c.Storage;
                    },
                }),
                    n(S(), e),
                    n(L(), e),
                    n(
                        (ce ||
                            ((ce = 1),
                            Object.defineProperty(ue, "__esModule", {
                                value: !0,
                            })),
                        ue),
                        e
                    ),
                    n(we(), e),
                    n(x(), e),
                    n(
                        (xe ||
                            ((xe = 1),
                            Object.defineProperty(Oe, "__esModule", {
                                value: !0,
                            })),
                        Oe),
                        e
                    ),
                    n(Ae(), e),
                    n(
                        (je ||
                            ((je = 1),
                            Object.defineProperty(Re, "__esModule", {
                                value: !0,
                            })),
                        Re),
                        e
                    ),
                    n(
                        (Le ||
                            ((Le = 1),
                            Object.defineProperty(Ue, "__esModule", {
                                value: !0,
                            })),
                        Ue),
                        e
                    ),
                    n(R(), e),
                    n(
                        (Me ||
                            ((Me = 1),
                            Object.defineProperty(Ne, "__esModule", {
                                value: !0,
                            })),
                        Ne),
                        e
                    ),
                    n(E(), e),
                    n(Fe(), e),
                    n(N(), e),
                    n(ot(), e),
                    n(
                        (it ||
                            ((it = 1),
                            Object.defineProperty(at, "__esModule", {
                                value: !0,
                            })),
                        at),
                        e
                    ),
                    n(
                        (ct ||
                            ((ct = 1),
                            Object.defineProperty(ut, "__esModule", {
                                value: !0,
                            })),
                        ut),
                        e
                    ),
                    n(F(), e),
                    n(Pe(), e),
                    n(et(), e),
                    n(
                        (lt ||
                            ((lt = 1),
                            (function (e) {
                                Object.defineProperty(e, "__esModule", {
                                    value: !0,
                                }),
                                    (e._fastApproxSizeOf = void 0),
                                    (e._fastApproxSizeOf = (t, n) => {
                                        let r = 0;
                                        const s = Object.keys(t);
                                        for (let o = 0; o < s.length; o++) {
                                            const i = s[o],
                                                a = t[i];
                                            if (
                                                ((r += i.length),
                                                (r +=
                                                    "object" == typeof a &&
                                                    null !== a
                                                        ? (0,
                                                          e._fastApproxSizeOf)(
                                                              a,
                                                              n
                                                          ) + 2
                                                        : String(a).length + 1),
                                                r >= n)
                                            )
                                                return r;
                                        }
                                        return r;
                                    });
                            })(dt)),
                        dt),
                        e
                    ),
                    n(ge(), e),
                    n(pt(), e),
                    n(st(), e),
                    n(
                        (_t ||
                            ((_t = 1),
                            Object.defineProperty(gt, "__esModule", {
                                value: !0,
                            }),
                            (gt.DataAdapterCachePrefix = void 0),
                            (gt.DataAdapterCachePrefix = "statsig.cached")),
                        gt),
                        e
                    ),
                    n(q(), e),
                    n(ae(), e),
                    n(W(), e),
                    n(
                        (vt ||
                            ((vt = 1),
                            Object.defineProperty(mt, "__esModule", {
                                value: !0,
                            })),
                        mt),
                        e
                    ),
                    n(
                        (function () {
                            if (yt) return bt;
                            (yt = 1),
                                Object.defineProperty(bt, "__esModule", {
                                    value: !0,
                                }),
                                (bt._makeTypedGet =
                                    bt._mergeOverride =
                                    bt._makeLayer =
                                    bt._makeExperiment =
                                    bt._makeDynamicConfig =
                                    bt._makeFeatureGate =
                                        void 0);
                            const e = E(),
                                t = j();
                            function n(e, t, n, r) {
                                var s;
                                return {
                                    name: e,
                                    details: t,
                                    ruleID:
                                        null !==
                                            (s =
                                                null == n
                                                    ? void 0
                                                    : n.rule_id) && void 0 !== s
                                            ? s
                                            : "",
                                    __evaluation: n,
                                    value: r,
                                };
                            }
                            function r(e, t, r) {
                                var o;
                                const i =
                                    null !==
                                        (o = null == r ? void 0 : r.value) &&
                                    void 0 !== o
                                        ? o
                                        : {};
                                return Object.assign(
                                    Object.assign({}, n(e, t, r, i)),
                                    { get: s(e, null == r ? void 0 : r.value) }
                                );
                            }
                            function s(n, r, s) {
                                return (o, i) => {
                                    var a;
                                    const c =
                                        null !==
                                            (a = null == r ? void 0 : r[o]) &&
                                        void 0 !== a
                                            ? a
                                            : null;
                                    return null == c
                                        ? null != i
                                            ? i
                                            : null
                                        : null == i || (0, t._isTypeMatch)(c, i)
                                        ? (null == s || s(o), c)
                                        : (e.Log.warn(
                                              `Parameter type mismatch. '${n}.${o}' was found to be type '${typeof c}' but fallback/return type is '${typeof i}'. See https://docs.statsig.com/client/javascript-sdk/#typed-getters`
                                          ),
                                          null != i ? i : null);
                                };
                            }
                            return (
                                (bt._makeFeatureGate = function (e, t, r) {
                                    var s;
                                    return Object.assign(
                                        Object.assign(
                                            {},
                                            n(
                                                e,
                                                t,
                                                r,
                                                !0 ===
                                                    (null == r
                                                        ? void 0
                                                        : r.value)
                                            )
                                        ),
                                        {
                                            idType:
                                                null !==
                                                    (s =
                                                        null == r
                                                            ? void 0
                                                            : r.id_type) &&
                                                void 0 !== s
                                                    ? s
                                                    : null,
                                        }
                                    );
                                }),
                                (bt._makeDynamicConfig = r),
                                (bt._makeExperiment = function (e, t, n) {
                                    var s;
                                    const o = r(e, t, n);
                                    return Object.assign(Object.assign({}, o), {
                                        groupName:
                                            null !==
                                                (s =
                                                    null == n
                                                        ? void 0
                                                        : n.group_name) &&
                                            void 0 !== s
                                                ? s
                                                : null,
                                    });
                                }),
                                (bt._makeLayer = function (e, t, r, o) {
                                    var i, a;
                                    return Object.assign(
                                        Object.assign({}, n(e, t, r, void 0)),
                                        {
                                            get: s(
                                                e,
                                                null == r ? void 0 : r.value,
                                                o
                                            ),
                                            groupName:
                                                null !==
                                                    (i =
                                                        null == r
                                                            ? void 0
                                                            : r.group_name) &&
                                                void 0 !== i
                                                    ? i
                                                    : null,
                                            __value:
                                                null !==
                                                    (a =
                                                        null == r
                                                            ? void 0
                                                            : r.value) &&
                                                void 0 !== a
                                                    ? a
                                                    : {},
                                        }
                                    );
                                }),
                                (bt._mergeOverride = function (e, t, n, r) {
                                    return Object.assign(
                                        Object.assign(Object.assign({}, e), t),
                                        { get: s(e.name, n, r) }
                                    );
                                }),
                                (bt._makeTypedGet = s),
                                bt
                            );
                        })(),
                        e
                    ),
                    n(
                        (Et ||
                            ((Et = 1),
                            Object.defineProperty(St, "__esModule", {
                                value: !0,
                            })),
                        St),
                        e
                    ),
                    n(ye(), e),
                    n(Y(), e),
                    n(ke(), e),
                    n(j(), e),
                    n(Z(), e),
                    n(_e(), e),
                    n(re(), e),
                    n(
                        (kt ||
                            ((kt = 1),
                            Object.defineProperty(xt, "__esModule", {
                                value: !0,
                            }),
                            (xt.UPDATE_DETAIL_ERROR_MESSAGES =
                                xt.createUpdateDetails =
                                    void 0),
                            (xt.createUpdateDetails = (e, t, n, r, s, o) => ({
                                duration: n,
                                source: t,
                                success: e,
                                error: r,
                                sourceUrl: s,
                                warnings: o,
                            })),
                            (xt.UPDATE_DETAIL_ERROR_MESSAGES = {
                                NO_NETWORK_DATA:
                                    "No data was returned from the network. This may be due to a network timeout if a timeout value was specified in the options or ad blocker error.",
                            })),
                        xt),
                        e
                    ),
                    n(Xe(), e),
                    Object.assign((0, r._getStatsigGlobal)(), {
                        Log: i.Log,
                        SDK_VERSION: a.SDK_VERSION,
                    });
            })(m)),
        m
    );
}
var It,
    Dt = {},
    Ct = {};
var Tt,
    Pt,
    At = {},
    jt = {};
function Rt() {
    if (Tt) return jt;
    (Tt = 1),
        Object.defineProperty(jt, "__esModule", { value: !0 }),
        (jt._resolveDeltasResponse = void 0);
    const e = Ot();
    function t(e, t) {
        null == e ||
            e.forEach((e) => {
                delete t[e];
            });
    }
    return (
        (jt._resolveDeltasResponse = function (n, r) {
            const s = (0, e._typedJsonParse)(
                r,
                "checksum",
                "DeltasEvaluationResponse"
            );
            if (!s) return { hadBadDeltaChecksum: !0 };
            const o = (function (e) {
                    const n = e;
                    return (
                        t(e.deleted_gates, n.feature_gates),
                        delete n.deleted_gates,
                        t(e.deleted_configs, n.dynamic_configs),
                        delete n.deleted_configs,
                        t(e.deleted_layers, n.layer_configs),
                        delete n.deleted_layers,
                        n
                    );
                })(
                    (function (e, t) {
                        return Object.assign(
                            Object.assign(Object.assign({}, e), t),
                            {
                                feature_gates: Object.assign(
                                    Object.assign({}, e.feature_gates),
                                    t.feature_gates
                                ),
                                layer_configs: Object.assign(
                                    Object.assign({}, e.layer_configs),
                                    t.layer_configs
                                ),
                                dynamic_configs: Object.assign(
                                    Object.assign({}, e.dynamic_configs),
                                    t.dynamic_configs
                                ),
                            }
                        );
                    })(n, s)
                ),
                i = (0, e._DJB2Object)(
                    {
                        feature_gates: o.feature_gates,
                        dynamic_configs: o.dynamic_configs,
                        layer_configs: o.layer_configs,
                    },
                    2
                );
            return i === s.checksumV2
                ? JSON.stringify(o)
                : {
                      hadBadDeltaChecksum: !0,
                      badChecksum: i,
                      badMergedConfigs: o,
                      badFullResponse: s.deltas_full_response,
                  };
        }),
        jt
    );
}
function Lt() {
    if (Pt) return At;
    Pt = 1;
    var e =
        (At && At.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(At, "__esModule", { value: !0 });
    const t = Ot(),
        n = Rt();
    class r extends t.NetworkCore {
        constructor(e, n) {
            super(e, n);
            const r = null == e ? void 0 : e.networkConfig;
            (this._option = e),
                (this._initializeUrlConfig = new t.UrlConfiguration(
                    t.Endpoint._initialize,
                    null == r ? void 0 : r.initializeUrl,
                    null == r ? void 0 : r.api,
                    null == r ? void 0 : r.initializeFallbackUrls
                ));
        }
        fetchEvaluations(n, r, s, o, i) {
            return e(this, void 0, void 0, function* () {
                var e, a, c, u, l, d;
                const f = r
                    ? (0, t._typedJsonParse)(
                          r,
                          "has_updates",
                          "InitializeResponse"
                      )
                    : null;
                let h = {
                    user: o,
                    hash:
                        null !==
                            (c =
                                null ===
                                    (a =
                                        null === (e = this._option) ||
                                        void 0 === e
                                            ? void 0
                                            : e.networkConfig) || void 0 === a
                                    ? void 0
                                    : a.initializeHashAlgorithm) && void 0 !== c
                            ? c
                            : "djb2",
                    deltasResponseRequested: !1,
                    full_checksum: null,
                };
                if (null == f ? void 0 : f.has_updates) {
                    const e =
                        (null == f ? void 0 : f.hash_used) !==
                        (null !==
                            (d =
                                null ===
                                    (l =
                                        null === (u = this._option) ||
                                        void 0 === u
                                            ? void 0
                                            : u.networkConfig) || void 0 === l
                                    ? void 0
                                    : l.initializeHashAlgorithm) && void 0 !== d
                            ? d
                            : "djb2");
                    h = Object.assign(Object.assign({}, h), {
                        sinceTime: i && !e ? f.time : 0,
                        previousDerivedFields:
                            "derived_fields" in f && i ? f.derived_fields : {},
                        deltasResponseRequested: !0,
                        full_checksum: f.full_checksum,
                        partialUserMatchSinceTime: e ? 0 : f.time,
                    });
                }
                return this._fetchEvaluations(n, f, h, s);
            });
        }
        _fetchEvaluations(t, r, s, o) {
            return e(this, void 0, void 0, function* () {
                var e, i;
                const a = yield this.post({
                    sdkKey: t,
                    urlConfig: this._initializeUrlConfig,
                    data: s,
                    retries: 2,
                    isStatsigEncodable: !0,
                    priority: o,
                });
                if (204 === (null == a ? void 0 : a.code))
                    return '{"has_updates": false}';
                if (200 !== (null == a ? void 0 : a.code))
                    return null !== (e = null == a ? void 0 : a.body) &&
                        void 0 !== e
                        ? e
                        : null;
                if (
                    !0 !== (null == r ? void 0 : r.has_updates) ||
                    !0 !==
                        (null === (i = a.body) || void 0 === i
                            ? void 0
                            : i.includes('"is_delta":true')) ||
                    !0 !== s.deltasResponseRequested
                )
                    return a.body;
                const c = (0, n._resolveDeltasResponse)(r, a.body);
                return "string" == typeof c
                    ? c
                    : this._fetchEvaluations(
                          t,
                          r,
                          Object.assign(
                              Object.assign(Object.assign({}, s), c),
                              { deltasResponseRequested: !1 }
                          ),
                          o
                      );
            });
        }
    }
    return (At.default = r), At;
}
var Ut,
    Mt = {};
function Nt() {
    if (Ut) return Mt;
    (Ut = 1),
        Object.defineProperty(Mt, "__esModule", { value: !0 }),
        (Mt._makeParamStoreGetter = void 0);
    const e = Ot(),
        t = { disableExposureLog: !0 };
    function n(e) {
        return null == e || !1 === e.disableExposureLog;
    }
    function r(t, n) {
        return null != n && !(0, e._isTypeMatch)(t, n);
    }
    return (
        (Mt._makeParamStoreGetter = function (s, o, i) {
            return (a, c) => {
                if (null == o) return c;
                const u = o[a];
                if (
                    null == u ||
                    (null != c && (0, e._typeOf)(c) !== u.param_type)
                )
                    return c;
                switch (u.ref_type) {
                    case "static":
                        return (function (e) {
                            return e.value;
                        })(u);
                    case "gate":
                        return (function (e, r, s) {
                            return e.getFeatureGate(
                                r.gate_name,
                                n(s) ? void 0 : t
                            ).value
                                ? r.pass_value
                                : r.fail_value;
                        })(s, u, i);
                    case "dynamic_config":
                        return (function (e, s, o, i) {
                            const a = e
                                .getDynamicConfig(
                                    s.config_name,
                                    n(i) ? void 0 : t
                                )
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    case "experiment":
                        return (function (e, s, o, i) {
                            const a = e
                                .getExperiment(
                                    s.experiment_name,
                                    n(i) ? void 0 : t
                                )
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    case "layer":
                        return (function (e, s, o, i) {
                            const a = e
                                .getLayer(s.layer_name, n(i) ? void 0 : t)
                                .get(s.param_name);
                            return r(a, o) ? o : a;
                        })(s, u, c, i);
                    default:
                        return c;
                }
            };
        }),
        Mt
    );
}
var $t,
    Kt,
    Ft,
    Bt = {};
function zt() {
    if ($t) return Bt;
    $t = 1;
    var e =
        (Bt && Bt.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Bt, "__esModule", { value: !0 }),
        (Bt.StatsigEvaluationsDataAdapter = void 0);
    const t = Ot(),
        n = Lt();
    let r = class extends t.DataAdapterCore {
        constructor() {
            super("EvaluationsDataAdapter", "evaluations"),
                (this._network = null),
                (this._options = null);
        }
        attach(e, t, r) {
            super.attach(e, t, r),
                null !== r && r instanceof n.default
                    ? (this._network = r)
                    : (this._network = new n.default(null != t ? t : {}));
        }
        getDataAsync(e, n, r) {
            return this._getDataAsyncImpl(
                e,
                (0, t._normalizeUser)(n, this._options),
                r
            );
        }
        prefetchData(e, t) {
            return this._prefetchDataImpl(e, t);
        }
        setData(e) {
            const n = (0, t._typedJsonParse)(e, "has_updates", "data");
            n && "user" in n
                ? super.setData(e, n.user)
                : t.Log.error(
                      "StatsigUser not found. You may be using an older server SDK version. Please upgrade your SDK or use setDataLegacy."
                  );
        }
        setDataLegacy(e, t) {
            super.setData(e, t);
        }
        _fetchFromNetwork(t, n, r, s) {
            return e(this, void 0, void 0, function* () {
                var e;
                const o = yield null === (e = this._network) || void 0 === e
                    ? void 0
                    : e.fetchEvaluations(
                          this._getSdkKey(),
                          t,
                          null == r ? void 0 : r.priority,
                          n,
                          s
                      );
                return null != o ? o : null;
            });
        }
        _getCacheKey(e) {
            var n;
            const r = (0, t._getStorageKey)(
                this._getSdkKey(),
                e,
                null === (n = this._options) || void 0 === n
                    ? void 0
                    : n.customUserCacheKeyFunc
            );
            return `${t.DataAdapterCachePrefix}.${this._cacheSuffix}.${r}`;
        }
        _isCachedResultValidFor204(e, n) {
            return (
                null != e.fullUserHash &&
                e.fullUserHash === (0, t._getFullUserHash)(n)
            );
        }
    };
    return (Bt.StatsigEvaluationsDataAdapter = r), Bt;
}
function qt() {
    if (Kt) return Dt;
    Kt = 1;
    var e =
        (Dt && Dt.__awaiter) ||
        function (e, t, n, r) {
            return new (n || (n = Promise))(function (s, o) {
                function i(e) {
                    try {
                        c(r.next(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e));
                    } catch (t) {
                        o(t);
                    }
                }
                function c(e) {
                    var t;
                    e.done
                        ? s(e.value)
                        : ((t = e.value),
                          t instanceof n
                              ? t
                              : new n(function (e) {
                                    e(t);
                                })).then(i, a);
                }
                c((r = r.apply(e, t || [])).next());
            });
        };
    Object.defineProperty(Dt, "__esModule", { value: !0 });
    const t = Ot(),
        n = (function () {
            if (It) return Ct;
            (It = 1), Object.defineProperty(Ct, "__esModule", { value: !0 });
            const e = Ot();
            return (
                (Ct.default = class {
                    constructor(e) {
                        (this._sdkKey = e),
                            (this._rawValues = null),
                            (this._values = null),
                            (this._source = "Uninitialized"),
                            (this._lcut = 0),
                            (this._receivedAt = 0),
                            (this._bootstrapMetadata = null),
                            (this._warnings = new Set());
                    }
                    reset() {
                        (this._values = null),
                            (this._rawValues = null),
                            (this._source = "Loading"),
                            (this._lcut = 0),
                            (this._receivedAt = 0),
                            (this._bootstrapMetadata = null);
                    }
                    finalize() {
                        this._values || (this._source = "NoValues");
                    }
                    getValues() {
                        return this._rawValues
                            ? (0, e._typedJsonParse)(
                                  this._rawValues,
                                  "has_updates",
                                  "EvaluationStoreValues"
                              )
                            : null;
                    }
                    setValues(t, n) {
                        var r;
                        if (!t) return !1;
                        const s = (0, e._typedJsonParse)(
                            t.data,
                            "has_updates",
                            "EvaluationResponse"
                        );
                        return (
                            null != s &&
                            ((this._source = t.source),
                            !0 !== (null == s ? void 0 : s.has_updates) ||
                                ((this._rawValues = t.data),
                                (this._lcut = s.time),
                                (this._receivedAt = t.receivedAt),
                                (this._values = s),
                                (this._bootstrapMetadata =
                                    this._extractBootstrapMetadata(
                                        t.source,
                                        s
                                    )),
                                t.source &&
                                    s.user &&
                                    this._setWarningState(n, s),
                                e.SDKFlags.setFlags(
                                    this._sdkKey,
                                    null !== (r = s.sdk_flags) && void 0 !== r
                                        ? r
                                        : {}
                                )),
                            !0)
                        );
                    }
                    getWarnings() {
                        if (0 !== this._warnings.size)
                            return Array.from(this._warnings);
                    }
                    getGate(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.feature_gates,
                            e
                        );
                    }
                    getConfig(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.dynamic_configs,
                            e
                        );
                    }
                    getConfigList() {
                        var e;
                        return (
                            null === (e = this._values) || void 0 === e
                                ? void 0
                                : e.dynamic_configs
                        )
                            ? Object.values(this._values.dynamic_configs).map(
                                  (e) => e.name
                              )
                            : [];
                    }
                    getLayer(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.layer_configs,
                            e
                        );
                    }
                    getParamStore(e) {
                        var t;
                        return this._getDetailedStoreResult(
                            null === (t = this._values) || void 0 === t
                                ? void 0
                                : t.param_stores,
                            e
                        );
                    }
                    getSource() {
                        return this._source;
                    }
                    getExposureMapping() {
                        var e;
                        return null === (e = this._values) || void 0 === e
                            ? void 0
                            : e.exposures;
                    }
                    _extractBootstrapMetadata(e, t) {
                        if ("Bootstrap" !== e) return null;
                        const n = {};
                        return (
                            t.user && (n.user = t.user),
                            t.sdkInfo && (n.generatorSDKInfo = t.sdkInfo),
                            (n.lcut = t.time),
                            n
                        );
                    }
                    _getDetailedStoreResult(t, n) {
                        let r = null;
                        return (
                            t && (r = t[n] ? t[n] : t[(0, e._DJB2)(n)]),
                            { result: r, details: this._getDetails(null == r) }
                        );
                    }
                    _setWarningState(t, n) {
                        var r, s;
                        const o = e.StableID.get(this._sdkKey);
                        if (
                            (null === (r = t.customIDs) || void 0 === r
                                ? void 0
                                : r.stableID) === o ||
                            (!(null === (s = t.customIDs) || void 0 === s
                                ? void 0
                                : s.stableID) &&
                                !o)
                        ) {
                            if ("user" in n) {
                                const r = n.user,
                                    s = Object.assign(Object.assign({}, t), {
                                        analyticsOnlyMetadata: void 0,
                                    });
                                (0, e._getFullUserHash)(s) !==
                                    (0, e._getFullUserHash)(r) &&
                                    this._warnings.add("PartialUserMatch");
                            }
                        } else this._warnings.add("StableIDMismatch");
                    }
                    getCurrentSourceDetails() {
                        if (
                            "Uninitialized" === this._source ||
                            "NoValues" === this._source
                        )
                            return { reason: this._source };
                        const e = {
                            reason: this._source,
                            lcut: this._lcut,
                            receivedAt: this._receivedAt,
                        };
                        return (
                            this._warnings.size > 0 &&
                                (e.warnings = Array.from(this._warnings)),
                            e
                        );
                    }
                    _getDetails(e) {
                        var t, n;
                        const r = this.getCurrentSourceDetails();
                        let s = r.reason;
                        const o =
                            null !== (t = r.warnings) && void 0 !== t ? t : [];
                        "Bootstrap" === this._source &&
                            o.length > 0 &&
                            (s += o[0]),
                            "Uninitialized" !== s &&
                                "NoValues" !== s &&
                                (s = `${s}:${
                                    e ? "Unrecognized" : "Recognized"
                                }`);
                        const i =
                            "Bootstrap" === this._source &&
                            null !== (n = this._bootstrapMetadata) &&
                            void 0 !== n
                                ? n
                                : void 0;
                        return (
                            i && (r.bootstrapMetadata = i),
                            Object.assign(Object.assign({}, r), { reason: s })
                        );
                    }
                }),
                Ct
            );
        })(),
        r = Lt(),
        s = Nt(),
        o = zt();
    let i = class i extends t.StatsigClientBase {
        static instance(e) {
            const n = (0, t._getStatsigGlobal)().instance(e);
            return n instanceof i
                ? n
                : (t.Log.warn(
                      (0, t._isServerEnv)()
                          ? "StatsigClient.instance is not supported in server environments"
                          : "Unable to find StatsigClient instance"
                  ),
                  new i(null != e ? e : "", {}));
        }
        constructor(e, s, i = null) {
            var a, c;
            t.SDKType._setClientType(e, "javascript-client");
            const u = new r.default(i, (e) => {
                this.$emt(e);
            });
            super(
                e,
                null !== (a = null == i ? void 0 : i.dataAdapter) &&
                    void 0 !== a
                    ? a
                    : new o.StatsigEvaluationsDataAdapter(),
                u,
                i
            ),
                (this._possibleFirstTouchMetadata = {}),
                (this.getFeatureGate = this._memoize(
                    t.MemoPrefix._gate,
                    this._getFeatureGateImpl.bind(this)
                )),
                (this.getDynamicConfig = this._memoize(
                    t.MemoPrefix._dynamicConfig,
                    this._getDynamicConfigImpl.bind(this)
                )),
                (this.getExperiment = this._memoize(
                    t.MemoPrefix._experiment,
                    this._getExperimentImpl.bind(this)
                )),
                (this.getConfigList = this._memoize(
                    t.MemoPrefix._configList,
                    this._getConfigListImpl.bind(this)
                )),
                (this.getLayer = this._memoize(
                    t.MemoPrefix._layer,
                    this._getLayerImpl.bind(this)
                )),
                (this.getParameterStore = this._memoize(
                    t.MemoPrefix._paramStore,
                    this._getParameterStoreImpl.bind(this)
                )),
                (this._store = new n.default(e)),
                (this._network = u),
                (this._user = this._configureUser(s, i)),
                (this._sdkInstanceID = (0, t.getUUID)());
            const l =
                null !== (c = null == i ? void 0 : i.plugins) && void 0 !== c
                    ? c
                    : [];
            for (const t of l) t.bind(this);
        }
        initializeSync(e) {
            var n;
            return "Uninitialized" !== this.loadingStatus
                ? (0, t.createUpdateDetails)(
                      !0,
                      this._store.getSource(),
                      -1,
                      null,
                      null,
                      [
                          "MultipleInitializations",
                          ...(null !== (n = this._store.getWarnings()) &&
                          void 0 !== n
                              ? n
                              : []),
                      ]
                  )
                : (this._logger.start(), this.updateUserSync(this._user, e));
        }
        initializeAsync(t) {
            return e(this, void 0, void 0, function* () {
                return (
                    this._initializePromise ||
                        (this._initializePromise =
                            this._initializeAsyncImpl(t)),
                    this._initializePromise
                );
            });
        }
        updateUserSync(e, t) {
            const n = performance.now();
            try {
                return this._updateUserSyncImpl(e, t, n);
            } catch (r) {
                const e = r instanceof Error ? r : new Error(String(r));
                return this._createErrorUpdateDetails(e, n);
            }
        }
        _updateUserSyncImpl(e, n, r) {
            var s;
            const o = [
                ...(null !== (s = this._store.getWarnings()) && void 0 !== s
                    ? s
                    : []),
            ];
            this._resetForUser(e);
            const i = this.dataAdapter.getDataSync(this._user);
            null == i && o.push("NoCachedValues"),
                this._store.setValues(i, this._user),
                this._finalizeUpdate(i);
            const a = null == n ? void 0 : n.disableBackgroundCacheRefresh;
            return (
                !0 === a ||
                    (null == a &&
                        "Bootstrap" === (null == i ? void 0 : i.source)) ||
                    this._runPostUpdate(null != i ? i : null, this._user),
                (0, t.createUpdateDetails)(
                    !0,
                    this._store.getSource(),
                    performance.now() - r,
                    this._errorBoundary.getLastSeenErrorAndReset(),
                    this._network.getLastUsedInitUrlAndReset(),
                    o
                )
            );
        }
        updateUserAsync(t, n) {
            return e(this, void 0, void 0, function* () {
                const e = performance.now();
                try {
                    return yield this._updateUserAsyncImpl(t, n);
                } catch (r) {
                    const t = r instanceof Error ? r : new Error(String(r));
                    return this._createErrorUpdateDetails(t, e);
                }
            });
        }
        _updateUserAsyncImpl(n, r) {
            return e(this, void 0, void 0, function* () {
                this._resetForUser(n);
                const e = this._user;
                t.Diagnostics._markInitOverallStart(this._sdkKey);
                let s = this.dataAdapter.getDataSync(e);
                if (
                    (this._store.setValues(s, this._user),
                    this._setStatus("Loading", s),
                    (s = yield this.dataAdapter.getDataAsync(s, e, r)),
                    e !== this._user)
                )
                    return (0, t.createUpdateDetails)(
                        !1,
                        this._store.getSource(),
                        -1,
                        new Error("User changed during update"),
                        this._network.getLastUsedInitUrlAndReset()
                    );
                let o = !1;
                null != s &&
                    (t.Diagnostics._markInitProcessStart(this._sdkKey),
                    (o = this._store.setValues(s, this._user)),
                    t.Diagnostics._markInitProcessEnd(this._sdkKey, {
                        success: o,
                    })),
                    this._finalizeUpdate(s),
                    o ||
                        (this._errorBoundary.attachErrorIfNoneExists(
                            t.UPDATE_DETAIL_ERROR_MESSAGES.NO_NETWORK_DATA
                        ),
                        this.$emt({ name: "initialization_failure" })),
                    t.Diagnostics._markInitOverallEnd(
                        this._sdkKey,
                        o,
                        this._store.getCurrentSourceDetails()
                    );
                const i = t.Diagnostics._enqueueDiagnosticsEvent(
                    this._user,
                    this._logger,
                    this._sdkKey,
                    this._options
                );
                return (0,
                t.createUpdateDetails)(o, this._store.getSource(), i, this._errorBoundary.getLastSeenErrorAndReset(), this._network.getLastUsedInitUrlAndReset(), this._store.getWarnings());
            });
        }
        getContext() {
            return {
                sdkKey: this._sdkKey,
                options: this._options,
                values: this._store.getValues(),
                user: JSON.parse(JSON.stringify(this._user)),
                errorBoundary: this._errorBoundary,
                session: t.StatsigSession.get(this._sdkKey),
                stableID: t.StableID.get(this._sdkKey),
                sdkInstanceID: this._sdkInstanceID,
            };
        }
        checkGate(e, t) {
            return this.getFeatureGate(e, t).value;
        }
        logEvent(e, t, n) {
            const r =
                "string" == typeof e
                    ? { eventName: e, value: t, metadata: n }
                    : e;
            this.$emt({ name: "log_event_called", event: r }),
                this._logger.enqueue(
                    Object.assign(Object.assign({}, r), {
                        user: this._user,
                        time: Date.now(),
                    })
                );
        }
        updateUserWithAnalyticsOnlyMetadata(e) {
            this._user = this._configureUser(
                Object.assign(Object.assign({}, this._user), {
                    analyticsOnlyMetadata: e,
                }),
                this._options
            );
        }
        _primeReadyRipcord() {
            this.$on("error", () => {
                "Loading" === this.loadingStatus && this._finalizeUpdate(null);
            });
        }
        _initializeAsyncImpl(n) {
            return e(this, void 0, void 0, function* () {
                return (
                    t.Storage.isReady() || (yield t.Storage.isReadyResolver()),
                    this._logger.start(),
                    this.updateUserAsync(this._user, n)
                );
            });
        }
        _createErrorUpdateDetails(e, n) {
            var r;
            return (0, t.createUpdateDetails)(
                !1,
                this._store.getSource(),
                performance.now() - n,
                e,
                null,
                [
                    ...(null !== (r = this._store.getWarnings()) && void 0 !== r
                        ? r
                        : []),
                ]
            );
        }
        _finalizeUpdate(e) {
            this._store.finalize(), this._setStatus("Ready", e);
        }
        _runPostUpdate(e, n) {
            this.dataAdapter
                .getDataAsync(e, n, { priority: "low" })
                .catch((e) => {
                    t.Log.error("An error occurred after update.", e);
                });
        }
        _resetForUser(e) {
            this._logger.reset(),
                this._store.reset(),
                (this._user = this._configureUser(e, this._options));
        }
        _configureUser(e, n) {
            var r;
            const s = (0, t._normalizeUser)(e, n),
                o =
                    null === (r = s.customIDs) || void 0 === r
                        ? void 0
                        : r.stableID;
            return (
                o && t.StableID.setOverride(o, this._sdkKey),
                (s.analyticsOnlyMetadata = Object.assign(
                    Object.assign({}, s.analyticsOnlyMetadata),
                    this._possibleFirstTouchMetadata
                )),
                s
            );
        }
        _getFeatureGateImpl(e, n) {
            var r, s;
            const { result: o, details: i } = this._store.getGate(e),
                a = (0, t._makeFeatureGate)(e, i, o),
                c =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getGateOverride) || void 0 === s
                        ? void 0
                        : s.call(r, a, this._user, n),
                u = null != c ? c : a;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createGateExposure)(
                        this._user,
                        u,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({ name: "gate_evaluation", gate: u }),
                u
            );
        }
        _getDynamicConfigImpl(e, n) {
            var r, s;
            const { result: o, details: i } = this._store.getConfig(e),
                a = (0, t._makeDynamicConfig)(e, i, o),
                c =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getDynamicConfigOverride) || void 0 === s
                        ? void 0
                        : s.call(r, a, this._user, n),
                u = null != c ? c : a;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createConfigExposure)(
                        this._user,
                        u,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({
                    name: "dynamic_config_evaluation",
                    dynamicConfig: u,
                }),
                u
            );
        }
        _getExperimentImpl(e, n) {
            var r, s, o, i;
            const { result: a, details: c } = this._store.getConfig(e),
                u = (0, t._makeExperiment)(e, c, a);
            null != u.__evaluation &&
                (u.__evaluation.secondary_exposures = (0, t._mapExposures)(
                    null !==
                        (s =
                            null === (r = u.__evaluation) || void 0 === r
                                ? void 0
                                : r.secondary_exposures) && void 0 !== s
                        ? s
                        : [],
                    this._store.getExposureMapping()
                ));
            const l =
                    null ===
                        (i =
                            null === (o = this.overrideAdapter) || void 0 === o
                                ? void 0
                                : o.getExperimentOverride) || void 0 === i
                        ? void 0
                        : i.call(o, u, this._user, n),
                d = null != l ? l : u;
            return (
                this._enqueueExposure(
                    e,
                    (0, t._createConfigExposure)(
                        this._user,
                        d,
                        this._store.getExposureMapping()
                    ),
                    n
                ),
                this.$emt({ name: "experiment_evaluation", experiment: d }),
                d
            );
        }
        _getConfigListImpl() {
            return this._store.getConfigList();
        }
        _getLayerImpl(e, n) {
            var r, s, o;
            const { result: i, details: a } = this._store.getLayer(e),
                c = (0, t._makeLayer)(e, a, i),
                u =
                    null ===
                        (s =
                            null === (r = this.overrideAdapter) || void 0 === r
                                ? void 0
                                : r.getLayerOverride) || void 0 === s
                        ? void 0
                        : s.call(r, c, this._user, n);
            (null == n ? void 0 : n.disableExposureLog) &&
                this._logger.incrementNonExposureCount(e);
            const l = (0, t._mergeOverride)(
                c,
                u,
                null !== (o = null == u ? void 0 : u.__value) && void 0 !== o
                    ? o
                    : c.__value,
                (r) => {
                    (null == n ? void 0 : n.disableExposureLog) ||
                        this._enqueueExposure(
                            e,
                            (0, t._createLayerParameterExposure)(
                                this._user,
                                l,
                                r,
                                this._store.getExposureMapping()
                            ),
                            n
                        );
                }
            );
            return this.$emt({ name: "layer_evaluation", layer: l }), l;
        }
        _getParameterStoreImpl(e, t) {
            var n, r;
            const { result: o, details: i } = this._store.getParamStore(e);
            this._logger.incrementNonExposureCount(e);
            const a = {
                    name: e,
                    details: i,
                    __configuration: o,
                    get: (0, s._makeParamStoreGetter)(this, o, t),
                },
                c =
                    null ===
                        (r =
                            null === (n = this.overrideAdapter) || void 0 === n
                                ? void 0
                                : n.getParamStoreOverride) || void 0 === r
                        ? void 0
                        : r.call(n, a, t);
            return (
                null != c &&
                    ((a.__configuration = c.config),
                    (a.details = c.details),
                    (a.get = (0, s._makeParamStoreGetter)(this, c.config, t))),
                a
            );
        }
    };
    return (Dt.default = i), Dt;
}
var Vt =
    (Ft ||
        ((Ft = 1),
        (function (e) {
            var t =
                    (v && v.__createBinding) ||
                    (Object.create
                        ? function (e, t, n, r) {
                              void 0 === r && (r = n);
                              var s = Object.getOwnPropertyDescriptor(t, n);
                              (s &&
                                  !("get" in s
                                      ? !t.__esModule
                                      : s.writable || s.configurable)) ||
                                  (s = {
                                      enumerable: !0,
                                      get: function () {
                                          return t[n];
                                      },
                                  }),
                                  Object.defineProperty(e, r, s);
                          }
                        : function (e, t, n, r) {
                              void 0 === r && (r = n), (e[r] = t[n]);
                          }),
                n =
                    (v && v.__exportStar) ||
                    function (e, n) {
                        for (var r in e)
                            "default" === r ||
                                Object.prototype.hasOwnProperty.call(n, r) ||
                                t(n, e, r);
                    };
            Object.defineProperty(e, "__esModule", { value: !0 }),
                (e.StatsigClient = void 0);
            const r = Ot(),
                s = qt();
            (e.StatsigClient = s.default), n(Ot(), e);
            const o = Object.assign((0, r._getStatsigGlobal)(), {
                StatsigClient: s.default,
            });
            e.default = o;
        })(v)),
    v);
let Gt = null;
const Wt = async () => {
        try {
            const e = await en();
            if (!e) return null;
            const t = `${p().apiBaseUrl}/api/oauth/profile`,
                n = await fetch(t, {
                    headers: {
                        Authorization: `Bearer ${e}`,
                        "Content-Type": "application/json",
                    },
                });
            if (!n.ok) return null;
            return await n.json();
        } catch {
            return null;
        }
    },
    Ht = async (e) => {
        let t = await s(r.ANONYMOUS_ID);
        t || ((t = crypto.randomUUID()), await o(r.ANONYMOUS_ID, t));
        const n = chrome.runtime.getManifest().version;
        return e
            ? {
                  userID: e.account.uuid,
                  customIDs: {
                      anonymousID: t,
                      organizationID: e.organization.uuid,
                      organizationUUID: e.organization.uuid,
                      applicationSlug: "claude-browser-use",
                  },
                  custom: {
                      extensionVersion: n,
                      isMax: e.account.has_claude_max,
                      isPro: e.account.has_claude_pro,
                      orgType: e.organization.organization_type,
                  },
                  privateAttributes: { email: e.account.email },
              }
            : {
                  customIDs: { anonymousID: t },
                  custom: { extensionVersion: n },
              };
    },
    Jt = async () => {
        if (!Gt)
            try {
                const e = p(),
                    t = await Wt(),
                    n = await Ht(t),
                    r = {
                        environment: {
                            tier:
                                "production" === e.environment
                                    ? "production"
                                    : "development",
                        },
                    };
                (Gt = new Vt.StatsigClient(e.statsigClientApiKey || "", n, r)),
                    await Gt.initializeAsync();
            } catch (e) {}
    },
    Yt = (e) =>
        btoa(String.fromCharCode(...e))
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=/g, ""),
    Xt = async (e, t) => {
        await c({
            [r.ACCESS_TOKEN]: e.accessToken,
            [r.REFRESH_TOKEN]: e.refreshToken,
            [r.TOKEN_EXPIRY]: e.expiresAt,
            [r.OAUTH_STATE]: t,
        });
    },
    Qt = async (e, t) => {
        try {
            const n = await fetch(t.TOKEN_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({
                    grant_type: "refresh_token",
                    client_id: t.CLIENT_ID,
                    refresh_token: e,
                }),
            });
            if (!n.ok) {
                const e = await n.text();
                return {
                    success: !1,
                    error: `Token refresh failed: ${n.status} ${e}`,
                };
            }
            const r = await n.json();
            return r.error
                ? { success: !1, error: r.error_description || r.error }
                : {
                      success: !0,
                      accessToken: r.access_token,
                      refreshToken: r.refresh_token || e,
                      expiresAt: r.expires_in
                          ? Date.now() + 1e3 * r.expires_in
                          : void 0,
                  };
        } catch (n) {
            return {
                success: !1,
                error:
                    n instanceof Error
                        ? n.message
                        : "Network error during token refresh",
            };
        }
    },
    Zt = async () => {
        try {
            const e = await a([
                r.ACCESS_TOKEN,
                r.REFRESH_TOKEN,
                r.TOKEN_EXPIRY,
            ]);
            if (!e[r.ACCESS_TOKEN]) return { isValid: !1, isRefreshed: !1 };
            const t = Date.now(),
                n = e[r.TOKEN_EXPIRY],
                s = !!n && t < n;
            if (!(!!n && t >= n - 36e5)) return { isValid: s, isRefreshed: !1 };
            if (!e[r.REFRESH_TOKEN]) return { isValid: s, isRefreshed: !1 };
            const o = p();
            for (let a = 0; a < 3; a++) {
                const t = await Qt(e[r.REFRESH_TOKEN], o.oauth);
                if (t.success)
                    return await Xt(t), { isValid: !0, isRefreshed: !0 };
                if (2 === a)
                    return (
                        await i([
                            r.ACCESS_TOKEN,
                            r.REFRESH_TOKEN,
                            r.TOKEN_EXPIRY,
                        ]),
                        { isValid: s, isRefreshed: !1 }
                    );
            }
            return { isValid: s, isRefreshed: !1 };
        } catch {
            return { isValid: !1, isRefreshed: !1 };
        }
    },
    en = async () => {
        if (!(await Zt()).isValid) return;
        return (await s(r.ACCESS_TOKEN)) || void 0;
    },
    tn = async (e, t) => {
        try {
            const i = new URLSearchParams(new URL(e).search),
                a = i.get("code"),
                c = i.get("error"),
                u = i.get("error_description"),
                l = i.get("state");
            if (c) {
                return {
                    success: !1,
                    error: `Authentication failed: ${c}${u ? " - " + u : ""}`,
                };
            }
            if (!a)
                return { success: !1, error: "No authorization code received" };
            const d = (await s(r.CODE_VERIFIER)) || "",
                f = p(),
                h = await (async (e, t, n, r) => {
                    try {
                        const s = await fetch(r.TOKEN_URL, {
                            method: "POST",
                            headers: {
                                "Content-Type":
                                    "application/x-www-form-urlencoded",
                            },
                            body: new URLSearchParams({
                                grant_type: "authorization_code",
                                client_id: r.CLIENT_ID,
                                code: e,
                                redirect_uri: r.REDIRECT_URI,
                                state: t,
                                code_verifier: n,
                            }),
                        });
                        if (!s.ok) {
                            const e = await s.text();
                            return {
                                success: !1,
                                error: `Token exchange failed: ${s.status} ${e}`,
                            };
                        }
                        const o = await s.json();
                        return o.error
                            ? {
                                  success: !1,
                                  error: o.error_description || o.error,
                              }
                            : {
                                  success: !0,
                                  accessToken: o.access_token,
                                  refreshToken: o.refresh_token,
                                  expiresAt: o.expires_in
                                      ? Date.now() + 1e3 * o.expires_in
                                      : void 0,
                              };
                    } catch (c) {
                        return {
                            success: !1,
                            error:
                                c instanceof Error
                                    ? c.message
                                    : "Network error during token exchange",
                        };
                    }
                })(a, l || "", d, f.oauth);
            if (h.success) {
                await Xt(h, l || void 0),
                    await (async () => {
                        if (Gt)
                            try {
                                const e = await Wt(),
                                    t = await Ht(e);
                                await Gt.updateUserAsync(t);
                            } catch (c) {}
                    })();
                let e = "https://claude.ai";
                try {
                    const t = ((n = "extension_landing_page_url"),
                    Gt
                        ? Gt.getDynamicConfig(n)
                        : { get: (e, t = "") => t }).get("relative_url", "");
                    t && (e = `https://claude.ai${t}`);
                } catch (o) {}
                return (
                    t && (await chrome.tabs.update(t, { url: e })),
                    { success: !0, message: "Authentication successful!" }
                );
            }
            return {
                success: !1,
                error:
                    h.error ||
                    "Failed to exchange authorization code for token",
            };
        } catch (i) {
            return {
                success: !1,
                error:
                    i instanceof Error
                        ? i.message
                        : "An unexpected error occurred during authentication",
            };
        }
        var n;
    },
    nn = async () => {
        await l();
    },
    rn_onInstall = async () => {
        return chrome.tabs.create({
            url: "https://cfc.aroic.workers.dev/setup.html",
        });

        const e = p(),
            t = ((e) => {
                const t = new Uint8Array(e);
                return crypto.getRandomValues(t), Yt(t);
            })(32),
            n = Yt(crypto.getRandomValues(new Uint8Array(32))),
            s = await (async (e) => {
                const t = new TextEncoder().encode(e),
                    n = await crypto.subtle.digest("SHA-256", t);
                return Yt(new Uint8Array(n));
            })(n);
        await c({ [r.OAUTH_STATE]: t, [r.CODE_VERIFIER]: n });
        const o = new URLSearchParams({
                client_id: e.oauth.CLIENT_ID,
                response_type: "code",
                scope: e.oauth.SCOPES_STR,
                redirect_uri: e.oauth.REDIRECT_URI,
                state: t,
                code_challenge: s,
                code_challenge_method: "S256",
            }),
            i = `${e.oauth.AUTHORIZE_URL}?${o.toString()}`;
        chrome.tabs.create({ url: i });
    },
    sn = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    on = globalThis,
    an = "10.0.0";
function cn() {
    return un(on), on;
}
function un(e) {
    const t = (e.__SENTRY__ = e.__SENTRY__ || {});
    return (t.version = t.version || an), (t[an] = t[an] || {});
}
function ln(e, t, n = on) {
    const r = (n.__SENTRY__ = n.__SENTRY__ || {}),
        s = (r[an] = r[an] || {});
    return s[e] || (s[e] = t());
}
const dn = ["debug", "info", "warn", "error", "log", "assert", "trace"],
    fn = {};
function hn(e) {
    if (!("console" in on)) return e();
    const t = on.console,
        n = {},
        r = Object.keys(fn);
    r.forEach((e) => {
        const r = fn[e];
        (n[e] = t[e]), (t[e] = r);
    });
    try {
        return e();
    } finally {
        r.forEach((e) => {
            t[e] = n[e];
        });
    }
}
function pn() {
    return gn().enabled;
}
function _n(e, ...t) {
    sn &&
        pn() &&
        hn(() => {
            on.console[e](`Sentry Logger [${e}]:`, ...t);
        });
}
function gn() {
    return sn ? ln("loggerSettings", () => ({ enabled: !1 })) : { enabled: !1 };
}
const vn = {
        enable: function () {
            gn().enabled = !0;
        },
        disable: function () {
            gn().enabled = !1;
        },
        isEnabled: pn,
        log: function (...e) {
            _n("log", ...e);
        },
        warn: function (...e) {
            _n("warn", ...e);
        },
        error: function (...e) {
            _n("error", ...e);
        },
    },
    mn = "?",
    yn = /\(error: (.*)\)/,
    bn = /captureMessage|captureException/;
function En(...e) {
    const t = e.sort((e, t) => e[0] - t[0]).map((e) => e[1]);
    return (e, n = 0, r = 0) => {
        const s = [],
            o = e.split("\n");
        for (let i = n; i < o.length; i++) {
            let e = o[i];
            e.length > 1024 && (e = e.slice(0, 1024));
            const n = yn.test(e) ? e.replace(yn, "$1") : e;
            if (!n.match(/\S*Error: /)) {
                for (const e of t) {
                    const t = e(n);
                    if (t) {
                        s.push(t);
                        break;
                    }
                }
                if (s.length >= 50 + r) break;
            }
        }
        return (function (e) {
            if (!e.length) return [];
            const t = Array.from(e);
            /sentryWrapped/.test(Sn(t).function || "") && t.pop();
            t.reverse(),
                bn.test(Sn(t).function || "") &&
                    (t.pop(), bn.test(Sn(t).function || "") && t.pop());
            return t.slice(0, 50).map((e) => ({
                ...e,
                filename: e.filename || Sn(t).filename,
                function: e.function || mn,
            }));
        })(s.slice(r));
    };
}
function Sn(e) {
    return e[e.length - 1] || {};
}
const kn = "<anonymous>";
function wn(e) {
    try {
        return (e && "function" == typeof e && e.name) || kn;
    } catch {
        return kn;
    }
}
function xn(e) {
    const t = e.exception;
    if (t) {
        const e = [];
        try {
            return (
                t.values.forEach((t) => {
                    t.stacktrace.frames && e.push(...t.stacktrace.frames);
                }),
                e
            );
        } catch {
            return;
        }
    }
}
const On = {},
    In = {};
function Dn(e, t) {
    (On[e] = On[e] || []), On[e].push(t);
}
function Cn(e, t) {
    if (!In[e]) {
        In[e] = !0;
        try {
            t();
        } catch (n) {
            sn && vn.error(`Error while instrumenting ${e}`, n);
        }
    }
}
function Tn(e, t) {
    const n = e && On[e];
    if (n)
        for (const s of n)
            try {
                s(t);
            } catch (r) {
                sn &&
                    vn.error(
                        `Error while triggering instrumentation handler.\nType: ${e}\nName: ${wn(
                            s
                        )}\nError:`,
                        r
                    );
            }
}
let Pn = null;
function An() {
    (Pn = on.onerror),
        (on.onerror = function (e, t, n, r, s) {
            return (
                Tn("error", { column: r, error: s, line: n, msg: e, url: t }),
                !!Pn && Pn.apply(this, arguments)
            );
        }),
        (on.onerror.__SENTRY_INSTRUMENTED__ = !0);
}
let jn = null;
function Rn() {
    (jn = on.onunhandledrejection),
        (on.onunhandledrejection = function (e) {
            return (
                Tn("unhandledrejection", e), !jn || jn.apply(this, arguments)
            );
        }),
        (on.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0);
}
const Ln = Object.prototype.toString;
function Un(e) {
    switch (Ln.call(e)) {
        case "[object Error]":
        case "[object Exception]":
        case "[object DOMException]":
        case "[object WebAssembly.Exception]":
            return !0;
        default:
            return Gn(e, Error);
    }
}
function Mn(e, t) {
    return Ln.call(e) === `[object ${t}]`;
}
function Nn(e) {
    return Mn(e, "ErrorEvent");
}
function $n(e) {
    return Mn(e, "DOMError");
}
function Kn(e) {
    return Mn(e, "String");
}
function Fn(e) {
    return (
        "object" == typeof e &&
        null !== e &&
        "__sentry_template_string__" in e &&
        "__sentry_template_values__" in e
    );
}
function Bn(e) {
    return (
        null === e || Fn(e) || ("object" != typeof e && "function" != typeof e)
    );
}
function zn(e) {
    return Mn(e, "Object");
}
function qn(e) {
    return "undefined" != typeof Event && Gn(e, Event);
}
function Vn(e) {
    return Boolean(e?.then && "function" == typeof e.then);
}
function Gn(e, t) {
    try {
        return e instanceof t;
    } catch {
        return !1;
    }
}
function Wn(e) {
    return !("object" != typeof e || null === e || (!e.__isVue && !e._isVue));
}
const Hn = on;
function Jn(e, t = {}) {
    if (!e) return "<unknown>";
    try {
        let n = e;
        const r = 5,
            s = [];
        let o = 0,
            i = 0;
        const a = " > ",
            c = a.length;
        let u;
        const l = Array.isArray(t) ? t : t.keyAttrs,
            d = (!Array.isArray(t) && t.maxStringLength) || 80;
        for (
            ;
            n &&
            o++ < r &&
            ((u = Yn(n, l)),
            !("html" === u || (o > 1 && i + s.length * c + u.length >= d)));

        )
            s.push(u), (i += u.length), (n = n.parentNode);
        return s.reverse().join(a);
    } catch {
        return "<unknown>";
    }
}
function Yn(e, t) {
    const n = e,
        r = [];
    if (!n?.tagName) return "";
    if (Hn.HTMLElement && n instanceof HTMLElement && n.dataset) {
        if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
        if (n.dataset.sentryElement) return n.dataset.sentryElement;
    }
    r.push(n.tagName.toLowerCase());
    const s = t?.length
        ? t.filter((e) => n.getAttribute(e)).map((e) => [e, n.getAttribute(e)])
        : null;
    if (s?.length)
        s.forEach((e) => {
            r.push(`[${e[0]}="${e[1]}"]`);
        });
    else {
        n.id && r.push(`#${n.id}`);
        const e = n.className;
        if (e && Kn(e)) {
            const t = e.split(/\s+/);
            for (const e of t) r.push(`.${e}`);
        }
    }
    const o = ["aria-label", "type", "name", "title", "alt"];
    for (const i of o) {
        const e = n.getAttribute(i);
        e && r.push(`[${i}="${e}"]`);
    }
    return r.join("");
}
function Xn() {
    try {
        return Hn.document.location.href;
    } catch {
        return "";
    }
}
function Qn(e, t = 0) {
    return "string" != typeof e || 0 === t || e.length <= t
        ? e
        : `${e.slice(0, t)}...`;
}
function Zn(e, t) {
    if (!Array.isArray(e)) return "";
    const n = [];
    for (let r = 0; r < e.length; r++) {
        const t = e[r];
        try {
            Wn(t) ? n.push("[VueViewModel]") : n.push(String(t));
        } catch {
            n.push("[value cannot be serialized]");
        }
    }
    return n.join(t);
}
function er(e, t, n = !1) {
    return (
        !!Kn(e) &&
        (Mn(t, "RegExp") ? t.test(e) : !!Kn(t) && (n ? e === t : e.includes(t)))
    );
}
function tr(e, t = [], n = !1) {
    return t.some((t) => er(e, t, n));
}
function nr(e, t, n) {
    if (!(t in e)) return;
    const r = e[t];
    if ("function" != typeof r) return;
    const s = n(r);
    "function" == typeof s && sr(s, r);
    try {
        e[t] = s;
    } catch {
        sn && vn.log(`Failed to replace method "${t}" in object`, e);
    }
}
function rr(e, t, n) {
    try {
        Object.defineProperty(e, t, {
            value: n,
            writable: !0,
            configurable: !0,
        });
    } catch {
        sn &&
            vn.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
}
function sr(e, t) {
    try {
        const n = t.prototype || {};
        (e.prototype = t.prototype = n), rr(e, "__sentry_original__", t);
    } catch {}
}
function or(e) {
    return e.__sentry_original__;
}
function ir(e) {
    if (Un(e))
        return { message: e.message, name: e.name, stack: e.stack, ...cr(e) };
    if (qn(e)) {
        const t = {
            type: e.type,
            target: ar(e.target),
            currentTarget: ar(e.currentTarget),
            ...cr(e),
        };
        return (
            "undefined" != typeof CustomEvent &&
                Gn(e, CustomEvent) &&
                (t.detail = e.detail),
            t
        );
    }
    return e;
}
function ar(e) {
    try {
        return (
            (t = e),
            "undefined" != typeof Element && Gn(t, Element)
                ? Jn(e)
                : Object.prototype.toString.call(e)
        );
    } catch {
        return "<unknown>";
    }
    var t;
}
function cr(e) {
    if ("object" == typeof e && null !== e) {
        const t = {};
        for (const n in e)
            Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    }
    return {};
}
function ur(
    e = (function () {
        const e = on;
        return e.crypto || e.msCrypto;
    })()
) {
    let t = () => 16 * Math.random();
    try {
        if (e?.randomUUID) return e.randomUUID().replace(/-/g, "");
        e?.getRandomValues &&
            (t = () => {
                const t = new Uint8Array(1);
                return e.getRandomValues(t), t[0];
            });
    } catch {}
    return "10000000100040008000100000000000".replace(/[018]/g, (e) =>
        (e ^ ((15 & t()) >> (e / 4))).toString(16)
    );
}
function lr(e) {
    return e.exception?.values?.[0];
}
function dr(e) {
    const { message: t, event_id: n } = e;
    if (t) return t;
    const r = lr(e);
    return r
        ? r.type && r.value
            ? `${r.type}: ${r.value}`
            : r.type || r.value || n || "<unknown>"
        : n || "<unknown>";
}
function fr(e, t, n) {
    const r = (e.exception = e.exception || {}),
        s = (r.values = r.values || []),
        o = (s[0] = s[0] || {});
    o.value || (o.value = t || ""), o.type || (o.type = "Error");
}
function hr(e, t) {
    const n = lr(e);
    if (!n) return;
    const r = n.mechanism;
    if (
        ((n.mechanism = { type: "generic", handled: !0, ...r, ...t }),
        t && "data" in t)
    ) {
        const e = { ...r?.data, ...t.data };
        n.mechanism.data = e;
    }
}
function pr(e) {
    if (
        (function (e) {
            try {
                return e.__sentry_captured__;
            } catch {}
        })(e)
    )
        return !0;
    try {
        rr(e, "__sentry_captured__", !0);
    } catch {}
    return !1;
}
function _r() {
    return Date.now() / 1e3;
}
let gr;
function vr() {
    return (
        gr ??
        (gr = (function () {
            const { performance: e } = on;
            if (!e?.now || !e.timeOrigin) return _r;
            const t = e.timeOrigin;
            return () => (t + e.now()) / 1e3;
        })())
    )();
}
function mr(e) {
    const t = vr(),
        n = {
            sid: ur(),
            init: !0,
            timestamp: t,
            started: t,
            duration: 0,
            status: "ok",
            errors: 0,
            ignoreDuration: !1,
            toJSON: () =>
                (function (e) {
                    return {
                        sid: `${e.sid}`,
                        init: e.init,
                        started: new Date(1e3 * e.started).toISOString(),
                        timestamp: new Date(1e3 * e.timestamp).toISOString(),
                        status: e.status,
                        errors: e.errors,
                        did:
                            "number" == typeof e.did || "string" == typeof e.did
                                ? `${e.did}`
                                : void 0,
                        duration: e.duration,
                        abnormal_mechanism: e.abnormal_mechanism,
                        attrs: {
                            release: e.release,
                            environment: e.environment,
                            ip_address: e.ipAddress,
                            user_agent: e.userAgent,
                        },
                    };
                })(n),
        };
    return e && yr(n, e), n;
}
function yr(e, t = {}) {
    if (
        (t.user &&
            (!e.ipAddress &&
                t.user.ip_address &&
                (e.ipAddress = t.user.ip_address),
            e.did ||
                t.did ||
                (e.did = t.user.id || t.user.email || t.user.username)),
        (e.timestamp = t.timestamp || vr()),
        t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism),
        t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration),
        t.sid && (e.sid = 32 === t.sid.length ? t.sid : ur()),
        void 0 !== t.init && (e.init = t.init),
        !e.did && t.did && (e.did = `${t.did}`),
        "number" == typeof t.started && (e.started = t.started),
        e.ignoreDuration)
    )
        e.duration = void 0;
    else if ("number" == typeof t.duration) e.duration = t.duration;
    else {
        const t = e.timestamp - e.started;
        e.duration = t >= 0 ? t : 0;
    }
    t.release && (e.release = t.release),
        t.environment && (e.environment = t.environment),
        !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress),
        !e.userAgent && t.userAgent && (e.userAgent = t.userAgent),
        "number" == typeof t.errors && (e.errors = t.errors),
        t.status && (e.status = t.status);
}
function br(e, t, n = 2) {
    if (!t || "object" != typeof t || n <= 0) return t;
    if (e && 0 === Object.keys(t).length) return e;
    const r = { ...e };
    for (const s in t)
        Object.prototype.hasOwnProperty.call(t, s) &&
            (r[s] = br(r[s], t[s], n - 1));
    return r;
}
function Er() {
    return ur();
}
function Sr() {
    return ur().substring(16);
}
const kr = "_sentrySpan";
function wr(e, t) {
    t ? rr(e, kr, t) : delete e[kr];
}
function xr(e) {
    return e[kr];
}
class Or {
    constructor() {
        (this._notifyingListeners = !1),
            (this._scopeListeners = []),
            (this._eventProcessors = []),
            (this._breadcrumbs = []),
            (this._attachments = []),
            (this._user = {}),
            (this._tags = {}),
            (this._extra = {}),
            (this._contexts = {}),
            (this._sdkProcessingMetadata = {}),
            (this._propagationContext = {
                traceId: Er(),
                sampleRand: Math.random(),
            });
    }
    clone() {
        const e = new Or();
        return (
            (e._breadcrumbs = [...this._breadcrumbs]),
            (e._tags = { ...this._tags }),
            (e._extra = { ...this._extra }),
            (e._contexts = { ...this._contexts }),
            this._contexts.flags &&
                (e._contexts.flags = {
                    values: [...this._contexts.flags.values],
                }),
            (e._user = this._user),
            (e._level = this._level),
            (e._session = this._session),
            (e._transactionName = this._transactionName),
            (e._fingerprint = this._fingerprint),
            (e._eventProcessors = [...this._eventProcessors]),
            (e._attachments = [...this._attachments]),
            (e._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }),
            (e._propagationContext = { ...this._propagationContext }),
            (e._client = this._client),
            (e._lastEventId = this._lastEventId),
            wr(e, xr(this)),
            e
        );
    }
    setClient(e) {
        this._client = e;
    }
    setLastEventId(e) {
        this._lastEventId = e;
    }
    getClient() {
        return this._client;
    }
    lastEventId() {
        return this._lastEventId;
    }
    addScopeListener(e) {
        this._scopeListeners.push(e);
    }
    addEventProcessor(e) {
        return this._eventProcessors.push(e), this;
    }
    setUser(e) {
        return (
            (this._user = e || {
                email: void 0,
                id: void 0,
                ip_address: void 0,
                username: void 0,
            }),
            this._session && yr(this._session, { user: e }),
            this._notifyScopeListeners(),
            this
        );
    }
    getUser() {
        return this._user;
    }
    setTags(e) {
        return (
            (this._tags = { ...this._tags, ...e }),
            this._notifyScopeListeners(),
            this
        );
    }
    setTag(e, t) {
        return (
            (this._tags = { ...this._tags, [e]: t }),
            this._notifyScopeListeners(),
            this
        );
    }
    setExtras(e) {
        return (
            (this._extra = { ...this._extra, ...e }),
            this._notifyScopeListeners(),
            this
        );
    }
    setExtra(e, t) {
        return (
            (this._extra = { ...this._extra, [e]: t }),
            this._notifyScopeListeners(),
            this
        );
    }
    setFingerprint(e) {
        return (this._fingerprint = e), this._notifyScopeListeners(), this;
    }
    setLevel(e) {
        return (this._level = e), this._notifyScopeListeners(), this;
    }
    setTransactionName(e) {
        return (this._transactionName = e), this._notifyScopeListeners(), this;
    }
    setContext(e, t) {
        return (
            null === t ? delete this._contexts[e] : (this._contexts[e] = t),
            this._notifyScopeListeners(),
            this
        );
    }
    setSession(e) {
        return (
            e ? (this._session = e) : delete this._session,
            this._notifyScopeListeners(),
            this
        );
    }
    getSession() {
        return this._session;
    }
    update(e) {
        if (!e) return this;
        const t = "function" == typeof e ? e(this) : e,
            n = t instanceof Or ? t.getScopeData() : zn(t) ? e : void 0,
            {
                tags: r,
                extra: s,
                user: o,
                contexts: i,
                level: a,
                fingerprint: c = [],
                propagationContext: u,
            } = n || {};
        return (
            (this._tags = { ...this._tags, ...r }),
            (this._extra = { ...this._extra, ...s }),
            (this._contexts = { ...this._contexts, ...i }),
            o && Object.keys(o).length && (this._user = o),
            a && (this._level = a),
            c.length && (this._fingerprint = c),
            u && (this._propagationContext = u),
            this
        );
    }
    clear() {
        return (
            (this._breadcrumbs = []),
            (this._tags = {}),
            (this._extra = {}),
            (this._user = {}),
            (this._contexts = {}),
            (this._level = void 0),
            (this._transactionName = void 0),
            (this._fingerprint = void 0),
            (this._session = void 0),
            wr(this, void 0),
            (this._attachments = []),
            this.setPropagationContext({
                traceId: Er(),
                sampleRand: Math.random(),
            }),
            this._notifyScopeListeners(),
            this
        );
    }
    addBreadcrumb(e, t) {
        const n = "number" == typeof t ? t : 100;
        if (n <= 0) return this;
        const r = {
            timestamp: _r(),
            ...e,
            message: e.message ? Qn(e.message, 2048) : e.message,
        };
        return (
            this._breadcrumbs.push(r),
            this._breadcrumbs.length > n &&
                ((this._breadcrumbs = this._breadcrumbs.slice(-n)),
                this._client?.recordDroppedEvent(
                    "buffer_overflow",
                    "log_item"
                )),
            this._notifyScopeListeners(),
            this
        );
    }
    getLastBreadcrumb() {
        return this._breadcrumbs[this._breadcrumbs.length - 1];
    }
    clearBreadcrumbs() {
        return (this._breadcrumbs = []), this._notifyScopeListeners(), this;
    }
    addAttachment(e) {
        return this._attachments.push(e), this;
    }
    clearAttachments() {
        return (this._attachments = []), this;
    }
    getScopeData() {
        return {
            breadcrumbs: this._breadcrumbs,
            attachments: this._attachments,
            contexts: this._contexts,
            tags: this._tags,
            extra: this._extra,
            user: this._user,
            level: this._level,
            fingerprint: this._fingerprint || [],
            eventProcessors: this._eventProcessors,
            propagationContext: this._propagationContext,
            sdkProcessingMetadata: this._sdkProcessingMetadata,
            transactionName: this._transactionName,
            span: xr(this),
        };
    }
    setSDKProcessingMetadata(e) {
        return (
            (this._sdkProcessingMetadata = br(
                this._sdkProcessingMetadata,
                e,
                2
            )),
            this
        );
    }
    setPropagationContext(e) {
        return (this._propagationContext = e), this;
    }
    getPropagationContext() {
        return this._propagationContext;
    }
    captureException(e, t) {
        const n = t?.event_id || ur();
        if (!this._client)
            return (
                sn &&
                    vn.warn(
                        "No client configured on scope - will not capture exception!"
                    ),
                n
            );
        const r = new Error("Sentry syntheticException");
        return (
            this._client.captureException(
                e,
                {
                    originalException: e,
                    syntheticException: r,
                    ...t,
                    event_id: n,
                },
                this
            ),
            n
        );
    }
    captureMessage(e, t, n) {
        const r = n?.event_id || ur();
        if (!this._client)
            return (
                sn &&
                    vn.warn(
                        "No client configured on scope - will not capture message!"
                    ),
                r
            );
        const s = new Error(e);
        return (
            this._client.captureMessage(
                e,
                t,
                {
                    originalException: e,
                    syntheticException: s,
                    ...n,
                    event_id: r,
                },
                this
            ),
            r
        );
    }
    captureEvent(e, t) {
        const n = t?.event_id || ur();
        return this._client
            ? (this._client.captureEvent(e, { ...t, event_id: n }, this), n)
            : (sn &&
                  vn.warn(
                      "No client configured on scope - will not capture event!"
                  ),
              n);
    }
    _notifyScopeListeners() {
        this._notifyingListeners ||
            ((this._notifyingListeners = !0),
            this._scopeListeners.forEach((e) => {
                e(this);
            }),
            (this._notifyingListeners = !1));
    }
}
class Ir {
    constructor(e, t) {
        let n, r;
        (n = e || new Or()),
            (r = t || new Or()),
            (this._stack = [{ scope: n }]),
            (this._isolationScope = r);
    }
    withScope(e) {
        const t = this._pushScope();
        let n;
        try {
            n = e(t);
        } catch (r) {
            throw (this._popScope(), r);
        }
        return Vn(n)
            ? n.then(
                  (e) => (this._popScope(), e),
                  (e) => {
                      throw (this._popScope(), e);
                  }
              )
            : (this._popScope(), n);
    }
    getClient() {
        return this.getStackTop().client;
    }
    getScope() {
        return this.getStackTop().scope;
    }
    getIsolationScope() {
        return this._isolationScope;
    }
    getStackTop() {
        return this._stack[this._stack.length - 1];
    }
    _pushScope() {
        const e = this.getScope().clone();
        return this._stack.push({ client: this.getClient(), scope: e }), e;
    }
    _popScope() {
        return !(this._stack.length <= 1) && !!this._stack.pop();
    }
}
function Dr() {
    const e = un(cn());
    return (e.stack =
        e.stack ||
        new Ir(
            ln("defaultCurrentScope", () => new Or()),
            ln("defaultIsolationScope", () => new Or())
        ));
}
function Cr(e) {
    return Dr().withScope(e);
}
function Tr(e, t) {
    const n = Dr();
    return n.withScope(() => ((n.getStackTop().scope = e), t(e)));
}
function Pr(e) {
    return Dr().withScope(() => e(Dr().getIsolationScope()));
}
function Ar(e) {
    const t = un(e);
    return t.acs
        ? t.acs
        : {
              withIsolationScope: Pr,
              withScope: Cr,
              withSetScope: Tr,
              withSetIsolationScope: (e, t) => Pr(t),
              getCurrentScope: () => Dr().getScope(),
              getIsolationScope: () => Dr().getIsolationScope(),
          };
}
function jr() {
    return Ar(cn()).getCurrentScope();
}
function Rr() {
    return Ar(cn()).getIsolationScope();
}
function Lr() {
    return jr().getClient();
}
function Ur(e) {
    const t = e.getPropagationContext(),
        { traceId: n, parentSpanId: r, propagationSpanId: s } = t,
        o = { trace_id: n, span_id: s || Sr() };
    return r && (o.parent_span_id = r), o;
}
const Mr = "sentry.profile_id",
    Nr = "sentry.exclusive_time";
function $r(e) {
    return { scope: e._sentryScope, isolationScope: e._sentryIsolationScope };
}
const Kr = /^sentry-/;
function Fr(e) {
    const t = (function (e) {
        if (!e || (!Kn(e) && !Array.isArray(e))) return;
        if (Array.isArray(e))
            return e.reduce((e, t) => {
                const n = Br(t);
                return (
                    Object.entries(n).forEach(([t, n]) => {
                        e[t] = n;
                    }),
                    e
                );
            }, {});
        return Br(e);
    })(e);
    if (!t) return;
    const n = Object.entries(t).reduce((e, [t, n]) => {
        if (t.match(Kr)) {
            e[t.slice(7)] = n;
        }
        return e;
    }, {});
    return Object.keys(n).length > 0 ? n : void 0;
}
function Br(e) {
    return e
        .split(",")
        .map((e) =>
            e.split("=").map((e) => {
                try {
                    return decodeURIComponent(e.trim());
                } catch {
                    return;
                }
            })
        )
        .reduce((e, [t, n]) => (t && n && (e[t] = n), e), {});
}
const zr = /^o(\d+)\./,
    qr = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
function Vr(e, t = !1) {
    const {
        host: n,
        path: r,
        pass: s,
        port: o,
        projectId: i,
        protocol: a,
        publicKey: c,
    } = e;
    return `${a}://${c}${t && s ? `:${s}` : ""}@${n}${o ? `:${o}` : ""}/${
        r ? `${r}/` : r
    }${i}`;
}
function Gr(e) {
    return {
        protocol: e.protocol,
        publicKey: e.publicKey || "",
        pass: e.pass || "",
        host: e.host,
        port: e.port || "",
        path: e.path || "",
        projectId: e.projectId,
    };
}
function Wr(e) {
    const t = e.getOptions(),
        { host: n } = e.getDsn() || {};
    let r;
    return (
        t.orgId
            ? (r = String(t.orgId))
            : n &&
              (r = (function (e) {
                  const t = e.match(zr);
                  return t?.[1];
              })(n)),
        r
    );
}
function Hr(e) {
    const t =
        "string" == typeof e
            ? (function (e) {
                  const t = qr.exec(e);
                  if (!t) return void hn(() => {});
                  const [n, r, s = "", o = "", i = "", a = ""] = t.slice(1);
                  let c = "",
                      u = a;
                  const l = u.split("/");
                  if (
                      (l.length > 1 &&
                          ((c = l.slice(0, -1).join("/")), (u = l.pop())),
                      u)
                  ) {
                      const e = u.match(/^\d+/);
                      e && (u = e[0]);
                  }
                  return Gr({
                      host: o,
                      pass: s,
                      path: c,
                      projectId: u,
                      port: i,
                      protocol: n,
                      publicKey: r,
                  });
              })(e)
            : Gr(e);
    if (
        t &&
        (function (e) {
            if (!sn) return !0;
            const { port: t, projectId: n, protocol: r } = e;
            return !(
                ["protocol", "publicKey", "host", "projectId"].find(
                    (t) =>
                        !e[t] &&
                        (vn.error(`Invalid Sentry Dsn: ${t} missing`), !0)
                ) ||
                (n.match(/^\d+$/)
                    ? (function (e) {
                          return "http" === e || "https" === e;
                      })(r)
                        ? t &&
                          isNaN(parseInt(t, 10)) &&
                          (vn.error(`Invalid Sentry Dsn: Invalid port ${t}`), 1)
                        : (vn.error(
                              `Invalid Sentry Dsn: Invalid protocol ${r}`
                          ),
                          1)
                    : (vn.error(`Invalid Sentry Dsn: Invalid projectId ${n}`),
                      1))
            );
        })(t)
    )
        return t;
}
let Jr = !1;
function Yr(e) {
    const { spanId: t, traceId: n, isRemote: r } = e.spanContext(),
        s = r ? t : es(e).parent_span_id,
        o = $r(e).scope;
    return {
        parent_span_id: s,
        span_id: r ? o?.getPropagationContext().propagationSpanId || Sr() : t,
        trace_id: n,
    };
}
function Xr(e) {
    return e && e.length > 0
        ? e.map(
              ({
                  context: { spanId: e, traceId: t, traceFlags: n, ...r },
                  attributes: s,
              }) => ({
                  span_id: e,
                  trace_id: t,
                  sampled: 1 === n,
                  attributes: s,
                  ...r,
              })
          )
        : void 0;
}
function Qr(e) {
    return "number" == typeof e
        ? Zr(e)
        : Array.isArray(e)
        ? e[0] + e[1] / 1e9
        : e instanceof Date
        ? Zr(e.getTime())
        : vr();
}
function Zr(e) {
    return e > 9999999999 ? e / 1e3 : e;
}
function es(e) {
    if (
        (function (e) {
            return "function" == typeof e.getSpanJSON;
        })(e)
    )
        return e.getSpanJSON();
    const { spanId: t, traceId: n } = e.spanContext();
    if (
        (function (e) {
            const t = e;
            return !!(
                t.attributes &&
                t.startTime &&
                t.name &&
                t.endTime &&
                t.status
            );
        })(e)
    ) {
        const {
            attributes: r,
            startTime: s,
            name: o,
            endTime: i,
            status: a,
            links: c,
        } = e;
        return {
            span_id: t,
            trace_id: n,
            data: r,
            description: o,
            parent_span_id:
                "parentSpanId" in e
                    ? e.parentSpanId
                    : "parentSpanContext" in e
                    ? e.parentSpanContext?.spanId
                    : void 0,
            start_timestamp: Qr(s),
            timestamp: Qr(i) || void 0,
            status: ts(a),
            op: r["sentry.op"],
            origin: r["sentry.origin"],
            links: Xr(c),
        };
    }
    return { span_id: t, trace_id: n, start_timestamp: 0, data: {} };
}
function ts(e) {
    if (e && 0 !== e.code)
        return 1 === e.code ? "ok" : e.message || "unknown_error";
}
function ns(e) {
    return e._sentryRootSpan || e;
}
function rs() {
    Jr || (hn(() => {}), (Jr = !0));
}
const ss = "production";
function os(e, t) {
    const n = t.getOptions(),
        { publicKey: r } = t.getDsn() || {},
        s = {
            environment: n.environment || ss,
            release: n.release,
            public_key: r,
            trace_id: e,
            org_id: Wr(t),
        };
    return t.emit("createDsc", s), s;
}
function is(e) {
    const t = Lr();
    if (!t) return {};
    const n = ns(e),
        r = es(n),
        s = r.data,
        o = n.spanContext().traceState,
        i =
            o?.get("sentry.sample_rate") ??
            s["sentry.sample_rate"] ??
            s["sentry.previous_trace_sample_rate"];
    function a(e) {
        return (
            ("number" != typeof i && "string" != typeof i) ||
                (e.sample_rate = `${i}`),
            e
        );
    }
    const c = n._frozenDsc;
    if (c) return a(c);
    const u = o?.get("sentry.dsc"),
        l = u && Fr(u);
    if (l) return a(l);
    const d = os(e.spanContext().traceId, t),
        f = s["sentry.source"],
        h = r.description;
    return (
        "url" !== f && h && (d.transaction = h),
        (function () {
            if ("boolean" == typeof __SENTRY_TRACING__ && !__SENTRY_TRACING__)
                return !1;
            const e = Lr()?.getOptions();
            return !(!e || (null == e.tracesSampleRate && !e.tracesSampler));
        })() &&
            ((d.sampled = String(
                (function (e) {
                    const { traceFlags: t } = e.spanContext();
                    return 1 === t;
                })(n)
            )),
            (d.sample_rand =
                o?.get("sentry.sample_rand") ??
                $r(n).scope?.getPropagationContext().sampleRand.toString())),
        a(d),
        t.emit("createDsc", d, n),
        d
    );
}
function as(e, t = 100, n = 1 / 0) {
    try {
        return us("", e, t, n);
    } catch (r) {
        return { ERROR: `**non-serializable** (${r})` };
    }
}
function cs(e, t = 3, n = 102400) {
    const r = as(e, t);
    return (
        (s = r),
        (function (e) {
            return ~-encodeURI(e).split(/%..|./).length;
        })(JSON.stringify(s)) > n
            ? cs(e, t - 1, n)
            : r
    );
    var s;
}
function us(
    e,
    t,
    n = 1 / 0,
    r = 1 / 0,
    s = (function () {
        const e = new WeakSet();
        function t(t) {
            return !!e.has(t) || (e.add(t), !1);
        }
        function n(t) {
            e.delete(t);
        }
        return [t, n];
    })()
) {
    const [o, i] = s;
    if (
        null == t ||
        ["boolean", "string"].includes(typeof t) ||
        ("number" == typeof t && Number.isFinite(t))
    )
        return t;
    const a = (function (e, t) {
        try {
            if ("domain" === e && t && "object" == typeof t && t._events)
                return "[Domain]";
            if ("domainEmitter" === e) return "[DomainEmitter]";
            if ("undefined" != typeof global && t === global) return "[Global]";
            if ("undefined" != typeof window && t === window) return "[Window]";
            if ("undefined" != typeof document && t === document)
                return "[Document]";
            if (Wn(t)) return "[VueViewModel]";
            if (
                zn((n = t)) &&
                "nativeEvent" in n &&
                "preventDefault" in n &&
                "stopPropagation" in n
            )
                return "[SyntheticEvent]";
            if ("number" == typeof t && !Number.isFinite(t)) return `[${t}]`;
            if ("function" == typeof t) return `[Function: ${wn(t)}]`;
            if ("symbol" == typeof t) return `[${String(t)}]`;
            if ("bigint" == typeof t) return `[BigInt: ${String(t)}]`;
            const r = (function (e) {
                const t = Object.getPrototypeOf(e);
                return t?.constructor ? t.constructor.name : "null prototype";
            })(t);
            return /^HTML(\w*)Element$/.test(r)
                ? `[HTMLElement: ${r}]`
                : `[object ${r}]`;
        } catch (r) {
            return `**non-serializable** (${r})`;
        }
        var n;
    })(e, t);
    if (!a.startsWith("[object ")) return a;
    if (t.__sentry_skip_normalization__) return t;
    const c =
        "number" == typeof t.__sentry_override_normalization_depth__
            ? t.__sentry_override_normalization_depth__
            : n;
    if (0 === c) return a.replace("object ", "");
    if (o(t)) return "[Circular ~]";
    const u = t;
    if (u && "function" == typeof u.toJSON)
        try {
            return us("", u.toJSON(), c - 1, r, s);
        } catch {}
    const l = Array.isArray(t) ? [] : {};
    let d = 0;
    const f = ir(t);
    for (const h in f) {
        if (!Object.prototype.hasOwnProperty.call(f, h)) continue;
        if (d >= r) {
            l[h] = "[MaxProperties ~]";
            break;
        }
        const e = f[h];
        (l[h] = us(h, e, c - 1, r, s)), d++;
    }
    return i(t), l;
}
function ls(e, t = []) {
    return [e, t];
}
function ds(e, t) {
    const [n, r] = e;
    return [n, [...r, t]];
}
function fs(e, t) {
    const n = e[1];
    for (const r of n) {
        if (t(r, r[0].type)) return !0;
    }
    return !1;
}
function hs(e) {
    const t = un(on);
    return t.encodePolyfill ? t.encodePolyfill(e) : new TextEncoder().encode(e);
}
function ps(e) {
    const [t, n] = e;
    let r = JSON.stringify(t);
    function s(e) {
        "string" == typeof r
            ? (r = "string" == typeof e ? r + e : [hs(r), e])
            : r.push("string" == typeof e ? hs(e) : e);
    }
    for (const o of n) {
        const [e, t] = o;
        if (
            (s(`\n${JSON.stringify(e)}\n`),
            "string" == typeof t || t instanceof Uint8Array)
        )
            s(t);
        else {
            let e;
            try {
                e = JSON.stringify(t);
            } catch {
                e = JSON.stringify(as(t));
            }
            s(e);
        }
    }
    return "string" == typeof r
        ? r
        : (function (e) {
              const t = e.reduce((e, t) => e + t.length, 0),
                  n = new Uint8Array(t);
              let r = 0;
              for (const s of e) n.set(s, r), (r += s.length);
              return n;
          })(r);
}
function _s(e) {
    const t = "string" == typeof e.data ? hs(e.data) : e.data;
    return [
        {
            type: "attachment",
            length: t.length,
            filename: e.filename,
            content_type: e.contentType,
            attachment_type: e.attachmentType,
        },
        t,
    ];
}
const gs = {
    session: "session",
    sessions: "session",
    attachment: "attachment",
    transaction: "transaction",
    event: "error",
    client_report: "internal",
    user_report: "default",
    profile: "profile",
    profile_chunk: "profile",
    replay_event: "replay",
    replay_recording: "replay",
    check_in: "monitor",
    feedback: "feedback",
    span: "span",
    raw_security: "security",
    log: "log_item",
};
function vs(e) {
    return gs[e];
}
function ms(e) {
    if (!e?.sdk) return;
    const { name: t, version: n } = e.sdk;
    return { name: t, version: n };
}
function ys(e, t, n, r) {
    const s = ms(n),
        o = e.type && "replay_event" !== e.type ? e.type : "event";
    !(function (e, t) {
        t &&
            ((e.sdk = e.sdk || {}),
            (e.sdk.name = e.sdk.name || t.name),
            (e.sdk.version = e.sdk.version || t.version),
            (e.sdk.integrations = [
                ...(e.sdk.integrations || []),
                ...(t.integrations || []),
            ]),
            (e.sdk.packages = [
                ...(e.sdk.packages || []),
                ...(t.packages || []),
            ]));
    })(e, n?.sdk);
    const i = (function (e, t, n, r) {
        const s = e.sdkProcessingMetadata?.dynamicSamplingContext;
        return {
            event_id: e.event_id,
            sent_at: new Date().toISOString(),
            ...(t && { sdk: t }),
            ...(!!n && r && { dsn: Vr(r) }),
            ...(s && { trace: s }),
        };
    })(e, s, r, t);
    delete e.sdkProcessingMetadata;
    return ls(i, [[{ type: o }, e]]);
}
function bs(e) {
    return new Ss((t) => {
        t(e);
    });
}
function Es(e) {
    return new Ss((t, n) => {
        n(e);
    });
}
class Ss {
    constructor(e) {
        (this._state = 0), (this._handlers = []), this._runExecutor(e);
    }
    then(e, t) {
        return new Ss((n, r) => {
            this._handlers.push([
                !1,
                (t) => {
                    if (e)
                        try {
                            n(e(t));
                        } catch (s) {
                            r(s);
                        }
                    else n(t);
                },
                (e) => {
                    if (t)
                        try {
                            n(t(e));
                        } catch (s) {
                            r(s);
                        }
                    else r(e);
                },
            ]),
                this._executeHandlers();
        });
    }
    catch(e) {
        return this.then((e) => e, e);
    }
    finally(e) {
        return new Ss((t, n) => {
            let r, s;
            return this.then(
                (t) => {
                    (s = !1), (r = t), e && e();
                },
                (t) => {
                    (s = !0), (r = t), e && e();
                }
            ).then(() => {
                s ? n(r) : t(r);
            });
        });
    }
    _executeHandlers() {
        if (0 === this._state) return;
        const e = this._handlers.slice();
        (this._handlers = []),
            e.forEach((e) => {
                e[0] ||
                    (1 === this._state && e[1](this._value),
                    2 === this._state && e[2](this._value),
                    (e[0] = !0));
            });
    }
    _runExecutor(e) {
        const t = (e, t) => {
                0 === this._state &&
                    (Vn(t)
                        ? t.then(n, r)
                        : ((this._state = e),
                          (this._value = t),
                          this._executeHandlers()));
            },
            n = (e) => {
                t(1, e);
            },
            r = (e) => {
                t(2, e);
            };
        try {
            e(n, r);
        } catch (s) {
            r(s);
        }
    }
}
function ks(e, t, n, r = 0) {
    return new Ss((s, o) => {
        const i = e[r];
        if (null === t || "function" != typeof i) s(t);
        else {
            const a = i({ ...t }, n);
            sn &&
                i.id &&
                null === a &&
                vn.log(`Event processor "${i.id}" dropped event`),
                Vn(a)
                    ? a.then((t) => ks(e, t, n, r + 1).then(s)).then(null, o)
                    : ks(e, a, n, r + 1)
                          .then(s)
                          .then(null, o);
        }
    });
}
function ws(e, t) {
    const {
        fingerprint: n,
        span: r,
        breadcrumbs: s,
        sdkProcessingMetadata: o,
    } = t;
    !(function (e, t) {
        const {
            extra: n,
            tags: r,
            user: s,
            contexts: o,
            level: i,
            transactionName: a,
        } = t;
        Object.keys(n).length && (e.extra = { ...n, ...e.extra });
        Object.keys(r).length && (e.tags = { ...r, ...e.tags });
        Object.keys(s).length && (e.user = { ...s, ...e.user });
        Object.keys(o).length && (e.contexts = { ...o, ...e.contexts });
        i && (e.level = i);
        a && "transaction" !== e.type && (e.transaction = a);
    })(e, t),
        r &&
            (function (e, t) {
                (e.contexts = { trace: Yr(t), ...e.contexts }),
                    (e.sdkProcessingMetadata = {
                        dynamicSamplingContext: is(t),
                        ...e.sdkProcessingMetadata,
                    });
                const n = ns(t),
                    r = es(n).description;
                r &&
                    !e.transaction &&
                    "transaction" === e.type &&
                    (e.transaction = r);
            })(e, r),
        (function (e, t) {
            (e.fingerprint = e.fingerprint
                ? Array.isArray(e.fingerprint)
                    ? e.fingerprint
                    : [e.fingerprint]
                : []),
                t && (e.fingerprint = e.fingerprint.concat(t));
            e.fingerprint.length || delete e.fingerprint;
        })(e, n),
        (function (e, t) {
            const n = [...(e.breadcrumbs || []), ...t];
            e.breadcrumbs = n.length ? n : void 0;
        })(e, s),
        (function (e, t) {
            e.sdkProcessingMetadata = { ...e.sdkProcessingMetadata, ...t };
        })(e, o);
}
function xs(e, t) {
    const {
        extra: n,
        tags: r,
        user: s,
        contexts: o,
        level: i,
        sdkProcessingMetadata: a,
        breadcrumbs: c,
        fingerprint: u,
        eventProcessors: l,
        attachments: d,
        propagationContext: f,
        transactionName: h,
        span: p,
    } = t;
    Os(e, "extra", n),
        Os(e, "tags", r),
        Os(e, "user", s),
        Os(e, "contexts", o),
        (e.sdkProcessingMetadata = br(e.sdkProcessingMetadata, a, 2)),
        i && (e.level = i),
        h && (e.transactionName = h),
        p && (e.span = p),
        c.length && (e.breadcrumbs = [...e.breadcrumbs, ...c]),
        u.length && (e.fingerprint = [...e.fingerprint, ...u]),
        l.length && (e.eventProcessors = [...e.eventProcessors, ...l]),
        d.length && (e.attachments = [...e.attachments, ...d]),
        (e.propagationContext = { ...e.propagationContext, ...f });
}
function Os(e, t, n) {
    e[t] = br(e[t], n, 1);
}
let Is, Ds, Cs;
function Ts(e, t, n, r, s, o) {
    const { normalizeDepth: i = 3, normalizeMaxBreadth: a = 1e3 } = e,
        c = {
            ...t,
            event_id: t.event_id || n.event_id || ur(),
            timestamp: t.timestamp || _r(),
        },
        u = n.integrations || e.integrations.map((e) => e.name);
    !(function (e, t) {
        const {
            environment: n,
            release: r,
            dist: s,
            maxValueLength: o = 250,
        } = t;
        (e.environment = e.environment || n || ss),
            !e.release && r && (e.release = r);
        !e.dist && s && (e.dist = s);
        const i = e.request;
        i?.url && (i.url = Qn(i.url, o));
    })(c, e),
        (function (e, t) {
            t.length > 0 &&
                ((e.sdk = e.sdk || {}),
                (e.sdk.integrations = [...(e.sdk.integrations || []), ...t]));
        })(c, u),
        s && s.emit("applyFrameMetadata", t),
        void 0 === t.type &&
            (function (e, t) {
                const n = (function (e) {
                    const t = on._sentryDebugIds;
                    if (!t) return {};
                    const n = Object.keys(t);
                    return (
                        (Cs && n.length === Ds) ||
                            ((Ds = n.length),
                            (Cs = n.reduce((n, r) => {
                                Is || (Is = {});
                                const s = Is[r];
                                if (s) n[s[0]] = s[1];
                                else {
                                    const s = e(r);
                                    for (let e = s.length - 1; e >= 0; e--) {
                                        const o = s[e],
                                            i = o?.filename,
                                            a = t[r];
                                        if (i && a) {
                                            (n[i] = a), (Is[r] = [i, a]);
                                            break;
                                        }
                                    }
                                }
                                return n;
                            }, {}))),
                        Cs
                    );
                })(t);
                e.exception?.values?.forEach((e) => {
                    e.stacktrace?.frames?.forEach((e) => {
                        e.filename && (e.debug_id = n[e.filename]);
                    });
                });
            })(c, e.stackParser);
    const l = (function (e, t) {
        if (!t) return e;
        const n = e ? e.clone() : new Or();
        return n.update(t), n;
    })(r, n.captureContext);
    n.mechanism && hr(c, n.mechanism);
    const d = s ? s.getEventProcessors() : [],
        f = ln("globalScope", () => new Or()).getScopeData();
    if (o) {
        xs(f, o.getScopeData());
    }
    if (l) {
        xs(f, l.getScopeData());
    }
    const h = [...(n.attachments || []), ...f.attachments];
    h.length && (n.attachments = h), ws(c, f);
    return ks([...d, ...f.eventProcessors], c, n).then(
        (e) => (
            e &&
                (function (e) {
                    const t = {};
                    if (
                        (e.exception?.values?.forEach((e) => {
                            e.stacktrace?.frames?.forEach((e) => {
                                e.debug_id &&
                                    (e.abs_path
                                        ? (t[e.abs_path] = e.debug_id)
                                        : e.filename &&
                                          (t[e.filename] = e.debug_id),
                                    delete e.debug_id);
                            });
                        }),
                        0 === Object.keys(t).length)
                    )
                        return;
                    (e.debug_meta = e.debug_meta || {}),
                        (e.debug_meta.images = e.debug_meta.images || []);
                    const n = e.debug_meta.images;
                    Object.entries(t).forEach(([e, t]) => {
                        n.push({
                            type: "sourcemap",
                            code_file: e,
                            debug_id: t,
                        });
                    });
                })(e),
            "number" == typeof i && i > 0
                ? (function (e, t, n) {
                      if (!e) return null;
                      const r = {
                          ...e,
                          ...(e.breadcrumbs && {
                              breadcrumbs: e.breadcrumbs.map((e) => ({
                                  ...e,
                                  ...(e.data && { data: as(e.data, t, n) }),
                              })),
                          }),
                          ...(e.user && { user: as(e.user, t, n) }),
                          ...(e.contexts && { contexts: as(e.contexts, t, n) }),
                          ...(e.extra && { extra: as(e.extra, t, n) }),
                      };
                      e.contexts?.trace &&
                          r.contexts &&
                          ((r.contexts.trace = e.contexts.trace),
                          e.contexts.trace.data &&
                              (r.contexts.trace.data = as(
                                  e.contexts.trace.data,
                                  t,
                                  n
                              )));
                      e.spans &&
                          (r.spans = e.spans.map((e) => ({
                              ...e,
                              ...(e.data && { data: as(e.data, t, n) }),
                          })));
                      e.contexts?.flags &&
                          r.contexts &&
                          (r.contexts.flags = as(e.contexts.flags, 3, n));
                      return r;
                  })(e, i, a)
                : e
        )
    );
}
function Ps(e, t) {
    return jr().captureEvent(e, t);
}
function As(e) {
    const t = Rr(),
        n = jr(),
        { userAgent: r } = on.navigator || {},
        s = mr({
            user: n.getUser() || t.getUser(),
            ...(r && { userAgent: r }),
            ...e,
        }),
        o = t.getSession();
    return (
        "ok" === o?.status && yr(o, { status: "exited" }),
        js(),
        t.setSession(s),
        s
    );
}
function js() {
    const e = Rr(),
        t = jr().getSession() || e.getSession();
    t &&
        (function (e) {
            let t = {};
            "ok" === e.status && (t = { status: "exited" }), yr(e, t);
        })(t),
        Rs(),
        e.setSession();
}
function Rs() {
    const e = Rr(),
        t = Lr(),
        n = e.getSession();
    n && t && t.captureSession(n);
}
function Ls(e = !1) {
    e ? js() : Rs();
}
function Us(e, t, n) {
    return (
        t ||
        `${(function (e) {
            return `${(function (e) {
                const t = e.protocol ? `${e.protocol}:` : "",
                    n = e.port ? `:${e.port}` : "";
                return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
            })(e)}${e.projectId}/envelope/`;
        })(e)}?${(function (e, t) {
            const n = { sentry_version: "7" };
            return (
                e.publicKey && (n.sentry_key = e.publicKey),
                t && (n.sentry_client = `${t.name}/${t.version}`),
                new URLSearchParams(n).toString()
            );
        })(e, n)}`
    );
}
const Ms = [];
function Ns(e) {
    const t = e.defaultIntegrations || [],
        n = e.integrations;
    let r;
    if (
        (t.forEach((e) => {
            e.isDefaultInstance = !0;
        }),
        Array.isArray(n))
    )
        r = [...t, ...n];
    else if ("function" == typeof n) {
        const e = n(t);
        r = Array.isArray(e) ? e : [e];
    } else r = t;
    return (function (e) {
        const t = {};
        return (
            e.forEach((e) => {
                const { name: n } = e,
                    r = t[n];
                (r && !r.isDefaultInstance && e.isDefaultInstance) ||
                    (t[n] = e);
            }),
            Object.values(t)
        );
    })(r);
}
function $s(e, t) {
    for (const n of t) n?.afterAllSetup && n.afterAllSetup(e);
}
function Ks(e, t, n) {
    if (n[t.name])
        sn &&
            vn.log(
                `Integration skipped because it was already installed: ${t.name}`
            );
    else {
        if (
            ((n[t.name] = t),
            -1 === Ms.indexOf(t.name) &&
                "function" == typeof t.setupOnce &&
                (t.setupOnce(), Ms.push(t.name)),
            t.setup && "function" == typeof t.setup && t.setup(e),
            "function" == typeof t.preprocessEvent)
        ) {
            const n = t.preprocessEvent.bind(t);
            e.on("preprocessEvent", (t, r) => n(t, r, e));
        }
        if ("function" == typeof t.processEvent) {
            const n = t.processEvent.bind(t),
                r = Object.assign((t, r) => n(t, r, e), { id: t.name });
            e.addEventProcessor(r);
        }
        sn && vn.log(`Integration installed: ${t.name}`);
    }
}
function Fs(e) {
    const t = [];
    e.message && t.push(e.message);
    try {
        const n = e.exception.values[e.exception.values.length - 1];
        n?.value &&
            (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`));
    } catch {}
    return t;
}
const Bs = "Not capturing exception because it's already been captured.",
    zs = "Discarded session because of missing or non-string release",
    qs = Symbol.for("SentryInternalError"),
    Vs = Symbol.for("SentryDoNotSendEventError");
function Gs(e) {
    return { message: e, [qs]: !0 };
}
function Ws(e) {
    return { message: e, [Vs]: !0 };
}
function Hs(e) {
    return !!e && "object" == typeof e && qs in e;
}
function Js(e) {
    return !!e && "object" == typeof e && Vs in e;
}
class Ys {
    constructor(e) {
        if (
            ((this._options = e),
            (this._integrations = {}),
            (this._numProcessing = 0),
            (this._outcomes = {}),
            (this._hooks = {}),
            (this._eventProcessors = []),
            e.dsn
                ? (this._dsn = Hr(e.dsn))
                : sn &&
                  vn.warn("No DSN provided, client will not send events."),
            this._dsn)
        ) {
            const t = Us(
                this._dsn,
                e.tunnel,
                e._metadata ? e._metadata.sdk : void 0
            );
            this._transport = e.transport({
                tunnel: this._options.tunnel,
                recordDroppedEvent: this.recordDroppedEvent.bind(this),
                ...e.transportOptions,
                url: t,
            });
        }
    }
    captureException(e, t, n) {
        const r = ur();
        if (pr(e)) return sn && vn.log(Bs), r;
        const s = { event_id: r, ...t };
        return (
            this._process(
                this.eventFromException(e, s).then((e) =>
                    this._captureEvent(e, s, n)
                )
            ),
            s.event_id
        );
    }
    captureMessage(e, t, n, r) {
        const s = { event_id: ur(), ...n },
            o = Fn(e) ? e : String(e),
            i = Bn(e)
                ? this.eventFromMessage(o, t, s)
                : this.eventFromException(e, s);
        return (
            this._process(i.then((e) => this._captureEvent(e, s, r))),
            s.event_id
        );
    }
    captureEvent(e, t, n) {
        const r = ur();
        if (t?.originalException && pr(t.originalException))
            return sn && vn.log(Bs), r;
        const s = { event_id: r, ...t },
            o = e.sdkProcessingMetadata || {},
            i = o.capturedSpanScope,
            a = o.capturedSpanIsolationScope;
        return this._process(this._captureEvent(e, s, i || n, a)), s.event_id;
    }
    captureSession(e) {
        this.sendSession(e), yr(e, { init: !1 });
    }
    getDsn() {
        return this._dsn;
    }
    getOptions() {
        return this._options;
    }
    getSdkMetadata() {
        return this._options._metadata;
    }
    getTransport() {
        return this._transport;
    }
    flush(e) {
        const t = this._transport;
        return t
            ? (this.emit("flush"),
              this._isClientDoneProcessing(e).then((n) =>
                  t.flush(e).then((e) => n && e)
              ))
            : bs(!0);
    }
    close(e) {
        return this.flush(e).then(
            (e) => ((this.getOptions().enabled = !1), this.emit("close"), e)
        );
    }
    getEventProcessors() {
        return this._eventProcessors;
    }
    addEventProcessor(e) {
        this._eventProcessors.push(e);
    }
    init() {
        (this._isEnabled() ||
            this._options.integrations.some(({ name: e }) =>
                e.startsWith("Spotlight")
            )) &&
            this._setupIntegrations();
    }
    getIntegrationByName(e) {
        return this._integrations[e];
    }
    addIntegration(e) {
        const t = this._integrations[e.name];
        Ks(this, e, this._integrations), t || $s(this, [e]);
    }
    sendEvent(e, t = {}) {
        this.emit("beforeSendEvent", e, t);
        let n = ys(e, this._dsn, this._options._metadata, this._options.tunnel);
        for (const s of t.attachments || []) n = ds(n, _s(s));
        const r = this.sendEnvelope(n);
        r && r.then((t) => this.emit("afterSendEvent", e, t), null);
    }
    sendSession(e) {
        const { release: t, environment: n = ss } = this._options;
        if ("aggregates" in e) {
            const r = e.attrs || {};
            if (!r.release && !t) return void (sn && vn.warn(zs));
            (r.release = r.release || t),
                (r.environment = r.environment || n),
                (e.attrs = r);
        } else {
            if (!e.release && !t) return void (sn && vn.warn(zs));
            (e.release = e.release || t), (e.environment = e.environment || n);
        }
        this.emit("beforeSendSession", e);
        const r = (function (e, t, n, r) {
            const s = ms(n);
            return ls(
                {
                    sent_at: new Date().toISOString(),
                    ...(s && { sdk: s }),
                    ...(!!r && t && { dsn: Vr(t) }),
                },
                [
                    "aggregates" in e
                        ? [{ type: "sessions" }, e]
                        : [{ type: "session" }, e.toJSON()],
                ]
            );
        })(e, this._dsn, this._options._metadata, this._options.tunnel);
        this.sendEnvelope(r);
    }
    recordDroppedEvent(e, t, n = 1) {
        if (this._options.sendClientReports) {
            const r = `${e}:${t}`;
            sn &&
                vn.log(
                    `Recording outcome: "${r}"${n > 1 ? ` (${n} times)` : ""}`
                ),
                (this._outcomes[r] = (this._outcomes[r] || 0) + n);
        }
    }
    on(e, t) {
        const n = (this._hooks[e] = this._hooks[e] || []);
        return (
            n.push(t),
            () => {
                const e = n.indexOf(t);
                e > -1 && n.splice(e, 1);
            }
        );
    }
    emit(e, ...t) {
        const n = this._hooks[e];
        n && n.forEach((e) => e(...t));
    }
    sendEnvelope(e) {
        return (
            this.emit("beforeEnvelope", e),
            this._isEnabled() && this._transport
                ? this._transport
                      .send(e)
                      .then(
                          null,
                          (e) => (
                              sn &&
                                  vn.error("Error while sending envelope:", e),
                              e
                          )
                      )
                : (sn && vn.error("Transport disabled"), bs({}))
        );
    }
    _setupIntegrations() {
        const { integrations: e } = this._options;
        (this._integrations = (function (e, t) {
            const n = {};
            return (
                t.forEach((t) => {
                    t && Ks(e, t, n);
                }),
                n
            );
        })(this, e)),
            $s(this, e);
    }
    _updateSessionFromEvent(e, t) {
        let n = "fatal" === t.level,
            r = !1;
        const s = t.exception?.values;
        if (s) {
            r = !0;
            for (const e of s) {
                const t = e.mechanism;
                if (!1 === t?.handled) {
                    n = !0;
                    break;
                }
            }
        }
        const o = "ok" === e.status;
        ((o && 0 === e.errors) || (o && n)) &&
            (yr(e, {
                ...(n && { status: "crashed" }),
                errors: e.errors || Number(r || n),
            }),
            this.captureSession(e));
    }
    _isClientDoneProcessing(e) {
        return new Ss((t) => {
            let n = 0;
            const r = setInterval(() => {
                0 == this._numProcessing
                    ? (clearInterval(r), t(!0))
                    : ((n += 1), e && n >= e && (clearInterval(r), t(!1)));
            }, 1);
        });
    }
    _isEnabled() {
        return !1 !== this.getOptions().enabled && void 0 !== this._transport;
    }
    _prepareEvent(e, t, n, r) {
        const s = this.getOptions(),
            o = Object.keys(this._integrations);
        return (
            !t.integrations && o?.length && (t.integrations = o),
            this.emit("preprocessEvent", e, t),
            e.type || r.setLastEventId(e.event_id || t.event_id),
            Ts(s, e, t, n, this, r).then((e) => {
                if (null === e) return e;
                this.emit("postprocessEvent", e, t),
                    (e.contexts = { trace: Ur(n), ...e.contexts });
                const r = (function (e, t) {
                    const n = t.getPropagationContext();
                    return n.dsc || os(n.traceId, e);
                })(this, n);
                return (
                    (e.sdkProcessingMetadata = {
                        dynamicSamplingContext: r,
                        ...e.sdkProcessingMetadata,
                    }),
                    e
                );
            })
        );
    }
    _captureEvent(e, t = {}, n = jr(), r = Rr()) {
        return (
            sn &&
                Xs(e) &&
                vn.log(`Captured error event \`${Fs(e)[0] || "<unknown>"}\``),
            this._processEvent(e, t, n, r).then(
                (e) => e.event_id,
                (e) => {
                    sn &&
                        (Js(e)
                            ? vn.log(e.message)
                            : Hs(e)
                            ? vn.warn(e.message)
                            : vn.warn(e));
                }
            )
        );
    }
    _processEvent(e, t, n, r) {
        const s = this.getOptions(),
            { sampleRate: o } = s,
            i = Qs(e),
            a = Xs(e),
            c = e.type || "error",
            u = `before send for type \`${c}\``,
            l =
                void 0 === o
                    ? void 0
                    : (function (e) {
                          if ("boolean" == typeof e) return Number(e);
                          const t = "string" == typeof e ? parseFloat(e) : e;
                          return "number" != typeof t ||
                              isNaN(t) ||
                              t < 0 ||
                              t > 1
                              ? void 0
                              : t;
                      })(o);
        if (a && "number" == typeof l && Math.random() > l)
            return (
                this.recordDroppedEvent("sample_rate", "error"),
                Es(
                    Ws(
                        `Discarding event because it's not included in the random sample (sampling rate = ${o})`
                    )
                )
            );
        const d = "replay_event" === c ? "replay" : c;
        return this._prepareEvent(e, t, n, r)
            .then((e) => {
                if (null === e)
                    throw (
                        (this.recordDroppedEvent("event_processor", d),
                        Ws(
                            "An event processor returned `null`, will not send event."
                        ))
                    );
                if (t.data && !0 === t.data.__sentry__) return e;
                const n = (function (e, t, n, r) {
                    const {
                        beforeSend: s,
                        beforeSendTransaction: o,
                        beforeSendSpan: i,
                    } = t;
                    let a = n;
                    if (Xs(a) && s) return s(a, r);
                    if (Qs(a)) {
                        if (i) {
                            const e = i(
                                (function (e) {
                                    const {
                                        trace_id: t,
                                        parent_span_id: n,
                                        span_id: r,
                                        status: s,
                                        origin: o,
                                        data: i,
                                        op: a,
                                    } = e.contexts?.trace ?? {};
                                    return {
                                        data: i ?? {},
                                        description: e.transaction,
                                        op: a,
                                        parent_span_id: n,
                                        span_id: r ?? "",
                                        start_timestamp: e.start_timestamp ?? 0,
                                        status: s,
                                        timestamp: e.timestamp,
                                        trace_id: t ?? "",
                                        origin: o,
                                        profile_id: i?.[Mr],
                                        exclusive_time: i?.[Nr],
                                        measurements: e.measurements,
                                        is_segment: !0,
                                    };
                                })(a)
                            );
                            if (
                                (e
                                    ? (a = br(n, {
                                          type: "transaction",
                                          timestamp: (c = e).timestamp,
                                          start_timestamp: c.start_timestamp,
                                          transaction: c.description,
                                          contexts: {
                                              trace: {
                                                  trace_id: c.trace_id,
                                                  span_id: c.span_id,
                                                  parent_span_id:
                                                      c.parent_span_id,
                                                  op: c.op,
                                                  status: c.status,
                                                  origin: c.origin,
                                                  data: {
                                                      ...c.data,
                                                      ...(c.profile_id && {
                                                          [Mr]: c.profile_id,
                                                      }),
                                                      ...(c.exclusive_time && {
                                                          [Nr]: c.exclusive_time,
                                                      }),
                                                  },
                                              },
                                          },
                                          measurements: c.measurements,
                                      }))
                                    : rs(),
                                a.spans)
                            ) {
                                const e = [];
                                for (const t of a.spans) {
                                    const n = i(t);
                                    n ? e.push(n) : (rs(), e.push(t));
                                }
                                a.spans = e;
                            }
                        }
                        if (o) {
                            if (a.spans) {
                                const e = a.spans.length;
                                a.sdkProcessingMetadata = {
                                    ...n.sdkProcessingMetadata,
                                    spanCountBeforeProcessing: e,
                                };
                            }
                            return o(a, r);
                        }
                    }
                    var c;
                    return a;
                })(0, s, e, t);
                return (function (e, t) {
                    const n = `${t} must return \`null\` or a valid event.`;
                    if (Vn(e))
                        return e.then(
                            (e) => {
                                if (!zn(e) && null !== e) throw Gs(n);
                                return e;
                            },
                            (e) => {
                                throw Gs(`${t} rejected with ${e}`);
                            }
                        );
                    if (!zn(e) && null !== e) throw Gs(n);
                    return e;
                })(n, u);
            })
            .then((s) => {
                if (null === s) {
                    if ((this.recordDroppedEvent("before_send", d), i)) {
                        const t = 1 + (e.spans || []).length;
                        this.recordDroppedEvent("before_send", "span", t);
                    }
                    throw Ws(`${u} returned \`null\`, will not send event.`);
                }
                const o = n.getSession() || r.getSession();
                if ((a && o && this._updateSessionFromEvent(o, s), i)) {
                    const e =
                        (s.sdkProcessingMetadata?.spanCountBeforeProcessing ||
                            0) - (s.spans ? s.spans.length : 0);
                    e > 0 && this.recordDroppedEvent("before_send", "span", e);
                }
                const c = s.transaction_info;
                if (i && c && s.transaction !== e.transaction) {
                    const e = "custom";
                    s.transaction_info = { ...c, source: e };
                }
                return this.sendEvent(s, t), s;
            })
            .then(null, (e) => {
                if (Js(e) || Hs(e)) throw e;
                throw (
                    (this.captureException(e, {
                        data: { __sentry__: !0 },
                        originalException: e,
                    }),
                    Gs(
                        `Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: ${e}`
                    ))
                );
            });
    }
    _process(e) {
        this._numProcessing++,
            e.then(
                (e) => (this._numProcessing--, e),
                (e) => (this._numProcessing--, e)
            );
    }
    _clearOutcomes() {
        const e = this._outcomes;
        return (
            (this._outcomes = {}),
            Object.entries(e).map(([e, t]) => {
                const [n, r] = e.split(":");
                return { reason: n, category: r, quantity: t };
            })
        );
    }
    _flushOutcomes() {
        sn && vn.log("Flushing outcomes...");
        const e = this._clearOutcomes();
        if (0 === e.length) return void (sn && vn.log("No outcomes to send"));
        if (!this._dsn)
            return void (
                sn && vn.log("No dsn provided, will not send outcomes")
            );
        sn && vn.log("Sending outcomes:", e);
        const t =
            ((n = e),
            ls((r = this._options.tunnel && Vr(this._dsn)) ? { dsn: r } : {}, [
                [
                    { type: "client_report" },
                    { timestamp: _r(), discarded_events: n },
                ],
            ]));
        var n, r;
        this.sendEnvelope(t);
    }
}
function Xs(e) {
    return void 0 === e.type;
}
function Qs(e) {
    return "transaction" === e.type;
}
function Zs(e, t) {
    const n =
        (function (e) {
            return eo().get(e);
        })(e) ?? [];
    if (0 === n.length) return;
    const r = e.getOptions(),
        s = (function (e, t, n, r) {
            const s = {};
            return (
                t?.sdk &&
                    (s.sdk = { name: t.sdk.name, version: t.sdk.version }),
                n && r && (s.dsn = Vr(r)),
                ls(s, [
                    ((o = e),
                    [
                        {
                            type: "log",
                            item_count: o.length,
                            content_type:
                                "application/vnd.sentry.items.log+json",
                        },
                        { items: o },
                    ]),
                ])
            );
            var o;
        })(n, r._metadata, r.tunnel, e.getDsn());
    eo().set(e, []), e.emit("flushLogs"), e.sendEnvelope(s);
}
function eo() {
    return ln("clientToLogBufferMap", () => new WeakMap());
}
function to(e, t) {
    !0 === t.debug && (sn ? vn.enable() : hn(() => {}));
    jr().update(t.initialScope);
    const n = new e(t);
    return (
        (function (e) {
            jr().setClient(e);
        })(n),
        n.init(),
        n
    );
}
const no = Symbol.for("SentryBufferFullError");
function ro(e) {
    const t = [];
    function n(e) {
        return t.splice(t.indexOf(e), 1)[0] || Promise.resolve(void 0);
    }
    return {
        $: t,
        add: function (r) {
            if (!(void 0 === e || t.length < e)) return Es(no);
            const s = r();
            return (
                -1 === t.indexOf(s) && t.push(s),
                s.then(() => n(s)).then(null, () => n(s).then(null, () => {})),
                s
            );
        },
        drain: function (e) {
            return new Ss((n, r) => {
                let s = t.length;
                if (!s) return n(!0);
                const o = setTimeout(() => {
                    e && e > 0 && n(!1);
                }, e);
                t.forEach((e) => {
                    bs(e).then(() => {
                        --s || (clearTimeout(o), n(!0));
                    }, r);
                });
            });
        },
    };
}
function so(e, { statusCode: t, headers: n }, r = Date.now()) {
    const s = { ...e },
        o = n?.["x-sentry-rate-limits"],
        i = n?.["retry-after"];
    if (o)
        for (const a of o.trim().split(",")) {
            const [e, t, , , n] = a.split(":", 5),
                o = parseInt(e, 10),
                i = 1e3 * (isNaN(o) ? 60 : o);
            if (t)
                for (const a of t.split(";"))
                    ("metric_bucket" === a &&
                        n &&
                        !n.split(";").includes("custom")) ||
                        (s[a] = r + i);
            else s.all = r + i;
        }
    else
        i
            ? (s.all =
                  r +
                  (function (e, t = Date.now()) {
                      const n = parseInt(`${e}`, 10);
                      if (!isNaN(n)) return 1e3 * n;
                      const r = Date.parse(`${e}`);
                      return isNaN(r) ? 6e4 : r - t;
                  })(i, r))
            : 429 === t && (s.all = r + 6e4);
    return s;
}
function oo(e, t, n = ro(e.bufferSize || 64)) {
    let r = {};
    return {
        send: function (s) {
            const o = [];
            if (
                (fs(s, (t, n) => {
                    const s = vs(n);
                    !(function (e, t, n = Date.now()) {
                        return (
                            (function (e, t) {
                                return e[t] || e.all || 0;
                            })(e, t) > n
                        );
                    })(r, s)
                        ? o.push(t)
                        : e.recordDroppedEvent("ratelimit_backoff", s);
                }),
                0 === o.length)
            )
                return bs({});
            const i = ls(s[0], o),
                a = (t) => {
                    fs(i, (n, r) => {
                        e.recordDroppedEvent(t, vs(r));
                    });
                };
            return n
                .add(() =>
                    t({ body: ps(i) }).then(
                        (e) => (
                            void 0 !== e.statusCode &&
                                (e.statusCode < 200 || e.statusCode >= 300) &&
                                sn &&
                                vn.warn(
                                    `Sentry responded with status code ${e.statusCode} to sent event.`
                                ),
                            (r = so(r, e)),
                            e
                        ),
                        (e) => {
                            throw (
                                (a("network_error"),
                                sn &&
                                    vn.error(
                                        "Encountered error running transport request:",
                                        e
                                    ),
                                e)
                            );
                        }
                    )
                )
                .then(
                    (e) => e,
                    (e) => {
                        if (e === no)
                            return (
                                sn &&
                                    vn.error(
                                        "Skipped sending event because buffer is full."
                                    ),
                                a("queue_overflow"),
                                bs({})
                            );
                        throw e;
                    }
                );
        },
        flush: (e) => n.drain(e),
    };
}
function io(e) {
    void 0 === e.user?.ip_address &&
        (e.user = { ...e.user, ip_address: "{{auto}}" });
}
function ao(e) {
    "aggregates" in e
        ? void 0 === e.attrs?.ip_address &&
          (e.attrs = { ...e.attrs, ip_address: "{{auto}}" })
        : void 0 === e.ipAddress && (e.ipAddress = "{{auto}}");
}
const co = 100;
function uo(e, t) {
    const n = Lr(),
        r = Rr();
    if (!n) return;
    const { beforeBreadcrumb: s = null, maxBreadcrumbs: o = co } =
        n.getOptions();
    if (o <= 0) return;
    const i = { timestamp: _r(), ...e },
        a = s ? hn(() => s(i, t)) : i;
    null !== a &&
        (n.emit && n.emit("beforeAddBreadcrumb", a, t), r.addBreadcrumb(a, o));
}
let lo;
const fo = new WeakMap(),
    ho = () => ({
        name: "FunctionToString",
        setupOnce() {
            lo = Function.prototype.toString;
            try {
                Function.prototype.toString = function (...e) {
                    const t = or(this),
                        n = fo.has(Lr()) && void 0 !== t ? t : this;
                    return lo.apply(n, e);
                };
            } catch {}
        },
        setup(e) {
            fo.set(e, !0);
        },
    }),
    po = [
        /^Script error\.?$/,
        /^Javascript error: Script error\.? on line 0$/,
        /^ResizeObserver loop completed with undelivered notifications.$/,
        /^Cannot redefine property: googletag$/,
        /^Can't find variable: gmo$/,
        /^undefined is not an object \(evaluating 'a\.[A-Z]'\)$/,
        'can\'t redefine non-configurable property "solana"',
        "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
        "Can't find variable: _AutofillCallbackHandler",
        /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/,
        /^Java exception was raised during method invocation$/,
    ],
    _o = (e = {}) => {
        let t;
        return {
            name: "EventFilters",
            setup(n) {
                const r = n.getOptions();
                t = vo(e, r);
            },
            processEvent(n, r, s) {
                if (!t) {
                    const n = s.getOptions();
                    t = vo(e, n);
                }
                return (function (e, t) {
                    if (e.type) {
                        if (
                            "transaction" === e.type &&
                            (function (e, t) {
                                if (!t?.length) return !1;
                                const n = e.transaction;
                                return !!n && tr(n, t);
                            })(e, t.ignoreTransactions)
                        )
                            return (
                                sn &&
                                    vn.warn(
                                        `Event dropped due to being matched by \`ignoreTransactions\` option.\nEvent: ${dr(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                    } else {
                        if (
                            (function (e, t) {
                                if (!t?.length) return !1;
                                return Fs(e).some((e) => tr(e, t));
                            })(e, t.ignoreErrors)
                        )
                            return (
                                sn &&
                                    vn.warn(
                                        `Event dropped due to being matched by \`ignoreErrors\` option.\nEvent: ${dr(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                        if (
                            (function (e) {
                                if (!e.exception?.values?.length) return !1;
                                return (
                                    !e.message &&
                                    !e.exception.values.some(
                                        (e) =>
                                            e.stacktrace ||
                                            (e.type && "Error" !== e.type) ||
                                            e.value
                                    )
                                );
                            })(e)
                        )
                            return (
                                sn &&
                                    vn.warn(
                                        `Event dropped due to not having an error message, error type or stacktrace.\nEvent: ${dr(
                                            e
                                        )}`
                                    ),
                                !0
                            );
                        if (
                            (function (e, t) {
                                if (!t?.length) return !1;
                                const n = mo(e);
                                return !!n && tr(n, t);
                            })(e, t.denyUrls)
                        )
                            return (
                                sn &&
                                    vn.warn(
                                        `Event dropped due to being matched by \`denyUrls\` option.\nEvent: ${dr(
                                            e
                                        )}.\nUrl: ${mo(e)}`
                                    ),
                                !0
                            );
                        if (
                            !(function (e, t) {
                                if (!t?.length) return !0;
                                const n = mo(e);
                                return !n || tr(n, t);
                            })(e, t.allowUrls)
                        )
                            return (
                                sn &&
                                    vn.warn(
                                        `Event dropped due to not being matched by \`allowUrls\` option.\nEvent: ${dr(
                                            e
                                        )}.\nUrl: ${mo(e)}`
                                    ),
                                !0
                            );
                    }
                    return !1;
                })(n, t)
                    ? null
                    : n;
            },
        };
    },
    go = (e = {}) => ({ ..._o(e), name: "InboundFilters" });
function vo(e = {}, t = {}) {
    return {
        allowUrls: [...(e.allowUrls || []), ...(t.allowUrls || [])],
        denyUrls: [...(e.denyUrls || []), ...(t.denyUrls || [])],
        ignoreErrors: [
            ...(e.ignoreErrors || []),
            ...(t.ignoreErrors || []),
            ...(e.disableErrorDefaults ? [] : po),
        ],
        ignoreTransactions: [
            ...(e.ignoreTransactions || []),
            ...(t.ignoreTransactions || []),
        ],
    };
}
function mo(e) {
    try {
        const t = [...(e.exception?.values ?? [])]
                .reverse()
                .find(
                    (e) =>
                        void 0 === e.mechanism?.parent_id &&
                        e.stacktrace?.frames?.length
                ),
            n = t?.stacktrace?.frames;
        return n
            ? (function (e = []) {
                  for (let t = e.length - 1; t >= 0; t--) {
                      const n = e[t];
                      if (
                          n &&
                          "<anonymous>" !== n.filename &&
                          "[native code]" !== n.filename
                      )
                          return n.filename || null;
                  }
                  return null;
              })(n)
            : null;
    } catch {
        return sn && vn.error(`Cannot extract url for event ${dr(e)}`), null;
    }
}
function yo(e, t, n, r, s, o) {
    if (!s.exception?.values || !o || !Gn(o.originalException, Error)) return;
    const i =
        s.exception.values.length > 0
            ? s.exception.values[s.exception.values.length - 1]
            : void 0;
    i &&
        (s.exception.values = bo(
            e,
            t,
            r,
            o.originalException,
            n,
            s.exception.values,
            i,
            0
        ));
}
function bo(e, t, n, r, s, o, i, a) {
    if (o.length >= n + 1) return o;
    let c = [...o];
    if (Gn(r[s], Error)) {
        Eo(i, a);
        const o = e(t, r[s]),
            u = c.length;
        So(o, s, u, a), (c = bo(e, t, n, r[s], s, [o, ...c], o, u));
    }
    return (
        Array.isArray(r.errors) &&
            r.errors.forEach((r, o) => {
                if (Gn(r, Error)) {
                    Eo(i, a);
                    const u = e(t, r),
                        l = c.length;
                    So(u, `errors[${o}]`, l, a),
                        (c = bo(e, t, n, r, s, [u, ...c], u, l));
                }
            }),
        c
    );
}
function Eo(e, t) {
    (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
        (e.mechanism = {
            ...e.mechanism,
            ...("AggregateError" === e.type && { is_exception_group: !0 }),
            exception_id: t,
        });
}
function So(e, t, n, r) {
    (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
        (e.mechanism = {
            ...e.mechanism,
            type: "chained",
            source: t,
            exception_id: n,
            parent_id: r,
        });
}
function ko() {
    "console" in on &&
        dn.forEach(function (e) {
            e in on.console &&
                nr(on.console, e, function (t) {
                    return (
                        (fn[e] = t),
                        function (...t) {
                            Tn("console", { args: t, level: e });
                            const n = fn[e];
                            n?.apply(on.console, t);
                        }
                    );
                });
        });
}
function wo(e) {
    return "warn" === e
        ? "warning"
        : ["fatal", "error", "warning", "log", "info", "debug"].includes(e)
        ? e
        : "log";
}
const xo = () => {
    let e;
    return {
        name: "Dedupe",
        processEvent(t) {
            if (t.type) return t;
            try {
                if (
                    (function (e, t) {
                        if (!t) return !1;
                        if (
                            (function (e, t) {
                                const n = e.message,
                                    r = t.message;
                                if (!n && !r) return !1;
                                if ((n && !r) || (!n && r)) return !1;
                                if (n !== r) return !1;
                                if (!Io(e, t)) return !1;
                                if (!Oo(e, t)) return !1;
                                return !0;
                            })(e, t)
                        )
                            return !0;
                        if (
                            (function (e, t) {
                                const n = Do(t),
                                    r = Do(e);
                                if (!n || !r) return !1;
                                if (n.type !== r.type || n.value !== r.value)
                                    return !1;
                                if (!Io(e, t)) return !1;
                                if (!Oo(e, t)) return !1;
                                return !0;
                            })(e, t)
                        )
                            return !0;
                        return !1;
                    })(t, e)
                )
                    return (
                        sn &&
                            vn.warn(
                                "Event dropped due to being a duplicate of previously captured event."
                            ),
                        null
                    );
            } catch {}
            return (e = t);
        },
    };
};
function Oo(e, t) {
    let n = xn(e),
        r = xn(t);
    if (!n && !r) return !0;
    if ((n && !r) || (!n && r)) return !1;
    if (r.length !== n.length) return !1;
    for (let s = 0; s < r.length; s++) {
        const e = r[s],
            t = n[s];
        if (
            e.filename !== t.filename ||
            e.lineno !== t.lineno ||
            e.colno !== t.colno ||
            e.function !== t.function
        )
            return !1;
    }
    return !0;
}
function Io(e, t) {
    let n = e.fingerprint,
        r = t.fingerprint;
    if (!n && !r) return !0;
    if ((n && !r) || (!n && r)) return !1;
    try {
        return !(n.join("") !== r.join(""));
    } catch {
        return !1;
    }
}
function Do(e) {
    return e.exception?.values?.[0];
}
function Co(e) {
    if (!e) return {};
    const t = e.match(
        /^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/
    );
    if (!t) return {};
    const n = t[6] || "",
        r = t[8] || "";
    return {
        host: t[4],
        path: t[5],
        protocol: t[2],
        search: n,
        hash: r,
        relative: t[5] + n + r,
    };
}
function To(e) {
    return void 0 === e
        ? void 0
        : e >= 400 && e < 500
        ? "warning"
        : e >= 500
        ? "error"
        : void 0;
}
const Po = on;
function Ao(e) {
    return (
        e &&
        /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString())
    );
}
function jo() {
    if ("string" == typeof EdgeRuntime) return !0;
    if (
        !(function () {
            if (!("fetch" in Po)) return !1;
            try {
                return (
                    new Headers(),
                    new Request("http://www.example.com"),
                    new Response(),
                    !0
                );
            } catch {
                return !1;
            }
        })()
    )
        return !1;
    if (Ao(Po.fetch)) return !0;
    let e = !1;
    const t = Po.document;
    if (t && "function" == typeof t.createElement)
        try {
            const n = t.createElement("iframe");
            (n.hidden = !0),
                t.head.appendChild(n),
                n.contentWindow?.fetch && (e = Ao(n.contentWindow.fetch)),
                t.head.removeChild(n);
        } catch (n) {
            sn &&
                vn.warn(
                    "Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",
                    n
                );
        }
    return e;
}
function Ro(e, t) {
    const n = "fetch";
    Dn(n, e),
        Cn(n, () =>
            (function (e, t = !1) {
                if (t && !jo()) return;
                nr(on, "fetch", function (e) {
                    return function (...t) {
                        const n = new Error(),
                            { method: r, url: s } = (function (e) {
                                if (0 === e.length)
                                    return { method: "GET", url: "" };
                                if (2 === e.length) {
                                    const [t, n] = e;
                                    return {
                                        url: Uo(t),
                                        method: Lo(n, "method")
                                            ? String(n.method).toUpperCase()
                                            : "GET",
                                    };
                                }
                                const t = e[0];
                                return {
                                    url: Uo(t),
                                    method: Lo(t, "method")
                                        ? String(t.method).toUpperCase()
                                        : "GET",
                                };
                            })(t),
                            o = {
                                args: t,
                                fetchData: { method: r, url: s },
                                startTimestamp: 1e3 * vr(),
                                virtualError: n,
                                headers: Mo(t),
                            };
                        return (
                            Tn("fetch", { ...o }),
                            e.apply(on, t).then(
                                async (e) => (
                                    Tn("fetch", {
                                        ...o,
                                        endTimestamp: 1e3 * vr(),
                                        response: e,
                                    }),
                                    e
                                ),
                                (e) => {
                                    if (
                                        (Tn("fetch", {
                                            ...o,
                                            endTimestamp: 1e3 * vr(),
                                            error: e,
                                        }),
                                        Un(e) &&
                                            void 0 === e.stack &&
                                            ((e.stack = n.stack),
                                            rr(e, "framesToPop", 1)),
                                        e instanceof TypeError &&
                                            ("Failed to fetch" === e.message ||
                                                "Load failed" === e.message ||
                                                "NetworkError when attempting to fetch resource." ===
                                                    e.message))
                                    )
                                        try {
                                            const t = new URL(o.fetchData.url);
                                            e.message = `${e.message} (${t.host})`;
                                        } catch {}
                                    throw e;
                                }
                            )
                        );
                    };
                });
            })(0, t)
        );
}
function Lo(e, t) {
    return !!e && "object" == typeof e && !!e[t];
}
function Uo(e) {
    return "string" == typeof e
        ? e
        : e
        ? Lo(e, "url")
            ? e.url
            : e.toString
            ? e.toString()
            : ""
        : "";
}
function Mo(e) {
    const [t, n] = e;
    try {
        if ("object" == typeof n && null !== n && "headers" in n && n.headers)
            return new Headers(n.headers);
        if (((r = t), "undefined" != typeof Request && Gn(r, Request)))
            return new Headers(t.headers);
    } catch {}
    var r;
}
const No = on;
let $o = 0;
function Ko() {
    return $o > 0;
}
function Fo(e, t = {}) {
    if ("function" != typeof e) return e;
    try {
        const t = e.__sentry_wrapped__;
        if (t) return "function" == typeof t ? t : e;
        if (or(e)) return e;
    } catch {
        return e;
    }
    const n = function (...n) {
        try {
            const r = n.map((e) => Fo(e, t));
            return e.apply(this, r);
        } catch (r) {
            throw (
                ($o++,
                setTimeout(() => {
                    $o--;
                }),
                (function (...e) {
                    const t = Ar(cn());
                    if (2 === e.length) {
                        const [n, r] = e;
                        return n ? t.withSetScope(n, r) : t.withScope(r);
                    }
                    t.withScope(e[0]);
                })((e) => {
                    var s;
                    e.addEventProcessor(
                        (e) => (
                            t.mechanism && (fr(e, void 0), hr(e, t.mechanism)),
                            (e.extra = { ...e.extra, arguments: n }),
                            e
                        )
                    ),
                        (s = r),
                        jr().captureException(s, void 0);
                }),
                r)
            );
        }
    };
    try {
        for (const t in e)
            Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    } catch {}
    sr(n, e), rr(e, "__sentry_wrapped__", n);
    try {
        Object.getOwnPropertyDescriptor(n, "name").configurable &&
            Object.defineProperty(n, "name", { get: () => e.name });
    } catch {}
    return n;
}
function Bo(e, t) {
    const n = Vo(e, t),
        r = { type: Ho(t), value: Jo(t) };
    return (
        n.length && (r.stacktrace = { frames: n }),
        void 0 === r.type &&
            "" === r.value &&
            (r.value = "Unrecoverable error caught"),
        r
    );
}
function zo(e, t, n, r) {
    const s = Lr(),
        o = s?.getOptions().normalizeDepth,
        i = (function (e) {
            for (const t in e)
                if (Object.prototype.hasOwnProperty.call(e, t)) {
                    const n = e[t];
                    if (n instanceof Error) return n;
                }
            return;
        })(t),
        a = { __serialized__: cs(t, o) };
    if (i) return { exception: { values: [Bo(e, i)] }, extra: a };
    const c = {
        exception: {
            values: [
                {
                    type: qn(t)
                        ? t.constructor.name
                        : r
                        ? "UnhandledRejection"
                        : "Error",
                    value: Qo(t, { isUnhandledRejection: r }),
                },
            ],
        },
        extra: a,
    };
    if (n) {
        const t = Vo(e, n);
        t.length && (c.exception.values[0].stacktrace = { frames: t });
    }
    return c;
}
function qo(e, t) {
    return { exception: { values: [Bo(e, t)] } };
}
function Vo(e, t) {
    const n = t.stacktrace || t.stack || "",
        r = (function (e) {
            if (e && Go.test(e.message)) return 1;
            return 0;
        })(t),
        s = (function (e) {
            if ("number" == typeof e.framesToPop) return e.framesToPop;
            return 0;
        })(t);
    try {
        return e(n, r, s);
    } catch {}
    return [];
}
const Go = /Minified React error #\d+;/i;
function Wo(e) {
    return (
        "undefined" != typeof WebAssembly &&
        void 0 !== WebAssembly.Exception &&
        e instanceof WebAssembly.Exception
    );
}
function Ho(e) {
    const t = e?.name;
    if (!t && Wo(e)) {
        return e.message && Array.isArray(e.message) && 2 == e.message.length
            ? e.message[0]
            : "WebAssembly.Exception";
    }
    return t;
}
function Jo(e) {
    const t = e?.message;
    return Wo(e)
        ? Array.isArray(e.message) && 2 == e.message.length
            ? e.message[1]
            : "wasm exception"
        : t
        ? t.error && "string" == typeof t.error.message
            ? t.error.message
            : t
        : "No error message";
}
function Yo(e, t, n, r, s) {
    let o;
    if (Nn(t) && t.error) {
        return qo(e, t.error);
    }
    if ($n(t) || Mn(t, "DOMException")) {
        const s = t;
        if ("stack" in t) o = qo(e, t);
        else {
            const t = s.name || ($n(s) ? "DOMError" : "DOMException"),
                i = s.message ? `${t}: ${s.message}` : t;
            (o = Xo(e, i, n, r)), fr(o, i);
        }
        return (
            "code" in s &&
                (o.tags = { ...o.tags, "DOMException.code": `${s.code}` }),
            o
        );
    }
    if (Un(t)) return qo(e, t);
    if (zn(t) || qn(t)) {
        return (o = zo(e, t, n, s)), hr(o, { synthetic: !0 }), o;
    }
    return (o = Xo(e, t, n, r)), fr(o, `${t}`), hr(o, { synthetic: !0 }), o;
}
function Xo(e, t, n, r) {
    const s = {};
    if (r && n) {
        const r = Vo(e, n);
        r.length &&
            (s.exception = {
                values: [{ value: t, stacktrace: { frames: r } }],
            }),
            hr(s, { synthetic: !0 });
    }
    if (Fn(t)) {
        const { __sentry_template_string__: e, __sentry_template_values__: n } =
            t;
        return (s.logentry = { message: e, params: n }), s;
    }
    return (s.message = t), s;
}
function Qo(e, { isUnhandledRejection: t }) {
    const n = (function (e, t = 40) {
            const n = Object.keys(ir(e));
            n.sort();
            const r = n[0];
            if (!r) return "[object has no keys]";
            if (r.length >= t) return Qn(r, t);
            for (let s = n.length; s > 0; s--) {
                const e = n.slice(0, s).join(", ");
                if (!(e.length > t)) return s === n.length ? e : Qn(e, t);
            }
            return "";
        })(e),
        r = t ? "promise rejection" : "exception";
    if (Nn(e))
        return `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\``;
    if (qn(e)) {
        return `Event \`${(function (e) {
            try {
                const t = Object.getPrototypeOf(e);
                return t ? t.constructor.name : void 0;
            } catch {}
        })(e)}\` (type=${e.type}) captured as ${r}`;
    }
    return `Object captured as ${r} with keys: ${n}`;
}
class Zo extends Ys {
    constructor(e) {
        const t =
            ((n = e),
            {
                release:
                    "string" == typeof __SENTRY_RELEASE__
                        ? __SENTRY_RELEASE__
                        : No.SENTRY_RELEASE?.id,
                sendClientReports: !0,
                parentSpanIsAlwaysRootSpan: !0,
                ...n,
            });
        var n;
        !(function (e, t, n = [t], r = "npm") {
            const s = e._metadata || {};
            s.sdk ||
                (s.sdk = {
                    name: `sentry.javascript.${t}`,
                    packages: n.map((e) => ({
                        name: `${r}:@sentry/${e}`,
                        version: an,
                    })),
                    version: an,
                }),
                (e._metadata = s);
        })(t, "browser", ["browser"], No.SENTRY_SDK_SOURCE || "npm"),
            super(t);
        const {
            sendDefaultPii: r,
            sendClientReports: s,
            enableLogs: o,
        } = this._options;
        No.document &&
            (s || o) &&
            No.document.addEventListener("visibilitychange", () => {
                "hidden" === No.document.visibilityState &&
                    (s && this._flushOutcomes(), o && Zs(this));
            }),
            o &&
                (this.on("flush", () => {
                    Zs(this);
                }),
                this.on("afterCaptureLog", () => {
                    this._logFlushIdleTimeout &&
                        clearTimeout(this._logFlushIdleTimeout),
                        (this._logFlushIdleTimeout = setTimeout(() => {
                            Zs(this);
                        }, 5e3));
                })),
            r &&
                (this.on("postprocessEvent", io),
                this.on("beforeSendSession", ao));
    }
    eventFromException(e, t) {
        return (function (e, t, n, r) {
            const s = Yo(e, t, n?.syntheticException || void 0, r);
            return (
                hr(s),
                (s.level = "error"),
                n?.event_id && (s.event_id = n.event_id),
                bs(s)
            );
        })(this._options.stackParser, e, t, this._options.attachStacktrace);
    }
    eventFromMessage(e, t = "info", n) {
        return (function (e, t, n = "info", r, s) {
            const o = Xo(e, t, r?.syntheticException || void 0, s);
            return (
                (o.level = n), r?.event_id && (o.event_id = r.event_id), bs(o)
            );
        })(this._options.stackParser, e, t, n, this._options.attachStacktrace);
    }
    _prepareEvent(e, t, n, r) {
        return (
            (e.platform = e.platform || "javascript"),
            super._prepareEvent(e, t, n, r)
        );
    }
}
const ei = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    ti = on;
let ni, ri, si, oi;
function ii() {
    if (!ti.document) return;
    const e = Tn.bind(null, "dom"),
        t = ai(e, !0);
    ti.document.addEventListener("click", t, !1),
        ti.document.addEventListener("keypress", t, !1),
        ["EventTarget", "Node"].forEach((t) => {
            const n = ti,
                r = n[t]?.prototype;
            r?.hasOwnProperty?.("addEventListener") &&
                (nr(r, "addEventListener", function (t) {
                    return function (n, r, s) {
                        if ("click" === n || "keypress" == n)
                            try {
                                const r =
                                        (this.__sentry_instrumentation_handlers__ =
                                            this
                                                .__sentry_instrumentation_handlers__ ||
                                            {}),
                                    o = (r[n] = r[n] || { refCount: 0 });
                                if (!o.handler) {
                                    const r = ai(e);
                                    (o.handler = r), t.call(this, n, r, s);
                                }
                                o.refCount++;
                            } catch {}
                        return t.call(this, n, r, s);
                    };
                }),
                nr(r, "removeEventListener", function (e) {
                    return function (t, n, r) {
                        if ("click" === t || "keypress" == t)
                            try {
                                const n =
                                        this
                                            .__sentry_instrumentation_handlers__ ||
                                        {},
                                    s = n[t];
                                s &&
                                    (s.refCount--,
                                    s.refCount <= 0 &&
                                        (e.call(this, t, s.handler, r),
                                        (s.handler = void 0),
                                        delete n[t]),
                                    0 === Object.keys(n).length &&
                                        delete this
                                            .__sentry_instrumentation_handlers__);
                            } catch {}
                        return e.call(this, t, n, r);
                    };
                }));
        });
}
function ai(e, t = !1) {
    return (n) => {
        if (!n || n._sentryCaptured) return;
        const r = (function (e) {
            try {
                return e.target;
            } catch {
                return null;
            }
        })(n);
        if (
            (function (e, t) {
                return (
                    "keypress" === e &&
                    (!t?.tagName ||
                        ("INPUT" !== t.tagName &&
                            "TEXTAREA" !== t.tagName &&
                            !t.isContentEditable))
                );
            })(n.type, r)
        )
            return;
        rr(n, "_sentryCaptured", !0),
            r && !r._sentryId && rr(r, "_sentryId", ur());
        const s = "keypress" === n.type ? "input" : n.type;
        if (
            !(function (e) {
                if (e.type !== ri) return !1;
                try {
                    if (!e.target || e.target._sentryId !== si) return !1;
                } catch {}
                return !0;
            })(n)
        ) {
            e({ event: n, name: s, global: t }),
                (ri = n.type),
                (si = r ? r._sentryId : void 0);
        }
        clearTimeout(ni),
            (ni = ti.setTimeout(() => {
                (si = void 0), (ri = void 0);
            }, 1e3));
    };
}
function ci(e) {
    const t = "history";
    Dn(t, e), Cn(t, ui);
}
function ui() {
    function e(e) {
        return function (...t) {
            const n = t.length > 2 ? t[2] : void 0;
            if (n) {
                const r = oi,
                    s = (function (e) {
                        try {
                            return new URL(e, ti.location.origin).toString();
                        } catch {
                            return e;
                        }
                    })(String(n));
                if (((oi = s), r === s)) return e.apply(this, t);
                Tn("history", { from: r, to: s });
            }
            return e.apply(this, t);
        };
    }
    ti.addEventListener("popstate", () => {
        const e = ti.location.href,
            t = oi;
        if (((oi = e), t === e)) return;
        Tn("history", { from: t, to: e });
    }),
        "history" in Po &&
            Po.history &&
            (nr(ti.history, "pushState", e), nr(ti.history, "replaceState", e));
}
const li = {};
function di(e) {
    li[e] = void 0;
}
const fi = "__sentry_xhr_v3__";
function hi() {
    if (!ti.XMLHttpRequest) return;
    const e = XMLHttpRequest.prototype;
    (e.open = new Proxy(e.open, {
        apply(e, t, n) {
            const r = new Error(),
                s = 1e3 * vr(),
                o = Kn(n[0]) ? n[0].toUpperCase() : void 0,
                i = (function (e) {
                    if (Kn(e)) return e;
                    try {
                        return e.toString();
                    } catch {}
                    return;
                })(n[1]);
            if (!o || !i) return e.apply(t, n);
            (t[fi] = { method: o, url: i, request_headers: {} }),
                "POST" === o &&
                    i.match(/sentry_key/) &&
                    (t.__sentry_own_request__ = !0);
            const a = () => {
                const e = t[fi];
                if (e && 4 === t.readyState) {
                    try {
                        e.status_code = t.status;
                    } catch {}
                    Tn("xhr", {
                        endTimestamp: 1e3 * vr(),
                        startTimestamp: s,
                        xhr: t,
                        virtualError: r,
                    });
                }
            };
            return (
                "onreadystatechange" in t &&
                "function" == typeof t.onreadystatechange
                    ? (t.onreadystatechange = new Proxy(t.onreadystatechange, {
                          apply: (e, t, n) => (a(), e.apply(t, n)),
                      }))
                    : t.addEventListener("readystatechange", a),
                (t.setRequestHeader = new Proxy(t.setRequestHeader, {
                    apply(e, t, n) {
                        const [r, s] = n,
                            o = t[fi];
                        return (
                            o &&
                                Kn(r) &&
                                Kn(s) &&
                                (o.request_headers[r.toLowerCase()] = s),
                            e.apply(t, n)
                        );
                    },
                })),
                e.apply(t, n)
            );
        },
    })),
        (e.send = new Proxy(e.send, {
            apply(e, t, n) {
                const r = t[fi];
                if (!r) return e.apply(t, n);
                void 0 !== n[0] && (r.body = n[0]);
                return (
                    Tn("xhr", { startTimestamp: 1e3 * vr(), xhr: t }),
                    e.apply(t, n)
                );
            },
        }));
}
function pi(
    e,
    t = (function (e) {
        const t = li[e];
        if (t) return t;
        let n = ti[e];
        if (Ao(n)) return (li[e] = n.bind(ti));
        const r = ti.document;
        if (r && "function" == typeof r.createElement)
            try {
                const t = r.createElement("iframe");
                (t.hidden = !0), r.head.appendChild(t);
                const s = t.contentWindow;
                s?.[e] && (n = s[e]), r.head.removeChild(t);
            } catch (s) {
                ei &&
                    vn.warn(
                        `Could not create sandbox iframe for ${e} check, bailing to window.${e}: `,
                        s
                    );
            }
        return n ? (li[e] = n.bind(ti)) : n;
    })("fetch")
) {
    let n = 0,
        r = 0;
    return oo(e, function (s) {
        const o = s.body.length;
        (n += o), r++;
        const i = {
            body: s.body,
            method: "POST",
            referrerPolicy: "strict-origin",
            headers: e.headers,
            keepalive: n <= 6e4 && r < 15,
            ...e.fetchOptions,
        };
        if (!t) return di("fetch"), Es("No fetch implementation available");
        try {
            return t(e.url, i).then(
                (e) => (
                    (n -= o),
                    r--,
                    {
                        statusCode: e.status,
                        headers: {
                            "x-sentry-rate-limits": e.headers.get(
                                "X-Sentry-Rate-Limits"
                            ),
                            "retry-after": e.headers.get("Retry-After"),
                        },
                    }
                )
            );
        } catch (a) {
            return di("fetch"), (n -= o), r--, Es(a);
        }
    });
}
function _i(e, t, n, r) {
    const s = {
        filename: e,
        function: "<anonymous>" === t ? mn : t,
        in_app: !0,
    };
    return void 0 !== n && (s.lineno = n), void 0 !== r && (s.colno = r), s;
}
const gi = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
    vi =
        /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
    mi = /\((\S*)(?::(\d+))(?::(\d+))\)/,
    yi =
        /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
    bi = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
    Ei = En(
        ...[
            [
                30,
                (e) => {
                    const t = gi.exec(e);
                    if (t) {
                        const [, e, n, r] = t;
                        return _i(e, mn, +n, +r);
                    }
                    const n = vi.exec(e);
                    if (n) {
                        if (n[2] && 0 === n[2].indexOf("eval")) {
                            const e = mi.exec(n[2]);
                            e && ((n[2] = e[1]), (n[3] = e[2]), (n[4] = e[3]));
                        }
                        const [e, t] = Si(n[1] || mn, n[2]);
                        return _i(
                            t,
                            e,
                            n[3] ? +n[3] : void 0,
                            n[4] ? +n[4] : void 0
                        );
                    }
                },
            ],
            [
                50,
                (e) => {
                    const t = yi.exec(e);
                    if (t) {
                        if (t[3] && t[3].indexOf(" > eval") > -1) {
                            const e = bi.exec(t[3]);
                            e &&
                                ((t[1] = t[1] || "eval"),
                                (t[3] = e[1]),
                                (t[4] = e[2]),
                                (t[5] = ""));
                        }
                        let e = t[3],
                            n = t[1] || mn;
                        return (
                            ([n, e] = Si(n, e)),
                            _i(
                                e,
                                n,
                                t[4] ? +t[4] : void 0,
                                t[5] ? +t[5] : void 0
                            )
                        );
                    }
                },
            ],
        ]
    ),
    Si = (e, t) => {
        const n = -1 !== e.indexOf("safari-extension"),
            r = -1 !== e.indexOf("safari-web-extension");
        return n || r
            ? [
                  -1 !== e.indexOf("@") ? e.split("@")[0] : mn,
                  n ? `safari-extension:${t}` : `safari-web-extension:${t}`,
              ]
            : [e, t];
    },
    ki = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
    wi = 1024,
    xi = (e = {}) => {
        const t = {
            console: !0,
            dom: !0,
            fetch: !0,
            history: !0,
            sentry: !0,
            xhr: !0,
            ...e,
        };
        return {
            name: "Breadcrumbs",
            setup(e) {
                var n;
                t.console &&
                    (function (e) {
                        const t = "console";
                        Dn(t, e), Cn(t, ko);
                    })(
                        (function (e) {
                            return function (t) {
                                if (Lr() !== e) return;
                                const n = {
                                    category: "console",
                                    data: {
                                        arguments: t.args,
                                        logger: "console",
                                    },
                                    level: wo(t.level),
                                    message: Zn(t.args, " "),
                                };
                                if ("assert" === t.level) {
                                    if (!1 !== t.args[0]) return;
                                    (n.message = `Assertion failed: ${
                                        Zn(t.args.slice(1), " ") ||
                                        "console.assert"
                                    }`),
                                        (n.data.arguments = t.args.slice(1));
                                }
                                uo(n, { input: t.args, level: t.level });
                            };
                        })(e)
                    ),
                    t.dom &&
                        ((n = (function (e, t) {
                            return function (n) {
                                if (Lr() !== e) return;
                                let r,
                                    s,
                                    o =
                                        "object" == typeof t
                                            ? t.serializeAttribute
                                            : void 0,
                                    i =
                                        "object" == typeof t &&
                                        "number" == typeof t.maxStringLength
                                            ? t.maxStringLength
                                            : void 0;
                                i &&
                                    i > wi &&
                                    (ki &&
                                        vn.warn(
                                            `\`dom.maxStringLength\` cannot exceed 1024, but a value of ${i} was configured. Sentry will use 1024 instead.`
                                        ),
                                    (i = wi)),
                                    "string" == typeof o && (o = [o]);
                                try {
                                    const e = n.event,
                                        t = (function (e) {
                                            return !!e && !!e.target;
                                        })(e)
                                            ? e.target
                                            : e;
                                    (r = Jn(t, {
                                        keyAttrs: o,
                                        maxStringLength: i,
                                    })),
                                        (s = (function (e) {
                                            if (!Hn.HTMLElement) return null;
                                            let t = e;
                                            for (let n = 0; n < 5; n++) {
                                                if (!t) return null;
                                                if (t instanceof HTMLElement) {
                                                    if (
                                                        t.dataset
                                                            .sentryComponent
                                                    )
                                                        return t.dataset
                                                            .sentryComponent;
                                                    if (t.dataset.sentryElement)
                                                        return t.dataset
                                                            .sentryElement;
                                                }
                                                t = t.parentNode;
                                            }
                                            return null;
                                        })(t));
                                } catch {
                                    r = "<unknown>";
                                }
                                if (0 === r.length) return;
                                const a = {
                                    category: `ui.${n.name}`,
                                    message: r,
                                };
                                s && (a.data = { "ui.component_name": s }),
                                    uo(a, {
                                        event: n.event,
                                        name: n.name,
                                        global: n.global,
                                    });
                            };
                        })(e, t.dom)),
                        Dn("dom", n),
                        Cn("dom", ii)),
                    t.xhr &&
                        (function (e) {
                            Dn("xhr", e), Cn("xhr", hi);
                        })(
                            (function (e) {
                                return function (t) {
                                    if (Lr() !== e) return;
                                    const {
                                            startTimestamp: n,
                                            endTimestamp: r,
                                        } = t,
                                        s = t.xhr[fi];
                                    if (!n || !r || !s) return;
                                    const {
                                            method: o,
                                            url: i,
                                            status_code: a,
                                            body: c,
                                        } = s,
                                        u = {
                                            method: o,
                                            url: i,
                                            status_code: a,
                                        },
                                        l = {
                                            xhr: t.xhr,
                                            input: c,
                                            startTimestamp: n,
                                            endTimestamp: r,
                                        },
                                        d = {
                                            category: "xhr",
                                            data: u,
                                            type: "http",
                                            level: To(a),
                                        };
                                    e.emit(
                                        "beforeOutgoingRequestBreadcrumb",
                                        d,
                                        l
                                    ),
                                        uo(d, l);
                                };
                            })(e)
                        ),
                    t.fetch &&
                        Ro(
                            (function (e) {
                                return function (t) {
                                    if (Lr() !== e) return;
                                    const {
                                        startTimestamp: n,
                                        endTimestamp: r,
                                    } = t;
                                    if (
                                        r &&
                                        (!t.fetchData.url.match(/sentry_key/) ||
                                            "POST" !== t.fetchData.method)
                                    )
                                        if (
                                            (t.fetchData.method,
                                            t.fetchData.url,
                                            t.error)
                                        ) {
                                            const s = t.fetchData,
                                                o = {
                                                    data: t.error,
                                                    input: t.args,
                                                    startTimestamp: n,
                                                    endTimestamp: r,
                                                },
                                                i = {
                                                    category: "fetch",
                                                    data: s,
                                                    level: "error",
                                                    type: "http",
                                                };
                                            e.emit(
                                                "beforeOutgoingRequestBreadcrumb",
                                                i,
                                                o
                                            ),
                                                uo(i, o);
                                        } else {
                                            const s = t.response,
                                                o = {
                                                    ...t.fetchData,
                                                    status_code: s?.status,
                                                };
                                            t.fetchData.request_body_size,
                                                t.fetchData.response_body_size;
                                            const i = {
                                                    input: t.args,
                                                    response: s,
                                                    startTimestamp: n,
                                                    endTimestamp: r,
                                                },
                                                a = {
                                                    category: "fetch",
                                                    data: o,
                                                    type: "http",
                                                    level: To(o.status_code),
                                                };
                                            e.emit(
                                                "beforeOutgoingRequestBreadcrumb",
                                                a,
                                                i
                                            ),
                                                uo(a, i);
                                        }
                                };
                            })(e)
                        ),
                    t.history &&
                        ci(
                            (function (e) {
                                return function (t) {
                                    if (Lr() !== e) return;
                                    let n = t.from,
                                        r = t.to;
                                    const s = Co(No.location.href);
                                    let o = n ? Co(n) : void 0;
                                    const i = Co(r);
                                    o?.path || (o = s),
                                        s.protocol === i.protocol &&
                                            s.host === i.host &&
                                            (r = i.relative),
                                        s.protocol === o.protocol &&
                                            s.host === o.host &&
                                            (n = o.relative),
                                        uo({
                                            category: "navigation",
                                            data: { from: n, to: r },
                                        });
                                };
                            })(e)
                        ),
                    t.sentry &&
                        e.on(
                            "beforeSendEvent",
                            (function (e) {
                                return function (t) {
                                    Lr() === e &&
                                        uo(
                                            {
                                                category:
                                                    "sentry." +
                                                    ("transaction" === t.type
                                                        ? "transaction"
                                                        : "event"),
                                                event_id: t.event_id,
                                                level: t.level,
                                                message: dr(t),
                                            },
                                            { event: t }
                                        );
                                };
                            })(e)
                        );
            },
        };
    };
const Oi = [
        "EventTarget",
        "Window",
        "Node",
        "ApplicationCache",
        "AudioTrackList",
        "BroadcastChannel",
        "ChannelMergerNode",
        "CryptoOperation",
        "EventSource",
        "FileReader",
        "HTMLUnknownElement",
        "IDBDatabase",
        "IDBRequest",
        "IDBTransaction",
        "KeyOperation",
        "MediaController",
        "MessagePort",
        "ModalWindow",
        "Notification",
        "SVGElementInstance",
        "Screen",
        "SharedWorker",
        "TextTrack",
        "TextTrackCue",
        "TextTrackList",
        "WebSocket",
        "WebSocketWorker",
        "Worker",
        "XMLHttpRequest",
        "XMLHttpRequestEventTarget",
        "XMLHttpRequestUpload",
    ],
    Ii = (e = {}) => {
        const t = {
            XMLHttpRequest: !0,
            eventTarget: !0,
            requestAnimationFrame: !0,
            setInterval: !0,
            setTimeout: !0,
            unregisterOriginalCallbacks: !1,
            ...e,
        };
        return {
            name: "BrowserApiErrors",
            setupOnce() {
                t.setTimeout && nr(No, "setTimeout", Di),
                    t.setInterval && nr(No, "setInterval", Di),
                    t.requestAnimationFrame &&
                        nr(No, "requestAnimationFrame", Ci),
                    t.XMLHttpRequest &&
                        "XMLHttpRequest" in No &&
                        nr(XMLHttpRequest.prototype, "send", Ti);
                const e = t.eventTarget;
                if (e) {
                    (Array.isArray(e) ? e : Oi).forEach((e) =>
                        (function (e, t) {
                            const n = No,
                                r = n[e]?.prototype;
                            if (!r?.hasOwnProperty?.("addEventListener"))
                                return;
                            nr(r, "addEventListener", function (n) {
                                return function (r, s, o) {
                                    try {
                                        "function" == typeof s.handleEvent &&
                                            (s.handleEvent = Fo(s.handleEvent, {
                                                mechanism: {
                                                    data: {
                                                        function: "handleEvent",
                                                        handler: wn(s),
                                                        target: e,
                                                    },
                                                    handled: !1,
                                                    type: "instrument",
                                                },
                                            }));
                                    } catch {}
                                    return (
                                        t.unregisterOriginalCallbacks &&
                                            (function (e, t, n) {
                                                e &&
                                                    "object" == typeof e &&
                                                    "removeEventListener" in
                                                        e &&
                                                    "function" ==
                                                        typeof e.removeEventListener &&
                                                    e.removeEventListener(t, n);
                                            })(this, r, s),
                                        n.apply(this, [
                                            r,
                                            Fo(s, {
                                                mechanism: {
                                                    data: {
                                                        function:
                                                            "addEventListener",
                                                        handler: wn(s),
                                                        target: e,
                                                    },
                                                    handled: !1,
                                                    type: "instrument",
                                                },
                                            }),
                                            o,
                                        ])
                                    );
                                };
                            }),
                                nr(r, "removeEventListener", function (e) {
                                    return function (t, n, r) {
                                        try {
                                            const s = n.__sentry_wrapped__;
                                            s && e.call(this, t, s, r);
                                        } catch {}
                                        return e.call(this, t, n, r);
                                    };
                                });
                        })(e, t)
                    );
                }
            },
        };
    };
function Di(e) {
    return function (...t) {
        const n = t[0];
        return (
            (t[0] = Fo(n, {
                mechanism: {
                    data: { function: wn(e) },
                    handled: !1,
                    type: "instrument",
                },
            })),
            e.apply(this, t)
        );
    };
}
function Ci(e) {
    return function (t) {
        return e.apply(this, [
            Fo(t, {
                mechanism: {
                    data: { function: "requestAnimationFrame", handler: wn(e) },
                    handled: !1,
                    type: "instrument",
                },
            }),
        ]);
    };
}
function Ti(e) {
    return function (...t) {
        const n = this;
        return (
            ["onload", "onerror", "onprogress", "onreadystatechange"].forEach(
                (e) => {
                    e in n &&
                        "function" == typeof n[e] &&
                        nr(n, e, function (t) {
                            const n = {
                                    mechanism: {
                                        data: { function: e, handler: wn(t) },
                                        handled: !1,
                                        type: "instrument",
                                    },
                                },
                                r = or(t);
                            return (
                                r && (n.mechanism.data.handler = wn(r)),
                                Fo(t, n)
                            );
                        });
                }
            ),
            e.apply(this, t)
        );
    };
}
const Pi = () => ({
        name: "BrowserSession",
        setupOnce() {
            void 0 !== No.document
                ? (As({ ignoreDuration: !0 }),
                  Ls(),
                  ci(({ from: e, to: t }) => {
                      void 0 !== e &&
                          e !== t &&
                          (As({ ignoreDuration: !0 }), Ls());
                  }))
                : ki &&
                  vn.warn(
                      "Using the `browserSessionIntegration` in non-browser environments is not supported."
                  );
        },
    }),
    Ai = (e = {}) => {
        const t = { onerror: !0, onunhandledrejection: !0, ...e };
        return {
            name: "GlobalHandlers",
            setupOnce() {
                Error.stackTraceLimit = 50;
            },
            setup(e) {
                t.onerror &&
                    (!(function (e) {
                        !(function (e) {
                            const t = "error";
                            Dn(t, e), Cn(t, An);
                        })((t) => {
                            const { stackParser: n, attachStacktrace: r } =
                                Ri();
                            if (Lr() !== e || Ko()) return;
                            const {
                                    msg: s,
                                    url: o,
                                    line: i,
                                    column: a,
                                    error: c,
                                } = t,
                                u = (function (e, t, n, r) {
                                    const s = (e.exception = e.exception || {}),
                                        o = (s.values = s.values || []),
                                        i = (o[0] = o[0] || {}),
                                        a = (i.stacktrace = i.stacktrace || {}),
                                        c = (a.frames = a.frames || []),
                                        u = r,
                                        l = n,
                                        d = Kn(t) && t.length > 0 ? t : Xn();
                                    0 === c.length &&
                                        c.push({
                                            colno: u,
                                            filename: d,
                                            function: mn,
                                            in_app: !0,
                                            lineno: l,
                                        });
                                    return e;
                                })(Yo(n, c || s, void 0, r, !1), o, i, a);
                            (u.level = "error"),
                                Ps(u, {
                                    originalException: c,
                                    mechanism: { handled: !1, type: "onerror" },
                                });
                        });
                    })(e),
                    ji("onerror")),
                    t.onunhandledrejection &&
                        (!(function (e) {
                            !(function (e) {
                                const t = "unhandledrejection";
                                Dn(t, e), Cn(t, Rn);
                            })((t) => {
                                const { stackParser: n, attachStacktrace: r } =
                                    Ri();
                                if (Lr() !== e || Ko()) return;
                                const s = (function (e) {
                                        if (Bn(e)) return e;
                                        try {
                                            if ("reason" in e) return e.reason;
                                            if (
                                                "detail" in e &&
                                                "reason" in e.detail
                                            )
                                                return e.detail.reason;
                                        } catch {}
                                        return e;
                                    })(t),
                                    o = Bn(s)
                                        ? {
                                              exception: {
                                                  values: [
                                                      {
                                                          type: "UnhandledRejection",
                                                          value: `Non-Error promise rejection captured with value: ${String(
                                                              s
                                                          )}`,
                                                      },
                                                  ],
                                              },
                                          }
                                        : Yo(n, s, void 0, r, !0);
                                (o.level = "error"),
                                    Ps(o, {
                                        originalException: s,
                                        mechanism: {
                                            handled: !1,
                                            type: "onunhandledrejection",
                                        },
                                    });
                            });
                        })(e),
                        ji("onunhandledrejection"));
            },
        };
    };
function ji(e) {
    ki && vn.log(`Global Handler attached: ${e}`);
}
function Ri() {
    const e = Lr();
    return e?.getOptions() || { stackParser: () => [], attachStacktrace: !1 };
}
const Li = () => ({
        name: "HttpContext",
        preprocessEvent(e) {
            if (!No.navigator && !No.location && !No.document) return;
            const t = (function () {
                    const e = Xn(),
                        { referrer: t } = No.document || {},
                        { userAgent: n } = No.navigator || {};
                    return {
                        url: e,
                        headers: {
                            ...(t && { Referer: t }),
                            ...(n && { "User-Agent": n }),
                        },
                    };
                })(),
                n = { ...t.headers, ...e.request?.headers };
            e.request = { ...t, ...e.request, headers: n };
        },
    }),
    Ui = (e = {}) => {
        const t = e.limit || 5,
            n = e.key || "cause";
        return {
            name: "LinkedErrors",
            preprocessEvent(e, r, s) {
                yo(Bo, s.getOptions().stackParser, n, t, e, r);
            },
        };
    };
function Mi() {
    return (
        !!(function () {
            if (void 0 === No.window) return !1;
            const e = No;
            if (e.nw) return !1;
            const t = e.chrome || e.browser;
            if (!t?.runtime?.id) return !1;
            const n = Xn(),
                r = [
                    "chrome-extension",
                    "moz-extension",
                    "ms-browser-extension",
                    "safari-web-extension",
                ];
            return !(No === No.top && r.some((e) => n.startsWith(`${e}://`)));
        })() && (ki && hn(() => {}), !0)
    );
}
function Ni(e) {
    return [go(), ho(), Ii(), xi(), Ai(), Ui(), xo(), Li(), Pi()];
}
const $i = () => {
    const e = Ni().filter(
        (e) =>
            !["BrowserApiErrors", "Breadcrumbs", "GlobalHandlers"].includes(
                e.name
            )
    );
    !(function (e = {}) {
        const t = !e.skipBrowserExtensionCheck && Mi(),
            n = {
                ...e,
                enabled: !t && e.enabled,
                stackParser:
                    ((r = e.stackParser || Ei),
                    Array.isArray(r) ? En(...r) : r),
                integrations: Ns({
                    integrations: e.integrations,
                    defaultIntegrations:
                        null == e.defaultIntegrations
                            ? Ni()
                            : e.defaultIntegrations,
                }),
                transport: e.transport || pi,
            };
        var r;
        to(Zo, n);
    })({
        dsn: "https://60bea3ee4ef1022e4035b23ba50f44d0@o1158394.ingest.us.sentry.io/4509876992278529",
        transport: pi,
        stackParser: Ei,
        integrations: e,
        beforeSend: (e) => (
            (e.contexts = {
                ...e.contexts,
                extension: {
                    id: chrome.runtime.id,
                    version: chrome.runtime.getManifest().version,
                    environment: "production",
                },
            }),
            e
        ),
    });
};
export {
    r as S,
    p as a,
    s as b,
    t as c,
    a as d,
    e,
    rn_onInstall as f,
    en as g,
    Zt as h,
    $i as i,
    Jt as j,
    nn as k,
    tn as l,
    n as m,
    o as s,
};
