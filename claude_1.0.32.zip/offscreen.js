// Offscreen document for playing notification sounds
// This runs in a hidden document context that can play audio

console.log("[Offscreen] Document loaded and ready");

// Initialize AudioContext immediately
const AudioCtx = window.AudioContext || window.webkitAudioContext;
const audioContext = new AudioCtx();
console.log("[Offscreen] AudioContext created, state:", audioContext.state);

// Play audio using Web Audio API (bypasses autoplay restrictions better)
async function playAudioWithWebAudioAPI(audioUrl, volume) {
  try {
    console.log("[Offscreen] Fetching audio file:", audioUrl);

    // Fetch the audio file
    const response = await fetch(audioUrl);
    const arrayBuffer = await response.arrayBuffer();

    console.log("[Offscreen] Audio file fetched, decoding...");

    // Decode the audio data
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

    console.log("[Offscreen] Audio decoded, creating source...");

    // Create buffer source
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;

    // Create gain node for volume control
    const gainNode = audioContext.createGain();
    gainNode.gain.value = volume;

    // Connect nodes
    source.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Resume audio context if needed
    if (audioContext.state === "suspended") {
      console.log("[Offscreen] Resuming AudioContext...");
      await audioContext.resume();
    }

    console.log("[Offscreen] Starting playback...");
    source.start(0);

    return new Promise((resolve, reject) => {
      source.onended = () => {
        console.log("[Offscreen] Playback finished");
        resolve();
      };
      source.onerror = (error) => {
        console.error("[Offscreen] Source error:", error);
        reject(error);
      };
    });
  } catch (error) {
    console.error("[Offscreen] Web Audio API error:", error);
    throw error;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PLAY_NOTIFICATION_SOUND") {
    console.log("[Offscreen] Received PLAY_NOTIFICATION_SOUND message");
    console.log("[Offscreen] AudioContext state:", audioContext.state);

    const volume = message.volume || 0.5;

    playAudioWithWebAudioAPI(message.audioUrl, volume)
      .then(() => {
        console.log("[Offscreen] Sound played successfully via Web Audio API");
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("[Offscreen] Failed to play sound:", error);
        sendResponse({ success: false, error: error.message });
      });

    // Return true to indicate async response
    return true;
  }
});
